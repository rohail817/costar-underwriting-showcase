(function () {
  "use strict";

  function blockNetworkSurface() {
    const blocked = function () { throw new Error("External network access is disabled in this local application."); };
    try { window.fetch = blocked; } catch (_) { /* browser policy may prevent replacement */ }
    try { window.XMLHttpRequest = function () { throw new Error("External network access is disabled."); }; } catch (_) { /* no-op */ }
    try { window.WebSocket = function () { throw new Error("External network access is disabled."); }; } catch (_) { /* no-op */ }
    try { window.EventSource = function () { throw new Error("External network access is disabled."); }; } catch (_) { /* no-op */ }
    try { navigator.sendBeacon = blocked; } catch (_) { /* no-op */ }
  }
  blockNetworkSurface();

  const clone = (value) => JSON.parse(JSON.stringify(value));
  let state = clone(window.HBF_DEMO);
  state.mode = state.mode || "demo";
  state.importedPacketIds = Array.isArray(state.importedPacketIds) ? state.importedPacketIds : [];
  state.entities = Array.isArray(state.entities) && state.entities.length
    ? state.entities
    : [
        { name: state.deal?.borrower || "", role: "Borrower" },
        ...(state.deal?.relationship && state.deal.relationship !== state.deal.borrower ? [{ name: state.deal.relationship, role: "Relationship" }] : [])
      ].filter((item) => item.name);
  state.workflow = state.workflow || (state.deal?.dealType === "Quarterly Monitor" ? "portfolio_monitor" : "credit_action");
  state.workbookScope = Array.isArray(state.workbookScope)
    ? Array.from(new Set(["relationship", ...state.workbookScope]))
    : (state.mode === "demo"
        ? (window.HBF_CreditPath?.WORKBOOK_SCOPE_DEFINITIONS || []).map((item) => item.id)
        : (window.HBF_CreditPath?.defaultWorkbookScope(state.deal?.dealType, state.deal?.facilityType) || ["relationship"]));
  state.workbookTabs = Array.isArray(state.workbookTabs)
    ? window.HBF_CreditPath?.selectedWorkbookTabs({ ...state, workbookTabs: state.workbookTabs }) || state.workbookTabs
    : state.mode === "demo"
      ? (window.HBF_CreditPath?.WORKBOOK_SCOPE_DEFINITIONS || []).flatMap((item) => item.sheets)
      : window.HBF_CreditPath?.defaultWorkbookTabs(state.deal?.dealType, state.deal?.facilityType) || ["Exposure"];
  state.workbookScope = (window.HBF_CreditPath?.workbookScopePlan(state) || []).filter((item) => item.selected).map((item) => item.id);
  state.workbookScopeConfirmed = state.mode === "demo" || state.workbookScopeConfirmed === true;
  state.additionalDocumentIds = Array.isArray(state.additionalDocumentIds) ? Array.from(new Set(state.additionalDocumentIds)) : [];
  state.monitor = state.monitor && typeof state.monitor === "object" ? state.monitor : null;
  state.contentRevision = Number.isSafeInteger(state.contentRevision) ? state.contentRevision : 0;
  state.attestationMetadata = state.attestationMetadata && typeof state.attestationMetadata === "object" ? state.attestationMetadata : {};
  let activeView = "brief";
  let issueFilter = "all";
  let editingSectionId = null;
  let pendingConflictSelection = {};
  let sessionDirty = false;
  let landingMode = true;
  let activeStage = "add";
  let issueDrawerOpen = false;
  let authoringController = null;
  let mountedAuthoring = null;
  let authoringExportBusy = false;

  const viewNames = {
    draft: "Document",
    brief: "Decision brief",
    monitor: "Portfolio monitor",
    workbench: "Underwriting",
    downside: "Downside lab",
    risks: "Risks & conditions",
    sources: "Documents & facts",
    reconcile: "Resolve conflicts",
    opus: "Opus workflow",
    memo: "Memo studio",
    gate: "Ready for review",
    export: "Export package"
  };

  const ACCEPTED_FACT_STATUSES = new Set(["supported", "accepted"]);
  const STRESS_INPUT_PATHS = [
    "facility.proposedCommitment", "facility.outstanding", "facility.projectedPeak", "facility.proposedMaturity",
    "collateral.asCompleteValue", "project.totalCost", "project.remainingCosts", "project.modeledEligibleFutureAdvances",
    "project.committedEquity", "project.remainingContingencyAndInterest", "operating.planAbsorption",
    "operating.netPaydownPerClosing", "guarantor.availableLiquidityAfterCalls"
  ];
  const STRESS_CALCULATION_IDS = new Set(["CALC02", "CALC03", "CALC04", "CALC06", "CALC07", "CALC09", "CALC10", "CALC11", "CALC12"]);
  const SELECTED_STRESS_PRESET = { priceDecline: 10, absorptionSlowdown: 30, costOverrun: 8, rateShock: 150, cancellationIncrease: 6 };
  const OPUS_FIELD_RULES = window.HBF_OPUS_FIELD_RULES || Object.freeze({
    "borrower.legalName": ["text", "as_of"],
    "relationship.name": ["text", "as_of"],
    "credit.currentRiskRating": ["text", "as_of"],
    "credit.recommendedRiskRating": ["text", "as_of"],
    "credit.borrowerTier": ["text", "as_of"],
    "facility.currentCommitment": ["USD", "as_of"],
    "facility.grossCommitment": ["USD", "as_of"],
    "facility.netCommitment": ["USD", "as_of"],
    "facility.bankGroupCommitment": ["USD", "as_of"],
    "facility.holdPercentage": ["percent", "as_of"],
    "facility.proposedCommitment": ["USD", "projected"],
    "facility.outstanding": ["USD", "as_of"],
    "facility.projectedPeak": ["USD", "projected"],
    "facility.currentMaturity": ["date", "as_of"],
    "facility.proposedMaturity": ["date", "projected"],
    "facility.currentPricing": ["text", "as_of"],
    "facility.proposedPricing": ["text", "projected"],
    "relationship.proFormaExposure": ["USD", "projected"],
    "relationship.outstanding": ["USD", "monthly"],
    "relationship.averageDeposits": ["USD", "monthly"],
    "collateral.asCompleteValue": ["USD", "as_of"],
    "collateral.currentBorrowingBaseAvailability": ["USD", "as_of"],
    "project.totalCost": ["USD", "as_of"],
    "project.remainingCosts": ["USD", "as_of"],
    "project.modeledEligibleFutureAdvances": ["USD", "projected"],
    "project.committedEquity": ["USD", "projected"],
    "project.remainingContingencyAndInterest": ["USD", "projected"],
    "operating.planAbsorption": ["units", "projected"],
    "operating.netPaydownPerClosing": ["USD", "projected"],
    "operating.ttmClosings": ["units", "ttm"],
    "operating.netSales": ["units", "ttm"],
    "operating.cancellationRate": ["percent", "ttm"],
    "operating.actualAbsorption": ["units", "ttm"],
    "operating.priorTtmClosings": ["units", "ttm"],
    "operating.netSalesMonthly": ["units", "monthly"],
    "operating.closingsMonthly": ["units", "monthly"],
    "operating.cancellationRateMonthly": ["percent", "monthly"],
    "operating.netSalesQuarter": ["units", "quarterly"],
    "operating.closingsQuarter": ["units", "quarterly"],
    "operating.netSalesYtd": ["units", "ytd"],
    "operating.closingsYtd": ["units", "ytd"],
    "inventory.soldUnderConstruction": ["units", "as_of"],
    "inventory.soldCompleted": ["units", "as_of"],
    "inventory.backlog": ["units", "as_of"],
    "inventory.specUnderConstruction": ["units", "as_of"],
    "inventory.specCompleted": ["units", "as_of"],
    "inventory.models": ["units", "as_of"],
    "inventory.totalUnits": ["units", "as_of"],
    "inventory.totalUnitsWithBacklog": ["units", "as_of"],
    "inventory.lotsOwnedControlled": ["units", "as_of"],
    "financial.revenueTtm": ["USD", "ttm"],
    "financial.grossProfitTtm": ["USD", "ttm"],
    "financial.operatingExpensesTtm": ["USD", "ttm"],
    "financial.netIncomeTtm": ["USD", "ttm"],
    "financial.interestExpenseTtm": ["USD", "ttm"],
    "financial.revenueQuarter": ["USD", "quarterly"],
    "financial.grossProfitQuarter": ["USD", "quarterly"],
    "financial.operatingExpensesQuarter": ["USD", "quarterly"],
    "financial.netIncomeQuarter": ["USD", "quarterly"],
    "financial.revenueYtd": ["USD", "ytd"],
    "financial.grossProfitYtd": ["USD", "ytd"],
    "financial.operatingExpensesYtd": ["USD", "ytd"],
    "financial.netIncomeYtd": ["USD", "ytd"],
    "financial.ebitdaTtm": ["USD", "ttm"],
    "financial.tangibleNetWorth": ["USD", "as_of"],
    "financial.liquidity": ["USD", "as_of"],
    "financial.leverage": ["multiple", "as_of"],
    "financial.fccr": ["multiple", "ttm"],
    "financial.cash": ["USD", "as_of"],
    "financial.currentAssets": ["USD", "as_of"],
    "financial.totalAssets": ["USD", "as_of"],
    "financial.currentLiabilities": ["USD", "as_of"],
    "financial.totalLiabilities": ["USD", "as_of"],
    "financial.netWorth": ["USD", "as_of"],
    "financial.intangibles": ["USD", "as_of"],
    "financial.deferredTaxAssets": ["USD", "as_of"],
    "financial.subordinatedDebt": ["USD", "as_of"],
    "financial.notesPayable": ["USD", "as_of"],
    "financial.reportedTangibleNetWorth": ["USD", "as_of"],
    "financial.calculatedTangibleNetWorth": ["USD", "as_of"],
    "financial.riskAssets": ["USD", "as_of"],
    "financial.permittedInvestments": ["USD", "as_of"],
    "financial.maintenanceLeverageRatio": ["percent", "as_of"],
    "financial.interestCoverageTtm": ["multiple", "ttm"],
    "facility.availableToDraw": ["USD", "as_of"],
    "facility.lettersOfCredit": ["USD", "as_of"],
    "facility.deferredPurchasePrice": ["USD", "as_of"],
    "guarantor.reportedLiquidity": ["USD", "as_of"],
    "guarantor.adjustedLiquidity": ["USD", "as_of"],
    "guarantor.identifiedCalls": ["USD", "as_of"],
    "guarantor.availableLiquidityAfterCalls": ["USD", "as_of"],
    "market.monthsSupply": ["months", "as_of"]
  });
  const NONNEGATIVE_OPUS_FIELDS = new Set([
    "facility.currentCommitment", "facility.proposedCommitment", "facility.outstanding", "facility.projectedPeak",
    "relationship.proFormaExposure", "collateral.asCompleteValue", "project.totalCost", "project.remainingCosts",
    "project.modeledEligibleFutureAdvances", "project.committedEquity", "project.remainingContingencyAndInterest",
    "operating.planAbsorption", "operating.ttmClosings", "operating.netSales", "financial.revenueTtm", "financial.liquidity",
    "guarantor.reportedLiquidity", "guarantor.adjustedLiquidity", "guarantor.identifiedCalls", "market.monthsSupply"
  ]);
  const MEMO_BLUEPRINT = [
    ["executive", "1. Executive decision summary"],
    ["request", "2. Request and transaction structure"],
    ["relationship", "3. Relationship and global exposure"],
    ["repayment", "4. Sources of repayment"],
    ["financial", "5. Financial performance and repayment capacity"],
    ["performance", "6. Sales, closings and inventory"],
    ["project", "7. Project feasibility and completion"],
    ["collateral", "8. Collateral and borrowing base"],
    ["downside", "9. Downside and break-even analysis"],
    ["market", "10. Market validation"],
    ["guarantor", "11. Guarantor and global support"],
    ["covenants", "12. Covenants and monitoring"],
    ["rating", "13. Risk rating rationale"],
    ["exceptions", "14. Policy and regulatory determinations"],
    ["risks", "15. Principal risks, mitigants and residual risk"],
    ["conditions", "16. Conditions and ongoing monitoring"],
    ["conclusion", "17. Recommendation and residual risk acceptance"]
  ];
  const APPLICABILITY_CATALOG = [
    ["terms", "Request, purpose and complete loan terms", "core"],
    ["exposure", "Borrower, related interests and total bank exposure", "core"],
    ["repayment", "Primary, secondary and tertiary repayment", "core"],
    ["financials", "Borrower/global financial capacity and trends", "core"],
    ["collateral", "Collateral, borrowing base and release controls", "core"],
    ["covenants", "Covenants, reporting and monitoring", "core"],
    ["guarantees", "Guarantees and support capacity", "core"],
    ["downside", "Downside, refinance and maturity analysis", "core"],
    ["rating", "Risk rating rationale and contrary evidence", "core"],
    ["conditions", "Risks, conditions and required attachments", "core"],
    ["cra", "CRA determination", "conditional"],
    ["reg_h", "Regulation H / insider-related determination", "conditional"],
    ["hmda", "HMDA determination", "conditional"],
    ["hvcre", "HVCRE preliminary treatment and capital review", "conditional"],
    ["leveraged", "Leveraged / high-risk C&I determination", "conditional"],
    ["ecp", "Eligible contract participant determination", "conditional"],
    ["appraisal", "Appraisal / evaluation status and independent review", "conditional"],
    ["environmental", "Environmental and flood diligence", "conditional"],
    ["modification", "Modification, financial difficulty and accounting review", "conditional"],
    ["exceptions", "Policy exceptions and approval authority", "conditional"]
  ];
  function normalizeApplicability(items) {
    const list = Array.isArray(items) ? items : [];
    const aliases = { terms: "APP-CORE", exposure: "APP-CORE", repayment: "APP-CORE", financials: "APP-CORE", collateral: "APP-CORE", covenants: "APP-CORE", guarantees: "APP-CORE", downside: "APP-CORE", rating: "APP-CORE", conditions: "APP-CORE", cra: "APP-CRA", reg_h: "APP-REGH", hmda: "APP-HMDA", hvcre: "APP-HVCRE", leveraged: "APP-LEVERAGED", ecp: "APP-ECP", appraisal: "APP-APPRAISAL", environmental: "APP-ENV-FLOOD", modification: "APP-MOD-ACCOUNTING", exceptions: "APP-POLICY" };
    return APPLICABILITY_CATALOG.map(([id, label, kind]) => {
      const match = list.find((item) => item.id === id || item.id === aliases[id]);
      return { id, label, kind, status: match?.status || "pending", basis: match?.basis || "", requiredAction: match?.requiredAction || match?.required_action || "" };
    });
  }
  state.applicability = normalizeApplicability(state.applicability);

  function esc(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function money(value, decimals) {
    if (value == null || value === "") return "—";
    const number = Number(value);
    if (!Number.isFinite(number)) return "—";
    const absolute = Math.abs(number);
    const digits = decimals == null ? (absolute >= 1000000 ? 1 : 0) : decimals;
    if (absolute >= 1000000) return `${number < 0 ? "(" : ""}$${(absolute / 1000000).toFixed(digits)}MM${number < 0 ? ")" : ""}`;
    if (absolute >= 1000) return `${number < 0 ? "(" : ""}$${(absolute / 1000).toFixed(digits)}K${number < 0 ? ")" : ""}`;
    return number.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: digits });
  }

  function percent(value, digits) {
    if (value == null || value === "") return "—";
    const number = Number(value);
    return Number.isFinite(number) ? `${(number * 100).toFixed(digits == null ? 1 : digits)}%` : "—";
  }

  function multiple(value, digits) {
    if (value == null || value === "") return "—";
    const number = Number(value);
    return Number.isFinite(number) ? `${number.toFixed(digits == null ? 2 : digits)}x` : "—";
  }

  function number(value, digits) {
    if (value == null || value === "") return "—";
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric.toLocaleString("en-US", { maximumFractionDigits: digits == null ? 1 : digits }) : "—";
  }

  function factById(id) { return state.facts.find((fact) => fact.id === id) || null; }
  function calcById(id) { return state.calculations.find((calc) => calc.id === id) || null; }
  function sourceById(id) { return state.sources.find((source) => source.id === id) || null; }

  function factScopeKey(fact) {
    return window.HBFMonitor?.factScopeKey
      ? window.HBFMonitor.factScopeKey(fact)
      : [normalizeEntity(fact?.entity), String(fact?.path || "").trim().toLowerCase(), String(fact?.periodType || "as_of").trim().toLowerCase(), String(fact?.asOfDate || ""), String(fact?.scenario || "actual").trim().toLowerCase(), String(fact?.unit || "").trim().toLowerCase()].join("|");
  }

  function eligibleFactsForPath(path, scope) {
    const candidates = state.facts.filter((fact) => fact.path === path && ACCEPTED_FACT_STATUSES.has(fact.status));
    if (!scope) return candidates;
    return candidates.filter((fact) => (!scope.entity || normalizeEntity(fact.entity) === normalizeEntity(scope.entity)) &&
      (!scope.periodType || fact.periodType === scope.periodType) && (!scope.asOfDate || fact.asOfDate === scope.asOfDate) &&
      (!scope.scenario || (fact.scenario || "actual") === scope.scenario) && (!scope.unit || (fact.unit || "") === scope.unit) &&
      (!scope.throughDate || !fact.asOfDate || fact.asOfDate <= scope.throughDate));
  }

  function factByPath(path, ...scopeArgs) {
    const scope = scopeArgs[0];
    const candidates = eligibleFactsForPath(path, scope);
    if (!scope && candidates.length > 1) {
      const dated = candidates.filter((fact) => isValidIsoDate(fact.asOfDate || "")).sort((a, b) => b.asOfDate.localeCompare(a.asOfDate));
      if (dated.length) {
        const latestDate = dated[0].asOfDate;
        const latest = dated.filter((fact) => fact.asOfDate === latestDate);
        const latestExplicit = latest.filter((fact) => fact.controlling === true);
        if (latestExplicit.length === 1) return latestExplicit[0];
        if (latest.length === 1) return latest[0];
      }
    }
    const explicit = candidates.filter((fact) => fact.controlling === true);
    if (explicit.length === 1) return explicit[0];
    if (explicit.length > 1) return null;
    const accepted = candidates.filter((fact) => fact.status === "accepted");
    if (accepted.length === 1) return accepted[0];
    if (accepted.length > 1) return null;
    return candidates.length === 1 ? candidates[0] : null;
  }

  function latestFact(path, scope) {
    const candidates = eligibleFactsForPath(path, scope).sort((a, b) => String(a.asOfDate || "").localeCompare(String(b.asOfDate || "")));
    if (!candidates.length) return null;
    const date = candidates[candidates.length - 1].asOfDate || "";
    const latest = candidates.filter((fact) => (fact.asOfDate || "") === date);
    const explicit = latest.filter((fact) => fact.controlling === true);
    if (explicit.length === 1) return explicit[0];
    return latest.length === 1 ? latest[0] : null;
  }

  function controllingAmbiguities() {
    const groups = new Map();
    state.facts.filter((fact) => ACCEPTED_FACT_STATUSES.has(fact.status)).forEach((fact) => {
      const key = factScopeKey(fact);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(fact);
    });
    return Array.from(groups.entries()).filter(([, facts]) => facts.length > 1 && facts.filter((fact) => fact.controlling).length !== 1).map(([key]) => key);
  }

  function normalizeEntity(value) {
    return String(value || "").trim().replace(/\s+/g, " ").toLowerCase();
  }

  function entityApproved(fact) {
    if (!fact || fact.provenance === "analyst_judgment" || state.mode === "demo") return true;
    const entity = normalizeEntity(fact.entity);
    return Boolean(entity) && (state.entities || []).some((item) => normalizeEntity(item.name) === entity);
  }

  function setControllingFact(id) {
    const selected = factById(id);
    if (!selected || !ACCEPTED_FACT_STATUSES.has(selected.status) || !entityApproved(selected)) return toast("Only an accepted fact for a registered deal entity can control an output.", "error");
    const scopeKey = factScopeKey(selected);
    const displacedIds = state.facts.filter((fact) => factScopeKey(fact) === scopeKey && fact.id !== selected.id && fact.controlling).map((fact) => fact.id);
    state.facts.forEach((fact) => { if (factScopeKey(fact) === scopeKey) fact.controlling = fact.id === selected.id; });
    supersedeDependentRecords(displacedIds, `${selected.id} replaced the cited controlling version for ${selected.path}.`);
    markScenarioStale(`${selected.label || selected.path} was selected as the controlling version.`);
    state.editHistory.push({ action: `Selected ${selected.id} as controlling for ${selected.path}`, at: new Date().toISOString() });
    toast("Controlling fact selection recorded; dependent analysis now requires refresh.");
  }

  function displayFact(path, fallback) {
    const fact = factByPath(path);
    if (!fact) return state.mode === "demo" && fallback != null ? fallback : "—";
    if (fact.valueType === "money") return money(fact.value);
    if (fact.valueType === "percent") return percent(fact.value);
    if (fact.valueType === "multiple") return multiple(fact.value);
    if (fact.valueType === "date") return formatDate(fact.value);
    if (fact.valueType === "number") return `${number(fact.value)}${fact.unit ? ` ${fact.unit}` : ""}`;
    return String(fact.value);
  }

  function formatDate(value) {
    if (!value) return "Not stated";
    const date = new Date(`${value}T00:00:00Z`);
    if (Number.isNaN(date.getTime())) return String(value);
    return new Intl.DateTimeFormat("en-US", { year: "numeric", month: "short", day: "numeric", timeZone: "UTC" }).format(date);
  }

  function isValidIsoDate(value) {
    if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const date = new Date(`${value}T00:00:00Z`);
    return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
  }

  function isValidIsoDateTime(value) {
    if (typeof value !== "string") return false;
    const match = /^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-](\d{2}):(\d{2}))$/.exec(value);
    if (!match || !isValidIsoDate(match[1])) return false;
    const [, , hour, minute, second, offsetHour, offsetMinute] = match;
    if (Number(hour) > 23 || Number(minute) > 59 || Number(second) > 59) return false;
    if (offsetHour != null && (Number(offsetHour) > 23 || Number(offsetMinute) > 59)) return false;
    return Number.isFinite(Date.parse(value));
  }

  function normalizedStatus(value) {
    return String(value || "").trim().toLowerCase().replace(/[\s_-]+/g, " ");
  }

  function monitorActionIsTerminal(action) {
    return new Set(["completed", "closed", "cancelled"]).has(normalizedStatus(action?.status));
  }

  function monitorActionIsCancelled(action) {
    return normalizedStatus(action?.status) === "cancelled";
  }

  function hasPlaceholderOrError(value) {
    return /(?:\brequired\b|\btbd\b|not entered|not provided|pm (?:review|selection)|#(?:n\/a|ref!|value!|div\/0!|name\?|num!))/i.test(String(value || ""));
  }

  function covenantIsException(item) {
    if (item?.reportedOutcome === "Noncompliant" || item?.computedStatus === "Noncompliant" || item?.comparable === false) return true;
    if (item?.reportedOutcome) return item.reportedOutcome !== "Compliant";
    return !/^(?:compliant|pass|passed)$/i.test(String(item?.status || ""));
  }

  function covenantRequiresReview(item) {
    return covenantIsException(item);
  }

  function completeMonitorAction(action) {
    return Boolean(action && String(action.action || "").trim().length >= 20 && String(action.owner || "").trim().length >= 2 &&
      isValidIsoDate(action.dueDate || "") && String(action.evidence || "").trim().length >= 5 && !monitorActionIsCancelled(action));
  }

  function openIssues(severity) {
    return state.issues.filter((issue) => issue.status === "open" && (!severity || issue.severity === severity));
  }

  function openConflicts() {
    return state.conflicts.filter((conflict) => conflict.status === "open" || !conflict.status);
  }

  function allAttested() {
    const required = ["facts", "calculations", "judgment", "rating"];
    const extraIncomplete = Object.entries(state.attestations || {}).some(([name, value]) => !required.includes(name) && typeof value === "boolean" && value !== true);
    return Number.isSafeInteger(state.contentRevision) && state.contentRevision >= 0 && !extraIncomplete && required.every((name) => state.attestations?.[name] === true && state.attestationMetadata?.[name]?.revision === state.contentRevision);
  }

  function appReadinessControlsFor(candidate) {
    const priorState = state;
    state = candidate;
    try {
      return openIssues("blocker").length === 0 && openConflicts().length === 0 && gateRows().every((gate) => gate.pass) && allAttested();
    } finally {
      state = priorState;
    }
  }

  function isReviewReady() {
    const appReady = openIssues("blocker").length === 0 && openConflicts().length === 0 && gateRows().every((gate) => gate.pass) && allAttested() && state.finalized;
    return appReady && (!window.HBFExporters?.evaluateReadiness || window.HBFExporters.evaluateReadiness(state).ready);
  }

  function statusMarkup() {
    if (isReviewReady()) return `<span class="status-pill ready">${state.workflow === "portfolio_monitor" || state.deal?.dealType === "Quarterly Monitor" ? "Review Package Complete" : "Review Ready"}</span>`;
    if (openIssues("blocker").length) return `<span class="status-pill blocked">${openIssues("blocker").length} review blocker${openIssues("blocker").length === 1 ? "" : "s"}</span>`;
    const failedControls = gateRows().filter((gate) => !gate.pass).length;
    if (failedControls) return `<span class="status-pill blocked">${failedControls} control${failedControls === 1 ? "" : "s"} incomplete</span>`;
    return '<span class="status-pill draft">Draft — attestation required</span>';
  }

  function pageHead(eyebrow, title, description, actions) {
    return `<header class="page-head">
      <div><p class="eyebrow">${esc(eyebrow)}</p><h2>${esc(title)}</h2><p>${esc(description)}</p></div>
      <div class="page-head-actions">${actions || statusMarkup()}</div>
    </header>`;
  }

  function factEvidenceButton(factId, label) {
    if (!factId) return "";
    return `<button class="evidence-button" type="button" data-evidence="${esc(factId)}" aria-label="Show evidence for ${esc(label || factId)}">E</button>`;
  }

  function citationToken(factId) {
    if (!factId) return "";
    return `<button class="citation-token" type="button" data-evidence="${esc(factId)}" title="Show supporting evidence">${esc(factId.replace(/^F/, ""))}</button>`;
  }

  function parseFactReferences(value) {
    return Array.from(new Set(String(value || "").split(/[,;\s]+/).map((item) => item.trim()).filter(Boolean)));
  }

  function acceptedFactReferences(record) {
    const ids = parseFactReferences(record?.sourceFactIds || record?.sourceFactId || "");
    return ids.filter((id) => {
      const fact = factById(id);
      return fact && ACCEPTED_FACT_STATUSES.has(fact.status) && entityApproved(fact) && factByPath(fact.path, { entity: fact.entity, periodType: fact.periodType, asOfDate: fact.asOfDate, scenario: fact.scenario || "actual" })?.id === fact.id;
    });
  }

  function governedRecordEvidence(record) {
    if (!record) return { pass: false, label: "Evidence required", className: "bad", ids: [] };
    if (record.recordStatus === "superseded") return { pass: false, label: "Superseded workbook result", className: "neutral", ids: [] };
    const requestedIds = parseFactReferences(record.sourceFactIds || record.sourceFactId || "");
    const acceptedIds = acceptedFactReferences(record);
    if (requestedIds.length && acceptedIds.length === requestedIds.length) {
      return { pass: true, label: `${acceptedIds.length} accepted fact${acceptedIds.length === 1 ? "" : "s"}`, className: "good", ids: acceptedIds };
    }
    if (requestedIds.length) return { pass: false, label: "Fact reference is not controlling", className: "bad", ids: acceptedIds };
    const workbookSource = sourceById(record.sourceId);
    if (record.evidenceClassification === "workbook_observation" && workbookSource && workbookSource.status !== "superseded" && state.workbook?.sourceId === record.sourceId && record.actualLocator && record.thresholdLocator && record.reviewedAt) {
      return { pass: true, label: "Reviewed workbook observation", className: "good", ids: [] };
    }
    if (record.evidenceClassification === "pm_judgment") {
      return { pass: true, label: "Explicit PM judgment", className: "neutral", ids: [] };
    }
    if (state.mode === "demo") return { pass: true, label: "Synthetic demo record", className: "neutral", ids: acceptedIds };
    return { pass: false, label: requestedIds.length ? "Fact reference is not accepted" : "Evidence required", className: "bad", ids: acceptedIds };
  }

  function evidenceMarkup(record) {
    const evidence = governedRecordEvidence(record);
    const tokens = evidence.ids.map(citationToken).join("");
    const sourceButton = evidence.pass && record?.evidenceClassification === "workbook_observation" && record.sourceId
      ? `<button class="citation-token" type="button" data-source-detail="${esc(record.sourceId)}" title="Show workbook source">${esc(record.sourceId)}</button>`
      : "";
    return `<span class="tag ${evidence.className}">${esc(evidence.label)}</span>${tokens || sourceButton ? `<br>${tokens}${sourceButton}` : ""}`;
  }

  function nextRecordId(prefix, records) {
    const used = new Set((records || []).map((item) => item.id));
    let index = (records || []).length + 1;
    while (used.has(`${prefix}${String(index).padStart(2, "0")}`)) index += 1;
    return `${prefix}${String(index).padStart(2, "0")}`;
  }

  function covenantStatusClass(status) {
    const normalized = String(status || "").trim().toLowerCase();
    if (normalized === "compliant") return "good";
    if (/noncompliant|not compliant|breach|violation|default|failed/.test(normalized)) return "bad";
    if (/waiver|exception|pending|not tested|review/.test(normalized)) return "warning";
    return "neutral";
  }

  function formatCovenantValue(value, valueType) {
    if (value == null || value === "") return "Not stated";
    if (valueType === "money") return money(value);
    if (valueType === "percent") return percent(value);
    if (valueType === "multiple") return multiple(value);
    return String(value);
  }

  function workbookFormulaErrorTotal(workbook) {
    if (Number.isFinite(Number(workbook?.applicableFormulaErrorCount)) && Number(workbook.applicableFormulaErrorCount) >= 0) return Number(workbook.applicableFormulaErrorCount);
    const samples = Array.isArray(workbook?.formulaErrorSamples)
      ? workbook.formulaErrorSamples
      : Array.isArray(workbook?.formulaErrors) ? workbook.formulaErrors : [];
    const reported = [workbook?.formulaErrorCount, workbook?.formulaWarnings, samples.length]
      .map((value) => Number(value))
      .filter((value) => Number.isFinite(value) && value >= 0);
    return reported.length ? Math.max(...reported) : 0;
  }

  function registeredEntityName(value) {
    const normalized = normalizeEntity(value);
    return (state.entities || []).find((entity) => normalizeEntity(entity.name) === normalized)?.name || null;
  }

  function entityOptions(selected, includeBlank) {
    const normalizedSelected = normalizeEntity(selected);
    const blank = includeBlank ? '<option value="">Select registered entity</option>' : "";
    return blank + (state.entities || []).map((entity) => `<option value="${esc(entity.name)}" ${normalizeEntity(entity.name) === normalizedSelected ? "selected" : ""}>${esc(entity.role)} • ${esc(entity.name)}</option>`).join("");
  }

  function validateRecordEvidence(classification, ids) {
    const references = parseFactReferences(ids);
    const invalid = references.filter((id) => {
      const fact = factById(id);
      return !fact || !ACCEPTED_FACT_STATUSES.has(fact.status) || !entityApproved(fact) || factByPath(fact.path, { entity: fact.entity, periodType: fact.periodType, asOfDate: fact.asOfDate, scenario: fact.scenario || "actual" })?.id !== fact.id;
    });
    if (invalid.length) return { pass: false, message: `These fact IDs are not accepted controlling evidence: ${invalid.join(", ")}.` };
    if (classification === "accepted_facts" && !references.length) return { pass: false, message: "Enter at least one accepted fact ID or classify the record as explicit PM judgment." };
    if (!["accepted_facts", "pm_judgment"].includes(classification)) return { pass: false, message: "Choose a valid evidence classification." };
    return { pass: true, references };
  }

  function supersedeDependentRecords(factIds, reason) {
    const affected = new Set((factIds || []).filter(Boolean));
    if (!affected.size) return 0;
    const supersededAt = new Date().toISOString();
    let count = 0;
    [state.changes || [], state.risks || [], state.covenants || []].forEach((records) => records.forEach((record) => {
      if (record.recordStatus === "superseded") return;
      const references = parseFactReferences(record.sourceFactIds || record.sourceFactId || "");
      if (!references.some((id) => affected.has(id))) return;
      record.recordStatus = "superseded";
      record.supersededAt = supersededAt;
      record.evidenceSupersededReason = reason || "A cited fact is no longer controlling evidence.";
      count += 1;
    }));
    return count;
  }

  function quarantineScopeDependentRecords(targetState, factIds, reason) {
    const affected = new Set((factIds || []).filter(Boolean));
    if (!affected.size) return 0;
    const quarantinedAt = new Date().toISOString();
    let count = 0;
    [targetState.changes || [], targetState.risks || [], targetState.covenants || []].forEach((records) => records.forEach((record) => {
      if (record.recordStatus === "superseded") return;
      const references = parseFactReferences(record.sourceFactIds || record.sourceFactId || "");
      if (!references.some((id) => affected.has(id))) return;
      record.scopeRecordStatusBeforeChange = record.recordStatus || "current";
      record.recordStatus = "superseded";
      record.supersededAt = quarantinedAt;
      record.evidenceSupersededReason = reason || "A cited workbook fact is outside the confirmed current tab scope.";
      count += 1;
    }));
    return count;
  }

  function restoreScopeDependentRecords(targetState) {
    [targetState.changes || [], targetState.risks || [], targetState.covenants || []].forEach((records) => records.forEach((record) => {
      if (!record.scopeRecordStatusBeforeChange) return;
      record.recordStatus = record.scopeRecordStatusBeforeChange === "current" ? undefined : record.scopeRecordStatusBeforeChange;
      delete record.scopeRecordStatusBeforeChange;
      delete record.supersededAt;
      delete record.evidenceSupersededReason;
    }));
  }

  function preserveRecordedScenarioAsStale(targetState, detail) {
    const recorded = targetState?.scenarioResults;
    if (!recorded || !["computed", "stale"].includes(recorded.status)) return;
    targetState.scenarioResults = {
      ...recorded,
      status: "stale",
      staleAt: new Date().toISOString(),
      staleReason: detail || "A fact, scope selection or scenario assumption changed after this case was recorded."
    };
  }

  function invalidateCheckpointScopeAnalysis(targetState, detail) {
    preserveRecordedScenarioAsStale(targetState, detail);
    targetState.stressReviewed = false;
    targetState.calculations = (targetState.calculations || []).filter((calculation) => !STRESS_CALCULATION_IDS.has(calculation.id));
    targetState.staleNarrativeReviewRequired = true;
    const ensureIssue = (id, title, actionView) => {
      const existing = (targetState.issues || []).find((issue) => issue.id === id);
      if (existing) { existing.status = "open"; existing.severity = "blocker"; existing.detail = detail; }
      else targetState.issues.push({ id, severity: "blocker", title, detail, actionView, status: "open", resolutionType: "system_control" });
    };
    ensureIssue("STRESS-STALE", "Selected downside is not synchronized", "downside");
    ensureIssue("FACT-NARRATIVE-STALE", "Memo narratives require dependency review", "memo");
    targetState.attestations = { facts: false, calculations: false, judgment: false, rating: false };
    targetState.attestationMetadata = {};
    targetState.finalized = false;
    if (targetState.deal) targetState.deal.status = "Draft";
    delete targetState.finalizedAt;
  }

  function emptyState() {
    return {
      schemaVersion: "1.0",
      appVersion: "0.2.0",
      mode: "live",
      workflow: "credit_action",
      deal: { id: "NEW-DEAL", borrower: "Untitled deal", relationship: "", dealType: "Renewal", facilityType: "Secured RLOC", asOfDate: "", preparedDate: "", reviewDateConfirmedAt: null, status: "Draft", recommendation: "PM recommendation required", request: "Request not defined", currentRating: "Not entered", proposedRating: "PM selection required", pmName: "Portfolio Manager", creditOfficer: "Senior Credit Officer" },
      sources: [], facts: [], calculations: [], conflicts: [], issues: [
        { id: "NEW-I01", severity: "blocker", title: "Deal evidence has not been imported", detail: "Select each individual underwriting tab used for the deal, load the HBF workbook with those tabs completed, and add at least one reviewed Opus evidence JSON packet.", actionView: "sources", status: "open" }
      ],
      entities: [], importedPacketIds: [],
      covenants: [], changes: [], risks: [], conditions: [],
      memoSections: MEMO_BLUEPRINT.map(([id, title]) => ({ id, title, narrative: "", generatedByScenario: false })),
      workbookScope: window.HBF_CreditPath?.defaultWorkbookScope("Renewal", "Secured RLOC") || ["relationship"],
      workbookTabs: window.HBF_CreditPath?.defaultWorkbookTabs("Renewal", "Secured RLOC") || ["Exposure"],
      workbookScopeConfirmed: false,
      additionalDocumentIds: [],
      applicability: APPLICABILITY_CATALOG.map(([id, label, kind]) => ({ id, label, kind, status: "pending", basis: "" })),
      workbook: {
        loaded: false, fileName: "", profile: "Not loaded", sheets: 0, mappedSheets: 0, mappedFacts: 0,
        metadataReviewRequiredFacts: [], formulaErrorCount: 0, formulaErrorSamples: [], formulaErrors: [], formulaWarnings: 0,
        recalculatedConfirmed: false, formulaErrorsReviewed: false, formulaErrorReviewConfirmed: false,
        formulaErrorReviewCount: 0, reviewedAsNonDealEvidence: false, errorReviewNote: ""
      },
      stress: clone(SELECTED_STRESS_PRESET),
      stressReviewed: false,
      importedNarratives: [],
      monitor: null,
      monitorWorkbook: { loaded: false, profile: "Not loaded", profileMatched: false },
      contentRevision: 0,
      attestationMetadata: {},
      attestations: { facts: false, calculations: false, judgment: false, rating: false }, finalized: false, editHistory: []
    };
  }

  function invalidateAttestations(reason) {
    const hadAttestation = Object.values(state.attestations || {}).some(Boolean);
    state.contentRevision = (Number(state.contentRevision) || 0) + 1;
    state.attestations = { facts: false, calculations: false, judgment: false, rating: false };
    state.attestationMetadata = {};
    state.finalized = false;
    if (state.workflow === "portfolio_monitor" && state.monitor) state.monitor.officerDraftReviewed = false;
    if (state.deal) state.deal.status = "Draft";
    sessionDirty = true;
    if (hadAttestation && reason) state.editHistory.push({ action: `Attestations invalidated: ${reason}`, at: new Date().toISOString() });
  }

  function toast(message, type) {
    const region = document.getElementById("toast-region");
    const item = document.createElement("div");
    item.className = `toast${type === "error" ? " error" : ""}`;
    item.textContent = message;
    region.appendChild(item);
    window.setTimeout(() => item.remove(), 4200);
  }

  function fieldHasUnsavedValue(field) {
    if (!field || field.disabled || field.type === "hidden" || field.matches("[data-stress], [data-app-basis], [data-app-status], [data-attestation]")) return false;
    if (field.type === "checkbox" || field.type === "radio") return field.checked !== field.defaultChecked;
    if (field.tagName === "SELECT") {
      const defaultIndex = Array.from(field.options).findIndex((option) => option.defaultSelected);
      return field.selectedIndex !== (defaultIndex >= 0 ? defaultIndex : 0);
    }
    return field.value !== field.defaultValue;
  }

  function viewHasUnsavedInputs(excludedContainer) {
    return Array.from(document.querySelectorAll("#view input, #view textarea, #view select")).some((field) =>
      !(excludedContainer?.contains?.(field)) && fieldHasUnsavedValue(field));
  }

  function draftFieldKey(field) {
    if (field?.id) return `id:${field.id}`;
    if (field?.form?.id && field.name) return `form:${field.form.id}:${field.name}`;
    const attribute = ["data-resolution-note", "data-meta-entity", "data-meta-period", "data-meta-date", "data-cov-entity", "data-cov-date", "data-cov-status"].find((name) => field?.hasAttribute?.(name));
    return attribute ? `${attribute}:${field.getAttribute(attribute)}` : null;
  }

  function captureViewDrafts(excludedContainer) {
    const activeKey = draftFieldKey(document.activeElement);
    const fields = Array.from(document.querySelectorAll("#view input, #view textarea, #view select"))
      .filter((field) => !(excludedContainer?.contains?.(field)) && fieldHasUnsavedValue(field))
      .map((field) => ({ key: draftFieldKey(field), checked: field.type === "checkbox" || field.type === "radio", value: field.type === "checkbox" || field.type === "radio" ? field.checked : field.value }))
      .filter((draft) => draft.key);
    return { activeKey, fields };
  }

  function restoreViewDrafts(snapshot) {
    if (!snapshot?.fields?.length) return;
    const currentFields = new Map(Array.from(document.querySelectorAll("#view input, #view textarea, #view select")).map((field) => [draftFieldKey(field), field]).filter(([key]) => key));
    snapshot.fields.forEach((draft) => {
      const field = currentFields.get(draft.key);
      if (!field || field.disabled) return;
      if (draft.checked) field.checked = Boolean(draft.value);
      else if (field.tagName !== "SELECT" || Array.from(field.options).some((option) => option.value === draft.value)) field.value = draft.value;
    });
    currentFields.get(snapshot.activeKey)?.focus?.({ preventScroll: true });
  }

  function confirmViewNavigation() {
    if (!viewHasUnsavedInputs()) return true;
    return window.confirm("Leave this work area? Unsaved form entries on this screen will be discarded. Save the current record first if it must be retained.");
  }

  function confirmMemoEditorSwitch(nextSectionId) {
    const editor = document.getElementById("memo-editor");
    const editorUnchanged = !editor || editor.value === editor.defaultValue;
    if ((nextSectionId && editingSectionId === nextSectionId) || editorUnchanged && !viewHasUnsavedInputs()) return true;
    return window.confirm("This action reloads the memo and discards unsaved changes. Choose Cancel, then save the current fields first.");
  }

  function confirmOutputWithUnsavedInputs(outputLabel) {
    if (!viewHasUnsavedInputs()) return true;
    return window.confirm(`The ${outputLabel || "output"} will use the last saved values, not the unsaved changes currently on screen. Choose Cancel to save first, or OK to use the last saved draft.`);
  }

  function confirmExportWithUnsavedInputs() {
    return confirmOutputWithUnsavedInputs("Word file");
  }

  function guidanceModel() {
    const gates = gateRows();
    const candidates = state.facts.filter((fact) => ["candidate", "conflicted", "missing", "judgment_required"].includes(fact.status)).length;
    const memoIncomplete = (state.memoSections || []).filter((section) => String(section.narrative || "").trim().length < 60).length;
    const decisionGates = gates.filter((gate) => /Primary repayment|Selected downside|Risk chains|Transaction changes|PM decision fields|Risk rating/.test(gate.title));
    const stressResult = calculateStress();
    const stressCurrent = Boolean(state.stressReviewed && stressResult.status === "computed" && state.scenarioResults?.inputFingerprint === stressInputFingerprint() && scenarioCalculationLedgerMatches());
    const creditTasks = window.HBF_CreditPath?.judgmentTasks(state, { stressCurrent }) || [];
    const nextCreditTask = creditTasks.find((task) => !task.complete) || null;
    const requiredDocumentOpen = state.mode === "demo" ? 0 : (window.HBF_CreditPath?.documentPlan(state) || []).filter((item) => item.required && !item.complete).length;
    const monitorJudgmentComplete = Boolean(state.monitor &&
      String(state.monitor.assessment || "").trim().length >= 12 &&
      String(state.monitor.rating?.recommended || "").trim().length >= 1 &&
      String(state.monitor.ratingRationale || "").trim().length >= 50 &&
      String(state.monitor.conclusion || "").trim().length >= 80 &&
      ![state.monitor.assessment, state.monitor.rating?.recommended, state.monitor.ratingRationale, state.monitor.conclusion].some(hasPlaceholderOrError));
    return {
      landing: landingMode,
      workflow: state.workflow,
      mode: state.mode,
      activeStage,
      activeView,
      workbookScopeConfirmed: state.mode === "demo" || state.workbookScopeConfirmed === true,
      workbookLoaded: Boolean(state.workbook?.loaded && !state.workbook?.scopeChangedAfterImport),
      monitorLoaded: Boolean(state.monitorWorkbook?.loaded && state.monitor),
      monitorReviewed: Boolean(state.monitor?.reviewed),
      monitorJudgmentComplete,
      monitorDraftReviewed: Boolean(state.monitor?.officerDraftReviewed),
      sourceCount: state.sources.length,
      packetCount: (state.importedPacketIds || []).length,
      requiredDocumentOpen,
      candidates,
      conflicts: openConflicts().length,
      stressCurrent,
      nextJudgmentTask: nextCreditTask ? { id: nextCreditTask.id, label: nextCreditTask.label, view: nextCreditTask.view, anchor: nextCreditTask.anchor } : null,
      creditJudgmentComplete: Boolean(decisionGates.length && decisionGates.every((gate) => gate.pass)),
      memoIncomplete,
      staleNarratives: Boolean(state.staleNarrativeReviewRequired),
      blockers: openIssues("blocker").length,
      failedControls: gates.filter((gate) => !gate.pass).length,
      attested: allAttested(),
      finalized: Boolean(state.finalized),
      ready: isReviewReady()
    };
  }

  function guidedSnapshot() {
    return window.HBF_Guided.derive(guidanceModel());
  }

  function setIssueDrawer(open, restoreFocus) {
    issueDrawerOpen = Boolean(open) && !landingMode;
    const drawer = document.getElementById("issue-rail");
    const toggle = document.getElementById("issue-drawer-toggle");
    document.body.classList.toggle("issues-open", issueDrawerOpen);
    drawer.setAttribute("aria-hidden", String(!issueDrawerOpen));
    toggle.setAttribute("aria-expanded", String(issueDrawerOpen));
    if (issueDrawerOpen) document.getElementById("close-issue-drawer")?.focus({ preventScroll: true });
    else if (restoreFocus) toggle.focus({ preventScroll: true });
  }

  function navigate(view, options) {
    const settings = options || {};
    const nextView = state.authoring && view === "memo" ? "draft" : viewNames[view] ? view : "brief";
    if (!settings.force && !confirmViewNavigation()) return false;
    landingMode = false;
    activeView = nextView;
    activeStage = settings.stage || window.HBF_Guided.stageForView(state.workflow, activeView, activeStage);
    setIssueDrawer(false, false);
    document.querySelectorAll(".nav-item").forEach((button) => {
      const active = button.dataset.view === activeView;
      button.classList.toggle("is-active", active);
      if (active) button.setAttribute("aria-current", "page"); else button.removeAttribute("aria-current");
    });
    document.getElementById("view-label").textContent = viewNames[activeView];
    renderView();
    document.getElementById("view").focus({ preventScroll: true });
    window.scrollTo({ top: 0, behavior: "auto" });
    return true;
  }

  function goToStage(stage, options) {
    if (!window.HBF_Guided.STAGE_ORDER.includes(stage)) return false;
    const model = guidanceModel();
    const view = window.HBF_Guided.stageView(state.workflow, stage, { ...model, activeView });
    return navigate(view, { stage, force: options?.force === true });
  }

  function focusWorkTarget(anchor) {
    if (!anchor) return;
    window.setTimeout(() => {
      const target = document.getElementById(anchor);
      if (!target) return;
      if (target.tagName === "DETAILS") target.open = true;
      target.scrollIntoView?.({ behavior: "smooth", block: "start" });
      const focusable = target.matches?.("button, input, select, textarea, [tabindex]") ? target : target.querySelector?.("button, input, select, textarea, [tabindex]");
      focusable?.focus?.({ preventScroll: true });
    }, 0);
  }

  function openCreditTask(taskId) {
    const stress = calculateStress();
    const stressCurrent = Boolean(state.stressReviewed && stress.status === "computed" && state.scenarioResults?.inputFingerprint === stressInputFingerprint() && scenarioCalculationLedgerMatches());
    const task = window.HBF_CreditPath?.judgmentTasks(state, { stressCurrent }).find((item) => item.id === taskId);
    if (!task) return false;
    if (!navigate(task.view, { stage: "judgment" })) return false;
    focusWorkTarget(task.anchor);
    return true;
  }

  function updateGuidedNavigation(snapshot) {
    document.getElementById("workflow-label").textContent = snapshot.workflow.label;
    document.querySelectorAll(".stage-item[data-stage]").forEach((button) => {
      const stage = snapshot.stages.find((item) => item.id === button.dataset.stage);
      if (!stage) return;
      button.disabled = landingMode;
      button.className = `stage-item is-${stage.status}${button.dataset.stage === snapshot.selectedStage && !landingMode ? " is-active" : ""}`;
      button.querySelector(".stage-copy strong").textContent = stage.label;
      button.querySelector(".stage-copy small").textContent = stage.title;
      button.querySelector(".stage-state").textContent = stage.status === "complete" ? "✓" : stage.status === "current" ? "•" : "";
      button.setAttribute("aria-label", `${button.querySelector(".stage-number").textContent}. ${stage.label}: ${stage.title}. ${stage.status}.`);
      if (button.dataset.stage === snapshot.selectedStage && !landingMode) button.setAttribute("aria-current", "step"); else button.removeAttribute("aria-current");
    });
  }

  function updateTopbar(snapshot) {
    const nextButton = document.getElementById("guided-next");
    const next = snapshot.next;
    nextButton.hidden = !next;
    nextButton.textContent = next ? `${next.label} →` : "";
    nextButton.dataset.guidedAction = next?.id || "";
    const isMonitor = state.workflow === "portfolio_monitor";
    document.getElementById("load-workbook").hidden = landingMode || isMonitor;
    document.getElementById("load-monitor").hidden = landingMode || !isMonitor;
    document.getElementById("import-opus").hidden = landingMode || isMonitor;
    document.getElementById("issue-drawer-toggle").hidden = landingMode;
    document.getElementById("session-menu").hidden = landingMode;
  }

  function updateSessionNotice() {
    const notice = document.getElementById("session-notice");
    if (landingMode) {
      notice.hidden = true;
      notice.innerHTML = "";
      return;
    }
    notice.hidden = false;
    if (state.mode === "demo") {
      notice.className = "session-notice is-demo";
      notice.innerHTML = '<div><strong>Synthetic demonstration</strong><span>Every name, number and source is fictional. Customer files cannot be added to this sample.</span></div><button class="button button-quiet" type="button" data-start-workflow="credit_action">Start live work</button>';
    } else {
      notice.className = "session-notice is-live";
      notice.innerHTML = '<div><strong>Live local session</strong><span>Deal data stays in this browser tab unless you explicitly download an output or checkpoint.</span></div><span class="local-boundary">No deal store · Working data stays local</span>';
    }
  }

  function updateShell() {
    const snapshot = guidedSnapshot();
    document.body.classList.toggle("is-landing", landingMode);
    document.getElementById("sidebar-borrower").textContent = landingMode ? "Start or resume work" : state.deal.borrower;
    document.getElementById("sidebar-deal-meta").textContent = landingMode ? "Nothing selected" : `${state.deal.dealType} • ${state.deal.facilityType}`;
    document.getElementById("deal-id-label").textContent = landingMode ? "New session" : state.authoring ? (window.HBFAuthoring.title(state.authoring) || "Untitled document") : (state.deal.documentTitle || state.deal.dealType);
    document.getElementById("return-to-document").hidden = landingMode || !state.authoring;
    const modeLabel = document.getElementById("mode-label");
    if (modeLabel) {
      modeLabel.textContent = landingMode ? "Choose a workflow" : state.mode === "demo" ? "Synthetic demo" : "Live local deal";
      modeLabel.className = `tag ${landingMode ? "neutral" : state.mode === "demo" ? "info" : "good"}`;
    }
    document.getElementById("source-count").textContent = String(landingMode ? 0 : state.sources.length);
    document.getElementById("conflict-count").textContent = String(landingMode ? 0 : openConflicts().length);
    const monitorCount = document.getElementById("monitor-count");
    if (monitorCount) monitorCount.textContent = !landingMode && state.monitor ? String((state.monitor.watchItems || []).filter((item) => item.status !== "resolved").length) : "0";
    const gateDot = document.getElementById("gate-dot");
    gateDot.className = `nav-dot ${!landingMode && isReviewReady() ? "is-ready" : !landingMode && openIssues("blocker").length ? "has-blocker" : ""}`;
    document.getElementById("attention-count").textContent = String(landingMode ? 0 : openIssues().length);
    document.getElementById("view-label").textContent = landingMode ? "Start" : viewNames[activeView];
    updateGuidedNavigation(snapshot);
    updateTopbar(snapshot);
    updateSessionNotice();
    if (landingMode && issueDrawerOpen) setIssueDrawer(false, false);
    renderIssueRail();
  }

  function renderIssueRail() {
    const items = openIssues().filter((issue) => issueFilter === "all" || issue.severity === issueFilter);
    document.getElementById("issue-total").textContent = String(openIssues().length);
    const container = document.getElementById("issue-list");
    container.innerHTML = items.length ? items.map((issue) => `<article class="issue-card ${esc(issue.severity)}">
      <div class="issue-meta"><span class="severity ${esc(issue.severity)}">${esc(issue.severity)}</span><span class="muted">${esc(issue.id)}</span></div>
      <h3>${esc(issue.title)}</h3>
      <p>${esc(issue.detail)}</p>
      <div class="issue-actions">
        <button type="button" data-issue-view="${esc(issue.actionView || "gate")}">Review</button>
        ${issueCanManualResolve(issue) ? `<button type="button" data-resolve-issue="${esc(issue.id)}">Record resolution</button>` : ""}
        ${issue.severity === "note" ? `<button type="button" data-acknowledge="${esc(issue.id)}">Acknowledge</button>` : ""}
      </div>
    </article>`).join("") : '<div class="empty-issues"><strong>No open items in this filter.</strong><br>Warnings and notes remain visible until acknowledged or resolved.</div>';
  }

  function issueCanManualResolve(issue) {
    if (!issue || issue.status !== "open" || issue.conflictId || issue.resolutionType === "system_control" || issue.resolutionType === "fact_disposition") return false;
    if (["NEW-I01", "I02", "AI-NARRATIVE-REVIEW"].includes(issue.id)) return false;
    return !/^(?:WB-|STRESS-|FACT-)/.test(issue.id);
  }

  function openIssueResolution(id) {
    const issue = state.issues.find((item) => item.id === id);
    if (!issueCanManualResolve(issue)) return toast("This blocker is closed only by its linked control workflow.", "error");
    document.getElementById("issue-resolution-id").value = issue.id;
    document.getElementById("issue-resolution-title").textContent = issue.title;
    const form = document.getElementById("issue-resolution-form");
    form.elements.evidenceId.value = ""; form.elements.rationale.value = ""; form.elements.resolutionType.value = "supplied_evidence";
    document.getElementById("issue-resolution-dialog").showModal();
  }

  function startDocument(workflow) {
    const selected = workflow === 'portfolio_monitor' ? 'portfolio_monitor' : 'credit_action';
    if (!confirmLiveSessionReplacement(selected === 'portfolio_monitor' ? 'a new quarterly review' : 'a new credit memo')) return false;
    const next = emptyState();
    next.deal.id = 'HBF-' + (window.crypto.randomUUID?.() || window.HBFCrypto.uuid());
    next.workflow = selected;
    next.deal.dealType = selected === 'portfolio_monitor' ? 'Quarterly Monitor' : 'Renewal';
    next.authoring = window.HBFAuthoring.create(selected);
    next.deal.documentTitle = window.HBFAuthoring.title(next.authoring);
    next.issues[0].detail = 'Source review has not been completed. Drafting and Word download are available; imported facts require the existing evidence checks.';
    next.issues[0].title = 'Source review remains open';
    if (selected === 'portfolio_monitor') next.issues[0].actionView = 'monitor';
    state = next; sessionDirty = true; landingMode = false; activeStage = 'review';
    editingSectionId = null; pendingConflictSelection = {};
    navigate('draft', { force: true, stage: 'review' });
    return true;
  }

  function authoringChanged() {
    const draft = state.authoring;
    state.deal.documentTitle = window.HBFAuthoring.title(draft);
    if (!state.sources.length) {
      const name = window.HBFAuthoring.borrower(draft);
      state.deal.borrower = name || 'Untitled deal';
      state.entities = name ? [{ name, role: 'Borrower' }] : [];
    }
    if (draft.kind === 'qpr') {
      const reviewDate = draft.content.dates.review;
      if (state.deal.asOfDate !== reviewDate) {
        state.deal.asOfDate = reviewDate; state.deal.preparedDate = reviewDate;
        state.deal.reviewDateConfirmedAt = reviewDate ? new Date().toISOString() : null;
        if (state.monitor) { state.monitor.reviewDateBasis = 'draft_date_changed'; state.monitor.reviewed = false; }
      }
    }
    invalidateAttestations('The PM edited the document draft.');
  }

  async function saveAuthoringCheckpoint() {
    const controller = authoringController;
    try {
      const startedState = state, frozen = clone(state), revision = frozen.contentRevision, identity = frozen.deal.id;
      await window.HBFExporters.exportCheckpoint(frozen);
      if (state === startedState && state.deal.id === identity && state.contentRevision === revision) { sessionDirty = false; controller?.markSaved(); }
      else controller?.status('Working file downloaded; newer edits still need saving.');
    } catch (error) { controller?.status(error.message, true); toast(error.message, 'error'); }
  }

  async function exportAuthoringDocument() {
    if (authoringExportBusy) return;
    authoringExportBusy = true;
    const controller = authoringController;
    try {
      controller?.status('Preparing the Word draft…');
      if (state.authoring.kind === 'qpr') await window.HBFExporters.exportMonitor(state);
      else await window.HBFExporters.exportMemo(state);
      controller?.status('Draft · Word document downloaded');
    } catch (error) { controller?.status(error.message, true); toast(error.message, 'error'); }
    finally { authoringExportBusy = false; }
  }

  function mountAuthoring() {
    if (authoringController && mountedAuthoring === state.authoring) return;
    authoringController?.dispose();
    mountedAuthoring = state.authoring;
    authoringController = window.HBFAuthoringUI.mount(document.getElementById('authoring-surface'), state.authoring, {
      onChange: authoringChanged,
      getContext: () => state,
      onSave: saveAuthoringCheckpoint,
      onOpen: () => document.getElementById('checkpoint-input').click(),
      onNew: () => { landingMode = true; renderView(); },
      onExport: exportAuthoringDocument,
      onTools: () => navigate(state.workflow === 'portfolio_monitor' ? 'monitor' : 'sources', { stage: 'add' })
    });
    if (window.HBFAuthoringLegacy && state.authoringMigration) {
      const controller = authoringController, dispose = controller.dispose;
      const disposeLegacy = window.HBFAuthoringLegacy.mount(document.getElementById('authoring-surface').shadowRoot, state, (id, target) => {
        window.HBFAuthoringLegacy.place(state, id, target); authoringChanged();
        authoringController.dispose(); authoringController = null; mountedAuthoring = null; mountAuthoring();
      });
      controller.dispose = () => { disposeLegacy(); dispose(); };
    }
  }

  function renderAuthoringToolsNote() {
    if (!state.authoring) return '';
    const label = state.workflow === 'portfolio_monitor' ? 'quarterly review' : 'credit memo';
    return `<section class="draft-tools-note"><strong>Your ${label} is available while you work here.</strong><p>Source files are optional for writing and downloading a draft. These tools retain the separate checks for imported facts, dates and calculations. Imported data does not replace your document text.</p><p>Review as-of date: ${state.deal.asOfDate ? esc(formatDate(state.deal.asOfDate)) : 'Not entered'}</p><button class="button button-quiet" type="button" data-edit-document-details>Edit document details</button> <button class="button button-primary" type="button" data-view-link="draft">Back to document</button></section>`;
  }

  function renderView() {
    updateShell();
    const showDocument = !landingMode && activeView === "draft" && Boolean(state.authoring);
    document.getElementById("authoring-surface").hidden = !showDocument;
    document.querySelector(".app-shell").hidden = showDocument;
    if (showDocument) { document.getElementById("view").innerHTML = ""; mountAuthoring(); return; }
    if (authoringController) { authoringController.dispose(); authoringController = null; mountedAuthoring = null; }

    if (landingMode) {
      document.getElementById("view").innerHTML = renderStartCenter();
      return;
    }
    const renderer = {
      brief: renderBrief,
      monitor: renderMonitor,
      workbench: renderWorkbench,
      downside: renderDownside,
      risks: renderRisks,
      sources: renderSources,
      reconcile: renderReconciliation,
      opus: renderOpus,
      memo: renderMemo,
      gate: renderGate,
      export: renderExport
    }[activeView] || renderBrief;
    const creditWorkPlan = state.workflow === "credit_action" && activeStage === "judgment" ? renderCreditJudgmentPlan() : "";
    document.getElementById("view").innerHTML = `${renderAuthoringToolsNote()}${renderGuidedContext()}${creditWorkPlan}${renderer()}`;
  }

  function renderViewPreservingDrafts(excludedContainer) {
    const draftSnapshot = captureViewDrafts(excludedContainer);
    const openDisclosureKeys = Array.from(document.querySelectorAll('#view details[open][data-preserve-open]'))
      .map((detail) => detail.dataset.preserveOpen)
      .filter(Boolean);
    renderView();
    restoreViewDrafts(draftSnapshot);
    openDisclosureKeys.forEach((key) => {
      const detail = document.querySelector(`#view details[data-preserve-open="${CSS.escape(key)}"]`);
      if (detail) detail.open = true;
    });
  }

  function renderViewPreservingDisclosures() {
    renderViewPreservingDrafts();
  }

  function workbookScopeIsCurrent() {
    if (!state.workbook?.loaded || state.workbook.scopeChangedAfterImport) return false;
    if (state.workflow === "credit_action" && state.workbookScopeConfirmed !== true) return false;
    const matcher = window.HBF_CreditPath?.workbookScopeMatches;
    return typeof matcher !== "function" || matcher(state);
  }

  function renderStartCenter() {
    return `<header class="start-brand-header"><div class="start-brand-lockup"><div class="start-studio-logo" role="img" aria-label="Credit Studio"><img src="../../brand/costar-lockup.png" width="880" height="200" alt="" aria-hidden="true"></div><div class="start-brand-product"><p>Homebuilder Finance</p><strong>Credit Decision Studio</strong></div></div></header>
    <section class="start-center" aria-labelledby="start-title">
      <div class="start-intro"><p class="eyebrow">HBF Credit Decision Studio</p><h2 id="start-title">What are you completing?</h2><p>Open a document and start writing. Add details and source material as you work.</p></div>
      <div class="workflow-choices">
        <article class="workflow-choice"><span class="choice-mark" aria-hidden="true">CrDD</span><div><p class="eyebrow">New · Renewal · Modification · Prescreen</p><h3>Prepare a credit memo</h3><p>Start with the complete credit memo template. Type, paste, or use optional Quick fill.</p><div class="required-result"><strong>Required output</strong><span>Editable Word credit memo</span></div></div><button class="button button-primary" type="button" data-start-workflow="credit_action">Start credit memo</button></article>
        <article class="workflow-choice"><span class="choice-mark" aria-hidden="true">QPR</span><div><p class="eyebrow">Quarterly monitoring</p><h3>Complete a portfolio review</h3><p>Start writing the quarterly review. Add the monitor workbook when you need source analysis.</p><div class="required-result"><strong>Required output</strong><span>Word portfolio monitor</span></div></div><button class="button button-primary" type="button" data-start-workflow="portfolio_monitor">Start quarterly review</button></article>
      </div>
      <div class="returning-actions" aria-label="Returning, guide and demonstration options">
        ${state.mode === "live" && state.authoring ? '<button class="returning-action" type="button" data-continue-document><span><strong>Continue current document</strong><small>Your work is still in this window</small></span></button>' : ""}
        <button class="returning-action" type="button" data-start-resume><span aria-hidden="true">↻</span><span><strong>Resume saved work</strong><small>Open a local checkpoint</small></span><span aria-hidden="true">→</span></button>
        <a class="returning-action" href="pilot-guide.html" target="_blank" rel="noopener"><span aria-hidden="true">?</span><span><strong>Open pilot guide</strong><small>Short step-by-step help</small></span><span aria-hidden="true">→</span></a>
        <button class="returning-action" type="button" data-start-demo><span aria-hidden="true">◇</span><span><strong>Explore synthetic demo</strong><small>Practice with fictional data</small></span><span aria-hidden="true">→</span></button>
      </div>
      <details class="pilot-boundaries"><summary>Privacy and pilot controls</summary><section class="trust-strip" aria-label="Pilot boundaries"><div><strong>In-memory only</strong><span>No application deal store or autosave</span></div><div><strong>Working data stays local</strong><span>Only anonymous visit activity is recorded</span></div><div><strong>Human-controlled</strong><span>The PM owns judgment and attestation</span></div><div><strong>Evidence-bound</strong><span>Material facts retain source and locator</span></div></section></details>
      <p class="start-footnote">Independent work sample by Rohail Abid · Synthetic or sanitized data only. Anonymous page visits and interactions are recorded; document contents stay in your browser.</p>
    </section>`;
  }

  function renderGuidedContext() {
    const model = guidanceModel();
    const snapshot = window.HBF_Guided.derive(model);
    const index = window.HBF_Guided.STAGE_ORDER.indexOf(snapshot.selectedStage) + 1;
    const tools = state.workflow === "portfolio_monitor"
      ? snapshot.selectedStage === "deliver" ? [["gate", "Final controls"], ["export", "Package options"]] : [["monitor", "Quarterly monitor"]]
      : ({
          add: [["sources", "Evidence control"], ["opus", "Opus workflow"]],
          verify: [["sources", "Candidate facts"], ["reconcile", "Conflict desk"]],
          judgment: [["workbench", "Underwriting"], ["downside", "Downside"], ["risks", "Risks & conditions"]],
          review: [["brief", "Decision brief"], ["memo", "Memo studio"]],
          deliver: [["gate", "Final controls"], ["export", "Package options"]]
        }[snapshot.selectedStage] || []);
    const monitorBalance = latestAtOrBefore(state.monitor?.balanceSheets, state.monitor?.financialPeriodEnd);
    const monitorContext = state.workflow === "portfolio_monitor" ? {
      gates: monitorGateRows(),
      maturityDays: monitorMaturityDays(state.monitor),
      crossFootDifference: monitorBalance?.crossFootDifference
    } : null;
    const stageSummary = state.workflow === "credit_action"
      ? window.HBF_CreditPath?.stageSummary(snapshot.selectedStage, state, model)
      : window.HBF_MonitorPath?.stageSummary(snapshot.selectedStage, state, model, monitorContext);
    const summaryMarkup = stageSummary ? `<details class="step-checks"><summary><span><strong>${stageSummary.completeCount} of ${stageSummary.totalCount}</strong> step checks complete</span><span>View checks</span></summary><section class="stage-pulse" aria-label="Step completion summary">
      <div class="stage-pulse-score"><strong>${stageSummary.completeCount}/${stageSummary.totalCount}</strong><span>step checks complete</span></div>
      <div><small>Completed</small><p>${esc(stageSummary.complete.slice(0, 2).join(" · ") || "No step checks complete yet")}</p></div>
      <div><small>Next</small><p>${esc(stageSummary.remaining.slice(0, 2).join(" · ") || "This step is complete")}</p></div>
      <div><small>Control owner</small><p>${esc(stageSummary.owner)}</p></div>
    </section></details>` : "";
    return `<section class="guided-context" aria-label="Current guided step"><div class="guided-context-copy"><span class="step-chip">Step ${index} of 5</span><div><strong>${esc(snapshot.selected.label)}</strong><span>${esc(snapshot.selected.description)}</span></div></div><div class="guided-tools" aria-label="Tools in this step">${tools.map(([view, label]) => `<button type="button" data-view-link="${esc(view)}" class="tool-chip${activeView === view ? " is-active" : ""}">${esc(label)}</button>`).join("")}</div></section>${summaryMarkup}`;
  }

  function renderCreditJudgmentPlan() {
    const stress = calculateStress();
    const stressCurrent = Boolean(state.stressReviewed && stress.status === "computed" && state.scenarioResults?.inputFingerprint === stressInputFingerprint() && scenarioCalculationLedgerMatches());
    const tasks = window.HBF_CreditPath?.judgmentTasks(state, { stressCurrent }) || [];
    const complete = tasks.filter((task) => task.complete).length;
    const next = tasks.find((task) => !task.complete);
    return `<section class="judgment-plan" aria-label="Portfolio manager credit judgment path">
      <div class="judgment-plan-head"><div><p class="eyebrow">PM credit judgment path</p><h3>Finish the analysis in decision order</h3><p>Each item opens the existing governed work area. No control or evidence record is bypassed.</p></div><div class="judgment-plan-progress"><strong>${complete}/${tasks.length}</strong><span>complete</span>${next ? `<button class="button button-primary" type="button" data-credit-task="${esc(next.id)}">Continue: ${esc(next.label)}</button>` : '<span class="tag good">Judgment path complete</span>'}</div></div>
      <ol class="judgment-task-list">${tasks.map((task, taskIndex) => `<li class="judgment-task ${task.complete ? "is-complete" : ""}"><button type="button" data-credit-task="${esc(task.id)}"><span class="task-number">${task.complete ? "✓" : taskIndex + 1}</span><span><strong>${esc(task.label)}</strong><small>${esc(task.description)}</small></span><span class="task-status">${task.complete ? "Complete" : "Open"}</span></button></li>`).join("")}</ol>
    </section>`;
  }

  function numericFact(path) {
    const fact = factByPath(path);
    const value = fact ? Number(fact.value) : NaN;
    return Number.isFinite(value) ? value : null;
  }

  function monthsBetween(startText, endText) {
    if (!isValidIsoDate(startText) || !isValidIsoDate(endText)) return null;
    const start = new Date(`${startText || ""}T00:00:00Z`);
    const end = new Date(`${endText || ""}T00:00:00Z`);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end <= start) return null;
    const whole = (end.getUTCFullYear() - start.getUTCFullYear()) * 12 + end.getUTCMonth() - start.getUTCMonth();
    return whole + (end.getUTCDate() - start.getUTCDate()) / 30.4375;
  }

  function stressInputFingerprint() {
    const facts = STRESS_INPUT_PATHS.map((path) => {
      const fact = factByPath(path);
      return fact ? [path, fact.id, fact.value, fact.unit || "", fact.scale || 1, fact.entity || "", fact.asOfDate || "", fact.periodType || "", fact.scenario || "actual"] : [path, null];
    });
    return JSON.stringify({ facts, dealAsOfDate: state.deal.asOfDate || "", assumptions: state.stress || {}, ruleVersion: "HBF-STRESS-1.1" });
  }

  function calculateStress() {
    const paths = {
      proposed: "facility.proposedCommitment",
      outstanding: "facility.outstanding",
      peak: "facility.projectedPeak",
      collateral: "collateral.asCompleteValue",
      totalCost: "project.totalCost",
      remainingCosts: "project.remainingCosts",
      eligibleAdvances: "project.modeledEligibleFutureAdvances",
      committedEquity: "project.committedEquity",
      reserve: "project.remainingContingencyAndInterest",
      availableLiquidity: "guarantor.availableLiquidityAfterCalls",
      planPace: "operating.planAbsorption",
      paydownPerClosing: "operating.netPaydownPerClosing"
    };
    const inputs = Object.fromEntries(Object.entries(paths).map(([key, path]) => [key, numericFact(path)]));
    const maturityFact = factByPath("facility.proposedMaturity");
    const missing = Object.entries(inputs).filter(([, value]) => value == null).map(([key]) => paths[key]);
    const maturityMonths = monthsBetween(state.deal.asOfDate, maturityFact?.value);
    if (maturityMonths == null) missing.push("facility.proposedMaturity");
    if (missing.length) return { status: "blocked", missing: Array.from(new Set(missing)), ruleVersion: "HBF-STRESS-1.1" };

    const invalid = [];
    ["proposed", "outstanding", "peak", "remainingCosts", "eligibleAdvances", "committedEquity", "reserve", "availableLiquidity"].forEach((key) => {
      if (inputs[key] < 0) invalid.push(`${paths[key]} must be nonnegative`);
    });
    ["collateral", "totalCost", "planPace", "paydownPerClosing"].forEach((key) => {
      if (inputs[key] <= 0) invalid.push(`${paths[key]} must be greater than zero`);
    });
    if (invalid.length) return { status: "blocked", missing: [], invalid, ruleVersion: "HBF-STRESS-1.1" };

    const s = state.stress || {};
    const priceDecline = Number(s.priceDecline ?? 0) / 100;
    const slowdown = Number(s.absorptionSlowdown ?? 0) / 100;
    const cancellationPressure = Number(s.cancellationIncrease ?? 0) / 100;
    const costOverrun = Number(s.costOverrun ?? 0) / 100;
    const rateShock = Number(s.rateShock ?? 0) / 10000;
    const contractualAvailability = Math.max(0, inputs.proposed - inputs.outstanding);
    const drawableFutureAdvances = Math.min(contractualAvailability, inputs.eligibleAdvances);
    const completionCushion = drawableFutureAdvances + inputs.committedEquity - inputs.remainingCosts - inputs.reserve;
    const stressedValue = inputs.collateral * Math.max(0, 1 - priceDecline);
    const stressedLtv = stressedValue > 0 ? inputs.proposed / stressedValue : Infinity;
    const stressedPace = inputs.planPace * Math.max(0, 1 - slowdown) * Math.max(0, 1 - cancellationPressure);
    const stressedPaydownPerClosing = inputs.paydownPerClosing * Math.max(0, 1 - priceDecline);
    const monthlyPaydown = stressedPace * stressedPaydownPerClosing;
    const payoffMonths = monthlyPaydown > 0 ? inputs.peak / monthlyPaydown : Infinity;
    const maturityRunway = Number.isFinite(payoffMonths) ? maturityMonths - payoffMonths : -Infinity;
    const maturityBalloon = Math.max(0, inputs.peak - monthlyPaydown * maturityMonths);
    const overrunNeed = Math.max(0, inputs.remainingCosts * costOverrun - Math.max(0, completionCushion));
    const averageExposure = (inputs.outstanding + inputs.peak) / 2;
    const incrementalInterest = averageExposure * rateShock * (maturityMonths / 12);
    const sponsorNeed = maturityBalloon + overrunNeed + incrementalInterest;
    const supportCoverage = sponsorNeed > 0 ? inputs.availableLiquidity / sponsorNeed : null;
    const maxPriceDecline = 1 - (inputs.proposed / 0.75) / inputs.collateral;
    const maxCostOverrun = inputs.remainingCosts > 0 ? Math.max(0, completionCushion) / inputs.remainingCosts : null;
    const minimumPace = maturityMonths > 0 && stressedPaydownPerClosing > 0 ? inputs.peak / (maturityMonths * stressedPaydownPerClosing) : Infinity;
    const baseMinimumPace = maturityMonths > 0 && inputs.paydownPerClosing > 0 ? inputs.peak / (maturityMonths * inputs.paydownPerClosing) : Infinity;
    const basePayoffMonths = inputs.planPace > 0 && inputs.paydownPerClosing > 0 ? inputs.peak / (inputs.planPace * inputs.paydownPerClosing) : Infinity;
    const baseRunway = Number.isFinite(basePayoffMonths) ? maturityMonths - basePayoffMonths : -Infinity;
    const estimatedPayoffDate = Number.isFinite(payoffMonths) ? addFractionalMonths(state.deal.asOfDate, payoffMonths) : "Not calculated";
    return {
      status: "computed", ruleVersion: "HBF-STRESS-1.1", inputFingerprint: stressInputFingerprint(), inputs, maturityMonths, contractualAvailability, drawableFutureAdvances,
      completionCushion, stressedValue, stressedLtv, stressedPace, stressedPaydownPerClosing, payoffMonths, maturityRunway,
      maturityBalloon, overrunNeed, averageExposure, incrementalInterest, sponsorNeed, supportCoverage, maxPriceDecline,
      maxCostOverrun, minimumPace, baseMinimumPace, basePayoffMonths, baseRunway, estimatedPayoffDate
    };
  }

  function upsertCalculation(calculation) {
    const index = state.calculations.findIndex((item) => item.id === calculation.id);
    if (index >= 0) state.calculations[index] = calculation;
    else state.calculations.push(calculation);
  }

  function scenarioCalculationLedgerMatches(targetState = state) {
    const scenario = targetState?.scenarioResults;
    const inputs = scenario?.inputs;
    if (scenario?.status !== "computed" || !inputs || typeof inputs !== "object") return false;
    const expected = new Map([
      ["CALC02", inputs.collateral > 0 ? inputs.proposed / inputs.collateral : NaN],
      ["CALC03", inputs.totalCost > 0 ? inputs.proposed / inputs.totalCost : NaN],
      ["CALC04", scenario.completionCushion],
      ["CALC06", scenario.baseRunway],
      ["CALC07", scenario.maturityRunway],
      ["CALC09", scenario.sponsorNeed],
      ["CALC10", scenario.supportCoverage],
      ["CALC11", scenario.maturityBalloon],
      ["CALC12", scenario.incrementalInterest]
    ]);
    const sameNumber = (actual, expectedValue) => {
      if (expectedValue == null) return actual == null;
      const left = Number(actual);
      const right = Number(expectedValue);
      return Number.isFinite(left) && Number.isFinite(right) && Math.abs(left - right) <= Math.max(1e-8, Math.abs(right) * 1e-9);
    };
    return Array.from(expected).every(([id, expectedValue]) => sameNumber((targetState.calculations || []).find((item) => item.id === id)?.result, expectedValue));
  }

  function syncScenarioCalculations(result) {
    if (!result || result.status !== "computed") return;
    const proposed = result.inputs.proposed;
    const totalCost = result.inputs.totalCost;
    const ltv = proposed / result.inputs.collateral;
    const ltc = totalCost > 0 ? proposed / totalCost : Infinity;
    const signedMonths = (value) => Number.isFinite(value) ? `${value < 0 ? "(" : ""}${number(Math.abs(value), 1)} months${value < 0 ? ")" : ""}` : "Unbounded";
    upsertCalculation({ id: "CALC02", name: "Proposed commitment LTV", formula: "Proposed commitment ÷ as-complete collateral value", inputs: ["facility.proposedCommitment", "collateral.asCompleteValue"], result: ltv, display: percent(ltv), status: ltv <= 0.75 ? "pass" : "fail", comparison: "Illustrative configured limit: 75.0%" });
    upsertCalculation({ id: "CALC03", name: "Proposed commitment LTC", formula: "Proposed commitment ÷ aggregate cost basis", inputs: ["facility.proposedCommitment", "project.totalCost"], result: ltc, display: percent(ltc), status: ltc <= 0.80 ? "pass" : "fail", comparison: "Illustrative configured limit: 80.0%" });
    upsertCalculation({ id: "CALC04", name: "Completion funding cushion", formula: "min(contractual availability, modeled eligible future advances) + committed equity − remaining costs − reserve", inputs: ["facility.proposedCommitment", "facility.outstanding", "project.modeledEligibleFutureAdvances", "project.committedEquity", "project.remainingCosts", "project.remainingContingencyAndInterest"], result: result.completionCushion, display: money(result.completionCushion), status: result.completionCushion >= 0 ? "pass" : "fail", comparison: "Must be nonnegative; future eligibility is separately sourced" });
    upsertCalculation({ id: "CALC06", name: "Base payoff runway", formula: "Months to maturity − [peak exposure ÷ (plan closings/month × net paydown/closing)]", inputs: ["facility.projectedPeak", "operating.planAbsorption", "operating.netPaydownPerClosing", "facility.proposedMaturity", "deal.asOfDate"], result: result.baseRunway, display: signedMonths(result.baseRunway), status: result.baseRunway >= 0 ? "pass" : "fail", comparison: "Positive means modeled payoff before maturity" });
    upsertCalculation({ id: "CALC07", name: "Selected downside payoff runway", formula: "Months to maturity − [peak exposure ÷ (stressed pace × stressed paydown/closing)]", inputs: ["facility.projectedPeak", "operating.planAbsorption", "operating.netPaydownPerClosing", "facility.proposedMaturity", "deal.asOfDate", "selected stress assumptions"], result: result.maturityRunway, display: signedMonths(result.maturityRunway), status: result.maturityRunway >= 0 ? "pass" : "fail", comparison: "Selected scenario; negative means payoff after maturity" });
    upsertCalculation({ id: "CALC09", name: "Selected downside support need", formula: "Maturity balloon + uncovered cost overrun + incremental interest through maturity", inputs: ["facility.projectedPeak", "operating.netPaydownPerClosing", "project.remainingCosts", "CALC04", "facility.outstanding", "selected stress assumptions"], result: result.sponsorNeed, display: money(result.sponsorNeed), status: result.sponsorNeed === 0 ? "pass" : "watch", comparison: `Balloon ${money(result.maturityBalloon)}; overrun ${money(result.overrunNeed)}; rate ${money(result.incrementalInterest)}` });
    upsertCalculation({ id: "CALC10", name: "Available guarantor liquidity coverage", formula: "Liquidity after identified calls ÷ selected downside support need", inputs: ["guarantor.availableLiquidityAfterCalls", "CALC09"], result: result.supportCoverage, display: result.supportCoverage == null ? "No support need" : multiple(result.supportCoverage), status: result.supportCoverage == null || result.supportCoverage >= 1.25 ? "pass" : result.supportCoverage >= 1 ? "watch" : "fail", comparison: "Before refreshed verification and any unidentified calls" });
    upsertCalculation({ id: "CALC11", name: "Selected downside maturity balloon", formula: "max(0, peak exposure − stressed pace × maturity months × stressed paydown per closing)", inputs: ["facility.projectedPeak", "operating.planAbsorption", "operating.netPaydownPerClosing", "facility.proposedMaturity", "deal.asOfDate", "selected stress assumptions"], result: result.maturityBalloon, display: money(result.maturityBalloon), status: result.maturityBalloon === 0 ? "pass" : "fail", comparison: result.maturityBalloon === 0 ? "No balance remains at modeled maturity" : `${money(result.maturityBalloon)} remains at modeled maturity` });
    upsertCalculation({ id: "CALC12", name: "Selected downside incremental interest", formula: "average(current outstanding, projected peak) × selected rate shock × maturity months ÷ 12", inputs: ["facility.outstanding", "facility.projectedPeak", "facility.proposedMaturity", "deal.asOfDate", "selected stress assumptions"], result: result.incrementalInterest, display: money(result.incrementalInterest), status: result.incrementalInterest === 0 ? "pass" : "watch", comparison: `${money(result.averageExposure)} average exposure under the recorded ${state.stress.rateShock}-basis-point shock` });
    state.scenarioResults = { ...result, assumptions: clone(state.stress), inputFingerprint: stressInputFingerprint(), recordedAt: new Date().toISOString() };
  }

  function stressNarrative(result) {
    if (!result || result.status !== "computed") return "Downside analysis is blocked until all named inputs are accepted.";
    const timing = result.maturityRunway >= 0 ? `${number(result.maturityRunway, 1)} months before maturity` : `${number(Math.abs(result.maturityRunway), 1)} months after maturity`;
    return `Under the selected case (${state.stress.priceDecline}% price decline, ${state.stress.absorptionSlowdown}% absorption slowdown, ${state.stress.costOverrun}% remaining-cost overrun, ${state.stress.rateShock} basis-point rate shock and ${state.stress.cancellationIncrease}% additional net-closing drag), net closings fall to ${number(result.stressedPace, 1)} per month and modeled payoff occurs ${timing}. The modeled maturity balloon is ${money(result.maturityBalloon)}; uncovered cost overrun is ${money(result.overrunNeed)}; incremental interest is ${money(result.incrementalInterest)}; and combined support need is ${money(result.sponsorNeed)}. Available liquidity after identified calls covers that need ${result.supportCoverage == null ? "without a draw" : multiple(result.supportCoverage)}. These are transparent scenario calculations, not an approval or risk-rating decision.`;
  }

  function recordStressScenario() {
    const result = calculateStress();
    if (result.status !== "computed") {
      const reason = (result.missing || []).length ? `Accept these inputs first: ${result.missing.join(", ")}.` : (result.invalid || []).join("; ");
      return toast(`Scenario blocked. ${reason}`, "error");
    }
    syncScenarioCalculations(result);
    state.stressReviewed = true;
    state.issues = state.issues.filter((issue) => issue.id !== "STRESS-STALE" && issue.id !== "STRESS-INPUTS" && issue.id !== "I02");
    if (result.maturityRunway < 0 || (result.supportCoverage != null && result.supportCoverage < 1) || result.completionCushion < 0) {
      const isBlocker = result.completionCushion < 0 || (result.supportCoverage != null && result.supportCoverage < 1);
      state.issues.push({ id: "I02", severity: isBlocker ? "blocker" : "warning", title: isBlocker ? "Selected downside requires a structural cure or Credit action" : "Selected downside payoff extends beyond maturity", detail: `Recorded scenario repays ${number(Math.abs(result.maturityRunway), 1)} months ${result.maturityRunway < 0 ? "after" : "before"} maturity with a ${money(result.maturityBalloon)} maturity balloon, ${money(result.sponsorNeed)} combined support need and ${result.supportCoverage == null ? "no required draw" : multiple(result.supportCoverage)} available-liquidity coverage.`, actionView: "downside", status: "open" });
    }
    const section = state.memoSections.find((item) => item.id === "downside");
    if (section && (state.mode === "demo" || section.generatedByScenario || section.narrative.trim().length === 0)) {
      section.narrative = stressNarrative(result);
      section.generatedByScenario = true;
      section.classification = "deterministic_calculation";
      section.supportingFactIds = STRESS_INPUT_PATHS.map((path) => factByPath(path)?.id).filter(Boolean);
    } else if (section) {
      state.issues.push({ id: "STRESS-NARRATIVE", severity: "blocker", title: "Downside narrative requires PM refresh", detail: "A new scenario was recorded after the PM-authored downside narrative. Reconcile the narrative to the recorded results before finalization.", actionView: "memo", status: "open" });
    }
    const risk = state.risks.find((item) => item.id === "R01");
    if (risk && state.mode === "demo") {
      risk.evidence = `The recorded downside produces ${number(result.stressedPace, 1)} net closings per month, payoff ${number(Math.abs(result.maturityRunway), 1)} months after maturity and a ${money(result.maturityBalloon)} maturity balloon.`;
      risk.condition = `Use ${number(result.baseMinimumPace, 1)} net closings per month as the base-price maturity trigger; under the selected price decline, ${number(result.minimumPace, 1)} per month is required. Below the applicable trigger, suspend new spec starts and require an inventory-reduction and curtailment plan.`;
    }
    invalidateAttestations("The recorded downside scenario and its dependent analysis changed.");
    state.finalized = false;
    toast("Selected downside was recalculated, recorded and linked to the memo.");
    renderViewPreservingDrafts();
  }

  function addFractionalMonths(dateText, months) {
    const date = new Date(`${dateText || ""}T00:00:00Z`);
    if (Number.isNaN(date.getTime())) return "Not calculated";
    date.setUTCDate(date.getUTCDate() + Math.round(Number(months || 0) * 30.4375));
    return date.toISOString().slice(0, 10);
  }

  function memoNarrative(id) {
    return state.memoSections.find((section) => section.id === id)?.narrative?.trim() || "Not yet completed.";
  }

  function metricRow(id) {
    const metric = calcById(id);
    if (!metric) return `<tr><td><strong>${esc(id)}</strong></td><td>—</td><td>Required inputs have not been accepted.</td><td><span class="metric-signal bad">Blocked</span></td></tr>`;
    const signalClass = metric.status === "pass" ? "good" : metric.status === "fail" ? "bad" : "watch";
    const signalText = metric.status === "pass" ? "Supported" : metric.status === "fail" ? "Outside" : "Watch";
    return `<tr><td><strong>${esc(metric.name)}</strong> ${factEvidenceButton(metric.id, metric.name)}</td><td>${esc(metric.display)}</td><td>${esc(metric.comparison)}</td><td><span class="metric-signal ${signalClass}">${signalText}</span></td></tr>`;
  }

  function renderBrief() {
    const currentCommitment = displayFact("facility.currentCommitment", "$35.0MM");
    const proposedCommitment = displayFact("facility.proposedCommitment", "$40.0MM");
    const outstanding = displayFact("facility.outstanding", "$22.4MM");
    const peak = displayFact("facility.projectedPeak", "$31.8MM");
    const relationshipExposure = displayFact("relationship.proFormaExposure", "$46.2MM");
    const stress = calculateStress();
    const currentChanges = state.changes.filter((change) => change.recordStatus !== "superseded");
    const currentRisks = state.risks.filter((risk) => risk.recordStatus !== "superseded");
    const exceptions = window.HBF_CreditPath?.officerExceptions(state) || openIssues().filter((issue) => issue.severity !== "note").map((issue) => ({ ...issue, actionView: issue.actionView || "gate" }));
    const repaymentEvidence = (window.HBF_CreditPath?.evidenceIdsForPaths(state, ["facility.proposedMaturity", "operating.actualAbsorption", "operating.planAbsorption", "operating.netPaydownPerClosing"], 8) || []).map(citationToken).join("");
    const downsideEvidence = ["CALC07", "CALC09", "CALC10"].filter((id) => calcById(id)).map(citationToken).join("");
    const supportedFacts = state.facts.filter((fact) => ACCEPTED_FACT_STATUSES.has(fact.status)).length;
    const completeMemoSections = state.memoSections.filter((section) => section.narrative.trim().length >= 60).length;
    const briefActions = '<button class="button button-quiet" type="button" data-view-link="memo">Open full 17-section memo</button><button class="button button-primary" type="button" data-view-link="export">Open package</button>';
    const riskRows = currentRisks.length ? currentRisks.slice(0, 3).map((risk) => {
      const evidence = acceptedFactReferences(risk).map(citationToken).join("");
      return `<article class="officer-risk"><div><strong>${esc(risk.title)}</strong>${evidence ? `<span class="officer-evidence">${evidence}</span>` : ""}</div><p><b>Consequence:</b> ${esc(risk.consequence || "Not yet stated.")}</p><p><b>Protection:</b> ${esc(risk.mitigant || "Not yet stated.")}</p><p><b>Residual:</b> ${esc(risk.residual || "Not yet stated.")}</p></article>`;
    }).join("") : '<div class="officer-empty">No current risk chain has been entered.</div>';
    const conditionRows = state.conditions.length ? state.conditions.slice(0, 4).map((condition) => `<article class="officer-condition"><div><strong>${esc(condition.requirement)}</strong><span class="tag ${condition.status === "Open" ? "warning" : "info"}">${esc(condition.status || "Open")}</span></div><p>${esc(condition.phase || "Timing not stated")} • ${esc(condition.owner || "Owner not stated")}</p><small>Purpose: ${esc(condition.purpose || "Not stated")} · Verify: ${esc(condition.verification || "Not stated")}</small></article>`).join("") : '<div class="officer-empty">No conditions have been entered.</div>';
    const changeRows = currentChanges.length ? currentChanges.map((change) => `<tr><td><strong>${esc(change.field)}</strong></td><td>${esc(change.prior || "—")}</td><td>${esc(change.current || "—")}</td><td>${esc(change.proposed || "—")}</td><td>${esc(change.impact || "Not stated")}${acceptedFactReferences(change).map(citationToken).join("")}</td></tr>`).join("") : '<tr><td colspan="5">No current renewal or modification changes have been entered.</td></tr>';

    return `${pageHead("Credit Officer review mode", `${state.deal.borrower} — decision brief`, "Recommendation, request, repayment, downside, risks, conditions, exceptions and evidence in one two-minute review.", briefActions)}
      <section class="officer-mode-bar"><div><strong>Decision-first review</strong><span>Read the conclusion, challenge the weak case, then open any evidence token without leaving this surface.</span></div>${statusMarkup()}</section>
      <section class="decision-banner" aria-label="Decision summary">
        <div class="recommendation"><small>PM recommendation</small><strong>${esc(state.deal.recommendation)}</strong><span>${esc(state.deal.dealType)} • ${esc(state.deal.facilityType)}</span></div>
        <div><small>Request</small><strong>${esc(state.deal.request)}</strong><span>${esc(currentCommitment)} current • ${esc(proposedCommitment)} proposed</span></div>
        <div><small>Current / proposed RR</small><strong>${esc(state.deal.currentRating)}</strong><span>${esc(state.deal.proposedRating)} proposed</span></div>
        <div><small>Funded / peak</small><strong>${esc(outstanding)}</strong><span>${esc(peak)} projected peak</span></div>
        <div><small>Pro forma relationship</small><strong>${esc(relationshipExposure)}</strong><span>${openIssues("blocker").length} blocker • ${openIssues("warning").length} warnings</span></div>
      </section>

      <section class="thesis-card officer-thesis">
        <div class="section-label"><h3>Credit thesis and residual acceptance</h3><button class="text-button" type="button" data-view-link="memo">Challenge full narrative →</button></div>
        <div class="thesis-grid">
          <div class="thesis-item"><small>Why support / recommendation</small><p>${esc(memoNarrative("executive"))}</p></div>
          <div class="thesis-item"><small>Residual risk acceptance</small><p>${esc(memoNarrative("conclusion"))}</p></div>
        </div>
      </section>

      <div class="officer-review-grid">
        <article class="officer-card">
          <div class="officer-card-head"><div><p class="eyebrow">1 · Cash exit</p><h3>Primary repayment</h3></div><span class="tag ${calcById("CALC06")?.status === "pass" ? "good" : "warning"}">${esc(calcById("CALC06")?.display || "Incomplete")}</span></div>
          <p class="officer-narrative">${esc(memoNarrative("repayment"))}</p>
          <div class="officer-facts"><div><span>Actual / plan pace</span><strong>${esc(displayFact("operating.actualAbsorption", "5.9 homes/month"))} / ${esc(displayFact("operating.planAbsorption", "6.5 homes/month"))}</strong></div><div><span>Net paydown / closing</span><strong>${esc(displayFact("operating.netPaydownPerClosing", "$252M"))}</strong></div><div><span>Proposed maturity</span><strong>${esc(displayFact("facility.proposedMaturity", "Jun. 30, 2028"))}</strong></div></div>
          <div class="officer-card-action"><span class="officer-evidence"><b>Evidence</b>${repaymentEvidence || " No controlling fact links yet"}</span><button class="text-button" type="button" data-credit-task="repayment">Open repayment analysis →</button></div>
        </article>
        <article class="officer-card">
          <div class="officer-card-head"><div><p class="eyebrow">2 · Weak case</p><h3>Selected downside</h3></div><span class="tag ${stress.status === "computed" && state.stressReviewed ? "good" : "bad"}">${stress.status === "computed" && state.stressReviewed ? "Recorded" : "Not current"}</span></div>
          ${stress.status === "blocked" ? `<div class="officer-alert"><strong>Calculation blocked</strong><p>Accept sourced values for ${esc((stress.missing || []).join(", ") || "the required inputs")}.</p></div>` : `<div class="officer-facts"><div><span>Selected assumptions</span><strong>${esc(state.stress.priceDecline)}% price · ${esc(state.stress.absorptionSlowdown)}% pace · ${esc(state.stress.costOverrun)}% cost · ${esc(state.stress.rateShock)} bps</strong></div><div><span>Payoff / maturity balloon</span><strong>${esc(formatDate(stress.estimatedPayoffDate))} / ${money(stress.maturityBalloon)}</strong></div><div><span>Support need / coverage</span><strong>${money(stress.sponsorNeed)} / ${stress.supportCoverage == null ? "No draw required" : multiple(stress.supportCoverage)}</strong></div></div>`}
          <div class="officer-card-action"><span class="officer-evidence"><b>Calculations</b>${downsideEvidence || " Not recorded"}</span><button class="text-button" type="button" data-view-link="downside">Challenge assumptions →</button></div>
        </article>
        <article class="officer-card span-2">
          <div class="officer-card-head"><div><p class="eyebrow">3 · Loss path</p><h3>Principal risks and protections</h3></div><span class="tag ${currentRisks.length ? "warning" : "bad"}">${currentRisks.length} current chain${currentRisks.length === 1 ? "" : "s"}</span></div>
          <div class="officer-risk-list">${riskRows}</div><div class="officer-card-action"><span>Evidence links open the exact controlling fact.</span><button class="text-button" type="button" data-view-link="risks">Open full risk challenge →</button></div>
        </article>
        <article class="officer-card span-2">
          <div class="officer-card-head"><div><p class="eyebrow">4 · Bank response</p><h3>Conditions</h3></div><span class="tag ${state.conditions.length ? "info" : "bad"}">${state.conditions.length} control${state.conditions.length === 1 ? "" : "s"}</span></div>
          <div class="officer-condition-list">${conditionRows}</div><div class="officer-card-action"><span>Each condition retains timing, owner, purpose and verification.</span><button class="text-button" type="button" data-credit-task="conditions">Open condition register →</button></div>
        </article>
      </div>

      <section class="panel officer-exceptions mt-15">
        <div class="panel-head"><div><p class="eyebrow">5 · Challenge queue</p><h3>Exceptions and unresolved matters</h3><p>Blockers appear first; warnings remain visible to the reviewer.</p></div><span class="tag ${exceptions.some((item) => item.severity === "blocker") ? "bad" : exceptions.length ? "warning" : "good"}">${exceptions.length ? `${exceptions.length} open` : "None open"}</span></div>
        <div class="officer-exception-list">${exceptions.length ? exceptions.slice(0, 10).map((item) => `<article class="officer-exception"><span class="tag ${item.severity === "blocker" ? "bad" : "warning"}">${esc(item.severity || "warning")}</span><div><strong>${esc(item.title || item.id)}</strong><p>${esc(item.detail || "Review required.")}</p></div><button class="button button-quiet" type="button" data-view-link="${esc(item.actionView || "gate")}">Review</button></article>`).join("") : '<div class="officer-empty is-clear"><strong>No unresolved exceptions or watch items.</strong><span>The officer can still challenge every source, calculation and PM conclusion.</span></div>'}</div>
      </section>

      <details class="panel metrics-panel officer-supporting mt-15"><summary class="panel-summary">Decision metrics and calculation definitions</summary><div class="table-wrap"><table class="metrics-table"><thead><tr><th>Metric</th><th>Recorded result</th><th>Requirement / interpretation</th><th>Signal</th></tr></thead><tbody>${["CALC01", "CALC02", "CALC03", "CALC04", "CALC06", "CALC07", "CALC09", "CALC10"].map(metricRow).join("")}</tbody></table></div><div class="panel-body">${stress.status === "blocked" ? `<div class="note-box"><strong>Downside is blocked:</strong> accept ${esc((stress.missing || []).join(", "))} before recording a scenario.</div>` : `<div class="note-box"><strong>Scenario control:</strong> ${state.stressReviewed ? "Current assumptions match the calculation ledger." : "Assumption changes are not yet recorded; readiness remains blocked."}</div>`}</div></details>

      <details class="panel officer-supporting mt-15"><summary class="panel-summary">${esc(state.deal.dealType)} transaction changes (${currentChanges.length})</summary><div class="table-wrap"><table class="data-table"><thead><tr><th>Field</th><th>Prior approval</th><th>Current</th><th>Proposed</th><th>Credit impact / evidence</th></tr></thead><tbody>${changeRows}</tbody></table></div><div class="panel-body right"><button class="text-button" type="button" data-credit-task="changes">Open governed change record →</button></div></details>

      <section class="officer-footer mt-15"><div><strong>Review support</strong><span>${supportedFacts} accepted / supported facts · ${state.sources.length} registered sources · ${completeMemoSections}/17 memo sections complete</span></div><div><span class="tag ${openIssues("blocker").length ? "bad" : "good"}">${openIssues("blocker").length} blocker</span><span class="tag ${openIssues("warning").length ? "warning" : "good"}">${openIssues("warning").length} warning${openIssues("warning").length === 1 ? "" : "s"}</span><button class="button button-quiet" type="button" data-view-link="sources">Open evidence register</button><button class="button button-primary" type="button" data-view-link="memo">Open full memo</button></div></section>
      <p class="muted mt-15">${state.mode === "demo" ? "Synthetic demonstration data. " : "Live local session. "}Displayed limits are illustrative configuration values, not Lender policy or an automated regulatory determination.</p>`;
  }

  function monitorValue(value, type, digits) {
    if (value == null || value === "" || !Number.isFinite(Number(value))) return "Not provided";
    if (type === "money") return money(value, digits);
    if (type === "percent") return percent(value, digits);
    if (type === "multiple") return multiple(value, digits);
    if (type === "percentage_points") return `${(Number(value) * 100).toFixed(digits == null ? 1 : digits)} pts`;
    if (type === "days") return `${number(value, 0)} days`;
    if (type === "months") return `${number(value, 1)} months`;
    return number(value, digits);
  }

  function monitorChange(current, prior, type) {
    if (current == null || prior == null || !Number.isFinite(Number(current)) || !Number.isFinite(Number(prior))) return { display: "Not comparable", className: "neutral", direction: "—" };
    const delta = Number(current) - Number(prior);
    const favorableDown = ["cancellationRate", "operatingExpenseRatio", "leverage", "utilization"].includes(type);
    const favorable = delta === 0 ? null : favorableDown ? delta < 0 : delta > 0;
    const display = type === "money" ? money(delta) : type === "percent" ? `${delta >= 0 ? "+" : ""}${(delta * 100).toFixed(1)} pts` : `${delta >= 0 ? "+" : ""}${number(delta, 1)}`;
    return { display, className: favorable == null ? "neutral" : favorable ? "good" : "warning", direction: delta > 0 ? "↑" : delta < 0 ? "↓" : "→" };
  }

  function seriesAtOrBefore(series, cutoff) {
    return (Array.isArray(series) ? series : [])
      .filter((item) => item?.periodEnd && (!cutoff || item.periodEnd <= cutoff))
      .sort((a, b) => String(a.periodEnd).localeCompare(String(b.periodEnd)));
  }

  function latestAtOrBefore(series, cutoff) {
    return seriesAtOrBefore(series, cutoff).slice(-1)[0] || null;
  }

  function monitorMaturityDays(monitor) {
    if (!isValidIsoDate(monitor?.reviewAsOfDate || "") || !isValidIsoDate(monitor?.facility?.lineMaturity || "")) return null;
    return Math.round((Date.parse(`${monitor.facility.lineMaturity}T00:00:00Z`) - Date.parse(`${monitor.reviewAsOfDate}T00:00:00Z`)) / 86400000);
  }

  function monitorFactValueMatches(actual, expected) {
    if (typeof expected === "number" && Number.isFinite(expected)) return Number.isFinite(Number(actual)) && Math.abs(Number(actual) - expected) <= Math.max(1e-8, Math.abs(expected) * 1e-9);
    return String(actual == null ? "" : actual).trim() === String(expected == null ? "" : expected).trim();
  }

  function comparablePriorYear(current, prior) {
    if (!isValidIsoDate(current?.periodEnd || "") || !isValidIsoDate(prior?.periodEnd || "")) return false;
    const currentDate = new Date(`${current.periodEnd}T00:00:00Z`);
    const priorDate = new Date(`${prior.periodEnd}T00:00:00Z`);
    return currentDate.getUTCFullYear() - priorDate.getUTCFullYear() === 1 && currentDate.getUTCMonth() === priorDate.getUTCMonth() && currentDate.getUTCDate() === priorDate.getUTCDate();
  }

  function lineChart(points, definitions, label) {
    const rows = (Array.isArray(points) ? points : []).filter((point) => point?.periodEnd).slice(-12);
    if (rows.length < 2) return `<div class="chart-empty">${esc(label)} needs at least two dated observations.</div>`;
    const width = 720; const height = 220; const left = 48; const right = 18; const top = 22; const bottom = 42;
    const values = rows.flatMap((point) => definitions.map((item) => Number(point[item.key])).filter(Number.isFinite));
    if (!values.length) return `<div class="chart-empty">${esc(label)} has no usable values.</div>`;
    const min = Math.min(0, ...values); const max = Math.max(...values); const span = max - min || 1;
    const x = (index) => left + index * ((width - left - right) / Math.max(1, rows.length - 1));
    const y = (value) => top + (max - value) / span * (height - top - bottom);
    const colors = ["#0f6d76", "#c47a22", "#37566b"];
    const paths = definitions.map((definition, definitionIndex) => {
      const valid = rows.map((point, index) => ({ value: Number(point[definition.key]), index })).filter((item) => Number.isFinite(item.value));
      if (valid.length < 2) return "";
      const pointsText = valid.map((item) => `${x(item.index).toFixed(1)},${y(item.value).toFixed(1)}`).join(" ");
      return `<polyline fill="none" stroke="${colors[definitionIndex]}" stroke-width="3" points="${pointsText}"></polyline>${valid.map((item) => `<circle cx="${x(item.index).toFixed(1)}" cy="${y(item.value).toFixed(1)}" r="4" fill="${colors[definitionIndex]}"></circle>`).join("")}`;
    }).join("");
    const labels = rows.map((point, index) => `<text x="${x(index).toFixed(1)}" y="202" text-anchor="middle">${esc(point.periodEnd.slice(2, 7))}</text>`).join("");
    const legend = definitions.map((definition, index) => `<span><i style="background:${colors[index]}"></i>${esc(definition.label)}</span>`).join("");
    return `<div class="monitor-chart"><div class="chart-legend">${legend}</div><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(label)}"><line x1="${left}" y1="${height - bottom}" x2="${width - right}" y2="${height - bottom}" stroke="#cbd6dc"></line>${paths}${labels}</svg></div>`;
  }

  function monitorCalc(id) {
    return (state.monitor?.calculations || []).find((item) => item.id === id) || null;
  }

  function covenantMonitorDisplay(item, field) {
    const value = item?.[field];
    if (value == null) return "Not provided";
    return monitorValue(value, item.valueType === "number" ? "number" : item.valueType);
  }

  function renderMonitor() {
    const monitor = state.monitor;
    const guidedMonitor = window.HBF_MonitorView?.render({
      state,
      stage: activeStage,
      gates: monitorGateRows(),
      maturityDays: monitorMaturityDays(monitor),
      helpers: { esc, formatDate, monitorValue, monitorChange, pageHead, lineChart, covenantStatusClass, covenantRequiresReview, monitorActionIsTerminal, monitorActionIsCancelled }
    });
    if (guidedMonitor) return guidedMonitor;
    if (!monitor) {
      return `${pageHead("Recurring credit surveillance", "Build the quarterly review from the same governed record", "Load the approved quarterly monitor workbook or resume a prior checkpoint. The Studio will use an explicit review date, preserve anomalies and create a decision-first officer report.")}
        <section class="monitor-empty"><div class="monitor-empty-mark">Q</div><h3>No quarterly snapshot is loaded</h3><p>The monitor workflow reuses the evidence ledger, issue queue, covenants, rating judgment and review pack. Customer information stays in this browser tab unless you explicitly download an output.</p><div class="empty-actions"><button class="button button-primary" type="button" data-trigger-monitor>Load quarterly monitor</button><button class="button button-quiet" type="button" data-trigger-checkpoint>Resume checkpoint</button></div><p class="muted">Supported workbook family: HBF quarterly portfolio monitor v2.1. Detailed income-statement and balance-sheet schedules remain available for analysis even when omitted from the officer PDF.</p></section>`;
    }

    const quarterlyThroughCutoff = seriesAtOrBefore(monitor.financial?.quarterly, monitor.financialPeriodEnd);
    const ytdThroughCutoff = seriesAtOrBefore(monitor.financial?.ytd, monitor.financialPeriodEnd);
    const ttmThroughCutoff = seriesAtOrBefore(monitor.financial?.ttm, monitor.financialPeriodEnd);
    const balanceThroughCutoff = seriesAtOrBefore(monitor.balanceSheets, monitor.financialPeriodEnd);
    const inventoryThroughCutoff = seriesAtOrBefore(monitor.inventorySeries, monitor.inventoryPeriodEnd);
    const bankingThroughCutoff = seriesAtOrBefore(monitor.bankingSeries, monitor.reviewAsOfDate);
    const latestQuarter = quarterlyThroughCutoff.slice(-1)[0] || null;
    const priorQuarter = quarterlyThroughCutoff.length >= 2 ? quarterlyThroughCutoff.at(-2) : null;
    const currentYtd = ytdThroughCutoff.slice(-1)[0] || null;
    const priorYtdCandidate = ytdThroughCutoff.length >= 2 ? ytdThroughCutoff.at(-2) : null;
    const priorYtd = comparablePriorYear(currentYtd, priorYtdCandidate) ? priorYtdCandidate : null;
    const latestTtm = ttmThroughCutoff.slice(-1)[0] || null;
    const latestBalance = balanceThroughCutoff.slice(-1)[0] || null;
    const priorBalance = balanceThroughCutoff.length >= 2 ? balanceThroughCutoff.at(-2) : null;
    const latestInventory = inventoryThroughCutoff.slice(-1)[0] || null;
    const latestBanking = bankingThroughCutoff.slice(-1)[0] || null;
    const priorBanking = bankingThroughCutoff.length >= 2 ? bankingThroughCutoff[0] : null;
    const revenueDelta = monitorChange(currentYtd?.revenue, priorYtd?.revenue, "money");
    const closingsDelta = monitorChange(currentYtd?.closings, priorYtd?.closings, "number");
    const marginDelta = monitorChange(latestQuarter?.grossMargin, priorQuarter?.grossMargin, "percent");
    const outstandingDelta = monitorChange(latestBanking?.outstanding, priorBanking?.outstanding, "money");
    const openWatch = (monitor.watchItems || []).filter((item) => item.status !== "resolved");
    const pastDue = (monitor.reportingItems || []).filter((item) => item.status === "Past due");
    const covenantExceptions = (monitor.covenants || []).filter(covenantRequiresReview);
    const unresolvedAnomalies = (monitor.anomalies || []).filter((item) => item.status !== "resolved");
    const monitoringReady = monitorGateRows().every((gate) => gate.pass);

    const metricRows = [
      ["YTD revenue", monitorValue(currentYtd?.revenue, "money"), monitorValue(priorYtd?.revenue, "money"), revenueDelta],
      ["YTD closings", monitorValue(currentYtd?.closings, "number", 0), monitorValue(priorYtd?.closings, "number", 0), closingsDelta],
      ["Quarterly gross margin", monitorValue(latestQuarter?.grossMargin, "percent"), monitorValue(priorQuarter?.grossMargin, "percent"), marginDelta],
      ["TTM net income", monitorValue(latestTtm?.netIncome, "money"), "TTM", { display: monitorValue(latestTtm?.netMargin, "percent"), className: "neutral", direction: "" }],
      ["Facility outstanding", monitorValue(latestBanking?.outstanding, "money"), monitorValue(priorBanking?.outstanding, "money"), outstandingDelta],
      ["Facility utilization", monitorValue(latestBanking?.utilization, "percent"), monitorValue(priorBanking?.utilization, "percent"), monitorChange(latestBanking?.utilization, priorBanking?.utilization, "utilization")],
      ["Tangible net worth", monitorValue(latestBalance?.tangibleNetWorth, "money"), priorBalance ? monitorValue(priorBalance.tangibleNetWorth, "money") : "Not comparable", monitorChange(latestBalance?.tangibleNetWorth, priorBalance?.tangibleNetWorth, "money")],
      ["Lot supply", monitorValue(monitorCalc("MON-LOT-001")?.result ?? latestInventory?.lotMonthsSupply, "months"), "TTM closing pace", { display: latestInventory?.dataGranularity === "quarterly_allocated_monthly" ? "Quarterly allocation" : "Current", className: latestInventory?.lotMonthsSupply > 60 ? "warning" : "neutral", direction: "" }]
    ];

    return `${pageHead("Quarterly portfolio monitor", `${monitor.identity?.borrower || state.deal.borrower} — ${formatDate(monitor.reportingPeriodEnd)} review`, "A decision-first view of performance, exposure, reporting, covenants, watch items and actions. Detailed schedules remain underneath the conclusions.", `<button class="button button-quiet" type="button" data-print-monitor>Print / save PDF</button><button class="button button-primary" type="button" data-export-monitor>Download Word monitor</button>`)}
      <section class="monitor-hero ${monitoringReady ? "is-ready" : "is-watch"}">
        <div class="monitor-assessment"><small>PM monitoring assessment</small><strong>${esc(monitor.assessment || "PM review required")}</strong><span>${esc(monitor.conclusion || "Portfolio manager conclusion required.")}</span></div>
        <div class="monitor-stat"><small>Current / recommended RR</small><strong>${esc(monitor.rating?.current || state.deal.currentRating || "Not provided")}</strong><span>${esc(monitor.rating?.recommended || state.deal.proposedRating || "PM selection required")} recommended</span></div>
        <div class="monitor-stat"><small>Outstanding / utilization</small><strong>${esc(monitorValue(latestBanking?.outstanding, "money"))}</strong><span>${esc(monitorValue(latestBanking?.utilization, "percent"))} at ${formatDate(latestBanking?.periodEnd)}</span></div>
        <div class="monitor-stat"><small>Deposits / UPB</small><strong>${esc(monitorValue(latestBanking?.deposits, "money"))}</strong><span>${esc(monitorValue(latestBanking?.depositCoverage, "percent"))} coverage</span></div>
        <div class="monitor-stat"><small>Review status</small><strong>${monitoringReady ? "Controls complete" : `${monitorGateRows().filter((item) => !item.pass).length} controls open`}</strong><span>${openWatch.length} watch items • ${pastDue.length} past due</span></div>
      </section>

      <section class="date-integrity" aria-label="Reporting cutoffs">
        <div><small>Explicit review date</small><strong>${formatDate(monitor.reviewAsOfDate)}</strong><span>Computer date is never used</span></div>
        <div><small>Financial cutoff</small><strong>${formatDate(monitor.financialPeriodEnd)}</strong><span>${monitor.financialPeriodEnd === monitor.reportingPeriodEnd ? "Aligned" : "Different from review period"}</span></div>
        <div><small>Inventory cutoff</small><strong>${formatDate(monitor.inventoryPeriodEnd)}</strong><span>${monitor.inventoryPeriodEnd === monitor.financialPeriodEnd ? "Aligned" : "Separate source date"}</span></div>
        <div><small>Banking cutoff</small><strong>${formatDate(latestBanking?.periodEnd)}</strong><span>Latest populated ≤ review date</span></div>
      </section>

      <div class="monitor-grid mt-15">
        <section class="panel monitor-metrics span-2"><div class="panel-head"><div><p class="eyebrow">Performance signals</p><h3>Current, comparable and directional change</h3></div><span class="tag info">No automated rating</span></div><div class="table-wrap"><table class="data-table monitor-table"><caption>Quarterly monitoring metrics</caption><thead><tr><th>Metric</th><th>Current</th><th>Comparable</th><th>Change / interpretation</th></tr></thead><tbody>${metricRows.map(([label, current, prior, delta]) => `<tr><td><strong>${esc(label)}</strong></td><td>${esc(current)}</td><td>${esc(prior)}</td><td><span class="metric-signal ${esc(delta.className)}">${esc(delta.direction)} ${esc(delta.display)}</span></td></tr>`).join("")}</tbody></table></div></section>
        <section class="panel exception-panel"><div class="panel-head"><div><p class="eyebrow">Review by exception</p><h3>What needs attention</h3></div><span class="tag ${openWatch.some((item) => item.severity === "blocker") ? "bad" : "warning"}">${openWatch.length} open</span></div><div class="panel-body"><ul class="monitor-watch-list">${openWatch.slice(0, 6).map((item) => `<li><span class="severity ${esc(item.severity)}">${esc(item.severity)}</span><div><strong>${esc(item.title)}</strong><p>${esc(item.detail)}</p><small>${esc(item.owner || "Portfolio Manager")} • ${esc(item.module || "Monitoring")}</small></div></li>`).join("") || "<li>No open watch items.</li>"}</ul></div></section>
      </div>

      <div class="monitor-chart-grid mt-15">
        <section class="panel"><div class="panel-head"><h3>Sales and closings</h3><span class="tag neutral">${esc(latestInventory?.dataGranularity === "quarterly_allocated_monthly" ? "Quarterly allocations" : "Dated series")}</span></div><div class="panel-body">${lineChart(inventoryThroughCutoff, [{ key: "netSales", label: "Net sales" }, { key: "closings", label: "Closings" }], "Net sales and closings trend")}</div></section>
        <section class="panel"><div class="panel-head"><h3>Inventory and backlog</h3><span class="tag ${latestInventory?.lotMonthsSupply > 60 ? "warning" : "neutral"}">${esc(monitorValue(latestInventory?.lotMonthsSupply, "months"))} lot supply</span></div><div class="panel-body">${lineChart(inventoryThroughCutoff, [{ key: "totalUnits", label: "Total units" }, { key: "backlog", label: "Backlog" }, { key: "specUnderConstruction", label: "Spec U/C" }], "Inventory composition trend")}</div></section>
        <section class="panel"><div class="panel-head"><h3>Banking relationship</h3><span class="tag info">${esc(outstandingDelta.direction)} ${esc(outstandingDelta.display)} UPB</span></div><div class="panel-body">${lineChart(bankingThroughCutoff, [{ key: "outstanding", label: "Outstanding" }, { key: "deposits", label: "Deposits" }], "Outstanding and deposit trend")}</div></section>
      </div>

      <div class="monitor-grid mt-15">
        <section class="panel span-2"><div class="panel-head"><div><p class="eyebrow">Covenant protection</p><h3>Actual, requirement and normalized headroom</h3></div><span class="tag ${covenantExceptions.length ? "warning" : "good"}">${covenantExceptions.length ? `${covenantExceptions.length} exception / review` : "Reported compliant"}</span></div><div class="table-wrap"><table class="data-table"><caption>Current covenant tests</caption><thead><tr><th>Covenant</th><th>Requirement</th><th>Actual</th><th>Headroom</th><th>Status</th><th>Source</th></tr></thead><tbody>${(monitor.covenants || []).map((item) => `<tr><td><strong>${esc(item.name)}</strong><br><span class="muted">${esc(item.entity || "Borrower")} • ${formatDate(item.testDate)}</span></td><td>${esc(item.direction === "minimum" ? "Minimum " : item.direction === "maximum" ? "Maximum " : "Review ")}${esc(covenantMonitorDisplay(item, "threshold"))}</td><td>${esc(covenantMonitorDisplay(item, "actual"))}</td><td>${esc(item.comparable === false ? "Not comparable" : covenantMonitorDisplay(item, "headroom"))}${item.relativeHeadroom != null ? `<br><span class="muted">${esc(percent(item.relativeHeadroom))} of threshold</span>` : ""}</td><td><span class="tag ${covenantStatusClass(item.status)}">${esc(item.status)}</span></td><td><span class="muted">${esc(item.locator || "Not provided")}</span></td></tr>`).join("") || '<tr><td colspan="6">No covenant tests were provided.</td></tr>'}</tbody></table></div></section>
        <section class="panel"><div class="panel-head"><div><p class="eyebrow">Information covenant</p><h3>Reporting status</h3></div><span class="tag ${pastDue.length ? "bad" : "good"}">${pastDue.length ? `${pastDue.length} past due` : "Current at review date"}</span></div><div class="panel-body"><div class="reporting-list">${(monitor.reportingItems || []).map((item) => `<div><span><strong>${esc(item.name)}</strong><small>Last period ${formatDate(item.lastReceivedPeriodEnd)} • due ${formatDate(item.dueDate)}</small></span><span class="tag ${item.status === "Past due" ? "bad" : item.status === "Due soon" ? "warning" : "good"}">${esc(item.status)}</span></div>`).join("") || "No reporting schedule was provided."}</div></div></section>
      </div>

      <section class="panel mt-15"><div class="panel-head"><div><p class="eyebrow">Structured follow-up</p><h3>Reporting, covenant and monitoring actions</h3></div><span class="tag ${pastDue.length ? "warning" : "neutral"}">${(monitor.actions || []).filter((item) => !monitorActionIsTerminal(item)).length} open actions</span></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Reporting item / scope</th><th>Action</th><th>Owner</th><th>Due</th><th>Evidence</th><th>Status</th></tr></thead><tbody>${(monitor.actions || []).map((item) => `<tr><td>${esc((monitor.reportingItems || []).find((report) => report.id === item.reportingItemId)?.name || (monitor.covenants || []).find((covenant) => covenant.id === item.covenantId)?.name || (item.relatedControlId === "balance_crossfoot" ? "Balance-sheet cross-foot" : item.relatedControlId === "line_maturity" ? "Line maturity" : "General monitoring"))}</td><td>${esc(item.action || "Not stated")}</td><td>${esc(item.owner || "Unassigned")}</td><td>${esc(formatDate(item.dueDate))}</td><td>${esc(item.evidence || "Not supplied")}</td><td><span class="tag ${monitorActionIsTerminal(item) && !monitorActionIsCancelled(item) ? "good" : "warning"}">${esc(item.status || "Open")}</span>${!monitorActionIsTerminal(item) ? ` <button class="text-button" type="button" data-complete-monitor-action="${esc(item.id)}">Mark complete</button>` : ""}</td></tr>`).join("") || '<tr><td colspan="6">No structured monitoring actions recorded.</td></tr>'}</tbody></table></div><form id="monitor-action-form" class="form-grid panel-body" autocomplete="off" spellcheck="false"><label class="field">Reporting item / scope<select name="reportingItemId"><option value="">General monitoring action</option><option value="CONTROL:balance_crossfoot">Balance-sheet cross-foot disposition</option><option value="CONTROL:line_maturity">Line-maturity disposition</option>${(monitor.reportingItems || []).map((item) => `<option value="${esc(item.id)}">Reporting: ${esc(item.name)} — ${esc(item.status)}</option>`).join("")}${(monitor.covenants || []).filter(covenantIsException).map((item) => `<option value="COV:${esc(item.id)}">Covenant: ${esc(item.name)} — ${esc(item.sourceStatus || item.status)}</option>`).join("")}</select></label><label class="field">Owner<input name="owner" required maxlength="100" spellcheck="false" autocomplete="off" value="Portfolio Manager"></label><label class="field field-wide">Action<input name="action" required minlength="20" maxlength="1000" spellcheck="false" autocomplete="off" placeholder="Specific follow-up, escalation or cure"></label><label class="field">Due date<input name="dueDate" type="date" required></label><label class="field">Evidence / verification<input name="evidence" required minlength="5" maxlength="300" spellcheck="false" autocomplete="off" placeholder="Receipt, ticket, source or approval"></label><div class="field-wide right"><button class="button button-primary" type="submit">Add monitoring action</button></div></form></section>

      <section class="panel mt-15"><div class="panel-head"><div><p class="eyebrow">Workbook integrity</p><h3>Visible anomalies and excluded legacy logic</h3></div><span class="tag ${unresolvedAnomalies.some((item) => item.severity === "blocker") ? "bad" : "warning"}">${unresolvedAnomalies.length} requires disposition</span></div><div class="anomaly-grid">${(monitor.anomalies || []).map((item) => `<article><span class="severity ${esc(item.severity === "informational" ? "note" : item.severity)}">${esc(item.severity)}</span><strong>${esc(item.title)}</strong><p>${esc(item.detail)}</p><small>${esc(item.locator || "Workbook diagnostic")}</small></article>`).join("") || "<p>No workbook anomalies recorded.</p>"}</div></section>

      <section class="panel mt-15"><div class="panel-head"><div><p class="eyebrow">PM ownership</p><h3>Monitoring conclusion and officer-output profile</h3></div><span class="tag neutral">Underlying analysis is always retained</span></div><form id="monitor-decision-form" class="form-grid panel-body" autocomplete="off" spellcheck="false">
        <label class="field">Overall assessment<input name="assessment" maxlength="220" value="${esc(monitor.assessment || "")}" required></label>
        <label class="field">Recommended risk rating<input name="recommendedRating" maxlength="80" value="${esc(monitor.rating?.recommended || "")}" required></label>
        <label class="field field-wide">Rating rationale <small>Full text stays in the review pack; the two-page monitor uses a bounded excerpt.</small><textarea name="ratingRationale" rows="3" maxlength="2400" required>${esc(monitor.ratingRationale || "")}</textarea></label>
        <label class="field field-wide">PM conclusion and actions <small>Full text stays in the review pack; the two-page monitor uses a bounded excerpt.</small><textarea name="conclusion" rows="4" maxlength="4000" required>${esc(monitor.conclusion || "")}</textarea></label>
        <label class="field">Officer output<select name="outputProfile"><option value="executive" ${monitor.outputProfile === "executive" ? "selected" : ""}>Compact two-page monitor</option><option value="standard" ${monitor.outputProfile === "standard" ? "selected" : ""}>Monitor + compact schedules</option><option value="full" ${monitor.outputProfile === "full" ? "selected" : ""}>Full monitor + appendices</option></select></label>
        <div class="field"><span>Optional detail in exported officer report</span><label class="check-line light"><input type="checkbox" name="includeFinancialTables" ${monitor.includeFinancialTables ? "checked" : ""}><span>Include financial-statement schedule</span></label><label class="check-line light"><input type="checkbox" name="includeBalanceSheetTable" ${monitor.includeBalanceSheetTable ? "checked" : ""}><span>Include balance-sheet schedule</span></label></div>
        <div class="field-wide right"><button class="button button-quiet" type="button" data-confirm-monitor>Confirm extracted data &amp; control review</button><button class="button button-primary" type="submit">Save PM monitor decision</button></div>
      </form></section>
      <p class="muted mt-15">The Studio produces monitoring signals, not an automated approval, tier or risk rating. Missing values remain “Not provided”; workbook formula errors and stale legacy blocks are never silently converted to zero.</p>`;
  }

  function moduleCard(title, subtitle, facts, takeaway, wide) {
    const complete = facts.length > 0 && facts.every((item) => item.value !== "—" && item.value !== "Not recorded");
    return `<article class="module-card${wide ? " span-2" : ""}">
      <div class="module-title"><div><p class="eyebrow">Decision module</p><h3>${esc(title)}</h3><p>${esc(subtitle)}</p></div><span class="tag ${complete ? "good" : "warning"}">${complete ? "Evidence linked" : "Incomplete"}</span></div>
      <div class="module-body">${facts.map((item) => `<div class="fact-row"><span>${esc(item.label)}</span><strong>${esc(item.value)}</strong>${factEvidenceButton(item.factId, item.label)}</div>`).join("")}
      <div class="credit-takeaway"><strong>Credit takeaway:</strong> ${esc(takeaway)}</div></div>
    </article>`;
  }

  function factItem(path, label, demoFallback) {
    return { label, value: displayFact(path, demoFallback), factId: factByPath(path)?.id || "" };
  }

  function calcItem(id, label) {
    const calc = calcById(id);
    return { label, value: calc?.display || "Not recorded", factId: calc ? id : "" };
  }

  function renderWorkbench() {
    const stress = calculateStress();
    const repaymentTakeaway = memoNarrative("repayment");
    const financialTakeaway = memoNarrative("financial");
    const performanceTakeaway = memoNarrative("performance");
    const projectTakeaway = memoNarrative("project");
    const guarantorTakeaway = memoNarrative("guarantor");
    const marketTakeaway = memoNarrative("market");
    const importedCovenants = Array.isArray(state.importedCovenants) ? state.importedCovenants : [];
    const workbookScopeStale = Boolean(state.workbook?.loaded && !workbookScopeIsCurrent());
    return `${pageHead("Underwriting workbench", "Analyze the credit, not the template", "Nine HBF modules convert workbook exhibits and extracted evidence into a linked credit conclusion.", '<button class="button button-quiet" type="button" data-view-link="sources">Inspect evidence</button>' + statusMarkup())}
      <section class="summary-band">
        <div><small>Evidence coverage</small><strong>${state.sources.length} sources</strong><span>${state.facts.filter((fact) => ["supported", "accepted"].includes(fact.status)).length} supported facts</span></div>
        <div><small>Workbook profile</small><strong>${esc(state.workbook.profile || "Not loaded")}</strong><span>${state.workbook.sheets || 0} sheets inspected</span></div>
        <div><small>Deterministic tests</small><strong>${state.calculations.length} results</strong><span>${state.calculations.filter((calc) => calc.status === "fail").length} outside selected case</span></div>
        <div><small>PM work queue</small><strong>${openIssues().length} open items</strong><span>${openIssues("blocker").length} review blocker${openIssues("blocker").length === 1 ? "" : "s"}</span></div>
      </section>
      <div class="module-grid">
        ${moduleCard("Request & relationship", "Exposure, structure and renewal change", [
          { label: "Current / proposed commitment", value: `${displayFact("facility.currentCommitment", "$35.0MM")} / ${displayFact("facility.proposedCommitment", "$40.0MM")}`, factId: factByPath("facility.proposedCommitment")?.id || "" },
          factItem("facility.outstanding", "Current outstanding", "$22.4MM"),
          factItem("relationship.proFormaExposure", "Pro forma relationship exposure", "$46.2MM"),
          factItem("facility.proposedMaturity", "Proposed maturity", "Jun. 30, 2028")
        ], memoNarrative("request"))}
        ${moduleCard("Financial capacity", "Trend, leverage, liquidity and coverage", [
          factItem("financial.revenueTtm", "TTM revenue", "$128.4MM"),
          factItem("financial.ebitdaTtm", "TTM EBITDA", "$13.5MM"),
          factItem("financial.tangibleNetWorth", "Tangible net worth", "$31.0MM"),
          factItem("financial.leverage", "Debt / TNW", "2.86x"),
          factItem("financial.fccr", "Fixed-charge coverage", "1.54x")
        ], financialTakeaway)}
        ${moduleCard("Sales quality & inventory", "Gross-to-net demand and cash conversion", [
          { label: "TTM net sales / closings", value: `${displayFact("operating.netSales", "76 homes")} / ${displayFact("operating.ttmClosings", "71 homes")}`, factId: factByPath("operating.netSales")?.id || "" },
          factItem("operating.cancellationRate", "Cancellation rate", "11.3%"),
          factItem("operating.actualAbsorption", "Actual absorption", "5.9 homes/month"),
          { label: "Spec / presold units", value: `${displayFact("inventory.specUnits", "19 homes")} / ${displayFact("inventory.presoldUnits", "26 homes")}`, factId: factByPath("inventory.specUnits")?.id || "" },
          factItem("inventory.agedCompletedSpecs", "Aged completed specs", "2 homes")
        ], performanceTakeaway)}
        ${moduleCard("Collateral & completion", "Availability, equity timing and remaining cost", [
          factItem("collateral.asCompleteValue", "As-complete collateral value", "$61.5MM"),
          { label: "Proposed commitment LTV / LTC", value: `${calcById("CALC02")?.display || "—"} / ${calcById("CALC03")?.display || "—"}`, factId: calcById("CALC02") ? "CALC02" : "" },
          factItem("collateral.currentBorrowingBaseAvailability", "Current borrowing-base availability", "$10.4MM"),
          factItem("project.modeledEligibleFutureAdvances", "Modeled eligible future advances", "$17.6MM"),
          factItem("project.committedEquity", "Committed borrower funds", "$4.2MM"),
          calcItem("CALC04", "Completion funding cushion")
        ], projectTakeaway)}
        <article class="module-card span-2">
          <div class="module-title"><div><p class="eyebrow">Cash conversion</p><h3>Project-to-repayment chain</h3><p>Where inventory becomes cash and where the bank can intervene</p></div><span class="tag info">HBF-specific</span></div>
          <div class="module-body">
            <div class="scenario-flow" style="background:#d9e1e5;color:#17242e">
              <div style="background:#fff"><small>1 · Inventory</small><strong>${esc(displayFact("inventory.totalUnits", "88 units / lots"))}</strong></div>
              <div style="background:#fff"><small>2 · Contracts</small><strong>${esc(displayFact("inventory.presoldUnits", "26 homes"))}</strong></div>
              <div style="background:#fff"><small>3 · Closings</small><strong>${esc(displayFact("operating.actualAbsorption", "5.9 homes/month"))}</strong></div>
              <div style="background:#eef6f5"><small>4 · Net paydown</small><strong>${esc(displayFact("operating.netPaydownPerClosing", "$257.5K / closing"))}</strong></div>
            </div>
            <div class="credit-takeaway"><strong>Repayment chain:</strong> ${esc(repaymentTakeaway)}</div>
          </div>
        </article>
        ${moduleCard("Guarantor support", "Capacity after haircuts and competing obligations", [
          factItem("guarantor.reportedLiquidity", "Reported liquidity", "$12.7MM"),
          factItem("guarantor.adjustedLiquidity", "Adjusted liquidity", "$9.2MM"),
          factItem("guarantor.availableLiquidityAfterCalls", "Available after identified calls", "$7.8MM"),
          factItem("guarantor.contingentGuarantees", "Stated contingent guarantees", "$56.4MM"),
          calcItem("CALC09", "Recorded downside support need"),
          calcItem("CALC10", "Coverage of recorded need")
        ], guarantorTakeaway)}
        ${moduleCard("Market validation", "Borrower case versus dated third-party evidence", [
          factItem("market.monthsSupply", "Subject submarket months supply", "3.4 months"),
          factItem("market.priorMonthsSupply", "Prior underwriting supply", "4.1 months"),
          factItem("market.builderShare", "Borrower share of submarket closings", "8.4%"),
          { label: "Market evidence as-of", value: formatDate(factByPath("market.monthsSupply")?.asOfDate), factId: factByPath("market.monthsSupply")?.id || "" }
        ], marketTakeaway)}
      </div>
      <section id="credit-change-work" class="panel mt-15">
        <div class="panel-head"><h3>${esc(state.deal.dealType)}: prior approval → current performance → proposed structure</h3><span class="tag info">Governed change record</span></div>
        <div class="table-wrap"><table class="data-table"><thead><tr><th>Field</th><th>Prior approval</th><th>Current</th><th>Proposed</th><th>Credit impact</th><th>Evidence</th></tr></thead><tbody>${state.changes.length ? state.changes.map((change) => `<tr><td><strong>${esc(change.field)}</strong>${change.id ? `<br><span class="muted">${esc(change.id)}</span>` : ""}</td><td>${esc(change.prior)}</td><td>${esc(change.current)}</td><td>${esc(change.proposed)}</td><td>${esc(change.impact)}</td><td>${evidenceMarkup(change)}${change.evidenceNote ? `<br><span class="muted">${esc(change.evidenceNote)}</span>` : ""}${change.evidenceSupersededReason ? `<br><span class="muted">${esc(change.evidenceSupersededReason)}</span>` : ""}</td></tr>`).join("") : '<tr><td colspan="6">No governed transaction-change records have been entered.</td></tr>'}</tbody></table></div>
      </section>
      <details class="panel mt-15"><summary class="panel-summary">Add a governed transaction change</summary><form id="change-form" class="form-grid inline-form" autocomplete="off" spellcheck="false">
        <label class="field">Field / term<input name="field" required maxlength="180" autocomplete="off" spellcheck="false"></label><label class="field">Prior approval<input name="prior" required maxlength="300" autocomplete="off" spellcheck="false"></label>
        <label class="field">Current position<input name="current" required maxlength="300" autocomplete="off" spellcheck="false"></label><label class="field">Proposed structure<input name="proposed" required maxlength="300" autocomplete="off" spellcheck="false"></label>
        <label class="field field-wide">Credit impact<textarea name="impact" required maxlength="1200" autocomplete="off" spellcheck="false"></textarea></label>
        <label class="field">Evidence classification<select name="evidenceClassification" required><option value="accepted_facts">Accepted fact IDs</option><option value="pm_judgment">Explicit PM judgment</option></select></label><label class="field">Supporting fact IDs<input name="sourceFactIds" maxlength="600" autocomplete="off" spellcheck="false" placeholder="F004, F009 (required for accepted facts)"></label>
        <label class="field field-wide">Evidence locator / PM basis<textarea name="evidenceNote" required maxlength="1200" autocomplete="off" spellcheck="false" placeholder="Identify the source comparison or explain the PM-owned conclusion."></textarea></label>
        <div class="field-wide right"><button class="button button-primary" type="submit">Add change record</button></div>
      </form></details>
      ${importedCovenants.length ? `<section class="panel mt-15"><div class="panel-head"><h3>Workbook covenant observations awaiting review</h3><span class="tag warning">${importedCovenants.length} quarantined</span></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Covenant</th><th>Normalized requirement / actual</th><th>Workbook locators</th><th>Bind entity / test date</th><th>Reviewed status</th><th>Action</th></tr></thead><tbody>${importedCovenants.map((item) => `<tr><td><strong>${esc(item.name)}</strong><br><span class="muted">${esc(item.frequency || "Frequency not stated")} • ${esc(item.periodLabel || "Period header not parsed")}</span></td><td>${esc(formatCovenantValue(item.threshold, item.valueType))} / ${esc(formatCovenantValue(item.actual, item.valueType))}<br><span class="muted">source ${esc(item.sourceThreshold)} / ${esc(item.sourceActual)} ${esc(item.sourceUnit || "")} × ${esc(item.normalizationFactor || 1)}</span></td><td>${esc(item.thresholdLocator || "No threshold locator")}<br>${esc(item.actualLocator || "No actual locator")}</td><td><select class="compact-select" data-cov-entity="${esc(item.id)}">${entityOptions(item.entity, true)}</select><input type="date" class="basis-input" data-cov-date="${esc(item.id)}" value="${esc(state.deal.asOfDate || "")}"></td><td><select class="compact-select" data-cov-status="${esc(item.id)}"><option value="Compliant">Compliant</option><option value="Noncompliant">Noncompliant</option><option value="Waiver / exception">Waiver / exception</option><option value="Pending / not tested">Pending / not tested</option></select></td><td><button class="button button-quiet" type="button" data-bind-covenant="${esc(item.id)}" ${workbookScopeStale ? "disabled" : ""}>${workbookScopeStale ? "Re-add workbook first" : "Add reviewed result"}</button></td></tr>`).join("")}</tbody></table></div><div class="panel-body"><p class="muted">${workbookScopeStale ? "The selected tabs changed. Re-add the workbook before reviewing any imported covenant observations." : "Workbook values remain quarantined until a PM binds a registered entity, valid test date and reviewed compliance status. Threshold and actual cell locators remain attached."}</p></div></section>` : ""}
      <section class="panel mt-15">
        <div class="panel-head"><h3>Covenant trend and headroom</h3><span class="tag ${state.covenants.length ? "good" : "warning"}">${state.covenants.length ? "Reviewed results" : "Not entered"}</span></div>
        <div class="table-wrap"><table class="data-table"><thead><tr><th>Covenant / test</th><th>Requirement</th><th>Actual</th><th>Headroom</th><th>Trend</th><th>Status</th><th>Evidence</th></tr></thead><tbody>${state.covenants.length ? state.covenants.map((covenant) => `<tr><td><strong>${esc(covenant.name)}</strong>${covenant.id ? ` <span class="muted">${esc(covenant.id)}</span>` : ""}<br><span class="muted">${esc(covenant.entity || (state.mode === "demo" ? "Synthetic demo borrower" : "Entity not stated"))} • ${esc(covenant.frequency || "Frequency not stated")} • ${esc(formatDate(covenant.asOfDate))}</span></td><td>${esc(covenant.threshold)}</td><td>${esc(covenant.actual)}</td><td>${esc(covenant.headroom || "Not calculated")}</td><td>${esc(covenant.trend || "Not stated")}</td><td><span class="tag ${covenantStatusClass(covenant.status)}">${esc(covenant.status)}</span></td><td>${evidenceMarkup(covenant)}${covenant.evidenceNote ? `<br><span class="muted">${esc(covenant.evidenceNote)}</span>` : ""}${covenant.evidenceSupersededReason ? `<br><span class="muted">${esc(covenant.evidenceSupersededReason)}</span>` : ""}</td></tr>`).join("") : '<tr><td colspan="7">No covenant results have been accepted.</td></tr>'}</tbody></table></div>
      </section>
      <details class="panel mt-15"><summary class="panel-summary">Add a governed covenant result</summary><form id="covenant-form" class="form-grid inline-form" autocomplete="off" spellcheck="false">
        <label class="field">Covenant name<input name="name" required maxlength="220" autocomplete="off" spellcheck="false"></label><label class="field">Tested entity<select name="entity" required>${entityOptions("", true)}</select></label>
        <label class="field">Test date<input name="asOfDate" type="date" required value="${esc(state.deal.asOfDate || "")}"></label><label class="field">Frequency<input name="frequency" required maxlength="100" autocomplete="off" spellcheck="false" placeholder="Quarterly / Monthly / Annual"></label>
        <label class="field">Requirement<input name="threshold" required maxlength="300" autocomplete="off" spellcheck="false"></label><label class="field">Actual<input name="actual" required maxlength="300" autocomplete="off" spellcheck="false"></label>
        <label class="field">Headroom<input name="headroom" required maxlength="300" autocomplete="off" spellcheck="false"></label><label class="field">Trend<input name="trend" required maxlength="500" autocomplete="off" spellcheck="false"></label>
        <label class="field">Reviewed status<select name="status" required><option value="Compliant">Compliant</option><option value="Noncompliant">Noncompliant</option><option value="Waiver / exception">Waiver / exception</option><option value="Pending / not tested">Pending / not tested</option></select></label><label class="field">Evidence classification<select name="evidenceClassification" required><option value="accepted_facts">Accepted fact IDs</option><option value="pm_judgment">Explicit PM judgment</option></select></label>
        <label class="field">Supporting fact IDs<input name="sourceFactIds" maxlength="600" autocomplete="off" spellcheck="false" placeholder="F034, F045 (required for accepted facts)"></label><label class="field">Evidence locator / PM basis<input name="evidenceNote" required maxlength="1200" autocomplete="off" spellcheck="false"></label>
        <div class="field-wide right"><button class="button button-primary" type="submit">Add covenant result</button></div>
      </form></details>`;
  }

  function stressControl(key, label, min, max, step, suffix, help) {
    const value = state.stress[key];
    return `<div class="stress-control">
      <label for="stress-${esc(key)}"><span>${esc(label)}</span><output id="output-${esc(key)}">${esc(value)}${esc(suffix)}</output></label>
      <input id="stress-${esc(key)}" type="range" min="${min}" max="${max}" step="${step}" value="${esc(value)}" data-stress="${esc(key)}" data-suffix="${esc(suffix)}">
      <div class="range-scale"><span>${min}${esc(suffix)}</span><span>${esc(help)}</span><span>${max}${esc(suffix)}</span></div>
    </div>`;
  }

  function renderDownside() {
    const stress = calculateStress();
    const actions = '<button class="button button-quiet" type="button" data-reset-stress>Reset selected case</button><button class="button button-primary" type="button" data-record-stress>Recalculate &amp; record</button>';
    if (stress.status !== "computed") return `${pageHead("Downside lab", "Make the weak assumption visible", "Calculations run only from accepted facts and named scenario assumptions; no risk rating or approval is generated.", actions)}
      <span id="downside-work" class="anchor-target" aria-hidden="true"></span>
      <div class="stress-layout"><section class="stress-controls">
        ${stressControl("priceDecline", "Home-price decline", 0, 30, 1, "%", "value stress")}
        ${stressControl("absorptionSlowdown", "Absorption slowdown", 0, 50, 1, "%", "pace stress")}
        ${stressControl("costOverrun", "Remaining-cost overrun", 0, 25, 1, "%", "cost stress")}
        ${stressControl("rateShock", "Interest-rate shock", 0, 400, 25, " bps", "rate stress")}
        ${stressControl("cancellationIncrease", "Additional net-closing drag", 0, 20, 1, "%", "demand stress")}
      </section><section class="stress-results"><article class="result-card" style="grid-column:1/-1"><small>Fail-closed calculation status</small><strong>Inputs required</strong><span>Accept sourced values for: ${esc(stress.missing.join(", "))}.</span></article></section></div>
      <p class="muted mt-15">No fixture defaults or conflicted candidates are substituted into a live calculation.</p>`;
    const runwayClass = stress.maturityRunway >= 0 ? "good" : "bad";
    const coverageClass = stress.supportCoverage == null || stress.supportCoverage >= 1.25 ? "good" : stress.supportCoverage >= 1 ? "watch" : "bad";
    const ltvClass = stress.stressedLtv <= 0.75 ? "good" : stress.stressedLtv <= 0.85 ? "watch" : "bad";
    return `${pageHead("Downside lab", "Make the weak assumption visible", "Calculations run only from accepted facts and named scenario assumptions; no risk rating or approval is generated.", actions)}
      <span id="downside-work" class="anchor-target" aria-hidden="true"></span>
      <div class="note-box mb-15"><strong>${state.stressReviewed ? "Recorded scenario" : "Unrecorded preview"}:</strong> ${state.stressReviewed ? `Rule ${esc(stress.ruleVersion)} is synchronized to the memo and calculation ledger.` : "Recalculate and record before approval; slider changes invalidate the prior attestation."}</div>
      <div class="stress-layout">
        <section class="stress-controls">
          ${stressControl("priceDecline", "Home-price decline", 0, 30, 1, "%", "value stress")}
          ${stressControl("absorptionSlowdown", "Absorption slowdown", 0, 50, 1, "%", "pace stress")}
          ${stressControl("costOverrun", "Remaining-cost overrun", 0, 25, 1, "%", "cost stress")}
          ${stressControl("rateShock", "Interest-rate shock", 0, 400, 25, " bps", "rate stress")}
          ${stressControl("cancellationIncrease", "Additional net-closing drag", 0, 20, 1, "%", "demand stress")}
        </section>
        <section class="stress-results">
          <article class="result-card"><small>Stressed collateral value</small><strong>${money(stress.stressedValue)}</strong><span>${state.stress.priceDecline}% below current supported value</span></article>
          <article class="result-card"><small>Stressed commitment LTV</small><strong>${percent(stress.stressedLtv)}</strong><span class="metric-signal ${ltvClass}">${stress.stressedLtv <= 0.75 ? "Within illustrative limit" : "Outside illustrative limit"}</span></article>
          <article class="result-card"><small>Stressed closing pace</small><strong>${number(stress.stressedPace, 1)} / mo.</strong><span>${number(factByPath("operating.planAbsorption")?.value, 1)} / month underwritten</span></article>
          <article class="result-card"><small>Estimated payoff</small><strong>${esc(formatDate(stress.estimatedPayoffDate))}</strong><span>Proposed maturity: ${esc(displayFact("facility.proposedMaturity", "Jun. 30, 2028"))}</span></article>
          <article class="result-card"><small>Maturity runway</small><strong>${stress.maturityRunway >= 0 ? number(stress.maturityRunway, 0) : `(${number(Math.abs(stress.maturityRunway), 0)})`} months</strong><span class="metric-signal ${runwayClass}">${stress.maturityRunway >= 0 ? "Before maturity" : "After maturity"}</span></article>
          <article class="result-card"><small>Combined support need</small><strong>${money(stress.sponsorNeed)}</strong><span class="metric-signal ${coverageClass}">${stress.supportCoverage == null ? "No need" : `${multiple(stress.supportCoverage)} available-liquidity coverage`}</span></article>
          <div class="scenario-strip">
            <h3>Cash-conversion consequence</h3>
            <div class="scenario-flow">
              <div><small>Inventory conversion</small><strong>${number(stress.stressedPace, 1)} homes / month</strong></div>
              <div><small>Estimated runoff</small><strong>${number(stress.payoffMonths, 0)} months</strong></div>
              <div><small>Maturity balloon</small><strong>${money(stress.maturityBalloon)}</strong></div>
              <div><small>Required response</small><strong>${stress.maturityRunway < 0 ? "Trigger intervention" : "Monitor base plan"}</strong></div>
            </div>
          </div>
        </section>
      </div>
      <section class="panel mt-15">
        <div class="panel-head"><h3>Reverse-stress / break-even envelope</h3><span class="tag warning">Bank assumptions required</span></div>
        <table class="metrics-table"><thead><tr><th>Constraint</th><th>Calculated break point</th><th>Current selected case</th><th>Interpretation</th></tr></thead><tbody>
          <tr><td><strong>Maximum price decline before 75% commitment LTV</strong></td><td>${percent(stress.maxPriceDecline)}</td><td>${state.stress.priceDecline}%</td><td>${state.stress.priceDecline / 100 <= stress.maxPriceDecline ? "Inside" : "Outside"} illustrative value envelope</td></tr>
          <tr><td><strong>Maximum cost overrun covered by completion cushion</strong></td><td>${percent(stress.maxCostOverrun)}</td><td>${state.stress.costOverrun}%</td><td>${state.stress.costOverrun / 100 <= stress.maxCostOverrun ? "Cushion remains" : "Additional funding required"}</td></tr>
          <tr><td><strong>Base-price absorption to run off by maturity</strong></td><td>${number(stress.baseMinimumPace, 1)} / month</td><td>${number(factByPath("operating.planAbsorption")?.value, 1)} / month</td><td>${Number(factByPath("operating.planAbsorption")?.value) >= stress.baseMinimumPace ? "Base pace supports maturity" : "Base pace misses maturity"}</td></tr>
          <tr><td><strong>Selected-price absorption to run off by maturity</strong></td><td>${number(stress.minimumPace, 1)} / month</td><td>${number(stress.stressedPace, 1)} / month</td><td>${stress.stressedPace >= stress.minimumPace ? "Selected pace supports maturity" : "Selected pace misses maturity"}</td></tr>
          <tr><td><strong>Available liquidity after identified calls</strong></td><td>1.00x need coverage</td><td>${stress.supportCoverage == null ? "No need" : multiple(stress.supportCoverage)}</td><td>${stress.supportCoverage == null || stress.supportCoverage >= 1 ? "Covered before unidentified calls" : "Funding gap remains"}</td></tr>
        </tbody></table>
      </section>
      <section class="panel mt-15">
        <div class="panel-head"><h3>Transparent calculation register</h3><button class="text-button" type="button" data-view-link="sources">Trace inputs →</button></div>
        <table class="data-table"><thead><tr><th>Calculation</th><th>Formula</th><th>Inputs</th><th>Control</th></tr></thead><tbody>
          <tr><td><strong>Stressed commitment LTV</strong></td><td>Proposed commitment ÷ [value × (1 − price decline)]</td><td>F004, F014, selected price decline</td><td>Full precision; rounded only for display</td></tr>
          <tr><td><strong>Stressed payoff</strong></td><td>Peak exposure ÷ [plan pace × (1 − slowdown) × (1 − additional net-closing drag) × paydown/closing × (1 − price decline)]</td><td>Accepted peak, pace and net-paydown facts plus selected assumptions</td><td>Actual as-of and maturity dates drive runway</td></tr>
          <tr><td><strong>Combined support need</strong></td><td>Maturity balloon + uncovered cost overrun + incremental interest through maturity</td><td>Accepted exposure/funding facts, CALC04 and selected assumptions</td><td>Each component shown separately; no timing-cost constant</td></tr>
        </tbody></table>
      </section>
      <p class="muted mt-15">Rule ${esc(stress.ruleVersion)} is a transparent demonstration calculation. Limits and production definitions require versioned Credit approval.</p>`;
  }

  function renderRisks() {
    const stress = calculateStress();
    return `${pageHead("Credit challenge", "Risk → consequence → protection → condition", "Every risk must show why it matters, whether the mitigant actually reduces loss, what remains, and how the bank will respond.", '<button class="button button-quiet" type="button" data-view-link="downside">Change stress case</button>')}
      <span id="credit-risk-work" class="anchor-target" aria-hidden="true"></span>
      ${state.risks.length ? state.risks.map((risk) => `<article class="risk-chain">
        <div class="risk-source"><small>Risk &amp; evidence${risk.id ? ` • ${esc(risk.id)}` : ""}</small><h3>${esc(risk.title)}</h3><p>${esc(risk.evidence)}</p><p class="mt-15">${evidenceMarkup(risk)}${risk.evidenceSupersededReason ? `<br><span class="muted">${esc(risk.evidenceSupersededReason)}</span>` : ""}</p></div>
        <div><small>Credit consequence</small><h3>What can break</h3><p>${esc(risk.consequence)}</p></div>
        <div><small>Protection &amp; residual</small><h3>${esc(risk.type)}</h3><p>${esc(risk.mitigant)}</p><p class="mt-15"><strong>Residual:</strong> ${esc(risk.residual)}</p></div>
        <div class="risk-condition"><small>Condition / trigger</small><h3>${esc(risk.owner)}</h3><p>${esc(risk.condition)}</p></div>
      </article>`).join("") : '<div class="empty-issues"><strong>No risk chain has been entered.</strong><br>Add at least one evidence → consequence → protection → residual → condition chain.</div>'}
      <details class="panel mt-15"><summary class="panel-summary">Add a PM-owned risk chain</summary><form id="risk-form" class="form-grid inline-form" autocomplete="off" spellcheck="false">
        <label class="field">Risk title<input name="title" required maxlength="180" autocomplete="off" spellcheck="false"></label><label class="field">Owner<input name="owner" required maxlength="100" value="PM" autocomplete="off" spellcheck="false"></label>
        <label class="field field-wide">Evidence<textarea name="evidence" required maxlength="1200" spellcheck="false" autocomplete="off"></textarea></label>
        <label class="field">Evidence classification<select name="evidenceClassification" required><option value="accepted_facts">Accepted fact IDs</option><option value="pm_judgment">Explicit PM judgment</option></select></label><label class="field">Supporting fact IDs<input name="sourceFactIds" maxlength="600" autocomplete="off" spellcheck="false" placeholder="F006, F009 (required for accepted facts)"></label>
        <label class="field">Credit consequence<textarea name="consequence" required maxlength="1200" spellcheck="false" autocomplete="off"></textarea></label><label class="field">Mitigant / protection<textarea name="mitigant" required maxlength="1200" spellcheck="false" autocomplete="off"></textarea></label>
        <label class="field">Mitigant type<select name="type"><option>Legally enforceable / structural</option><option>Demonstrated financial capacity</option><option>Collateral / cash control</option><option>Monitoring / detection</option><option>Narrative only</option></select></label><label class="field">Residual risk<input name="residual" required maxlength="400" autocomplete="off" spellcheck="false"></label>
        <label class="field field-wide">Condition or trigger<textarea name="condition" required maxlength="1200" spellcheck="false" autocomplete="off"></textarea></label><div class="field-wide right"><button class="button button-primary" type="submit">Add risk chain</button></div>
      </form></details>
      <section id="credit-condition-work" class="panel mt-15">
        <div class="panel-head"><h3>Condition and monitoring register</h3><span class="tag info">${state.conditions.length} linked controls</span></div>
        <div class="table-wrap"><table class="data-table"><thead><tr><th>Timing</th><th>Requirement</th><th>Credit purpose</th><th>Owner</th><th>Verification</th><th>Status</th></tr></thead><tbody>${state.conditions.length ? state.conditions.map((condition) => `<tr><td>${esc(condition.phase)}</td><td><strong>${esc(condition.requirement)}</strong></td><td>${esc(condition.purpose)}</td><td>${esc(condition.owner)}</td><td>${esc(condition.verification)}</td><td><span class="tag ${condition.status === "Open" ? "warning" : "info"}">${esc(condition.status)}</span></td></tr>`).join("") : '<tr><td colspan="6">No conditions have been entered.</td></tr>'}</tbody></table></div>
      </section>
      <details class="panel mt-15"><summary class="panel-summary">Add an approval condition or monitoring trigger</summary><form id="condition-form" class="form-grid inline-form" autocomplete="off" spellcheck="false">
        <label class="field">Timing<input name="phase" required maxlength="100" autocomplete="off" spellcheck="false" placeholder="Prior to closing / Ongoing monthly"></label><label class="field">Owner<input name="owner" required maxlength="100" value="PM / Borrower" autocomplete="off" spellcheck="false"></label>
        <label class="field field-wide">Requirement<textarea name="requirement" required maxlength="1500" spellcheck="false" autocomplete="off"></textarea></label><label class="field">Credit purpose<textarea name="purpose" required maxlength="800" spellcheck="false" autocomplete="off"></textarea></label><label class="field">Verification method<textarea name="verification" required maxlength="800" spellcheck="false" autocomplete="off"></textarea></label>
        <div class="field-wide right"><button class="button button-primary" type="submit">Add condition</button></div>
      </form></details>
      <section class="panel mt-15"><div class="panel-head"><h3>What must be true</h3><span class="tag warning">Challenge assumptions</span></div><div class="panel-body">
        <div class="thesis-grid">
          <div class="thesis-item"><small>Sales conversion</small><p>${stress.status === "computed" ? `${number(stress.minimumPace, 1)} net closings per month are required under the selected price case to repay by maturity.` : "Accepted pace, paydown and maturity inputs are required."}</p></div>
          <div class="thesis-item"><small>Completion funding</small><p>${calcById("CALC04") ? `${calcById("CALC04").display} recorded completion cushion; eligible future advances and equity timing remain distinct inputs.` : "Completion sources, eligible future advances, costs and reserves must be reconciled."}</p></div>
          <div class="thesis-item"><small>Secondary support</small><p>${calcById("CALC10") ? `${calcById("CALC10").display} coverage of the recorded downside need after identified calls.` : "Available liquidity after identified calls must be sourced and compared with the recorded downside need."}</p></div>
        </div>
      </div></section>`;
  }

  function sourceStatusTag(status) {
    const className = status === "supported" ? "good" : status === "conflicted" ? "bad" : status === "warning" ? "warning" : "neutral";
    return `<span class="tag ${className}">${esc(status || "unreviewed")}</span>`;
  }

  function renderCreditIntakePlan() {
    if (state.workflow !== "credit_action") return "";
    const scope = window.HBF_CreditPath?.workbookScopePlan(state) || [];
    const documents = window.HBF_CreditPath?.documentPlan(state) || [];
    const batches = window.HBF_CreditPath?.batchPlan(state) || [];
    const selectedTabs = window.HBF_CreditPath?.selectedWorkbookTabs(state) || [];
    const totalSelectableTabs = scope.reduce((total, item) => total + item.sheets.length, 0);
    const requiredDocuments = documents.filter((item) => item.required);
    const conditionalDocuments = documents.filter((item) => !item.required);
    const requiredOpen = requiredDocuments.filter((item) => !item.complete).length;
    const nextRequiredDocument = requiredDocuments.find((item) => !item.complete) || null;
    const packetCount = (state.importedPacketIds || []).length;
    const workbookNeedsRefresh = Boolean(state.workbook?.loaded && state.workbook?.scopeChangedAfterImport);
    const scopeConfirmed = state.mode === "demo" || state.workbookScopeConfirmed === true;
    const workbookStatus = !scopeConfirmed ? "Confirm tabs first" : workbookNeedsRefresh ? "Re-add for changed scope" : state.workbook?.loaded ? "Workbook added" : "Workbook needed";
    const workbookAction = !scopeConfirmed ? "Confirm selected tabs above" : workbookNeedsRefresh ? "Re-add workbook" : state.workbook?.loaded ? "Replace workbook" : "Add workbook";
    const documentRow = (item, optional) => `<article class="document-row ${item.complete ? "is-complete" : ""}">
      <span class="document-check" aria-hidden="true">${item.complete ? "✓" : optional ? "·" : "○"}</span>
      <div><strong>${esc(item.label)}</strong><p>${esc(item.examples)}</p><small>Internal Opus ${esc(item.batch)} • one checklist row uses one upload slot${item.matchedSourceIds.length ? ` • registered source: ${esc(item.matchedSourceIds.join(", "))}` : ""}</small>${!item.requiredByRule ? `<label class="document-choice"><input type="checkbox" data-document-override="${esc(item.id)}" ${item.addedByPm ? "checked" : ""}><span>${item.addedByPm ? "PM marked this document as needed" : "Add this document for this deal"}</span></label>` : ""}</div>
      <span class="tag ${item.complete ? "good" : optional ? "neutral" : "warning"}">${item.complete ? "Added" : optional ? "If needed" : item.addedByPm ? `PM added • ${esc(item.batch)}` : `Needed • ${esc(item.batch)}`}</span>
    </article>`;
    return `<section class="intake-simple mb-15" aria-label="Credit memo document intake">
      <div class="intake-simple-head"><div><p class="eyebrow">Add documents</p><h3>Three steps; two file types added here</h3><p>Original borrower, bank, collateral and market documents go to the approved internal Opus chat in step 2. This Studio receives only the HBF workbook in step 1 and reviewed Opus JSON in step 3.</p></div><span class="tag ${requiredOpen ? "warning" : "good"}">${requiredOpen ? `${requiredOpen} required document type${requiredOpen === 1 ? "" : "s"} still open` : "Required documents represented"}</span></div>

      <div class="direct-upload-grid">
        <article class="direct-upload-card" id="workbook-scope"><span class="direct-step">1</span><div><h3>Underwriting workbook (.xlsx)</h3><p>Keep the full HBF workbook intact, but complete only the individual tabs the PM will use for this deal.</p><details class="scope-picker" data-preserve-open="workbook-scope" ${!scopeConfirmed ? "open" : ""}><summary>${selectedTabs.length} of ${totalSelectableTabs} underwriting tabs selected — ${scopeConfirmed ? "selection confirmed" : "choose and confirm tabs"}</summary><div class="scope-grid">${scope.map((item) => `<details class="scope-group" data-preserve-open="scope-${esc(item.id)}" ${item.always ? "open" : ""}><summary><span><strong>${esc(item.label)}${item.always ? " — always used" : ""}</strong><small>${item.selectedCount} of ${item.sheets.length} tab${item.sheets.length === 1 ? "" : "s"} selected</small></span></summary><div class="scope-tab-list">${item.sheets.map((sheet) => `<label class="scope-tab ${item.selectedSheets.includes(sheet) ? "is-selected" : ""}"><input type="checkbox" data-workbook-tab="${esc(sheet)}" ${item.selectedSheets.includes(sheet) ? "checked" : ""} ${sheet === "Exposure" ? "disabled" : ""}><span>${esc(sheet)}</span></label>`).join("")}</div></details>`).join("")}</div><p class="scope-note"><strong>Each checkbox is one workbook tab.</strong> Unselected tabs may remain blank and their extracted values or formula defects stay outside the deal ledger. Memo conclusions still require PM support or a clear not-applicable explanation. Template Modifications is administrative and is never requested from the PM.</p><div class="scope-confirm"><button class="button ${scopeConfirmed ? "button-quiet" : "button-primary"}" type="button" data-confirm-workbook-scope>${scopeConfirmed ? "Reconfirm selected tabs" : "Confirm these are the tabs used"}</button><span class="tag ${scopeConfirmed ? "good" : "warning"}">${scopeConfirmed ? "PM selection recorded" : "Required before workbook import"}</span></div></details></div><div class="direct-upload-action"><span class="tag ${scopeConfirmed && state.workbook?.loaded && !workbookNeedsRefresh ? "good" : "warning"}">${workbookStatus}</span>${state.mode === "demo" ? '<button class="button button-quiet" type="button" data-start-workflow="credit_action">Start live work</button>' : `<button class="button button-primary" type="button" data-trigger-workbook ${scopeConfirmed ? "" : "disabled"}>${workbookAction}</button>`}</div></article>
        <article class="next-document-card"><span class="direct-step">2</span><div><p class="eyebrow">Originals for internal Opus</p>${nextRequiredDocument ? `<h3>Next: ${esc(nextRequiredDocument.label)}</h3><p>${esc(nextRequiredDocument.examples)}</p><small>${esc(nextRequiredDocument.batch)} • one original file slot</small>` : '<h3>Required source documents are represented</h3><p>Open the full checklist to review optional support or go to the Opus batches.</p>'}</div><button class="button button-primary" type="button" data-view-link="opus">${nextRequiredDocument ? `Open ${esc(nextRequiredDocument.batch)} instructions` : "Open Opus batches"}</button></article>
        <article class="direct-upload-card"><span class="direct-step">3</span><div><h3>Import the validated Opus evidence (.json)</h3><p>After reviewing the extracted facts in internal Opus, add the strict JSON returned for each batch. Use the same Deal ID every time.</p></div><div class="direct-upload-action"><span class="tag ${packetCount ? "good" : "warning"}">${packetCount ? `${packetCount} packet${packetCount === 1 ? "" : "s"} added` : "Evidence JSON needed"}</span>${state.mode === "demo" ? '<button class="button button-quiet" type="button" data-start-workflow="credit_action">Start live work</button>' : '<button class="button button-primary" type="button" data-trigger-packet>Add Opus JSON</button>'}</div></article>
      </div>

      <section class="required-document-map" aria-labelledby="required-document-map-title"><div class="required-document-map-head"><div><p class="eyebrow">Step 2 · exact originals for internal Opus</p><h3 id="required-document-map-title">Documents needed for this memo</h3><p>Core financial and operating sources are always included. Your exact tab choices add only their relevant supporting documents.</p></div><strong>${requiredDocuments.length} required</strong></div><div class="required-document-map-grid">${batches.filter((batch) => batch.documents.length).map((batch) => `<article><div class="required-document-batch"><span>${esc(batch.id)}</span><div><strong>${esc(batch.label)}</strong><small>${batch.pendingDocuments.length ? `${batch.pendingDocuments.length} still needed` : "Complete"}</small></div></div><ul>${batch.documents.map((item) => `<li class="${item.complete ? "is-complete" : ""}"><span aria-hidden="true">${item.complete ? "✓" : "○"}</span><span>${esc(item.label)}</span></li>`).join("")}</ul></article>`).join("")}</div><p class="required-document-map-note">Upload only the documents listed above to approved internal Opus, with no more than five files in one chat. The Opus screen gives one exact prompt per batch.</p></section>

      <details class="document-checklist" data-preserve-open="document-checklist" aria-labelledby="document-checklist-title"><summary class="document-checklist-summary"><span><strong id="document-checklist-title">Examples and optional documents</strong><small>${requiredDocuments.length} required • ${requiredOpen} still open • ${conditionalDocuments.length} optional</small></span><span>Show details</span></summary><div class="document-checklist-body"><div class="document-checklist-head"><div><p class="eyebrow">Detailed checklist</p><h3>Examples and deal-specific support</h3><p>Open this only when you need examples, registered source IDs or optional diligence such as environmental, flood or title support.</p></div></div>
        <div class="document-group"><h4>Required now</h4>${requiredDocuments.map((item) => documentRow(item, false)).join("") || '<p class="muted">No required document types are open.</p>'}</div>
        <details class="conditional-documents" data-preserve-open="conditional-documents"><summary>Documents needed only when applicable (${conditionalDocuments.length})</summary><div class="document-group">${conditionalDocuments.map((item) => documentRow(item, true)).join("")}</div></details></div>
      </details>

    </section>`;
  }

  function renderSources() {
    const workbook = state.workbook || {};
    const workbookScopeStale = Boolean(workbook.loaded && !workbookScopeIsCurrent());
    const selectedWorkbookScope = (window.HBF_CreditPath?.workbookScopePlan(state) || []).filter((item) => item.selected);
    const selectedWorkbookTabs = window.HBF_CreditPath?.selectedWorkbookTabs(state) || ["Exposure"];
    const candidates = window.HBF_CreditPath?.prioritizeCandidates(state.facts) || state.facts.filter((fact) => fact.status === "candidate" || fact.status === "judgment_required" || fact.status === "missing" || fact.status === "conflicted");
    const eligibleFacts = state.facts.filter((fact) => ACCEPTED_FACT_STATUSES.has(fact.status));
    const ambiguousPaths = new Set(controllingAmbiguities());
    const quarantinedObservations = Array.isArray(workbook.metadataReviewRequiredFacts) ? workbook.metadataReviewRequiredFacts : [];
    const formulaErrorSamples = Array.isArray(workbook.formulaErrorSamples) ? workbook.formulaErrorSamples : Array.isArray(workbook.formulaErrors) ? workbook.formulaErrors : [];
    const formulaErrorCount = workbookFormulaErrorTotal(workbook);
    const totalFormulaErrorCount = Number.isFinite(Number(workbook.totalFormulaErrorCount)) ? Number(workbook.totalFormulaErrorCount) : formulaErrorCount;
    const excludedFormulaErrorCount = Number.isFinite(Number(workbook.excludedFormulaErrorCount)) ? Number(workbook.excludedFormulaErrorCount) : Math.max(0, totalFormulaErrorCount - formulaErrorCount);
    const demoNonDealReview = state.mode === "demo" && workbook.reviewedAsNonDealEvidence === true;
    const sourceDates = state.sources.map((source) => source.asOfDate).filter(Boolean).sort();
    const oldestEvidence = sourceDates.length ? formatDate(sourceDates[0]) : "Not stated";
    const workbookIssues = [
      workbook.profile && workbook.profile.includes("Unsupported") ? "Unknown or changed workbook profile" : null,
      workbookScopeStale ? "Workbook must be re-added or its exact tab selection reconfirmed before review" : null,
      workbook.calcMode === "manual" ? "Workbook calculation mode is manual" : null,
      workbook.formulasWithoutCachedValues ? `${workbook.formulasWithoutCachedValues} formulas have no saved value` : null,
      workbook.externalLinks ? `${workbook.externalLinks} external-link indicators detected` : null,
      formulaErrorCount ? `${formulaErrorCount} saved formula errors${demoNonDealReview ? " are isolated to the non-deal parser specimen" : " require exact-count review"}` : null
    ].filter(Boolean);
    const candidateAction = (fact) => {
      if (fact.status === "conflicted") return '<button class="button button-quiet" type="button" data-view-link="reconcile">Resolve conflict</button>';
      if (fact.status === "missing") return `<button class="button button-quiet" type="button" data-trigger-packet>Add source packet</button> <button class="text-button" type="button" data-reject-fact="${esc(fact.id)}">Mark not used</button>`;
      if (fact.status === "judgment_required") return `<button class="button button-quiet" type="button" data-credit-task="rating">Record PM decision</button> <button class="text-button" type="button" data-reject-fact="${esc(fact.id)}">Mark not used</button>`;
      if (fact.requiresMetadataReview) return `<span class="tag warning">Bind metadata above</span> <button class="text-button" type="button" data-reject-fact="${esc(fact.id)}">Reject</button>`;
      if (!entityApproved(fact)) return `<span class="tag bad">Register entity first</span> <button class="text-button" type="button" data-reject-fact="${esc(fact.id)}">Reject</button>`;
      return `<button class="button button-quiet" type="button" data-accept-fact="${esc(fact.id)}">Accept as controlling</button> <button class="text-button" type="button" data-reject-fact="${esc(fact.id)}">Reject</button>`;
    };
    if (activeStage === "add") {
      return renderCreditIntakePlan();
    }
    return `${pageHead("Evidence control", "Source register and as-of timeline", "The file name is not the evidence. Each material fact retains a source ID, date, page/tab/cell locator, classification and review status.", '<button class="button button-primary" type="button" data-trigger-workbook>Load workbook</button>')}
      <section class="summary-band">
        <div><small>Registered sources</small><strong>${state.sources.length}</strong><span>${new Set(state.sources.map((source) => source.packet)).size} packets / local imports</span></div>
        <div><small>Supported facts</small><strong>${state.facts.filter((fact) => ["supported", "accepted"].includes(fact.status)).length}</strong><span>${state.facts.length} total candidate records</span></div>
        <div><small>Conflicted facts</small><strong>${state.facts.filter((fact) => fact.status === "conflicted").length}</strong><span>${openConflicts().length} material conflict</span></div>
        <div><small>Oldest registered evidence</small><strong>${esc(oldestEvidence)}</strong><span>Staleness remains a PM review item</span></div>
      </section>
      ${quarantinedObservations.length ? `<section class="panel mb-15"><div class="panel-head"><h3>Workbook observations awaiting metadata binding</h3><span class="tag warning">${quarantinedObservations.length} quarantined</span></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Observation</th><th>Normalized value / source scale</th><th>Source headers</th><th>Bind entity / period / as-of</th><th>Action</th></tr></thead><tbody>${quarantinedObservations.slice(0, 100).map((fact) => `<tr><td><strong>${esc(fact.label || fact.path)}</strong><br><span class="muted">${esc(fact.locator)} • ${esc((fact.metadataReviewRequired || []).join(", ") || "PM metadata review")}</span></td><td>${esc(fact.valueType === "money" ? money(fact.value) : fact.value)}<br><span class="muted">source ${esc(fact.sourceValue)} ${esc(fact.sourceUnit || fact.unit || "")} × ${esc(fact.normalizationFactor || 1)}</span></td><td>${esc((fact.sourceHeaders || []).map((item) => `${item.address}: ${item.value || "blank"}`).join("; ") || "No period header parsed")}</td><td><select class="compact-select" data-meta-entity="${esc(fact.id)}">${entityOptions(fact.entity, true)}</select><select class="compact-select" data-meta-period="${esc(fact.id)}"><option value="">Select period</option><option value="as_of">As of</option><option value="ttm">TTM</option><option value="ytd">YTD</option><option value="annual">Annual</option><option value="monthly">Monthly</option><option value="quarterly">Quarterly</option><option value="projected">Projected</option><option value="cumulative">Cumulative</option><option value="as_complete">As complete</option><option value="not_applicable">Not applicable</option></select><input type="date" class="basis-input" data-meta-date="${esc(fact.id)}" value="${esc(state.deal.asOfDate || "")}"></td><td><button class="button button-quiet" type="button" data-bind-observation="${esc(fact.id)}" ${workbookScopeStale ? "disabled" : ""}>${workbookScopeStale ? "Re-add workbook first" : "Bind metadata"}</button></td></tr>`).join("")}</tbody></table></div><div class="panel-body"><p class="muted">${workbookScopeStale ? "The selected tabs changed. Re-add the workbook before binding any imported observations." : "These normalized values cannot enter calculations or memo outputs until the PM binds an approved entity, period and date; they then enter the ordinary candidate-acceptance queue."}</p></div></section>` : ""}
      <section class="panel mb-15">
        <div class="panel-head"><h3>Approved deal-entity registry</h3><span class="tag ${state.entities?.length ? "good" : "warning"}">${state.entities?.length || 0} registered</span></div>
        <div class="panel-body"><div class="entity-chips">${(state.entities || []).map((entity) => `<span class="tag neutral">${esc(entity.role)} • ${esc(entity.name)}</span>`).join("") || '<span class="muted">Register the borrower and every related entity before accepting its facts.</span>'}</div>
          <form id="entity-form" class="form-grid inline-form" autocomplete="off"><label class="field">Exact legal / market entity<input name="entityName" required maxlength="240" spellcheck="false" autocomplete="off"></label><label class="field">Role<select name="entityRole"><option>Borrower</option><option>Co-borrower</option><option>Guarantor</option><option>Relationship</option><option>Project / collateral</option><option>Market geography</option><option>Other reviewed entity</option></select></label><div class="field-wide right"><button class="button button-quiet" type="submit">Register entity</button></div></form>
          <p class="muted">Packet facts for an unregistered entity cannot be accepted or control a memo value.</p>
        </div>
      </section>
      <section class="panel mb-15">
        <div class="panel-head"><h3>Underwriting workbook control</h3>${workbook.loaded ? `<span class="tag ${workbook.profileMatched && !workbookScopeStale ? "good" : "warning"}">${workbookScopeStale ? "Re-add / confirm required" : esc(workbook.profile)}</span>` : '<span class="tag neutral">Not loaded</span>'}</div>
        <div class="panel-body">
          ${workbook.loaded ? `<div class="fact-row"><span>File</span><strong>${esc(workbook.fileName)}</strong><span></span></div>
            <div class="fact-row"><span>PM-selected underwriting tabs</span><strong>${selectedWorkbookTabs.length} exact tabs across ${selectedWorkbookScope.length} categories</strong><span class="tag info">Individual scope</span></div>
            <details class="mt-15"><summary>Show the exact selected tabs</summary><p class="muted">${esc(selectedWorkbookTabs.join(" • "))}</p></details>
            <div class="fact-row"><span>Template / selected fact coverage</span><strong>${esc(workbook.sheets || 0)} template sheets retained • ${esc(workbook.mappedSheets || 0)} sheets selected • ${esc(workbook.mappedFacts || 0)} high-value candidates</strong><span></span></div>
            <div class="fact-row"><span>Selected-scope formulas / errors</span><strong>${number(workbook.applicableFormulaCount ?? workbook.formulaCount ?? 0, 0)} formulas • ${number(formulaErrorCount, 0)} flagged (${number(formulaErrorSamples.length, 0)} sample${formulaErrorSamples.length === 1 ? "" : "s"} retained)</strong><span class="tag ${formulaErrorCount ? "warning" : "good"}">${formulaErrorCount ? "Review" : "Clear"}</span></div>
            <div class="fact-row"><span>Outside selected scope</span><strong>${number(excludedFormulaErrorCount, 0)} formula errors • ${number(workbook.excludedFormulasWithoutCachedValues || 0, 0)} formulas without saved values • ${number(workbook.excludedScopeObservationCount || 0, 0)} extracted observations excluded from the deal ledger</strong><span class="tag neutral">Disclosed</span></div>
            <div class="fact-row"><span>Workbook fingerprint</span><strong>${esc((workbook.digest || workbook.profile || "").slice(0, 22))}${workbook.digest ? "…" : ""}</strong><span></span></div>
            <div class="fact-row"><span>Saved-value controls</span><strong>${demoNonDealReview ? "Not relied on — parser specimen is excluded from deal evidence" : workbook.recalculatedConfirmed ? "Automatic mode; cached values present" : "Corrected workbook required"}</strong><span class="tag ${demoNonDealReview ? "neutral" : workbook.recalculatedConfirmed ? "good" : "bad"}">${demoNonDealReview ? "Non-deal only" : workbook.recalculatedConfirmed ? "Passed" : "Blocked"}</span></div>
            <div class="fact-row"><span>Structural signatures</span><strong>${esc((workbook.signatureChecks || []).filter((item) => item.matched || item.found).length)} of ${esc((workbook.signatureChecks || []).length)} required groups</strong><span class="tag ${workbook.profileMatched ? "good" : "bad"}">${workbook.profileMatched ? "Matched" : "Changed"}</span></div>
            ${workbookIssues.length ? `<div class="note-box mt-15"><strong>Workbook review:</strong> ${esc(workbookIssues.join("; "))}. Excel remains the full-workbook calculation engine; the Studio independently recalculates only decision-critical metrics.</div>` : '<div class="note-box mt-15"><strong>Workbook structure and saved-value controls passed.</strong> Extracted values are still candidates until a PM accepts them.</div>'}
            ${formulaErrorCount ? `<div class="workbook-review mt-15">${demoNonDealReview
              ? `<div class="note-box"><strong>Reviewed as non-deal evidence:</strong> ${esc(workbook.errorReviewNote || `All ${formulaErrorCount} saved errors are confined to the parser specimen and excluded from deal facts, calculations and conclusions.`)}</div>`
              : workbookScopeStale
                ? '<div class="note-box"><strong>Re-add workbook first.</strong> Formula-error review is disabled until the workbook matches a confirmed exact tab selection.</div>'
                : `<label class="review-confirm"><input id="workbook-error-confirm" type="checkbox" ${workbook.formulaErrorReviewConfirmed ? "checked" : ""}><span>I reviewed the complete population of <strong>${number(formulaErrorCount, 0)}</strong> saved formula errors in the selected tabs—not only the ${number(formulaErrorSamples.length, 0)} retained samples—and confirm none affects a relied-upon input, calculation or memo conclusion. If any selected-scope error is relevant, I will correct, recalculate, save and re-import the workbook.</span></label><label class="field">Selected-scope error review basis<textarea id="workbook-error-note" minlength="80" maxlength="2000" autocomplete="off" spellcheck="false" placeholder="At least 80 characters: identify the selected-scope error population, affected sheets and why none affects relied-upon analysis.">${esc(workbook.errorReviewNote || "")}</textarea></label><div class="right mt-15"><button class="button button-primary" type="button" data-review-workbook-errors>${workbook.formulaErrorsReviewed ? "Update exact-count review" : "Record exact-count review"}</button></div><p class="muted">This review resolves only the selected-scope formula-error blocker. A relevant error, manual/unknown calculation mode, selected-scope missing cached values, external links, changed scope or changed profile requires a corrected re-import.</p>`}
              ${formulaErrorSamples.length ? `<details class="mt-15"><summary>Show retained error samples (${formulaErrorSamples.length}${workbook.formulaErrorSamplesTruncated ? ` of ${formulaErrorCount}` : ""})</summary><div class="table-wrap mt-15"><table class="data-table"><thead><tr><th>Sheet</th><th>Cell</th><th>Saved result</th></tr></thead><tbody>${formulaErrorSamples.slice(0, 100).map((item) => `<tr><td>${esc(item.sheet || "Unknown sheet")}</td><td>${esc(item.address || "Unknown cell")}</td><td>${esc(item.value || "#ERROR")}</td></tr>`).join("")}</tbody></table></div></details>` : ""}
            </div>` : ""}` : '<div class="note-box"><strong>No workbook loaded.</strong> Select the HBF v2.2 workbook with only the PM-selected tabs completed. The file is read in browser memory and is never uploaded by this application.</div>'}
        </div>
      </section>
      <section class="panel mb-15">
        <div class="panel-head"><div><p class="eyebrow">Confirm what matters</p><h3>Exception-first fact queue</h3><p>Resolve decision blockers first. Every row explains the credit consequence before asking for a disposition.</p></div><span class="tag ${candidates.length ? "warning" : "good"}">${candidates.length ? `${candidates.length} awaiting PM review` : "Queue cleared"}</span></div>
        <div class="table-wrap"><table class="data-table exception-table"><thead><tr><th>Priority</th><th>Fact / value</th><th>Why it matters</th><th>Source / period</th><th>Review action</th></tr></thead><tbody>${candidates.length ? candidates.slice(0, 100).map((fact) => `<tr><td><span class="tag ${fact.rank <= 2 ? "bad" : fact.rank <= 4 ? "warning" : "neutral"}">${esc(fact.band || "PM review")}</span></td><td><strong>${esc(fact.label || fact.path)}</strong><br>${esc(fact.valueType === "money" ? money(fact.value) : fact.valueType === "percent" ? percent(fact.value) : fact.value == null ? "Not stated" : fact.value)}<br><span class="muted">${esc(fact.path)} • ${esc(fact.entity || "Entity missing")}</span></td><td>${esc(fact.consequence || "This fact must be dispositioned before it can control an output.")}</td><td>${esc(fact.sourceId || "PM / missing source")} • ${esc(fact.locator || "No locator")}<br><span class="muted">${esc(fact.periodType || "Period not classified")} • ${esc(formatDate(fact.asOfDate))}</span></td><td>${candidateAction(fact)}</td></tr>`).join("") : '<tr><td colspan="5">All imported facts have a recorded disposition.</td></tr>'}</tbody></table></div>
        ${candidates.some((fact) => fact.status === "candidate" && entityApproved(fact) && !fact.requiresMetadataReview) ? '<div class="panel-body right"><button class="button button-quiet" type="button" data-accept-all-facts>Accept all eligible non-conflicting facts</button></div>' : ""}
      </section>
      <details class="panel mb-15"><summary class="panel-summary">Accepted / supported fact ledger (${eligibleFacts.length})</summary><div class="table-wrap"><table class="data-table"><thead><tr><th>ID / canonical field</th><th>Entity / period</th><th>Value</th><th>Output role</th><th>Action</th></tr></thead><tbody>${eligibleFacts.length ? eligibleFacts.slice(0, 150).map((fact) => {
        const versions = eligibleFactsForPath(fact.path);
        const controls = factByPath(fact.path)?.id === fact.id;
        return `<tr><td><button class="text-button" type="button" data-evidence="${esc(fact.id)}">${esc(fact.id)}</button><br><span class="muted">${esc(fact.path)}</span></td><td>${esc(fact.entity || "PM / legacy demo")}<br><span class="muted">${esc(fact.periodType || "not classified")} • ${esc(formatDate(fact.asOfDate))}</span></td><td>${esc(fact.valueType === "money" ? money(fact.value) : fact.valueType === "percent" ? percent(fact.value) : fact.value == null ? "Not stated" : fact.value)}</td><td><span class="tag ${controls ? "good" : ambiguousPaths.has(fact.path) ? "bad" : "neutral"}">${controls ? "Controlling" : ambiguousPaths.has(fact.path) ? "Ambiguous" : "Historical / alternate"}</span></td><td>${versions.length > 1 && !controls ? `<button class="button button-quiet" type="button" data-control-fact="${esc(fact.id)}">Use as controlling</button>` : "—"}</td></tr>`;
      }).join("") : '<tr><td colspan="5">No accepted or supported facts.</td></tr>'}</tbody></table></div></details>
      <section class="panel">
        <div class="panel-head"><h3>Registered evidence</h3><span class="tag info">Click a source ID for detail</span></div>
        <div class="table-wrap"><table class="data-table"><thead><tr><th>ID</th><th>Source</th><th>Document type</th><th>As-of</th><th>Packet</th><th>Fingerprint</th><th>Status</th></tr></thead><tbody>${state.sources.length ? state.sources.map((source) => `<tr><td><button class="text-button" type="button" data-source-detail="${esc(source.id)}">${esc(source.id)}</button></td><td><strong>${esc(source.name)}</strong><br><span class="muted">${esc(source.detail || "")}</span></td><td>${esc(source.type)}</td><td>${esc(formatDate(source.asOfDate))}</td><td>${esc(source.packet || "—")}</td><td>${esc((source.fingerprint || source.digest || "not supplied").slice(0, 18))}${(source.fingerprint || source.digest || "").length > 18 ? "…" : ""}</td><td>${sourceStatusTag(source.status)}</td></tr>`).join("") : '<tr><td colspan="7">No sources have been registered in this session.</td></tr>'}</tbody></table></div>
      </section>
      <p class="muted mt-15">Exact borrower facts may not rely on chat memory. A source document and locator are required even when Opus remembers the workflow.</p>`;
  }

  function renderReconciliation() {
    const conflicts = state.conflicts;
    return `${pageHead("Reconciliation desk", "Conflicts are preserved, never silently overwritten", "Compare competing values, choose the controlling evidence, and retain the rejected value and PM rationale in the review pack.", '<span class="tag ' + (openConflicts().length ? 'bad' : 'good') + '">' + openConflicts().length + ' unresolved</span>')}
      ${conflicts.length ? conflicts.map((conflict) => {
        const isOpen = conflict.status === "open" || !conflict.status;
        const isResolved = conflict.status === "resolved";
        const isSuperseded = conflict.status === "superseded";
        const scopeStale = conflictHasStaleWorkbookEvidence(conflict);
        const canAct = isOpen && !scopeStale;
        const selectedId = isOpen ? pendingConflictSelection[conflict.id] || conflict.selectedFactId : conflict.selectedFactId;
        const statusClass = isResolved ? "good" : isSuperseded ? "neutral" : "bad";
        return `<article class="reconcile-card">
          <div class="reconcile-head"><div><p class="eyebrow">${esc(conflict.id)} • ${esc(conflict.materiality)}</p><h3>${esc(conflict.label)}</h3></div><span class="tag ${statusClass}">${esc(conflict.status || "open")}</span></div>
          <div class="candidate-grid">${conflict.candidates.map((factId) => {
            const fact = factById(factId);
            const source = sourceById(fact?.sourceId);
            return `<div class="candidate${selectedId === factId ? " is-selected" : ""}">
              <strong>${fact?.valueType === "money" ? money(fact.value) : esc(fact?.value)}</strong>
              <p>${esc(source?.name || fact?.sourceId || "Unknown source")} • ${esc(fact?.locator || "No locator")} • as of ${esc(formatDate(fact?.asOfDate))}</p>
              <div class="note-box">${esc(fact?.excerpt || "No excerpt supplied")}</div>
              <button class="button ${selectedId === factId ? "button-primary" : "button-quiet"} mt-15" type="button" data-select-candidate="${esc(factId)}" data-conflict="${esc(conflict.id)}" ${canAct ? "" : "disabled"}>${scopeStale ? "Re-add workbook first" : selectedId === factId ? "Selected" : isSuperseded ? "Historical candidate" : "Use this value"}</button>
            </div>`;
          }).join("")}</div>
          ${scopeStale ? '<div class="note-box"><strong>Workbook scope changed.</strong> Re-add the workbook before selecting, completing or reopening this reconciliation.</div>' : ""}
          <div class="resolution-note"><label>PM resolution rationale<input type="text" maxlength="400" autocomplete="off" spellcheck="false" data-resolution-note="${esc(conflict.id)}" value="${esc(conflict.rationale || "")}" placeholder="Why is this source controlling?" ${canAct ? "" : "disabled"}></label>
            <div class="right mt-15">${isResolved ? `<button class="button button-quiet" type="button" data-reopen-conflict="${esc(conflict.id)}" ${scopeStale ? "disabled" : ""}>${scopeStale ? "Re-add workbook first" : "Reopen"}</button>` : isSuperseded ? '<span class="tag neutral">Historical record — source version replaced</span>' : `<button class="button button-primary" type="button" data-complete-conflict="${esc(conflict.id)}" ${selectedId && !scopeStale ? "" : "disabled"}>${scopeStale ? "Re-add workbook first" : "Complete resolution"}</button>`}</div>
          </div>
        </article>`;
      }).join("") : '<div class="empty-issues"><strong>No conflicts have been identified.</strong><br>New packets and workbook facts are still checked against the canonical ledger when imported.</div>'}
      <section class="panel mt-15"><div class="panel-head"><h3>Merge rules</h3><span class="tag neutral">Fail closed</span></div><div class="panel-body"><ul class="compact-list"><li>Entity, canonical field, period type, as-of date, scenario and normalized unit form the merge key; source scale remains provenance.</li><li>A newer date can be suggested but never silently determines authority.</li><li>Different entities or periods coexist; same-key normalized differences become conflicts.</li><li>The selected value, rejected value, reviewer and rationale remain in the exported review pack.</li></ul></div></section>`;
  }

  function conflictHasStaleWorkbookEvidence(conflict) {
    return Boolean(conflict?.candidates?.some((factId) => {
      const fact = factById(factId);
      return fact?.status === "scope_stale" || fact?.sourceId === state.workbook?.sourceId && !workbookScopeIsCurrent();
    }));
  }

  function nextOpusPacketId(batchId) {
    const base = String(batchId || "B01").toUpperCase();
    const imported = new Set((state.importedPacketIds || []).map((id) => String(id).toUpperCase()));
    if (!imported.has(base)) return base;
    let revision = 2;
    while (imported.has(`${base}R${revision}`)) revision += 1;
    return `${base}R${revision}`;
  }

  function opusPromptForBatch(batchId) {
    const batch = (window.HBF_CreditPath?.batchPlan(state) || []).find((item) => item.id === batchId);
    if (!batch) throw new Error("Choose an applicable Opus batch first.");
    const pendingDocuments = Array.isArray(batch.pendingDocuments) ? batch.pendingDocuments : batch.documents.filter((item) => !item.complete);
    if (!pendingDocuments.length) throw new Error(`${batch.id} is complete; no additional prompt is needed.`);
    const packetId = nextOpusPacketId(batch.id);
    return { batch, packetId, documents: pendingDocuments, prompt: window.HBF_OPUS_PROMPT(state.deal.id, packetId, pendingDocuments) };
  }

  function renderOpus() {
    const packets = Array.from(new Set([...(state.importedPacketIds || []), ...state.sources.map((source) => source.packet).filter((packet) => /^B/i.test(packet || ""))]));
    const batches = window.HBF_CreditPath?.batchPlan(state) || [];
    return `${pageHead("Internal model bridge", "One exact upload list and one exact prompt per Opus chat", "Each open row below is one original file slot. Continuation prompts include only missing source types and retain their stable IDs, so represented originals are not uploaded twice.", '<button class="button button-primary" type="button" data-trigger-packet>Import returned JSON</button>')}
      <section class="panel opus-batch-panel">
        <div class="panel-head"><div><p class="eyebrow">Applicable to this deal</p><h3>${batches.length} internal Opus batch${batches.length === 1 ? "" : "es"}</h3></div><span class="tag good">Maximum 5 files each</span></div>
        <div class="panel-body"><p><strong>Do this for each batch:</strong> open a new approved internal Opus chat, upload exactly the listed originals that are available, then copy that batch's prompt. Review the JSON before importing it here.</p></div>
        <div class="opus-batch-list">${batches.map((batch) => {
          const packetId = nextOpusPacketId(batch.id);
          const pendingDocuments = Array.isArray(batch.pendingDocuments) ? batch.pendingDocuments : batch.documents.filter((item) => !item.complete);
          return `<article class="opus-batch-row"><div class="opus-batch-id"><span>${esc(batch.id)}</span><small>${pendingDocuments.length ? `Next packet: ${esc(packetId)}` : "Batch complete"}</small></div><div><h3>${esc(batch.label)}</h3>${pendingDocuments.length ? `<ol>${pendingDocuments.map((document, index) => { const slot = /-S(\d{2})$/i.exec(document.expectedSourceId || "")?.[1] || String(index + 1).padStart(2, "0"); return `<li><code>${esc(packetId)}-S${slot}</code> ${esc(document.label)}</li>`; }).join("")}</ol>` : "<p><strong>All required originals in this batch are represented.</strong></p>"}<p>${esc(batch.purpose)}</p><small>One row = one uploaded file. If the first returned packet omits an original, the next prompt is automatically numbered ${esc(batch.id)}R2, ${esc(batch.id)}R3, and so on and lists only what is still missing.</small></div><div class="opus-batch-actions"><span class="tag ${batch.complete ? "good" : "warning"}">${batch.complete ? "Documents represented" : `${pendingDocuments.length} still needed`}</span>${pendingDocuments.length ? `<button class="button button-primary" type="button" data-copy-prompt="${esc(batch.id)}">Copy ${esc(packetId)} prompt</button><button class="button button-quiet" type="button" data-download-prompt="${esc(batch.id)}">Download prompt</button>` : ""}</div></article>`;
        }).join("")}</div>
        <div class="panel-body"><a class="button button-quiet" href="canonical-field-catalog.json" download>Download field catalog</a><p class="muted mt-15"><strong>Customer-data boundary:</strong> originals go only to the bank-approved internal Opus environment. This Studio receives the workbook and reviewed JSON. Chat memory may retain workflow instructions, but it is never evidence for borrower-specific facts.</p></div>
      </section>
      <section class="panel mt-15"><div class="panel-head"><h3>Imported packet register</h3><span class="tag neutral">Deal ID enforced</span></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Packet</th><th>Sources</th><th>As-of range</th><th>Status</th></tr></thead><tbody>${packets.length ? packets.map((packet) => {
        const packetSources = state.sources.filter((source) => source.packet === packet);
        return `<tr><td><strong>${esc(packet)}</strong></td><td>${packetSources.length}</td><td>${esc(packetSources.map((source) => source.asOfDate).filter(Boolean).sort()[0] || "Not stated")} → ${esc(packetSources.map((source) => source.asOfDate).filter(Boolean).sort().slice(-1)[0] || "Not stated")}</td><td><span class="tag good">Merged with review</span></td></tr>`;
      }).join("") : '<tr><td colspan="4">No Opus packet has been imported in this local session.</td></tr>'}</tbody></table></div></section>`;
  }

  const sectionEvidence = {
    executive: ["F003", "F004", "F005", "F006"], request: ["F003", "F004", "F009", "F011"], relationship: ["F005", "F006", "F007"], repayment: ["F009", "F024", "F025", "F039"], financial: ["F030", "F031", "F032", "F034", "F036", "F037"], performance: ["F020", "F022", "F023", "F027", "F028", "F029"], project: ["F016", "F017", "F018", "F019"], collateral: ["F014", "F015", "F005"], downside: ["F009", "F025", "F039"], market: ["F041", "F042", "F043"], guarantor: ["F038", "F039", "F040"], covenants: ["F034", "F035", "F036", "F044", "F045", "F046"], rating: ["F012", "F013", "F036"], risks: ["F024", "F029", "F036", "F039"], conditions: ["F004", "F018", "F038"], conclusion: ["F006", "F009", "F014", "F016", "F017"]
  };

  function narrativeSectionId(key) {
    const normalized = String(key || "").toLowerCase().replace(/[^a-z]/g, "");
    const aliases = { executive: "executive", executivesummary: "executive", borrowerbackground: "relationship", businessbackground: "relationship", request: "request", transactionoverview: "request", transactionstructure: "request", relationship: "relationship", globalexposure: "relationship", repayment: "repayment", sourcesofrepayment: "repayment", primaryrepayment: "repayment", financial: "financial", financialperformance: "financial", performance: "performance", operatingupdate: "performance", salesinventory: "performance", salesandclosings: "performance", project: "project", projectfeasibility: "project", collateral: "collateral", borrowingbase: "collateral", downside: "downside", stress: "downside", market: "market", marketanalysis: "market", guarantor: "guarantor", globalsupport: "guarantor", covenants: "covenants", rating: "rating", riskrating: "rating", exceptions: "exceptions", policy: "exceptions", risks: "risks", keyrisks: "risks", conditions: "conditions", conclusion: "conclusion", recommendation: "conclusion" };
    return aliases[normalized] || null;
  }

  function acceptNarrativePacket(packetId) {
    const packet = (state.importedNarratives || []).find((item) => item.packetId === packetId);
    if (!packet) return toast("Narrative packet was not found.", "error");
    let accepted = 0;
    const unsupported = [];
    const packetFactPrefix = `P-${packetId}-`;
    const acceptedPacketFacts = state.facts.filter((fact) => {
      if (!String(fact.id || "").startsWith(packetFactPrefix) || !ACCEPTED_FACT_STATUSES.has(fact.status) || !entityApproved(fact)) return false;
      const controlling = factByPath(fact.path, { entity: fact.entity, periodType: fact.periodType, asOfDate: fact.asOfDate, scenario: fact.scenario || "actual", unit: fact.unit || "" });
      return controlling?.id === fact.id;
    });
    Object.entries(packet.narratives || {}).forEach(([key, value]) => {
      const sectionId = narrativeSectionId(key);
      const section = state.memoSections.find((item) => item.id === sectionId);
      const narrative = typeof value === "string" ? value : String(value?.narrative || value?.text || "");
      const supportingPaths = Array.isArray(value?.supportingFieldIds) ? value.supportingFieldIds : [];
      const supportingMatches = supportingPaths.map((path) => acceptedPacketFacts.filter((fact) => fact.path === path));
      if (!supportingPaths.length || supportingMatches.some((matches) => matches.length !== 1)) {
        unsupported.push(key);
        return;
      }
      const supportingFacts = supportingMatches.map((matches) => matches[0]);
      if (section && !section.narrative.trim() && narrative.trim().length >= 20) {
        section.narrative = narrative.trim().slice(0, 12000);
        section.generatedByScenario = false;
        section.aiDraftStaged = true;
        section.supportingFactIds = supportingFacts.map((fact) => fact.id);
        accepted += 1;
      }
    });
    if (!accepted) return toast(`No narrative was staged. Accept each cited fact first${unsupported.length ? ` (${unsupported.join(", ")})` : ""}.`, "error");
    packet.status = "staged for PM review";
    state.staleNarrativeReviewRequired = true;
    if (!state.issues.some((issue) => issue.id === "AI-NARRATIVE-REVIEW" && issue.status === "open")) state.issues.push({ id: "AI-NARRATIVE-REVIEW", severity: "blocker", title: "Staged Opus prose requires PM grounding review", detail: "Confirm every material number/date against the cited controlling facts, edit conclusions in your own credit judgment and complete the fact-to-narrative review.", actionView: "memo", status: "open", resolutionType: "system_control" });
    state.editHistory.push({ action: `Staged ${accepted} grounded Opus drafts from ${packetId} for PM editing`, at: new Date().toISOString() });
    invalidateAttestations(`Opus narrative drafts from ${packetId} were staged for PM review.`);
    state.finalized = false;
    toast(`${accepted} grounded draft${accepted === 1 ? "" : "s"} staged; PM dependency review is now required.`);
    renderView();
  }

  function memoClassificationMarkup(section) {
    if (section.aiDraftStaged) return '<span class="tag warning">AI draft staged</span>';
    if (section.classification === "pm_judgment") return '<span class="tag neutral">PM judgment</span>';
    if (section.classification === "deterministic_calculation") return '<span class="tag info">Deterministic calculation</span>';
    const ids = Array.isArray(section.supportingFactIds) ? section.supportingFactIds : [];
    const grounded = ids.length > 0 && ids.every((id) => { const fact = factById(id); return fact && ACCEPTED_FACT_STATUSES.has(fact.status); });
    return grounded ? '<span class="tag good">Accepted-fact grounded</span>' : '<span class="tag warning">Basis review required</span>';
  }

  function renderMemo() {
    const memoSections = state.memoSections || [];
    const importedDrafts = (state.importedNarratives || []).filter((packet) => packet.status === "AI draft — not accepted");
    const completedSections = memoSections.filter((section) => section.narrative.trim().length >= 60);
    const nextSection = memoSections.find((section) => section.narrative.trim().length < 60) || memoSections[0];
    const supportingTableAction = (sectionId) => ({
      covenants: ['workbench', 'Manage covenant records'],
      risks: ['risks', 'Manage risk records'],
      conditions: ['risks', 'Manage condition records']
    }[sectionId] || null);
    return `${pageHead("Memo studio", "Edit the complete credit memo", "Every narrative section and decision field is editable. Source-backed figures are corrected through evidence controls so the original value and rationale are never lost.", '<button class="button button-primary" type="button" data-export-memo>Download Word memo</button>')}
      ${state.staleNarrativeReviewRequired ? '<section class="note-box mb-15"><strong>Dependency review required:</strong> a controlling fact changed after narrative was prepared. Reconcile every affected section, risk, condition and change row, then <button class="text-button" type="button" data-complete-narrative-review>record the PM dependency review</button>.</section>' : ""}
      <section class="memo-edit-banner"><div><p class="eyebrow">Editable from start to finish</p><h3>All 17 memo narrative sections can be changed</h3><p>Your saved narrative is used in the required Word memo. Source-backed figures use controlled corrections; structured risk, condition and covenant records remain governed and append-only.</p></div><div><strong>${completedSections.length}/17</strong><span>sections complete</span>${nextSection ? `<button class="button button-primary" type="button" data-edit-section="${esc(nextSection.id)}">${completedSections.length === 17 ? "Review first section" : `Edit next: ${esc(nextSection.title.replace(/^\d+\.\s*/, ""))}`}</button>` : ""}</div></section>
      <section class="panel mb-15"><div class="panel-head"><h3>PM decision fields</h3><span class="tag warning">Human-owned</span></div><form id="decision-form" class="form-grid inline-form" autocomplete="off" spellcheck="false">
        <label class="field field-wide">Request / transaction summary<textarea name="request" required maxlength="1200" spellcheck="false" ${editingSectionId ? "disabled" : ""}>${esc(state.deal.request)}</textarea></label>
        <label class="field field-wide">PM recommendation<textarea name="recommendation" required maxlength="1200" spellcheck="false" ${editingSectionId ? "disabled" : ""}>${esc(state.deal.recommendation)}</textarea></label>
        <label class="field">Current risk rating<input name="currentRating" required maxlength="80" spellcheck="false" autocomplete="off" value="${esc(state.deal.currentRating)}" ${editingSectionId ? "disabled" : ""}></label><label class="field">Proposed PM risk rating<input name="proposedRating" required maxlength="80" spellcheck="false" autocomplete="off" value="${esc(state.deal.proposedRating)}" ${editingSectionId ? "disabled" : ""}></label>
        <div class="field-wide right"><button class="button button-primary" type="submit" ${editingSectionId ? "disabled" : ""}>Save decision fields</button></div>
      </form></section>
      ${importedDrafts.length ? `<section class="panel mb-15"><div class="panel-head"><h3>Unaccepted Opus narrative drafts</h3><span class="tag warning">${importedDrafts.length} packet${importedDrafts.length === 1 ? "" : "s"}</span></div><div class="panel-body">${importedDrafts.map((packet) => `<div class="note-box mb-15"><strong>${esc(packet.packetId)}</strong> • ${Object.keys(packet.narratives || {}).map(esc).join(", ") || "No mapped sections"}<div class="right mt-15"><button class="button button-quiet" type="button" data-accept-narratives="${esc(packet.packetId)}">Stage grounded drafts in blank sections</button></div></div>`).join("")}<p class="muted">Only drafts whose supporting field paths resolve to accepted controlling facts can be staged. Staging opens a PM grounding-review blocker; it never converts model prose into factual authority.</p></div></section>` : ""}
      ${memoSections.length ? `<div class="memo-layout">
        <aside class="memo-outline"><h3>Memo outline</h3>${memoSections.map((section) => `<button type="button" data-scroll-section="${esc(section.id)}">${esc(section.title.replace(/^\d+\.\s*/, ""))}</button>`).join("")}</aside>
        <article class="memo-paper">
          <header class="memo-header"><div><p class="eyebrow">Credit memorandum</p><h2>${esc(state.deal.borrower)}</h2><p>${esc(state.deal.dealType)} • ${esc(state.deal.facilityType)} • As of ${esc(formatDate(state.deal.asOfDate))}</p></div><div class="memo-status">${statusMarkup()}<p>${esc(state.deal.id)}</p></div></header>
          <section class="memo-section" id="memo-decision"><h3>Decision profile</h3>
            <table class="data-table"><tbody><tr><td><strong>Recommendation</strong></td><td>${esc(state.deal.recommendation)}</td><td><strong>Request</strong></td><td>${esc(state.deal.request)}</td></tr><tr><td><strong>Current / proposed RR</strong></td><td>${esc(state.deal.currentRating)} / ${esc(state.deal.proposedRating)}</td><td><strong>Outstanding / peak</strong></td><td>${esc(displayFact("facility.outstanding", "$22.4MM"))} / ${esc(displayFact("facility.projectedPeak", "$31.8MM"))}</td></tr></tbody></table>
          </section>
          ${memoSections.map((section) => { const tableAction = supportingTableAction(section.id); return `<section class="memo-section" id="memo-${esc(section.id)}">
            <div class="section-label"><h3>${esc(section.title)}</h3><span>${section.narrative.trim().length >= 60 ? '<span class="tag good">Complete</span>' : '<span class="tag warning">Draft required</span>'} ${memoClassificationMarkup(section)} ${tableAction ? `<button class="text-button no-print" type="button" data-view-link="${esc(tableAction[0])}">${esc(tableAction[1])}</button>` : ""} ${editingSectionId === section.id ? "" : `<button class="text-button no-print" type="button" data-edit-section="${esc(section.id)}">Edit section</button>`}</span></div>
            ${editingSectionId === section.id ? `<textarea id="memo-editor" maxlength="12000" spellcheck="false" autocomplete="off">${esc(section.narrative)}</textarea><p class="muted no-print">Any nonblank draft can be saved. The final check will keep the section open until its explanation is complete.</p><div class="right mt-15 no-print"><button class="button button-quiet" type="button" data-cancel-section>Cancel</button> <button class="button button-primary" type="button" data-save-section="${esc(section.id)}">Save as PM narrative</button></div>` : `<p>${esc(section.narrative || "Not yet completed.")} ${(section.supportingFactIds || (state.mode === "demo" ? sectionEvidence[section.id] || [] : [])).slice(0, 8).map(citationToken).join("")}</p>`}
            ${section.id === "risks" ? `<table class="data-table"><thead><tr><th>Risk</th><th>Residual risk</th><th>Condition / response</th></tr></thead><tbody>${state.risks.filter((risk) => risk.recordStatus !== "superseded").map((risk) => `<tr><td><strong>${esc(risk.title)}</strong></td><td>${esc(risk.residual)}</td><td>${esc(risk.condition)}</td></tr>`).join("")}</tbody></table>` : ""}
            ${section.id === "conditions" ? `<table class="data-table"><thead><tr><th>Timing</th><th>Condition</th><th>Owner</th></tr></thead><tbody>${state.conditions.map((condition) => `<tr><td>${esc(condition.phase)}</td><td>${esc(condition.requirement)}</td><td>${esc(condition.owner)}</td></tr>`).join("")}</tbody></table>` : ""}
          </section>`; }).join("")}
          <section class="memo-section"><h3>Evidence statement</h3><p>Structured and autopopulated facts are linked to the source register or to a named deterministic calculation. PM-edited narrative is explicitly classified and covered by human attestation; the Studio does not perform sentence-level factual validation of free text. Imported model language remains draft until reviewed or rewritten by the portfolio manager. Unresolved facts, regulatory conclusions and human credit judgments are not silently converted into support.</p></section>
        </article>
      </div>` : `<div class="empty-issues"><strong>The memo has not been initialized.</strong><br>Import the workbook and Opus evidence packets, then complete the PM decision fields.</div>`}`;
  }

  function monitorGateRows() {
    const monitor = state.monitor;
    if (!monitor) return [{ title: "Quarterly monitor loaded", pass: false, detail: "Load a recognized quarterly monitor workbook or resume a monitor checkpoint." }];
    const datesValid = [monitor.reviewAsOfDate, monitor.financialPeriodEnd, monitor.inventoryPeriodEnd].every(isValidIsoDate);
    const dateOrderValid = datesValid && monitor.reviewDateBasis === "user_explicit" && monitor.financialPeriodEnd <= monitor.reviewAsOfDate && monitor.inventoryPeriodEnd <= monitor.reviewAsOfDate;
    const latestBanking = latestAtOrBefore(monitor.bankingSeries, monitor.reviewAsOfDate);
    const bankingCutoffValid = Boolean(latestBanking?.periodEnd && latestBanking.periodEnd <= monitor.reviewAsOfDate);
    const latestQuarter = latestAtOrBefore(monitor.financial?.quarterly, monitor.financialPeriodEnd);
    const latestBalance = latestAtOrBefore(monitor.balanceSheets, monitor.financialPeriodEnd);
    const latestInventory = latestAtOrBefore(monitor.inventorySeries, monitor.inventoryPeriodEnd);
    const monitorFacts = state.facts.filter((fact) => fact.sourceId === monitor.workbookSourceId);
    const acceptedMonitorFacts = monitorFacts.filter((fact) => ["accepted", "supported"].includes(fact.status));
    const monitorSource = state.sources.find((source) => source.id === monitor.workbookSourceId && source.status !== "superseded");
    const sourceBound = Boolean(monitorSource && (state.mode === "demo" || (state.monitorWorkbook?.loaded && state.monitorWorkbook.sourceId === monitor.workbookSourceId && state.monitorWorkbook.digest && monitorSource.fingerprint === state.monitorWorkbook.digest)));
    const unreviewedFacts = monitorFacts.filter((fact) => !["accepted", "supported", "rejected"].includes(fact.status));
    const rejectedFacts = monitorFacts.filter((fact) => fact.status === "rejected");
    const materialFacts = [
      ["borrower.legalName", monitor.reviewAsOfDate, monitor.identity?.borrower],
      ["credit.currentRiskRating", monitor.reviewAsOfDate, monitor.rating?.current],
      ["facility.lineMaturity", monitor.reviewAsOfDate, monitor.facility?.lineMaturity],
      ["facility.grossCommitment", latestBanking?.periodEnd, latestBanking?.grossCommitment],
      ["relationship.outstanding", latestBanking?.periodEnd, latestBanking?.outstanding],
      ["relationship.averageDeposits", latestBanking?.periodEnd, latestBanking?.deposits],
      ["financial.revenueQuarter", latestQuarter?.periodEnd, latestQuarter?.revenue],
      ["financial.netIncomeQuarter", latestQuarter?.periodEnd, latestQuarter?.netIncome],
      ["operating.closingsQuarter", latestQuarter?.periodEnd, latestQuarter?.closings],
      ["financial.totalAssets", latestBalance?.periodEnd, latestBalance?.totalAssets],
      ["financial.totalLiabilities", latestBalance?.periodEnd, latestBalance?.totalLiabilities],
      ["financial.reportedTangibleNetWorth", latestBalance?.periodEnd, latestBalance?.tangibleNetWorth],
      ["inventory.totalUnits", latestInventory?.periodEnd, latestInventory?.totalUnits],
      ["inventory.lotsOwnedControlled", latestInventory?.periodEnd, latestInventory?.lotsOwnedControlled]
    ];
    const materialCoverage = state.mode === "demo" ? acceptedMonitorFacts.length >= 3 : materialFacts.every(([path, asOfDate, value]) => value != null && acceptedMonitorFacts.some((fact) => fact.controlling === true && fact.path === path && fact.asOfDate === asOfDate && monitorFactValueMatches(fact.value, value)));
    const blockingAnomalies = (monitor.anomalies || []).filter((item) => item.status !== "resolved" && item.severity === "blocker");
    const openAnomalies = (monitor.anomalies || []).filter((item) => item.status !== "resolved");
    const pastDue = (monitor.reportingItems || []).filter((item) => item.status === "Past due");
    const reportingExceptions = (monitor.reportingItems || []).filter((item) => ["Past due", "Review required"].includes(item.status));
    const reportingAddressed = reportingExceptions.length === 0 || reportingExceptions.every((item) => (monitor.actions || []).some((action) =>
      action.reportingItemId === item.id && completeMonitorAction(action)
    ));
    const reportingDatesValid = (monitor.reportingItems || []).every((item) => !item.lastReceivedPeriodEnd || isValidIsoDate(item.lastReceivedPeriodEnd) && item.lastReceivedPeriodEnd <= monitor.reviewAsOfDate);
    const covenantRows = monitor.covenants || [];
    const covenantReviewItems = covenantRows.filter(covenantRequiresReview);
    const covenantActionsReady = covenantReviewItems.every((item) => (monitor.actions || []).some((action) => action.covenantId === item.id && completeMonitorAction(action)));
    const covenantsComplete = covenantRows.length > 0 && covenantRows.every((item) => item.name && isValidIsoDate(item.testDate || "") && item.testDate <= monitor.reviewAsOfDate && item.threshold != null && item.actual != null && item.status && item.reportedOutcome !== "Review required" && !item.outcomeMismatch && (item.comparable !== false || monitor.covenantReviewConfirmed)) && covenantActionsReady;
    const crossFootDisposition = (monitor.actions || []).some((action) => action.relatedControlId === "balance_crossfoot" && completeMonitorAction(action));
    const balanceReviewed = Boolean(latestBalance && latestBalance.crossFootDifference != null && (Math.abs(Number(latestBalance.crossFootDifference)) < 1 || crossFootDisposition));
    const judgmentValues = [monitor.assessment, monitor.conclusion, monitor.ratingRationale, monitor.rating?.current, monitor.rating?.recommended].map((value) => String(value || "").trim());
    const judgmentComplete = judgmentValues[0].length >= 12 && judgmentValues[1].length >= 80 && judgmentValues[2].length >= 50 && judgmentValues[3].length >= 1 && judgmentValues[4].length >= 1 && !judgmentValues.some(hasPlaceholderOrError);
    const maturityDays = monitorMaturityDays(monitor);
    const maturityCalc = (monitor.calculations || []).find((item) => item.id === "MON-MAT-001");
    const expectedMaturityStatus = maturityDays == null ? "review" : maturityDays < 365 ? "watch" : "pass";
    const maturityCalculationValid = maturityDays != null && Number(maturityCalc?.result) === maturityDays && normalizedStatus(maturityCalc?.status) === expectedMaturityStatus;
    const expiredMaturityAddressed = maturityDays == null || maturityDays >= 0 || (monitor.actions || []).some((action) => action.relatedControlId === "line_maturity" && completeMonitorAction(action));
    const coreDataComplete = Boolean(monitor.identity?.borrower && monitor.identity?.obligorNumber && monitor.facility?.type && monitor.facility?.grossCommitment != null && isValidIsoDate(monitor.facility?.lineMaturity || "") && maturityCalculationValid && expiredMaturityAddressed && latestBanking && latestBanking.outstanding != null && latestQuarter?.periodEnd && latestQuarter.revenue != null && latestQuarter.netIncome != null);
    return [
      { title: "Recognized quarterly-monitor profile and source binding", pass: Boolean(monitor.profileMatched) && sourceBound, detail: monitor.profileMatched && sourceBound ? `${monitor.profile}; exact workbook structure and active source fingerprint are bound to the reviewed observations.` : "Workbook profile, active source record, fingerprint binding or imported monitor facts are missing or changed." },
      { title: "Review date and source periods confirmed", pass: dateOrderValid && bankingCutoffValid, detail: dateOrderValid && bankingCutoffValid ? `PM-entered review ${monitor.reviewAsOfDate}; workbook financial ${monitor.financialPeriodEnd}; workbook inventory ${monitor.inventoryPeriodEnd}; latest eligible banking ${latestBanking.periodEnd}. No TODAY() dependency.` : "Enter the review date and confirm that the workbook financial/inventory dates and latest eligible banking period do not fall after it." },
      { title: "Core borrower, facility and period data present", pass: coreDataComplete, detail: coreDataComplete ? `Borrower identity, ratings, exposure and current-quarter financials are populated; ${maturityDays} days to maturity is date-reconciled.` : "Borrower identity, current/recommended ratings, facility commitment/maturity, date-reconciled maturity calculation, banking exposure or cutoff-period revenue/net income is missing; an expired maturity also requires a structured disposition." },
      { title: "Extracted observations reviewed by exception", pass: Boolean(monitor.reviewed) && monitorFacts.length >= 3 && materialCoverage && unreviewedFacts.length === 0 && rejectedFacts.length === 0, detail: !monitorFacts.length ? "No active monitor observations remain bound to the workbook source." : !materialCoverage ? "One or more displayed core borrower, rating, maturity, banking, financial, balance-sheet or inventory values lack an accepted controlling fact at the stated cutoff." : rejectedFacts.length ? `${rejectedFacts.length} extracted monitor observation(s) were rejected; correct and re-import the workbook before completing the review package.` : unreviewedFacts.length ? `${unreviewedFacts.length} monitor observation(s) still require acceptance, rejection or reconciliation.` : monitor.reviewed ? "Defined core facts are controlling and the remaining mapped saved-value observations were confirmed by exception." : "PM confirmation of the extracted monitor data is required." },
      { title: "Material workbook anomalies dispositioned", pass: Boolean(monitor.anomalyDispositionReviewed) && blockingAnomalies.length === 0, detail: blockingAnomalies.length ? `${blockingAnomalies.length} blocking formula/external-link anomaly remains.` : openAnomalies.length ? `${openAnomalies.length} warning/note anomaly item(s) are retained with PM review.` : "No unresolved workbook anomaly." },
      { title: "Reporting schedule reviewed", pass: Boolean(monitor.reportingReviewed) && reportingDatesValid && reportingAddressed, detail: !reportingDatesValid ? "A reported last-received period falls after the review date or is not a valid date." : reportingExceptions.length ? `${pastDue.length} item(s) are past due and ${reportingExceptions.length - pastDue.length} require date/status review; each exception requires a documented action.` : "No item is past due or lacks a usable due-date basis as of the explicit review date." },
      { title: "Covenants mapped, tested and sourced", pass: Boolean(monitor.covenantReviewConfirmed) && covenantsComplete, detail: covenantsComplete ? `${covenantRows.length} covenant tests carry dated actuals, requirements and normalized headroom; every exception or non-comparable test has a structured owner, action, due date and evidence path.` : `${covenantReviewItems.length} covenant test(s) require structured action, and every test must have comparable sourced values or an explicit reviewed disposition with no reported/computed mismatch.` },
      { title: "Balance sheet and reconciliations reviewed", pass: balanceReviewed, detail: latestBalance ? `Cross-foot difference: ${money(latestBalance.crossFootDifference)}. Missing risk assets remain missing.` : "No current balance-sheet snapshot was supplied." },
      { title: "PM conclusion and rating judgment complete", pass: judgmentComplete, detail: judgmentComplete ? "Assessment, conclusion, current and recommended rating, and contrary evidence are PM-owned." : "Complete the PM assessment, conclusion, current and recommended ratings, and rationale." },
      { title: "Material same-scope conflicts resolved", pass: openConflicts().length === 0, detail: openConflicts().length ? `${openConflicts().length} conflict(s) remain in the period-aware fact ledger.` : "No unresolved same-entity, same-period conflict remains." }
    ];
  }

  function gateRows() {
    if (state.workflow === "portfolio_monitor" || state.deal?.dealType === "Quarterly Monitor") return monitorGateRows();
    const hasPrimaryRepayment = (state.memoSections || []).some((section) => section.id === "repayment" && section.narrative.length > 80);
    const hasStress = Boolean(state.stressReviewed && state.scenarioResults?.status === "computed" && state.scenarioResults.inputFingerprint === stressInputFingerprint() && scenarioCalculationLedgerMatches());
    const activeRisks = state.risks.filter((risk) => risk.recordStatus !== "superseded");
    const risksLinked = activeRisks.length > 0 && activeRisks.every((risk) => risk.evidence && risk.consequence && risk.mitigant && risk.residual && risk.condition && governedRecordEvidence(risk).pass);
    const changesRequired = ["Renewal", "Modification"].includes(state.deal.dealType);
    const activeChanges = state.changes.filter((change) => change.recordStatus !== "superseded");
    const changesGoverned = (!changesRequired || activeChanges.length > 0) && activeChanges.every((change) =>
      change.field && change.prior && change.current && change.proposed && change.impact && governedRecordEvidence(change).pass &&
      (state.mode === "demo" || String(change.evidenceNote || "").trim().length >= 8)
    );
    const activeCovenants = state.covenants.filter((covenant) => covenant.recordStatus !== "superseded");
    const covenantScopeSelected = Array.isArray(state.workbookTabs) ? state.workbookTabs.includes("Covenant Tracking") : !Array.isArray(state.workbookScope) || state.workbookScope.includes("covenants");
    const covenantRowsGoverned = activeCovenants.length > 0 && activeCovenants.every((covenant) =>
      covenant.name && covenant.threshold && covenant.actual && covenant.headroom && covenant.trend && covenant.status && governedRecordEvidence(covenant).pass &&
      (state.mode === "demo" || Boolean(registeredEntityName(covenant.entity)) && isValidIsoDate(covenant.asOfDate) && String(covenant.evidenceNote || "").trim().length >= 8)
    );
    const covenantsGoverned = covenantRowsGoverned || (!covenantScopeSelected && activeCovenants.length === 0);
    const requiredDocuments = (window.HBF_CreditPath?.documentPlan(state) || []).filter((item) => item.required);
    const documentsRepresented = state.mode === "demo" || requiredDocuments.length > 0 && requiredDocuments.every((item) => item.complete);
    const conditionsComplete = state.conditions.length > 0 && state.conditions.every((condition) => [condition.phase, condition.requirement, condition.purpose, condition.owner, condition.verification].every((value) => String(value || "").trim()));
    const placeholders = (state.memoSections || []).filter((section) => /(?:\bTBD\b|\bXX+\b|\binsert\b|choose an item|#(?:N\/A|REF!|VALUE!|DIV\/0!|NAME\?|NUM!))/i.test(section.narrative));
    const ratingOwned = Boolean(state.deal.proposedRating && !/required|not entered|\btbd\b/i.test(state.deal.proposedRating));
    const unreviewedFacts = state.facts.filter((fact) => !["supported", "accepted", "rejected", "superseded"].includes(fact.status));
    const sourcesSupported = state.facts.filter((fact) => ["supported", "accepted"].includes(fact.status)).every((fact) => fact.provenance === "analyst_judgment" ? Boolean(fact.locator) : Boolean(fact.sourceId && fact.locator && entityApproved(fact)));
    const memoIds = new Set((state.memoSections || []).map((section) => section.id));
    const memoStructureComplete = state.memoSections.length === MEMO_BLUEPRINT.length && memoIds.size === MEMO_BLUEPRINT.length && MEMO_BLUEPRINT.every(([id]) => memoIds.has(id));
    const memoIncomplete = (state.memoSections || []).filter((section) => section.narrative.trim().length < 60);
    const ungroundedSections = (state.memoSections || []).filter((section) => {
      if (state.mode === "demo") return false;
      if (section.classification === "pm_judgment") return false;
      return !(section.supportingFactIds || []).length || section.supportingFactIds.some((id) => { const fact = factById(id); return !fact || !ACCEPTED_FACT_STATUSES.has(fact.status); });
    });
    const applicabilityIncomplete = (state.applicability || []).filter((item) => !["ready", "not_applicable"].includes(item.status) || item.kind === "core" && item.status !== "ready" || String(item.basis || "").trim().length < 8);
    const modificationControl = (state.applicability || []).find((item) => item.id === "modification");
    const modificationReady = state.deal.dealType !== "Modification" || modificationControl?.status === "ready";
    const formulaErrorCount = workbookFormulaErrorTotal(state.workbook || {});
    const formulaReviewReady = formulaErrorCount === 0 || Boolean(
      state.workbook.formulaErrorsReviewed &&
      state.workbook.formulaErrorReviewConfirmed &&
      Number(state.workbook.formulaErrorReviewCount) === formulaErrorCount &&
      String(state.workbook.errorReviewNote || "").trim().length >= 80
    );
    const demoWorkbookReady = Boolean(
      state.mode === "demo" && state.workbook.loaded && !state.workbook.scopeChangedAfterImport && state.workbook.profileMatched &&
      state.workbook.reviewedAsNonDealEvidence === true && state.workbook.formulaErrorsReviewed === true &&
      String(state.workbook.errorReviewNote || "").trim().length >= 80
    );
    const workbookScopeMatches = Boolean(window.HBF_CreditPath?.workbookScopeMatches?.(state));
    const liveWorkbookReady = Boolean(state.mode === "live" && state.workbookScopeConfirmed === true && state.workbook.loaded && !state.workbook.scopeChangedAfterImport && workbookScopeMatches && state.workbook.profileMatched && state.workbook.recalculatedConfirmed && formulaReviewReady);
    const workbookReady = state.mode === "demo" ? demoWorkbookReady : liveWorkbookReady;
    const decisionOwned = Boolean(state.deal.request && state.deal.recommendation && !/(?:not defined|required|\btbd\b|#(?:N\/A|REF!|VALUE!|DIV\/0!|NAME\?|NUM!))/i.test(`${state.deal.request} ${state.deal.recommendation}`));
    const ratingFact = factByPath("credit.proposedRiskRating");
    const ratingAligned = Boolean(ratingFact && String(ratingFact.value).trim() === String(state.deal.proposedRating).trim() && ratingFact.provenance === "analyst_judgment");
    const ambiguousPaths = controllingAmbiguities();
    const sharedDiagnostics = window.HBFExporters?.evaluateReadiness?.(state)?.creditDiagnostics;
    const failedSharedControls = sharedDiagnostics ? Object.entries(sharedDiagnostics).filter(([key, value]) => key !== "ready" && value === false).map(([key]) => key) : ["shared readiness engine unavailable"];
    return [
      { title: "Required source documents are represented", pass: documentsRepresented, detail: documentsRepresented ? `${requiredDocuments.length} applicable source-document slots are represented by reviewed Opus sources.` : `${requiredDocuments.filter((item) => !item.complete).length} required document slot(s) remain open. Return to Add documents for the exact names and Opus batches.` },
      { title: "Material conflicts resolved", pass: openConflicts().length === 0, detail: openConflicts().length ? `${openConflicts().length} same-field conflict remains.` : "Selected and rejected values retained with rationale." },
      { title: "One explicit controlling version per canonical output", pass: ambiguousPaths.length === 0, detail: ambiguousPaths.length ? `${ambiguousPaths.length} path(s) have multiple accepted versions but no single controlling selection: ${ambiguousPaths.slice(0, 4).join(", ")}.` : "No entity, period or scenario version is selected by array order." },
      { title: "Workbook structure, saved values and applicable errors reviewed", pass: workbookReady, detail: !state.workbook.loaded ? "No workbook loaded." : state.mode === "demo" ? demoWorkbookReady ? `${state.workbook.profile}; all ${formulaErrorCount} reported errors and missing cached values are explicitly isolated to a non-deal parser specimen.` : "The demo parser specimen lacks its required non-deal evidence disposition." : `${state.workbook.profile}; automatic-mode/saved-value control ${state.workbook.recalculatedConfirmed ? "passed" : "failed"}; ${formulaErrorCount ? `exact-count review ${formulaReviewReady ? `recorded for all ${formulaErrorCount}` : `required for ${formulaErrorCount}`}` : "no saved formula errors reported"}.` },
      { title: "Every imported fact is accepted, rejected or reconciled", pass: unreviewedFacts.length === 0, detail: unreviewedFacts.length ? `${unreviewedFacts.length} candidate, missing, judgment-required or conflicted fact(s) remain.` : "No unreviewed candidate can drive output." },
      { title: "Primary repayment source quantified", pass: hasPrimaryRepayment, detail: hasPrimaryRepayment ? "Amount, timing, weak assumption and maturity link are described." : "Repayment narrative is incomplete." },
      { title: "Selected downside is recorded and synchronized", pass: hasStress, detail: hasStress ? `Rule ${state.scenarioResults.ruleVersion}; price, pace, cost, rate and cancellation consequences recorded.` : "No current recorded scenario, or accepted inputs are incomplete." },
      { title: "Risk chains and conditions are actionable", pass: risksLinked && conditionsComplete, detail: risksLinked && conditionsComplete ? `${activeRisks.length} current risks and ${state.conditions.length} complete conditions are linked to action, ownership and verification${state.risks.length > activeRisks.length ? `; ${state.risks.length - activeRisks.length} superseded risk record(s) remain as history` : ""}.` : "A current risk chain or condition register is incomplete." },
      { title: "Transaction changes and covenant results are governed", pass: changesGoverned && covenantsGoverned, detail: changesGoverned && covenantsGoverned ? `${activeChanges.length} current change record(s); ${covenantScopeSelected ? `${activeCovenants.length} current covenant result(s)` : "the PM omitted the covenant workbook module and the memo must carry the N/A conclusion"}. Current records carry controlling fact citations, reviewed workbook lineage or explicit PM-judgment classification${state.changes.length + state.covenants.length > activeChanges.length + activeCovenants.length ? `; ${state.changes.length + state.covenants.length - activeChanges.length - activeCovenants.length} superseded record(s) remain as history` : ""}.` : `${changesRequired && !activeChanges.length ? "A renewal/modification requires at least one current change record. " : ""}${covenantScopeSelected && !activeCovenants.length ? "The selected covenant module requires at least one governed result. " : ""}Every current change and covenant must carry valid evidence lineage or explicit PM judgment.` },
      { title: "All 17 memo sections are complete", pass: memoStructureComplete && memoIncomplete.length === 0, detail: !memoStructureComplete ? "The fixed 17-section memo outline is missing, duplicated or altered." : memoIncomplete.length ? `${memoIncomplete.length} section(s) contain fewer than 60 characters.` : "The fixed 17-section memo outline is populated." },
      { title: "Memo sections are grounded or PM-classified", pass: ungroundedSections.length === 0, detail: ungroundedSections.length ? `${ungroundedSections.length} section(s) need accepted citations or an explicit PM-judgment edit.` : "Each section is tied to accepted facts or explicit PM judgment." },
      { title: "Narratives are current to controlling facts", pass: !state.staleNarrativeReviewRequired, detail: state.staleNarrativeReviewRequired ? "A controlling fact changed after narrative preparation; PM dependency review remains open." : "No unresolved fact-to-narrative dependency flag remains." },
      { title: "Legacy and conditional applicability is decided", pass: Boolean((state.applicability || []).length) && applicabilityIncomplete.length === 0 && modificationReady, detail: !modificationReady ? "A modification deal requires a Ready modification/accounting workflow disposition; N/A is not permitted." : applicabilityIncomplete.length ? `${applicabilityIncomplete.length} applicability decision(s) or bases remain.` : "Every core/conditional control is Ready or N/A with a PM basis." },
      { title: "No unresolved placeholders or formula errors in narrative", pass: placeholders.length === 0, detail: placeholders.length ? `${placeholders.length} memo section(s) contain placeholder/error patterns.` : "Narrative scan passed." },
      { title: "PM decision fields are complete", pass: decisionOwned, detail: decisionOwned ? "Request and recommendation are explicitly PM-owned." : "Request or recommendation remains a placeholder." },
      { title: "Risk rating remains a named, aligned PM judgment", pass: ratingOwned && ratingAligned, detail: ratingOwned && ratingAligned ? `${state.deal.proposedRating}; PM decision record is the controlling rating fact.` : "The proposed rating is missing or not synchronized to a PM-owned canonical record." },
      { title: "Accepted material fact lineage is present", pass: sourcesSupported && state.facts.some((fact) => ["supported", "accepted"].includes(fact.status)), detail: sourcesSupported ? "Every accepted fact has a source and locator." : "One or more accepted facts lack a source locator." },
      { title: "Shared export readiness controls pass", pass: Boolean(sharedDiagnostics?.ready), detail: sharedDiagnostics?.ready ? "The same pure controls used by Word, PDF, CSV and checkpoint restore pass this revision." : `Shared export controls remain open: ${failedSharedControls.join(", ")}.` }
    ];
  }

  function renderGate() {
    const gates = gateRows();
    const rulesPass = gates.every((gate) => gate.pass) && openIssues("blocker").length === 0;
    const isMonitor = state.workflow === "portfolio_monitor" || state.deal?.dealType === "Quarterly Monitor";
    return `${pageHead("Review readiness", isMonitor ? "A monitor is complete only when its cutoffs, exceptions and judgment can be challenged" : "A memo is complete only when its support can be challenged", "Blockers, warnings and required human attestations are separate—never collapsed into a misleading completion percentage.")}
      <div class="gate-grid">
        <section class="gate-list">${gates.sort((a, b) => Number(a.pass) - Number(b.pass)).map((gate) => `<div class="gate-row"><span class="gate-icon${gate.pass ? "" : " blocked"}">${gate.pass ? "✓" : "!"}</span><div><h3>${esc(gate.title)}</h3><p>${esc(gate.detail)}</p></div><span class="tag ${gate.pass ? "good" : "bad"}">${gate.pass ? "Passed" : "Blocked"}</span></div>`).join("")}</section>
        <aside class="attestation-card">
          <p class="eyebrow" style="color:#8fb0bc">Human ownership</p><h3>Portfolio manager attestation</h3><p>The Studio assembles and verifies. The PM owns the credit judgment. Any material edit clears these attestations.</p>
          <label class="check-line"><input type="checkbox" data-attestation="facts" ${state.attestations.facts ? "checked" : ""}><span>I reviewed the controlling facts, source dates and conflict resolutions.</span></label>
          <label class="check-line"><input type="checkbox" data-attestation="calculations" ${state.attestations.calculations ? "checked" : ""}><span>I reviewed the material calculations, definitions and stress assumptions.</span></label>
          <label class="check-line"><input type="checkbox" data-attestation="judgment" ${state.attestations.judgment ? "checked" : ""}><span>I own the recommendation, risk analysis, mitigants and conditions.</span></label>
          <label class="check-line"><input type="checkbox" data-attestation="rating" ${state.attestations.rating ? "checked" : ""}><span>I selected the proposed risk rating under current bank definitions.</span></label>
          <button class="button button-primary" type="button" data-finalize ${rulesPass && allAttested() ? "" : "disabled"}>${state.finalized ? (isMonitor ? "Review Package Complete" : "Review Ready") : (isMonitor ? "Mark Review Package Complete" : "Mark Review Ready")}</button>
          <p class="mt-15">${rulesPass ? allAttested() ? "All controls are ready for finalization." : "Control gates pass. Complete all four attestations." : `${openIssues("blocker").length || gates.filter((gate) => !gate.pass).length} control blocker(s) must be cleared.`}</p>
        </aside>
      </div>
      ${isMonitor ? `<section class="panel mt-15"><div class="panel-head"><h3>Quarterly-monitor controls</h3><span class="tag neutral">Separate from credit approval</span></div><div class="panel-body"><p>The completion state confirms the review package is internally consistent and PM-attested. It does not approve credit, change the risk rating or waive an exception. Those decisions remain with authorized bank officers.</p><button class="button button-quiet" type="button" data-view-link="monitor">Return to portfolio monitor</button></div></section>` : `<section id="applicability-matrix" class="panel mt-15"><div class="panel-head"><h3>Memo and regulatory applicability matrix</h3><span class="tag neutral">PM / specialist-owned determinations</span></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Control</th><th>Type</th><th>Decision</th><th>PM basis / specialist status</th></tr></thead><tbody>${(state.applicability || []).map((item) => `<tr><td><strong>${esc(item.label)}</strong></td><td>${esc(item.kind)}</td><td><select class="compact-select" data-app-status="${esc(item.id)}"><option value="pending" ${item.status === "pending" ? "selected" : ""}>Pending</option><option value="ready" ${item.status === "ready" ? "selected" : ""}>Required — ready</option><option value="not_applicable" ${item.kind === "core" ? "disabled" : ""} ${item.status === "not_applicable" ? "selected" : ""}>Not applicable</option></select></td><td><input class="basis-input" data-app-basis="${esc(item.id)}" maxlength="600" autocomplete="off" value="${esc(item.basis || "")}" placeholder="Required basis, source, owner or specialist review"></td></tr>`).join("")}</tbody></table></div><div class="panel-body"><p class="muted">The tool records the workflow disposition only. Final CRA, Reg H, HMDA, HVCRE, appraisal, environmental, accounting, policy and other specialist determinations remain with authorized bank functions.</p></div></section>`}
      <section class="panel mt-15"><div class="panel-head"><h3>Warnings carried to reviewer</h3><span class="tag warning">${openIssues("warning").length} warning${openIssues("warning").length === 1 ? "" : "s"}</span></div><div class="panel-body">${openIssues("warning").length ? `<ul class="compact-list">${openIssues("warning").map((issue) => `<li><strong>${esc(issue.title)}:</strong> ${esc(issue.detail)}</li>`).join("")}</ul>` : "No unresolved warnings."}</div></section>`;
  }

  function renderExport() {
    const hasMonitor = Boolean(state.monitor);
    const isMonitor = state.workflow === "portfolio_monitor" || state.deal?.dealType === "Quarterly Monitor";
    const wordAction = isMonitor
      ? '<button class="button button-primary button-large" type="button" data-export-monitor>Download Word monitor</button>'
      : '<button class="button button-primary button-large" type="button" data-export-memo>Download Word memo</button>';
    const requiredAction = `<div class="required-output-actions">${wordAction}<button class="button button-quiet" type="button" data-view-link="gate">${state.finalized ? "View final controls" : "Complete final check"}</button></div>`;
    const requiredTitle = isMonitor ? "Quarterly portfolio monitor (.docx)" : "Credit memo (.docx)";
    const requiredDescription = isMonitor
      ? "The required officer-facing Word monitor. Financial-statement and balance-sheet detail remain available as selected output modules."
      : "The required, fully editable Word credit memo. Every saved memo narrative is included; unresolved controls keep the document visibly marked Draft.";
    return `${pageHead("Required output", isMonitor ? "Download the Word portfolio monitor" : "Download the Word credit memo", "Word is always available. It remains visibly Draft until the exact readiness controls and PM attestations pass.")}
      <section class="required-output-card"><span class="required-output-icon" aria-hidden="true">W</span><div><p class="eyebrow">Required for every ${isMonitor ? "quarterly review" : "credit memo"}</p><h3>${requiredTitle}</h3><p>${requiredDescription}</p><div class="required-output-status">${statusMarkup()}<span>${state.finalized ? "Current review-ready revision" : "Safe to download now as a working draft"}</span></div></div>${requiredAction}</section>
      <details class="optional-output-shell"><summary>Optional supporting files</summary><div class="export-grid">
        <article class="export-card"><span class="export-icon">P</span><h3>PDF copy</h3><p>Print the current officer-facing memo or monitor and save it as PDF.</p><button class="button button-quiet" type="button" ${isMonitor ? "data-print-monitor" : "data-print-memo"}>Print / save PDF</button></article>
        <article class="export-card"><span class="export-icon">R</span><h3>Credit review pack</h3><p>Full source lineage, calculations, conflicts, conditions, edit history, attestations and snapshot metadata.</p><button class="button button-quiet" type="button" data-export-review>Download review pack</button></article>
        <article class="export-card"><span class="export-icon">!</span><h3>Open-action register</h3><p>Actionable issues, conditions, reporting and covenant exceptions sorted for follow-up.</p><button class="button button-quiet" type="button" data-export-issues>Download open actions</button></article>
        ${hasMonitor ? `<article class="export-card"><span class="export-icon">Σ</span><h3>Portfolio rollup row</h3><p>One normalized CSV row using the same values shown in the monitor.</p><button class="button button-quiet" type="button" data-export-rollup>Download rollup CSV</button></article>` : ""}
        <article class="export-card"><span class="export-icon">↻</span><h3>Local checkpoint</h3><p>Integrity-tagged JSON for an approved folder. The application never autosaves the deal.</p><button class="button button-quiet" type="button" data-export-checkpoint>Save checkpoint</button><button class="button button-quiet mt-8" type="button" data-trigger-checkpoint>Resume checkpoint</button></article>
      </div></details>
      <details class="package-status"><summary>Package status and controls</summary><section class="panel"><div class="panel-body"><div class="fact-row"><span>Accepted ledger facts</span><strong>${state.facts.filter((fact) => ["supported", "accepted"].includes(fact.status)).length} accepted / supported facts</strong><span class="tag good">Ledgered</span></div><div class="fact-row"><span>Conflicts</span><strong>${openConflicts().length} unresolved</strong><span class="tag ${openConflicts().length ? "bad" : "good"}">${openConflicts().length ? "Blocks final" : "Cleared"}</span></div><div class="fact-row"><span>Human attestation</span><strong>${Object.values(state.attestations).filter(Boolean).length} of 4 complete</strong><span class="tag ${allAttested() ? "good" : "warning"}">${allAttested() ? "Complete" : "Required"}</span></div><div class="fact-row"><span>Privacy boundary</span><strong>No application persistence or outbound customer-data transmission</strong><span class="tag good">Local</span></div></div></section></details>
      <p class="muted mt-15">Downloaded files become bank records and must be stored, transmitted and retained only in approved locations. Browser and operating-system download history are outside the application’s control.</p>`;
  }

  async function printFrozenOutput(kind) {
    if (!window.HBFExporters?.buildPrintHtml) return toast("The local print composer did not load.", "error");
    const surface = document.getElementById("print-surface");
    const result = await window.HBFExporters.buildPrintHtml(state, kind);
    surface.innerHTML = result.html;
    surface.setAttribute("data-orientation", result.orientation || "portrait");
    surface.setAttribute("aria-hidden", "false");
    document.body.classList.add("printing-output");
    const cleanup = () => {
      document.body.classList.remove("printing-output");
      surface.setAttribute("aria-hidden", "true");
      surface.innerHTML = "";
      window.removeEventListener("afterprint", cleanup);
    };
    window.addEventListener("afterprint", cleanup);
    window.setTimeout(() => window.print(), 120);
  }

  function showEvidence(id) {
    const dialog = document.getElementById("evidence-dialog");
    const title = document.getElementById("evidence-title");
    const content = document.getElementById("evidence-content");
    const fact = factById(id);
    const calculation = calcById(id);
    const source = sourceById(id);

    if (fact) {
      const evidenceSource = sourceById(fact.sourceId);
      title.textContent = fact.label || fact.path;
      content.innerHTML = `<div class="evidence-grid">
        <div class="evidence-box"><small>Canonical field</small><strong>${esc(fact.path)}</strong></div>
        <div class="evidence-box"><small>Value / classification</small><strong>${esc(fact.valueType === "money" ? money(fact.value) : fact.valueType === "percent" ? percent(fact.value) : fact.valueType === "multiple" ? multiple(fact.value) : fact.value)} • ${esc(fact.provenance)}</strong></div>
        <div class="evidence-box"><small>Source</small><strong>${esc(evidenceSource?.name || fact.sourceId || "PM judgment")}</strong></div>
        <div class="evidence-box"><small>Locator / as-of</small><strong>${esc(fact.locator || "Not supplied")} • ${esc(formatDate(fact.asOfDate))}</strong></div>
        ${fact.formula ? `<div class="evidence-box"><small>Formula</small><strong>${esc(fact.formula)}</strong></div>` : ""}
        <div class="evidence-box"><small>Verification</small><strong>${esc(fact.status)}</strong></div>
        <div class="evidence-excerpt">${esc(fact.excerpt || "No source excerpt retained.")}</div>
      </div>`;
    } else if (calculation) {
      title.textContent = calculation.name;
      content.innerHTML = `<div class="evidence-grid">
        <div class="evidence-box"><small>Rule ID</small><strong>${esc(calculation.id)} • v1.0-demo</strong></div>
        <div class="evidence-box"><small>Result / status</small><strong>${esc(calculation.display)} • ${esc(calculation.status)}</strong></div>
        <div class="evidence-box"><small>Formula</small><strong>${esc(calculation.formula)}</strong></div>
        <div class="evidence-box"><small>Comparison</small><strong>${esc(calculation.comparison)}</strong></div>
        <div class="evidence-excerpt">Inputs: ${(calculation.inputs || []).map((inputRef) => {
          const input = factById(inputRef) || factByPath(inputRef);
          if (input) return esc(`${inputRef} = ${input.valueType === "money" ? money(input.value) : input.value}`);
          if (inputRef === "deal.asOfDate") return esc(`${inputRef} = ${state.deal.asOfDate || "not supplied"}`);
          if (inputRef === "selected stress assumptions") return esc(`${inputRef} = ${JSON.stringify(state.stress || {})}`);
          const linkedCalculation = calcById(inputRef);
          return esc(`${inputRef} = ${linkedCalculation ? linkedCalculation.display : "not found"}`);
        }).join("\n") || "No input IDs recorded."}\n\nFull precision result: ${esc(calculation.result)}\nDisplayed result: ${esc(calculation.display)}</div>
      </div>`;
    } else if (source) {
      title.textContent = source.name;
      const relatedFacts = state.facts.filter((item) => item.sourceId === source.id);
      content.innerHTML = `<div class="evidence-grid">
        <div class="evidence-box"><small>Source ID / type</small><strong>${esc(source.id)} • ${esc(source.type)}</strong></div>
        <div class="evidence-box"><small>As-of / packet</small><strong>${esc(formatDate(source.asOfDate))} • ${esc(source.packet || "Local")}</strong></div>
        <div class="evidence-box"><small>Fingerprint</small><strong>${esc(source.fingerprint || source.digest || "Not supplied")}</strong></div>
        <div class="evidence-box"><small>Mapped facts</small><strong>${relatedFacts.length}</strong></div>
        <div class="evidence-excerpt">${esc(source.detail || "No source notes.")}\n\n${relatedFacts.length ? esc(relatedFacts.slice(0, 20).map((item) => `${item.id}  ${item.path}  ${item.locator}`).join("\n")) : "No material fact is currently linked to this source."}</div>
      </div>`;
    } else {
      title.textContent = "Evidence not found";
      content.textContent = "This evidence identifier is no longer present in the active session.";
    }
    dialog.showModal();
  }

  function normalizePacketText(text) {
    let value = String(text || "").trim();
    value = value.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "");
    const first = value.indexOf("{");
    const last = value.lastIndexOf("}");
    if (first > 0 && last > first) value = value.slice(first, last + 1);
    return value;
  }

  function assertOnlyKeys(record, allowedKeys, label) {
    const unexpected = Object.keys(record || {}).filter((key) => !allowedKeys.has(key));
    if (unexpected.length) throw new Error(`${label} contains unsupported propert${unexpected.length === 1 ? "y" : "ies"}: ${unexpected.join(", ")}.`);
  }

  function validatePacket(packet) {
    if (!packet || typeof packet !== "object" || Array.isArray(packet)) throw new Error("Packet must be one JSON object.");
    assertOnlyKeys(packet, new Set(["schemaVersion", "dealId", "packetId", "createdAt", "sourceManifest", "facts", "narratives", "openItems"]), "Packet");
    if (packet.schemaVersion !== "1.0") throw new Error("Unsupported packet schema. Expected version 1.0.");
    if (packet.dealId !== state.deal.id) throw new Error(`Deal ID mismatch. This session is ${state.deal.id}; the packet is ${packet.dealId || "blank"}.`);
    if (!packet.packetId || typeof packet.packetId !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._-]{1,79}$/.test(packet.packetId)) throw new Error("packetId must be 2–80 letters, numbers, dots, underscores or hyphens.");
    if (!isValidIsoDateTime(packet.createdAt)) throw new Error("createdAt must be a full ISO-8601 date-time with seconds and a Z or ±HH:MM timezone.");
    if (!Array.isArray(packet.sourceManifest) || packet.sourceManifest.length < 1 || packet.sourceManifest.length > 5) throw new Error("sourceManifest must contain one to five documents.");
    if (!Array.isArray(packet.facts)) throw new Error("facts must be an array.");
    if (!Array.isArray(packet.openItems)) throw new Error("openItems must be an array.");
    if (JSON.stringify(packet).length > 2000000) throw new Error("Packet exceeds the 2 MB safety limit.");

    const serialized = JSON.stringify(packet);
    if (/\b\d{3}-\d{2}-\d{4}\b/.test(serialized) || /"(?:ssn|tax_?id|account_?number|date_?of_?birth|dob)"\s*:/i.test(serialized)) {
      throw new Error("The packet appears to contain a prohibited sensitive identifier. Remove it in Opus and generate a corrected packet.");
    }

    const normalizedPacketId = packet.packetId.toUpperCase();
    const plannedBatchDefinition = (window.HBF_CreditPath?.BATCH_DEFINITIONS || []).find((batch) => {
      if (normalizedPacketId === batch.id) return true;
      if (!normalizedPacketId.startsWith(`${batch.id}R`)) return false;
      const revision = Number(normalizedPacketId.slice(batch.id.length + 1));
      return Number.isSafeInteger(revision) && revision >= 2;
    });
    if (!plannedBatchDefinition) throw new Error("packetId must be an applicable generated B01–B06 packet ID, optionally followed by R2, R3 and so on for a continuation chat.");
    const currentBatchPlan = window.HBF_CreditPath?.batchPlan?.(state) || [];
    const plannedBatch = currentBatchPlan.find((batch) => batch.id === plannedBatchDefinition.id && Array.isArray(batch.pendingDocuments) && batch.pendingDocuments.length > 0);
    if (!plannedBatch) throw new Error(`${plannedBatchDefinition.id} has no pending applicable documents for the current deal and exact workbook-tab selection.`);
    const importedPacketIds = new Set((state.importedPacketIds || []).map((id) => String(id).toUpperCase()));
    let expectedPacketId = plannedBatch.id;
    if (importedPacketIds.has(expectedPacketId)) {
      let revision = 2;
      while (importedPacketIds.has(`${plannedBatch.id}R${revision}`)) revision += 1;
      expectedPacketId = `${plannedBatch.id}R${revision}`;
    }
    if (normalizedPacketId !== expectedPacketId) throw new Error(`packetId must be the current generated ID ${expectedPacketId} for this batch.`);
    const pendingDocumentIds = new Set(plannedBatch.pendingDocuments.map((document) => document.id));
    const sourceIds = new Set();
    const sourceHashes = new Map();
    const sourceFileNames = new Map();
    (Array.isArray(state.sources) ? state.sources : [])
      .filter((source) => source && !["rejected", "superseded", "reference_only"].includes(source.status) && /^B0[1-6](?:R(?:[2-9]|[1-9]\d+))?$/i.test(String(source.packet || "")))
      .forEach((source) => {
        const normalizedHash = /^[A-Fa-f0-9]{64}$/.test(String(source.fingerprint || "")) ? String(source.fingerprint).toLowerCase() : "";
        const normalizedFileName = String(source.name || "").trim().replace(/\s+/g, " ").toLowerCase();
        if (normalizedHash && !sourceHashes.has(normalizedHash)) sourceHashes.set(normalizedHash, source.id || "an earlier Opus source");
        if (normalizedFileName && !sourceFileNames.has(normalizedFileName)) sourceFileNames.set(normalizedFileName, { sourceId: source.id || "an earlier Opus source", hash: normalizedHash });
      });
    packet.sourceManifest.forEach((source, index) => {
      if (!source || typeof source !== "object" || !source.sourceId || !source.fileName || !source.documentType || !source.asOfDate) throw new Error(`sourceManifest[${index}] is missing a required field.`);
      assertOnlyKeys(source, new Set(["sourceId", "fileName", "documentType", "asOfDate", "sha256"]), `sourceManifest[${index}]`);
      if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/.test(source.sourceId)) throw new Error(`sourceManifest[${index}].sourceId is invalid.`);
      if (typeof source.fileName !== "string" || !source.fileName.trim() || source.fileName.length > 240) throw new Error(`sourceManifest[${index}].fileName must contain 1–240 characters.`);
      if (typeof source.documentType !== "string" || !source.documentType.trim() || source.documentType.length > 120) throw new Error(`sourceManifest[${index}].documentType must contain 1–120 characters.`);
      if (/^USE EXACT UPLOADED FILENAME FOR:/i.test(source.fileName.trim())) throw new Error(`sourceManifest[${index}].fileName still contains prompt instruction text; replace it with the exact uploaded filename in Opus.`);
      if (!isValidIsoDate(source.asOfDate)) throw new Error(`sourceManifest[${index}].asOfDate must be a real YYYY-MM-DD date.`);
      if (plannedBatchDefinition) {
        const assignment = new RegExp(`^${normalizedPacketId}-S(\\d{2})(?:-[A-Z])?$`, "i").exec(source.sourceId);
        const slot = assignment ? Number(assignment[1]) : 0;
        const documentId = plannedBatchDefinition.documentIds[slot - 1];
        const expectedDocument = (window.HBF_CreditPath?.DOCUMENT_DEFINITIONS || []).find((item) => item.id === documentId);
        if (!assignment || !expectedDocument) throw new Error(`sourceManifest[${index}].sourceId must use one of the generated ${normalizedPacketId}-S01 through ${normalizedPacketId}-S${String(plannedBatchDefinition.documentIds.length).padStart(2, "0")} assignments.`);
        if (!pendingDocumentIds.has(documentId)) throw new Error(`sourceManifest[${index}] is not a pending applicable document in the current generated ${expectedPacketId} prompt.`);
        if (source.documentType.trim().toLowerCase() !== expectedDocument.label.toLowerCase()) throw new Error(`sourceManifest[${index}].documentType must remain “${expectedDocument.label}” for source ${source.sourceId}.`);
      }
      if (source.sha256 != null && !/^[A-Fa-f0-9]{64}$/.test(source.sha256)) throw new Error(`sourceManifest[${index}].sha256 must contain 64 hexadecimal characters.`);
      const normalizedHash = String(source.sha256 || "").toLowerCase();
      const normalizedFileName = source.fileName.trim().replace(/\s+/g, " ").toLowerCase();
      if (normalizedHash && sourceHashes.has(normalizedHash)) throw new Error(`sourceManifest[${index}] duplicates the physical file already assigned to ${sourceHashes.get(normalizedHash)}. One original file cannot satisfy multiple document slots.`);
      const priorFile = sourceFileNames.get(normalizedFileName);
      if (priorFile && (!normalizedHash || !priorFile.hash)) throw new Error(`sourceManifest[${index}].fileName duplicates ${priorFile.sourceId} without distinct SHA-256 fingerprints. One original file cannot satisfy multiple document slots.`);
      if (normalizedHash) sourceHashes.set(normalizedHash, source.sourceId);
      sourceFileNames.set(normalizedFileName, { sourceId: source.sourceId, hash: normalizedHash });
      if (sourceIds.has(source.sourceId)) throw new Error(`Duplicate source ID ${source.sourceId} in packet.`);
      sourceIds.add(source.sourceId);
      const existing = sourceById(source.sourceId);
      if (existing) {
        const exactMatch = existing.name === source.fileName && existing.type === source.documentType && existing.asOfDate === source.asOfDate && String(existing.fingerprint || "not supplied").toLowerCase() === String(source.sha256 || "not supplied").toLowerCase();
        if (!exactMatch) throw new Error(`Source ID ${source.sourceId} is already registered with different name, type, date or fingerprint metadata.`);
      }
    });
    const latestSourceDate = Math.max(...packet.sourceManifest.map((source) => Date.parse(`${source.asOfDate}T00:00:00Z`)));
    if (Date.parse(packet.createdAt) < latestSourceDate) throw new Error("createdAt cannot precede the latest source as-of date.");

    const allowedProvenance = new Set(["source_fact"]);
    const allowedVerification = new Set(["supported", "conflicted", "missing", "judgment_required"]);
    const allowedUnits = new Set(["USD", "percent", "multiple", "units", "months", "text", "date"]);
    const allowedPeriods = new Set(["as_of", "monthly", "quarterly", "annual", "ytd", "ttm", "projected", "cumulative", "not_applicable"]);
    const allowedScales = new Set([1, 1000, 1000000]);
    const generatedFactIds = new Set();
    packet.facts.forEach((fact, index) => {
      if (!fact || typeof fact !== "object" || !fact.fieldId || fact.value === undefined || !fact.provenance || !fact.sourceId || !fact.locator) throw new Error(`facts[${index}] lacks fieldId, value, provenance, sourceId or locator.`);
      assertOnlyKeys(fact, new Set(["fieldId", "value", "unit", "scale", "entity", "periodType", "scenario", "asOfDate", "provenance", "sourceId", "locator", "excerpt", "verification"]), `facts[${index}]`);
      if (!/^[a-z][A-Za-z0-9]*(?:\.[a-z][A-Za-z0-9]*)+$/.test(fact.fieldId)) throw new Error(`facts[${index}].fieldId is not a canonical domain.field path.`);
      if (!sourceIds.has(fact.sourceId)) throw new Error(`facts[${index}] must reference a source in this packet's sourceManifest; ${fact.sourceId} is not listed.`);
      if (!allowedProvenance.has(fact.provenance)) throw new Error(`facts[${index}].provenance is not allowed.`);
      if (!allowedVerification.has(fact.verification)) throw new Error(`facts[${index}].verification is not allowed.`);
      if (!allowedUnits.has(fact.unit)) throw new Error(`facts[${index}].unit is not allowed.`);
      if (!allowedPeriods.has(fact.periodType)) throw new Error(`facts[${index}].periodType is not allowed.`);
      const canonicalRule = OPUS_FIELD_RULES[fact.fieldId];
      if (!canonicalRule) throw new Error(`facts[${index}].fieldId is not in the approved canonical field catalog.`);
      if (fact.unit !== canonicalRule[0] || fact.periodType !== canonicalRule[1]) throw new Error(`facts[${index}] does not use the approved unit and period for ${fact.fieldId}.`);
      if (typeof fact.entity !== "string" || !fact.entity.trim() || fact.entity.length > 240) throw new Error(`facts[${index}].entity is required.`);
      if (!allowedScales.has(fact.scale)) throw new Error(`facts[${index}].scale must be 1, 1000 or 1000000.`);
      if (fact.unit !== "USD" && fact.scale !== 1) throw new Error(`facts[${index}].scale must be 1 for non-USD units.`);
      if (!isValidIsoDate(fact.asOfDate)) throw new Error(`facts[${index}].asOfDate must be a real YYYY-MM-DD date.`);
      if (Date.parse(`${fact.asOfDate}T00:00:00Z`) > Date.parse(packet.createdAt)) throw new Error(`facts[${index}].asOfDate cannot be after packet createdAt.`);
      const intentionallyMissing = fact.value === null && ["missing", "judgment_required"].includes(fact.verification);
      if (["USD", "percent", "multiple", "units", "months"].includes(fact.unit) && !intentionallyMissing && (typeof fact.value !== "number" || !Number.isFinite(fact.value))) throw new Error(`facts[${index}].value must be a finite JSON number for ${fact.unit}.`);
      if (["USD", "percent", "multiple", "units", "months"].includes(fact.unit) && !intentionallyMissing) {
        const normalizedNumericValue = fact.unit === "USD" ? fact.value * fact.scale : fact.value;
        if (!Number.isFinite(normalizedNumericValue) || Math.abs(normalizedNumericValue) > Number.MAX_SAFE_INTEGER) throw new Error(`facts[${index}].value exceeds the safe normalized numeric range for ${fact.unit}.`);
      }
      if (!intentionallyMissing && NONNEGATIVE_OPUS_FIELDS.has(fact.fieldId) && fact.value < 0) throw new Error(`facts[${index}].value cannot be negative for ${fact.fieldId}.`);
      if (fact.fieldId === "operating.cancellationRate" && !intentionallyMissing && (fact.value < 0 || fact.value > 1)) throw new Error(`facts[${index}].value must be between 0 and 1 for operating.cancellationRate.`);
      if (fact.unit === "date" && !intentionallyMissing && (!isValidIsoDate(fact.value) || fact.scale !== 1)) throw new Error(`facts[${index}].value must be a real YYYY-MM-DD date with scale 1.`);
      if (fact.unit === "text" && !intentionallyMissing && (typeof fact.value !== "string" || !fact.value.trim() || fact.value.length > 4000 || fact.scale !== 1)) throw new Error(`facts[${index}].text value is invalid.`);
      if (typeof fact.locator !== "string" || !fact.locator.trim() || fact.locator.length > 500) throw new Error(`facts[${index}].locator is invalid.`);
      if (typeof fact.excerpt === "string" && fact.excerpt.length > 400) throw new Error(`facts[${index}].excerpt exceeds the allowed length.`);
      if (fact.scenario != null && (typeof fact.scenario !== "string" || !fact.scenario.trim() || fact.scenario.length > 80)) throw new Error(`facts[${index}].scenario is invalid.`);
      const generatedId = `P-${packet.packetId}-${String(index + 1).padStart(3, "0")}`;
      if (generatedFactIds.has(generatedId) || factById(generatedId)) throw new Error(`Generated fact ID ${generatedId} is duplicated in this deal session.`);
      generatedFactIds.add(generatedId);
    });

    const knownNarrativeKeys = new Set(MEMO_BLUEPRINT.map(([id]) => id));
    const packetFieldIds = new Set(packet.facts.map((fact) => fact.fieldId));
    if (!packet.narratives || typeof packet.narratives !== "object" || Array.isArray(packet.narratives)) throw new Error("narratives must be an object keyed to memo sections.");
    Object.entries(packet.narratives).forEach(([key, narrative]) => {
      if (!knownNarrativeKeys.has(key)) throw new Error(`Narrative section ${key} is not recognized.`);
      if (!narrative || typeof narrative !== "object" || typeof narrative.text !== "string" || narrative.text.length < 1 || narrative.text.length > 12000) throw new Error(`Narrative section ${key} must contain bounded text.`);
      assertOnlyKeys(narrative, new Set(["text", "supportingFieldIds"]), `Narrative section ${key}`);
      if (!Array.isArray(narrative.supportingFieldIds) || narrative.supportingFieldIds.length < 1 || narrative.supportingFieldIds.some((fieldId) => !packetFieldIds.has(fieldId))) throw new Error(`Narrative section ${key} must cite supportingFieldIds present in this same packet.`);
      if (new Set(narrative.supportingFieldIds).size !== narrative.supportingFieldIds.length) throw new Error(`Narrative section ${key} contains duplicate supportingFieldIds.`);
    });

    packet.openItems.forEach((item, index) => {
      if (!item || typeof item !== "object" || typeof item.title !== "string" || !item.title.trim() || item.title.length > 220) throw new Error(`openItems[${index}].title is invalid.`);
      assertOnlyKeys(item, new Set(["title", "severity", "owner", "dueDate"]), `openItems[${index}]`);
      if (!["blocker", "warning", "note"].includes(item.severity)) throw new Error(`openItems[${index}].severity is invalid.`);
      if (item.owner != null && (typeof item.owner !== "string" || !item.owner.trim() || item.owner.length > 80)) throw new Error(`openItems[${index}].owner is invalid.`);
      if (item.dueDate != null && !isValidIsoDate(item.dueDate)) throw new Error(`openItems[${index}].dueDate must be a real YYYY-MM-DD date.`);
    });
  }

  function valuesEquivalent(a, b) {
    if (typeof a === "number" || typeof b === "number") return Number.isFinite(Number(a)) && Number.isFinite(Number(b)) && Math.abs(Number(a) - Number(b)) < 0.000001;
    return String(a).trim().toLowerCase() === String(b).trim().toLowerCase();
  }

  function factMergeKey(fact) {
    return JSON.stringify([
      String(fact.entity || "").trim().replace(/\s+/g, " ").toLowerCase(), String(fact.path || "").trim().toLowerCase(),
      String(fact.periodType || "").trim().toLowerCase(), String(fact.asOfDate || "").trim(),
      String(fact.scenario || "actual").trim().toLowerCase(), String(fact.unit || "").trim().toLowerCase()
    ]);
  }

  function mergeCandidateFact(newFact) {
    const newKey = factMergeKey(newFact);
    const competing = state.facts.find((existing) => factMergeKey(existing) === newKey && !["rejected", "missing", "judgment_required", "superseded", "scope_stale"].includes(existing.status) && existing.id !== newFact.id && !valuesEquivalent(existing.value, newFact.value));
    const displacedControllingFact = Boolean(competing && (competing.controlling || ACCEPTED_FACT_STATUSES.has(competing.status)));
    state.facts.push(newFact);
    if (!competing) return;
    const existingConflict = competing.conflictId ? state.conflicts.find((conflict) => conflict.id === competing.conflictId) : null;
    if (existingConflict && (existingConflict.status === "open" || !existingConflict.status)) {
      if (!existingConflict.candidates.includes(newFact.id)) existingConflict.candidates.push(newFact.id);
      newFact.conflictId = existingConflict.id;
      newFact.status = "conflicted";
      return;
    }
    const conflictId = `C${String(state.conflicts.length + 1).padStart(2, "0")}`;
    competing.status = "conflicted";
    competing.conflictId = conflictId;
    newFact.status = "conflicted";
    newFact.conflictId = conflictId;
    state.conflicts.push({ id: conflictId, fieldPath: newFact.path, mergeKey: newKey, label: newFact.label || newFact.path, materiality: "Same entity, field, period type, as-of date, scenario and normalized unit; different normalized values", status: "open", selectedFactId: null, rationale: "", candidates: [competing.id, newFact.id] });
    state.issues.push({ id: `I-${conflictId}`, severity: "blocker", title: `${newFact.label || newFact.path} does not reconcile`, detail: "Two same-period source values differ. Select the controlling evidence and document the rationale.", actionView: "reconcile", status: "open", conflictId });
    if (displacedControllingFact) {
      supersedeDependentRecords([competing.id], `${competing.id} became conflicted after new same-period evidence arrived.`);
      markScenarioStale(`${newFact.label || newFact.path} now has conflicting same-period evidence; dependent analysis is no longer current.`);
    }
  }

  function ensureLiveImportSession() {
    if (state.mode !== "live") {
      openDealDialog();
      throw new Error("Start a live local deal before importing customer files. Demo and live facts cannot be mixed.");
    }
  }

  function mergePacketText(text) {
    ensureLiveImportSession();
    if (state.workflow === "credit_action" && !workbookScopeIsCurrent()) throw new Error("Add or re-add the workbook for the confirmed current tab selection before importing Opus evidence.");
    if (String(text || "").length > 2000000) throw new Error("Packet exceeds the 2 MB safety limit.");
    let packet;
    try { packet = JSON.parse(normalizePacketText(text)); } catch (error) { throw new Error(`Packet is not valid JSON: ${error.message}`); }
    validatePacket(packet);
    state.importedPacketIds = Array.isArray(state.importedPacketIds) ? state.importedPacketIds : [];
    if (state.importedPacketIds.includes(packet.packetId)) throw new Error(`Packet ${packet.packetId} has already been merged.`);

    packet.sourceManifest.forEach((source) => {
      if (!sourceById(source.sourceId)) state.sources.push({
        id: String(source.sourceId).slice(0, 80), name: String(source.fileName).slice(0, 240), type: String(source.documentType).slice(0, 120), asOfDate: String(source.asOfDate).slice(0, 30), packet: String(packet.packetId).slice(0, 80), status: "supported", fingerprint: String(source.sha256 || "not supplied").slice(0, 150), detail: "Imported through a validated internal Opus packet"
      });
    });

    const declaredConflictCandidates = [];
    packet.facts.forEach((fact, index) => {
      const type = fact.unit === "USD" ? "money" : fact.unit === "percent" ? "percent" : fact.unit === "multiple" ? "multiple" : fact.unit === "date" ? "date" : typeof fact.value === "number" ? "number" : "text";
      const value = fact.value === null ? null : type === "money" ? fact.value * fact.scale : fact.value;
      const candidate = {
        id: `P-${packet.packetId}-${String(index + 1).padStart(3, "0")}`,
        path: String(fact.fieldId).slice(0, 200), label: String(fact.fieldId).split(".").slice(-1)[0].replace(/([A-Z])/g, " $1"), value, valueType: type, unit: fact.unit || "", scale: Number(fact.scale || 1), entity: fact.entity || "", periodType: fact.periodType || "", scenario: fact.scenario || "actual", sourceId: String(fact.sourceId).slice(0, 80), locator: String(fact.locator).slice(0, 500), excerpt: String(fact.excerpt || "").slice(0, 400), status: ["missing", "judgment_required"].includes(fact.verification) ? fact.verification : "candidate", modelVerification: fact.verification, provenance: fact.provenance, asOfDate: fact.asOfDate || "", controlling: false
      };
      mergeCandidateFact(candidate);
      if (fact.verification === "conflicted") declaredConflictCandidates.push({ candidate, index });
    });

    declaredConflictCandidates.forEach(({ candidate, index }) => {
      if (candidate.status === "candidate" && !candidate.conflictId) {
        candidate.status = "judgment_required";
        state.issues.push({ id: `I-${packet.packetId}-FACT-${String(index + 1).padStart(3, "0")}`, severity: "blocker", title: `${candidate.label || candidate.path} was declared conflicted by the source review`, detail: "The model identified a conflict but only one candidate reached this packet. Import the competing source/value or reject this record; it cannot drive output.", actionView: "sources", status: "open", resolutionType: "fact_disposition", relatedFactId: candidate.id });
      }
    });

    packet.openItems.forEach((item, index) => state.issues.push({
      id: `I-${packet.packetId}-${String(index + 1).padStart(2, "0")}`, severity: ["blocker", "warning", "note"].includes(item.severity) ? item.severity : "warning", title: String(item.title || "Imported open item").slice(0, 220), detail: `Owner: ${String(item.owner || "PM").slice(0, 80)}${item.dueDate ? ` • Due: ${String(item.dueDate).slice(0, 30)}` : ""}`, actionView: "sources", status: "open", resolutionType: "documented_follow_up", openedByPacket: packet.packetId
    }));

    if (!state.importedNarratives) state.importedNarratives = [];
    if (packet.narratives && typeof packet.narratives === "object" && Object.keys(packet.narratives).length > 0) state.importedNarratives.push({ packetId: packet.packetId, narratives: packet.narratives, status: "AI draft — not accepted" });
    state.importedPacketIds.push(packet.packetId);
    state.editHistory.push({ action: `Validated and merged Opus evidence packet ${packet.packetId}`, at: new Date().toISOString() });
    state.issues = state.issues.filter((issue) => issue.id !== "NEW-I01");
    invalidateAttestations(`Opus evidence packet ${packet.packetId} was merged.`);
    return packet.packetId;
  }

  async function importWorkbook(file) {
    ensureLiveImportSession();
    if (state.workflow === "credit_action" && state.workbookScopeConfirmed !== true) throw new Error("Confirm the individual underwriting tabs used for this deal before adding the workbook.");
    toast("Inspecting the workbook locally…");
    const importState = state, importWorkflow = state.workflow, importScope = JSON.stringify([state.workbookTabs,state.workbookScopeConfirmed,state.deal.borrower]);
    const result = await window.HBFWorkbook.inspect(file);
    if (state !== importState || state.workflow !== importWorkflow || JSON.stringify([state.workbookTabs,state.workbookScopeConfirmed,state.deal.borrower]) !== importScope) throw new Error('The document changed while the workbook was being read. Add the file again for the current document.');
    if (!result.profileMatched) throw new Error(`Workbook profile is unknown or changed. Missing sheets: ${(result.missingSheets || []).join(", ") || "none"}; unexpected sheets: ${(result.unexpectedSheets || []).join(", ") || "none"}. The existing workbook, if any, was left untouched.`);
    if (!result.digest || /^unavailable/i.test(result.digest)) throw new Error("A cryptographic workbook fingerprint could not be created. Import stopped without changing the current session.");
    const scopedResult = window.HBF_CreditPath?.scopeWorkbookResult ? window.HBF_CreditPath.scopeWorkbookResult(state, result) : { ids: ["relationship"], sheetNames: ["Exposure"], code: "1", mappedFacts: result.mappedFacts || [], metadataReviewRequiredFacts: result.metadataReviewRequiredFacts || [], covenants: result.covenants || [], excludedScopeObservationCount: 0, sheetDiagnostics: result.sheetDiagnostics || [], applicableFormulaCount: result.formulaCount || 0, applicableFormulaErrorCount: result.formulaErrorCount || 0, applicableFormulasWithoutCachedValues: result.formulasWithoutCachedValues || 0, applicableExternalFormulaCount: result.externalFormulaCount || 0, applicableFormulaErrorSamples: result.formulaErrorSamples || result.formulaErrors || [] };
    const selectedScopeIds = scopedResult.ids;
    const selectedTabNames = scopedResult.sheetNames || window.HBF_CreditPath?.selectedWorkbookTabs(state) || ["Exposure"];
    const scopeCode = scopedResult.code;
    const baseSourceId = `WB-${String(result.digest || "UNAVAILABLE").slice(0, 12).toUpperCase()}-${scopeCode}`;
    const matchingWorkbookVersions = state.sources.filter((source) => source.origin === "workbook" && (source.id === baseSourceId || source.id.startsWith(`${baseSourceId}-R`)));
    if (matchingWorkbookVersions.some((source) => source.status !== "superseded")) throw new Error("This exact workbook version and PM-selected tab scope are already current.");
    const sourceId = matchingWorkbookVersions.length ? `${baseSourceId}-R${matchingWorkbookVersions.length + 1}` : baseSourceId;
    const previousWorkbookSources = new Set(state.sources.filter((source) => source.origin === "workbook" && source.status !== "superseded").map((source) => source.id));
    const previousWorkbookFactIds = new Set(state.facts.filter((fact) => previousWorkbookSources.has(fact.sourceId)).map((fact) => fact.id));
    state.sources.forEach((source) => { if (previousWorkbookSources.has(source.id)) source.status = "superseded"; });
    state.facts.forEach((fact) => { if (previousWorkbookFactIds.has(fact.id)) { fact.status = "superseded"; fact.controlling = false; fact.supersededAt = new Date().toISOString(); } });
    state.covenants.forEach((covenant) => { if (previousWorkbookSources.has(covenant.sourceId)) { covenant.recordStatus = "superseded"; covenant.supersededAt = new Date().toISOString(); covenant.evidenceSupersededReason = "The reviewed workbook source was superseded by a new local import."; } });
    supersedeDependentRecords(Array.from(previousWorkbookFactIds), "The cited workbook fact version was superseded by a new local workbook import.");
    state.conflicts.forEach((conflict) => {
      if (!conflict.candidates.some((id) => previousWorkbookFactIds.has(id))) return;
      conflict.status = "superseded"; conflict.selectedFactId = null; conflict.resolutionType = "source_reimport";
      conflict.rationale = `${conflict.rationale ? `${conflict.rationale} ` : ""}The workbook version was superseded by local re-import; surviving values returned to the candidate queue.`.trim();
      conflict.candidates.filter((id) => !previousWorkbookFactIds.has(id)).forEach((id) => { const fact = factById(id); if (fact && fact.status === "conflicted") { fact.status = "candidate"; fact.conflictId = null; fact.controlling = false; } });
      state.issues.forEach((issue) => { if (issue.conflictId === conflict.id) { issue.status = "resolved"; issue.resolution = { type: "source_reimport", evidenceId: sourceId, rationale: "Prior workbook version superseded; surviving fact requires fresh acceptance.", resolvedAt: new Date().toISOString() }; } });
    });
    const scopedMappedFacts = scopedResult.mappedFacts;
    const scopedMetadataFacts = scopedResult.metadataReviewRequiredFacts;
    const excludedScopeObservationCount = scopedResult.excludedScopeObservationCount;
    const metadataReviewRequiredFacts = [...scopedMetadataFacts, ...scopedMappedFacts.filter((fact) => !fact.asOfDate || !entityApproved(fact)).map((fact) => ({ ...fact, status: "metadata_review_required", eligibleForImport: false, metadataReviewRequired: Array.from(new Set([...(fact.metadataReviewRequired || []), ...(!fact.asOfDate ? ["asOfDate"] : []), ...(!entityApproved(fact) ? ["entity"] : [])])), reviewReason: "Bind a registered deal entity, period and as-of date before this workbook observation can enter the candidate fact ledger." }))];
    const readyMappedFacts = scopedMappedFacts.filter((fact) => !metadataReviewRequiredFacts.some((item) => item.id === fact.id));
    const perSheetDiagnostics = scopedResult.sheetDiagnostics;
    const applicableFormulaCount = scopedResult.applicableFormulaCount;
    const applicableFormulaErrorCount = scopedResult.applicableFormulaErrorCount;
    const applicableFormulasWithoutCachedValues = scopedResult.applicableFormulasWithoutCachedValues;
    const applicableExternalFormulaCount = scopedResult.applicableExternalFormulaCount;
    const applicableFormulaErrorSamples = scopedResult.applicableFormulaErrorSamples;
    const selectedCovenants = scopedResult.covenants;
    state.workbook = {
      loaded: true, fileName: result.fileName, profile: result.profile, profileMatched: result.profileMatched, sheets: result.sheets,
      mappedSheets: result.sheetNames.filter((name) => window.HBFWorkbook.approvedSheets.includes(name) && (window.HBF_CreditPath?.workbookSheetSelected ? window.HBF_CreditPath.workbookSheetSelected(state, name) : true)).length, mappedFacts: readyMappedFacts.length,
      metadataReviewRequiredFacts, formulaCount: result.formulaCount,
      applicableFormulaCount, applicableFormulaErrorCount, totalFormulaErrorCount: result.formulaErrorCount || 0,
      formulaErrorCount: applicableFormulaErrorCount, formulaErrorSamples: applicableFormulaErrorSamples, formulaErrors: applicableFormulaErrorSamples, formulaWarnings: applicableFormulaErrorCount,
      allFormulaErrorSamples: result.formulaErrorSamples || result.formulaErrors || [], formulaErrorSampleLimit: result.formulaErrorSampleLimit || 100, formulaErrorSamplesTruncated: applicableFormulaErrorCount > applicableFormulaErrorSamples.length,
      formulasWithoutCachedValues: applicableFormulasWithoutCachedValues, totalFormulasWithoutCachedValues: result.formulasWithoutCachedValues || 0,
      excludedFormulaErrorCount: Math.max(0, Number(result.formulaErrorCount || 0) - applicableFormulaErrorCount), excludedFormulasWithoutCachedValues: Math.max(0, Number(result.formulasWithoutCachedValues || 0) - applicableFormulasWithoutCachedValues),
      calcMode: result.calcMode, externalLinks: Number(result.externalLinks || 0) + applicableExternalFormulaCount, totalExternalFormulaCount: result.externalFormulaCount || 0,
      calcModeRecognized: Boolean(result.calcModeRecognized), calcModeBasis: result.calcModeBasis || "", savedFormulaValuesComplete: Boolean(result.calcModeRecognized && applicableFormulasWithoutCachedValues === 0),
      digest: result.digest, sourceId, scopeIds: selectedScopeIds, tabNames: selectedTabNames, scopeChangedAfterImport: false, excludedScopeObservationCount, sheetDiagnostics: perSheetDiagnostics,
      recalculatedConfirmed: Boolean(result.calcModeRecognized && applicableFormulasWithoutCachedValues === 0),
      formulaErrorsReviewed: false, formulaErrorReviewConfirmed: false, formulaErrorReviewCount: 0,
      reviewedAsNonDealEvidence: false, errorReviewNote: "", signatureChecks: result.signatureChecks || [], scaleChecks: result.scaleChecks || [], missingSheets: result.missingSheets, unexpectedSheets: result.unexpectedSheets
    };
    state.sources.push({ id: sourceId, name: result.fileName, type: "Underwriting workbook", origin: "workbook", asOfDate: "", packet: "Local import", status: result.profileMatched ? "supported" : "warning", fingerprint: result.digest, detail: `${result.sheets} template sheets retained; ${selectedTabNames.length} individually selected underwriting tabs across ${selectedScopeIds.length} groups; ${applicableFormulaErrorCount} applicable saved errors (${state.workbook.excludedFormulaErrorCount} out of scope); ${readyMappedFacts.length} directly eligible candidate facts; ${metadataReviewRequiredFacts.length} observations quarantined for metadata binding; ${excludedScopeObservationCount} extracted observations excluded from the deal ledger by scope` });
    readyMappedFacts.forEach((fact, index) => mergeCandidateFact({ ...fact, id: `${sourceId}-${String(index + 1).padStart(3, "0")}`, sourceId, controlling: false, status: "candidate" }));
    state.importedCovenants = selectedCovenants.map((item, index) => ({ ...item, id: `WC-${String(index + 1).padStart(3, "0")}`, sourceId, status: "review_required" }));
    state.issues = state.issues.filter((issue) => !String(issue.id).startsWith("WB-") && issue.id !== "NEW-I01");
    if (!result.profileMatched) state.issues.push({ id: "WB-PROFILE", severity: "blocker", title: "Workbook profile is unknown or changed", detail: `Missing sheets: ${result.missingSheets.join(", ") || "none"}; unexpected sheets: ${result.unexpectedSheets.join(", ") || "none"}. Exact mappings are disabled until reviewed.`, actionView: "sources", status: "open" });
    if (!result.calcModeRecognized) state.issues.push({ id: "WB-MANUAL", severity: "blocker", title: "Workbook calculation mode is not recognized automatic mode", detail: `${result.calcModeBasis || result.calcMode || "Calculation declaration missing"}. Open in Excel, use automatic calculation, recalculate the full workbook, save and re-import.`, actionView: "sources", status: "open" });
    if (result.externalLinks || applicableExternalFormulaCount) state.issues.push({ id: "WB-EXTERNAL", severity: "blocker", title: "Workbook depends on external links", detail: "External-link results are not accepted as current evidence until resolved and saved in the approved workbook.", actionView: "sources", status: "open" });
    if (applicableFormulaErrorCount) state.issues.push({ id: "WB-ERRORS", severity: "blocker", title: "Selected workbook tabs contain formula errors", detail: `${applicableFormulaErrorCount} saved error cells were found in the PM-selected tabs; up to ${result.formulaErrorSampleLimit || 100} addresses are retained for local review. Record every affected applicable module, or re-import a corrected workbook. The ${state.workbook.excludedFormulaErrorCount} error cells outside scope remain disclosed and never become zero or blank.`, actionView: "sources", status: "open" });
    if (applicableFormulasWithoutCachedValues) state.issues.push({ id: "WB-CACHE", severity: "blocker", title: "Selected workbook tabs contain formulas without saved values", detail: `${applicableFormulasWithoutCachedValues} formula cells in the PM-selected tabs do not have a cached result. Recalculate and save in Excel. ${state.workbook.excludedFormulasWithoutCachedValues} additional missing cached values are outside the selected scope and remain disclosed.`, actionView: "sources", status: "open" });
    invalidateAttestations("An underwriting workbook version was imported or replaced.");
    markScenarioStale("A workbook version was imported or replaced. Reaccept controlling facts and refresh dependent analysis.");
    state.editHistory.push({ action: `Imported workbook ${result.fileName} as ${sourceId} for ${selectedTabNames.length} PM-selected tabs (${selectedTabNames.join(", ")}); prior workbook versions retained as superseded`, at: new Date().toISOString() });
    toast(`Workbook inspected for ${selectedTabNames.length} selected tabs: ${readyMappedFacts.length} direct candidates and ${metadataReviewRequiredFacts.length} observations awaiting metadata binding.`);
  }

  async function importMonitorWorkbook(file) {
    ensureLiveImportSession();
    if (!window.HBFMonitor) throw new Error("The local quarterly-monitor adapter did not load.");
    toast("Inspecting the quarterly monitor locally…");
    const requestedReviewDate = state.monitor?.reviewDateBasis === "user_explicit" && isValidIsoDate(state.monitor.reviewAsOfDate || "") ? state.monitor.reviewAsOfDate : state.deal?.reviewDateConfirmedAt && isValidIsoDate(state.deal?.asOfDate || "") ? state.deal.asOfDate : null;
    if (!requestedReviewDate) throw new Error("Enter the review as-of date in Document details before importing the quarterly monitor. You can keep drafting with dates blank.");
    const importState = state, importWorkflow = state.workflow, importDateState = JSON.stringify([state.deal.asOfDate,state.deal.reviewDateConfirmedAt,state.monitor?.reviewAsOfDate,state.monitor?.reviewDateBasis]);
    const result = await window.HBFMonitor.inspect(file, { reviewAsOfDate: requestedReviewDate });
    if (state !== importState || state.workflow !== importWorkflow || JSON.stringify([state.deal.asOfDate,state.deal.reviewDateConfirmedAt,state.monitor?.reviewAsOfDate,state.monitor?.reviewDateBasis]) !== importDateState) throw new Error('The document or review date changed while the monitor was being read. Add it again for the current document.');
    if (!result.profileMatched) throw new Error(`Quarterly monitor profile is unknown or changed. Missing sheets: ${(result.missingSheets || []).join(", ") || "none"}; unexpected sheets: ${(result.unexpectedSheets || []).join(", ") || "none"}. The current monitor was left untouched.`);
    if (!result.digest || /^unavailable/i.test(result.digest)) throw new Error("A cryptographic workbook fingerprint could not be created. Import stopped without changing the current session.");
    const importedBorrower = String(result.monitor?.identity?.borrower || "").trim();
    const currentBorrower = String(state.deal?.borrower || "").trim();
    if (currentBorrower && !["Untitled deal", ""].includes(currentBorrower) && importedBorrower && normalizeEntity(currentBorrower) !== normalizeEntity(importedBorrower)) {
      throw new Error(`Borrower mismatch. This session is ${currentBorrower}; the workbook is ${importedBorrower}. No data was changed.`);
    }
    const baseSourceId = `QPM-${String(result.digest).slice(0, 12).toUpperCase()}`;
    const matchingVersions = state.sources.filter(source => source.origin === 'quarterly_monitor' && (source.id === baseSourceId || source.id.startsWith(baseSourceId + '-R')));
    if (matchingVersions.some(source => source.status !== 'superseded') && state.monitor?.reviewDateBasis === 'user_explicit' && state.monitor.reviewAsOfDate === requestedReviewDate) throw new Error("This exact quarterly-monitor workbook version is already current for this review date.");
    const sourceId = matchingVersions.length ? `${baseSourceId}-R${matchingVersions.length + 1}` : baseSourceId;

    const previousSources = new Set(state.sources.filter((source) => source.origin === "quarterly_monitor" && source.status !== "superseded").map((source) => source.id));
    const previousFactIds = new Set(state.facts.filter((fact) => previousSources.has(fact.sourceId)).map((fact) => fact.id));
    state.sources.forEach((source) => { if (previousSources.has(source.id)) source.status = "superseded"; });
    state.facts.forEach((fact) => {
      if (previousSources.has(fact.sourceId)) { fact.status = "superseded"; fact.controlling = false; fact.supersededAt = new Date().toISOString(); }
    });
    supersedeDependentRecords(Array.from(previousFactIds), "A newer quarterly-monitor workbook version was imported.");
    state.conflicts.forEach((conflict) => {
      if (!(conflict.candidates || []).some((id) => previousFactIds.has(id))) return;
      conflict.status = "superseded";
      conflict.selectedFactId = null;
      conflict.resolutionType = "source_reimport";
      conflict.rationale = `${conflict.rationale ? `${conflict.rationale} ` : ""}The quarterly-monitor workbook version was superseded by local re-import; surviving values returned to the candidate queue.`.trim();
      (conflict.candidates || []).filter((id) => !previousFactIds.has(id)).forEach((id) => {
        const fact = factById(id);
        if (fact && fact.status === "conflicted") { fact.status = "candidate"; fact.conflictId = null; fact.controlling = false; }
      });
      state.issues.forEach((issue) => {
        if (issue.conflictId === conflict.id) issue.status = "resolved";
      });
    });

    const monitor = result.monitor;
    monitor.workbookSourceId = sourceId;
    monitor.reviewed = false;
    monitor.reportingReviewed = false;
    monitor.covenantReviewConfirmed = false;
    monitor.anomalyDispositionReviewed = false;
    state.monitor = monitor;
    state.monitorWorkbook = {
      loaded: true,
      fileName: result.fileName,
      sourceId,
      digest: result.digest,
      profile: result.profile,
      profileMatched: result.profileMatched,
      sheets: result.sheets,
      cells: result.cells,
      formulaCount: result.formulaCount,
      formulaErrorCount: result.formulaErrorCount,
      formulaErrorDiagnostics: result.formulaErrorDiagnostics,
      formulasWithoutCachedValues: result.formulasWithoutCachedValues,
      missingCachedDiagnostics: result.missingCachedDiagnostics,
      calcMode: result.calcMode,
      calcModeRecognized: result.calcModeRecognized,
      externalLinks: result.externalLinks,
      externalFormulaCount: result.externalFormulaCount,
      conditionalReferenceErrors: result.conditionalReferenceErrors,
      reviewedAt: null
    };
    state.sources.push({ id: sourceId, name: result.fileName, type: "Quarterly portfolio monitor", origin: "quarterly_monitor", reviewAsOfDate: requestedReviewDate, asOfDate: monitor.reportingPeriodEnd || "", packet: "Local import", status: "supported", fingerprint: result.digest, detail: `${result.sheets} sheets; ${result.formulaCount} formulas; ${result.formulaErrorCount} saved errors classified by active/history/unused relevance; ${monitor.observations.length} dated observations staged for review` });
    monitor.observations.forEach((observation, index) => mergeCandidateFact({ ...observation, id: `${sourceId}-${String(index + 1).padStart(3, "0")}`, sourceId, status: "candidate", controlling: false }));
    state.issues = state.issues.filter((issue) => !String(issue.id).startsWith("MON-") && issue.id !== "NEW-I01");
    state.issues.push({ id: "MON-REVIEW", severity: "blocker", title: "Quarterly monitor review is not confirmed", detail: "Review the explicit cutoffs, extracted observations, formula-error classification, covenants, reporting items and anomalies before the monitor can be marked complete.", actionView: "monitor", status: "open", resolutionType: "system_control" });
    (monitor.anomalies || []).forEach((item) => state.issues.push({ id: item.id, severity: item.severity === "informational" ? "note" : item.severity, title: item.title, detail: item.detail, actionView: "monitor", status: item.status || "open", resolutionType: "system_control" }));
    if (importedBorrower) {
      state.deal.borrower = importedBorrower;
      state.deal.relationship = monitor.identity.relationship || importedBorrower;
    }
    state.deal.dealType = "Quarterly Monitor";
    state.deal.facilityType = monitor.facility.type || state.deal.facilityType;
    state.deal.asOfDate = monitor.reviewAsOfDate || state.deal.asOfDate;
    state.deal.currentRating = monitor.rating.current || state.deal.currentRating;
    state.deal.proposedRating = monitor.rating.recommended || state.deal.proposedRating;
    state.deal.request = "Quarterly portfolio monitoring review";
    state.deal.recommendation = monitor.assessment;
    state.workflow = "portfolio_monitor";
    invalidateAttestations("A quarterly monitor workbook version was imported or replaced.");
    state.editHistory.push({ action: `Imported quarterly monitor ${result.fileName} as ${sourceId}; prior monitor versions retained as superseded`, at: new Date().toISOString() });
    toast(`Quarterly monitor inspected: ${result.profile}; ${monitor.observations.length} dated observations and ${monitor.anomalies.length} explicit anomaly controls.`);
  }

  function confirmMonitorReview() {
    const monitor = state.monitor;
    if (!monitor) return toast("Load a quarterly monitor before confirming review.", "error");
    const blocking = (monitor.anomalies || []).filter((item) => item.severity === "blocker" && item.status !== "resolved");
    if (blocking.length) return toast(`${blocking.length} blocking workbook anomaly item(s) must be resolved before confirmation.`, "error");
    const rejected = state.facts.filter((fact) => fact.sourceId === monitor.workbookSourceId && fact.status === "rejected");
    if (rejected.length) return toast(`${rejected.length} monitor observation(s) were rejected. Correct and re-import the workbook before confirming the review.`, "error");
    invalidateAttestations("Quarterly monitor extraction and controls were confirmed.");
    const candidates = state.facts.filter((fact) => fact.sourceId === monitor.workbookSourceId && fact.status === "candidate");
    candidates.forEach((fact) => {
      const scope = factScopeKey(fact);
      state.facts.forEach((item) => { if (factScopeKey(item) === scope) item.controlling = false; });
      fact.status = "accepted";
      fact.controlling = true;
      fact.acceptedAt = new Date().toISOString();
    });
    monitor.reviewed = true;
    monitor.reportingReviewed = true;
    monitor.covenantReviewConfirmed = true;
    monitor.anomalyDispositionReviewed = true;
    if (state.monitorWorkbook) state.monitorWorkbook.reviewedAt = new Date().toISOString();
    state.issues.forEach((issue) => { if (issue.id === "MON-REVIEW") issue.status = "resolved"; });
    state.editHistory.push({ action: `Confirmed quarterly monitor extraction, cutoffs, reporting schedule, covenants and ${monitor.anomalies?.length || 0} anomaly dispositions`, at: new Date().toISOString() });
    toast(`${candidates.length} clean monitor observation${candidates.length === 1 ? "" : "s"} accepted; exceptions remain visible.`);
    activeStage = firstIncompleteStage();
    renderViewPreservingDrafts();
  }

  function canonicalJson(value) {
    if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
    if (value && typeof value === "object") return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`;
    return JSON.stringify(value);
  }

  async function sha256Text(value) {
    if (!window.crypto?.subtle && !window.HBFCrypto) throw new Error("A cryptographic file check is required to verify checkpoint integrity.");
    const digest = window.HBFCrypto ? await window.HBFCrypto.sha256(value) : await window.crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
    return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  function validateCheckpointState(candidate) {
    if (candidate?.authoring) {
      if (!window.HBFAuthoring) throw new Error("This working file needs the document editor. Reopen it in the current Studio.");
      window.HBFAuthoring.validate(candidate.authoring, candidate.workflow);
    }
    window.HBFAuthoringLegacy?.validate(candidate?.authoringMigration);
    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) throw new Error("Checkpoint state must be one JSON object.");
    if (candidate.schemaVersion !== "1.0") throw new Error("Unsupported checkpoint schema. Expected state schema 1.0.");
    if (!candidate.deal || typeof candidate.deal !== "object" || typeof candidate.deal.id !== "string" || typeof candidate.deal.borrower !== "string") throw new Error("Checkpoint deal identity is missing.");
    const limits = { sources: 500, facts: 20000, calculations: 5000, conflicts: 5000, issues: 10000, risks: 2000, conditions: 2000, covenants: 5000, changes: 5000, memoSections: 100 };
    Object.entries(limits).forEach(([key, limit]) => {
      if (!Array.isArray(candidate[key])) throw new Error(`Checkpoint ${key} must be an array.`);
      if (candidate[key].length > limit) throw new Error(`Checkpoint ${key} exceeds the ${limit.toLocaleString()}-record safety limit.`);
    });
    if (candidate.monitor != null && (typeof candidate.monitor !== "object" || Array.isArray(candidate.monitor))) throw new Error("Checkpoint monitor must be an object or null.");
  }

  function rejectDangerousObjectKeys(value, path) {
    if (!value || typeof value !== "object") return;
    for (const key of Object.keys(value)) {
      if (["__proto__", "prototype", "constructor"].includes(key)) throw new Error(`Checkpoint contains a prohibited object key at ${path || "root"}.`);
      rejectDangerousObjectKeys(value[key], path ? `${path}.${key}` : key);
    }
  }

  function normalizeRestoredCheckpoint(restored) {
    const next = clone(restored);
    ["editHistory", "applicability", "entities", "importedPacketIds", "importedNarratives", "actions", "workbookScope", "workbookTabs", "additionalDocumentIds"].forEach((key) => {
      next[key] = Array.isArray(next[key]) ? next[key] : [];
    });
    next.workbookScopeConfirmed = next.workbookScopeConfirmed === true;
    if (next.monitor && typeof next.monitor === "object" && !Array.isArray(next.monitor)) {
      ["bankingSeries", "balanceSheets", "inventorySeries", "reportingItems", "covenants", "calculations", "anomalies", "watchItems", "actions", "observations"].forEach((key) => {
        next.monitor[key] = Array.isArray(next.monitor[key]) ? next.monitor[key] : [];
      });
      next.monitor.financial = next.monitor.financial && typeof next.monitor.financial === "object" && !Array.isArray(next.monitor.financial) ? next.monitor.financial : {};
      ["quarterly", "ytd", "ttm"].forEach((key) => { next.monitor.financial[key] = Array.isArray(next.monitor.financial[key]) ? next.monitor.financial[key] : []; });
    }
    return next;
  }

  async function importCheckpoint(file) {
    if (!file || !/\.json$/i.test(file.name || "")) throw new Error("Choose a JSON checkpoint file.");
    if (file.size > 10 * 1024 * 1024) throw new Error("Checkpoint exceeds the 10 MB safety limit.");
    const startedState = state, startedRevision = state.contentRevision;
    const raw = await file.text();
    if (new TextEncoder().encode(raw).byteLength > 10 * 1024 * 1024) throw new Error("Checkpoint exceeds the 10 MB safety limit.");
    if (/"(?:__proto__|prototype|constructor)"\s*:/.test(raw)) throw new Error("Checkpoint contains a prohibited object key.");
    let parsed;
    try { parsed = JSON.parse(raw); } catch (error) { throw new Error(`Checkpoint is not valid JSON: ${error.message}`); }
    rejectDangerousObjectKeys(parsed, "root");
    if (parsed.format === 'HBF-CDS-TEMPLATE-WORKING-FILE') {
      const documentDraft = await window.HBFTemplate.restore(raw);
      const next = emptyState(); next.deal.id = 'HBF-' + (window.crypto.randomUUID?.() || window.HBFCrypto.uuid());
      next.authoring = { version: '1.0', kind: 'memo', content: documentDraft };
      next.deal.borrower = window.HBFAuthoring.borrower(next.authoring) || 'Untitled deal';
      next.deal.documentTitle = window.HBFAuthoring.title(next.authoring);
      parsed = { checkpointFormat: 'HBF-CDS-CHECKPOINT', checkpointVersion: '1.3', state: next, stateDigest: await window.HBFExporters.digestCanonical(next) };
    }
    if (parsed.checkpointFormat !== "HBF-CDS-CHECKPOINT" || !["1.1", "1.2", "1.3"].includes(parsed.checkpointVersion) || !parsed.state || !/^[a-f0-9]{64}$/i.test(parsed.stateDigest || "")) throw new Error("This is not a supported Studio working file. Use a Studio working file (1.1, 1.2 or 1.3) or a full-template working file (2.0). The earlier reduced five-page proof still opens in its saved example.");
    const actual = window.HBFExporters?.digestCanonical
      ? await window.HBFExporters.digestCanonical(parsed.state)
      : await sha256Text(canonicalJson(parsed.state));
    if (actual !== String(parsed.stateDigest).toLowerCase()) throw new Error("Checkpoint SHA-256 corruption check failed. The file may be incomplete or modified.");
    if (Boolean(parsed.state.authoring) !== (["1.2", "1.3"].includes(parsed.checkpointVersion))) throw new Error("The working-file version does not match its document content. The current document is unchanged.");
    const checkpointHadWorkbookScope = Array.isArray(parsed.state.workbookScope) && parsed.state.workbookScope.length > 0;
    const checkpointHadWorkbookTabs = Array.isArray(parsed.state.workbookTabs);
    const next = normalizeRestoredCheckpoint(parsed.state);
    if (next.authoring?.kind === "memo") next.authoring.content.reviewedRevision = null;
    validateCheckpointState(next);
    if (state !== startedState || state.contentRevision !== startedRevision) throw new Error('The current document changed while the working file was opening. Open the file again when ready.');
    if (!confirmLiveSessionReplacement(`checkpoint ${next.deal.id} for ${next.deal.borrower}`)) return;
    next.mode = "live";
    next.workflow = next.workflow || (next.deal.dealType === "Quarterly Monitor" ? "portfolio_monitor" : "credit_action");
    next.monitor = next.monitor && typeof next.monitor === "object" ? next.monitor : null;
    next.appVersion = "0.2.0";
    next.applicability = normalizeApplicability(next.applicability);
    next.workbookScope = Array.from(new Set(["relationship", ...(next.workbookScope.length ? next.workbookScope : window.HBF_CreditPath?.defaultWorkbookScope(next.deal.dealType, next.deal.facilityType) || [])]));
    next.workbookTabs = checkpointHadWorkbookTabs
      ? window.HBF_CreditPath?.selectedWorkbookTabs({ ...next, workbookTabs: next.workbookTabs }) || next.workbookTabs
      : (window.HBF_CreditPath?.WORKBOOK_SCOPE_DEFINITIONS || []).flatMap((item) => next.workbookScope.includes(item.id) ? item.sheets : []);
    next.workbookScope = (window.HBF_CreditPath?.workbookScopePlan(next) || []).filter((item) => item.selected).map((item) => item.id);
    if (next.workbook?.loaded && !Array.isArray(next.workbook.scopeIds)) {
      if (!checkpointHadWorkbookScope) {
        next.workbookScope = (window.HBF_CreditPath?.WORKBOOK_SCOPE_DEFINITIONS || []).map((item) => item.id);
        next.workbookTabs = (window.HBF_CreditPath?.WORKBOOK_SCOPE_DEFINITIONS || []).flatMap((item) => item.sheets);
        next.workbook.scopeIds = next.workbookScope.slice();
        next.workbook.tabNames = next.workbookTabs.slice();
        next.workbook.scopeChangedAfterImport = false;
      } else {
        next.workbook.scopeIds = [];
        next.workbook.scopeChangedAfterImport = true;
        next.issues.push({ id: "WB-SCOPE", severity: "blocker", title: "Re-add workbook to bind its tab scope", detail: "This checkpoint records a workbook-scope selection but not the scope used when its workbook facts were imported. Re-add the workbook before relying on its facts or marking the memo Review Ready.", actionView: "sources", status: "open" });
      }
    }
    if (next.workbook?.loaded && !Array.isArray(next.workbook.tabNames)) {
      next.workbook.tabNames = (window.HBF_CreditPath?.WORKBOOK_SCOPE_DEFINITIONS || []).flatMap((item) => (next.workbook.scopeIds || []).includes(item.id) ? item.sheets : []);
      if (checkpointHadWorkbookTabs) next.workbook.scopeChangedAfterImport = true;
    }
    if (next.workbook?.loaded) {
      const exactScopeMatches = Boolean(window.HBF_CreditPath?.workbookScopeMatches?.(next));
      const scopeNeedsReimport = Boolean(next.workbook.scopeChangedAfterImport || !exactScopeMatches);
      next.workbook.scopeChangedAfterImport = scopeNeedsReimport;
      if (scopeNeedsReimport) {
        const detail = "The current individual workbook-tab selection does not exactly match the tabs inspected on the saved workbook source. Re-add the workbook before any workbook fact, covenant or diagnostic can be relied upon.";
        const existingScopeIssue = next.issues.find((item) => item.id === "WB-SCOPE");
        if (existingScopeIssue) { existingScopeIssue.status = "open"; existingScopeIssue.severity = "blocker"; existingScopeIssue.detail = detail; }
        else next.issues.push({ id: "WB-SCOPE", severity: "blocker", title: "Re-add workbook for the current tab selection", detail, actionView: "sources", status: "open" });
        const affectedWorkbookFactIds = [];
        next.facts.forEach((fact) => {
          if (fact.sourceId !== next.workbook.sourceId || fact.status === "superseded") return;
          affectedWorkbookFactIds.push(fact.id);
          if (!fact.scopeStatusBeforeChange) { fact.scopeStatusBeforeChange = fact.status; fact.scopeControllingBeforeChange = Boolean(fact.controlling); }
          fact.status = "scope_stale";
          fact.controlling = false;
        });
        quarantineScopeDependentRecords(next, affectedWorkbookFactIds, "A cited workbook fact is outside the exact tab scope restored from this checkpoint.");
        next.covenants.forEach((covenant) => {
          if (covenant.sourceId !== next.workbook.sourceId || covenant.recordStatus === "superseded") return;
          if (!covenant.scopeRecordStatusBeforeChange) covenant.scopeRecordStatusBeforeChange = covenant.recordStatus || "current";
          covenant.recordStatus = "superseded";
          covenant.evidenceSupersededReason = "Workbook tab scope mismatch detected during checkpoint restore; re-add the workbook before reliance.";
        });
        const workbookSource = next.sources.find((source) => source.id === next.workbook.sourceId);
        if (workbookSource && workbookSource.status !== "superseded") workbookSource.status = "warning";
        invalidateCheckpointScopeAnalysis(next, "The saved workbook tab scope does not match the PM's current exact selection. Re-add the workbook, recalculate the downside and review affected memo sections before reliance.");
        next.contentRevision = (Number(next.contentRevision) || 0) + 1;
      }
    }
    next.importedPacketIds = Array.isArray(next.importedPacketIds) ? next.importedPacketIds : [];
    next.entities = Array.isArray(next.entities) && next.entities.length ? next.entities : [{ name: next.deal.borrower, role: "Borrower" }];
    next.attestations = next.attestations && typeof next.attestations === "object" ? next.attestations : { facts: false, calculations: false, judgment: false, rating: false };
    next.attestationMetadata = next.attestationMetadata && typeof next.attestationMetadata === "object" ? next.attestationMetadata : {};
    next.contentRevision = Number.isSafeInteger(next.contentRevision) ? next.contentRevision : 0;
    const migrated = window.HBFAuthoringLegacy?.upgrade(next);
    if (next.authoring) window.HBFAuthoring.validate(next.authoring, next.workflow);
    if (migrated) next.editHistory.push({ action: 'Preserved earlier working-file content in the full document workspace; combined narratives retained in Saved text for PM placement', at: new Date().toISOString() });
    const appControlsReady = appReadinessControlsFor(next);
    const exportControlsReady = !window.HBFExporters?.evaluateReadiness || window.HBFExporters.evaluateReadiness(next).ready;
    if (next.finalized && (!appControlsReady || !exportControlsReady)) {
      next.finalized = false;
      next.deal.status = "Draft";
      delete next.finalizedAt;
    }
    if (!next.finalized) next.deal.status = "Draft";
    next.editHistory.push({ action: "Resumed an explicit local checkpoint after schema validation and SHA-256 corruption check", at: new Date().toISOString() });
    state = next;
    sessionDirty = Boolean(migrated);
    editingSectionId = null;
    pendingConflictSelection = {};
    landingMode = false;
    activeStage = "add";
    activeStage = firstIncompleteStage();
    activeView = state.authoring ? "draft" : state.workflow === "portfolio_monitor" && state.monitor ? "monitor" : "brief";
    navigate(activeView, { stage: activeStage, force: true });
    toast(`Checkpoint resumed for ${state.deal.borrower}. No data was uploaded or stored by the application.`);
  }

  function syncResolvedField(conflict, selected) {
    if (!selected) return;
    if (conflict.fieldPath === "facility.proposedCommitment" && selected.valueType === "money") {
      const value = Number(selected.value);
      if (Number.isFinite(value)) {
        const short = money(value);
        state.deal.request = `${short} ${state.deal.dealType.toLowerCase()} request`;
        const commitmentChange = state.changes.find((item) => /commitment/i.test(item.field));
        if (commitmentChange) {
          commitmentChange.proposed = short;
          const current = numericFact("facility.currentCommitment");
          commitmentChange.impact = current == null ? "Controlling commitment updated; PM impact narrative required" : `${money(value - current)} change; PM must refresh the credit impact`;
        }
      }
    }
    markScenarioStale(`The controlling value for ${conflict.fieldPath} changed. Recalculate the downside case and review every affected narrative, condition and change row.`);
  }

  function completeConflict(conflictId) {
    const conflict = state.conflicts.find((item) => item.id === conflictId);
    const selectedId = pendingConflictSelection[conflictId] || conflict?.selectedFactId;
    const input = document.querySelector(`[data-resolution-note="${CSS.escape(conflictId)}"]`);
    const rationale = input ? input.value.trim() : conflict?.rationale || "";
    if (!conflict || !selectedId) return toast("Select the controlling value first.", "error");
    if (conflictHasStaleWorkbookEvidence(conflict)) return toast("Re-add the workbook for the confirmed current tab selection before resolving this conflict.", "error");
    if (conflict.status && conflict.status !== "open") return toast("Only an open conflict can be resolved.", "error");
    if (!conflict.candidates.includes(selectedId)) return toast("The selected value is not a candidate in this conflict.", "error");
    const selectedFact = factById(selectedId);
    if (!selectedFact || selectedFact.status === "superseded" || !entityApproved(selectedFact)) return toast("The selected fact must be a current record for the exact registered deal entity.", "error");
    if (rationale.length < 8) return toast("Add a short PM rationale before completing the resolution.", "error");
    conflict.selectedFactId = selectedId;
    conflict.rationale = rationale;
    conflict.status = "resolved";
    const selectedScopeKey = factScopeKey(selectedFact);
    state.facts.forEach((fact) => { if (factScopeKey(fact) === selectedScopeKey) fact.controlling = false; });
    conflict.candidates.forEach((factId) => {
      const fact = factById(factId);
      if (fact) { fact.status = factId === selectedId ? "accepted" : "rejected"; fact.controlling = factId === selectedId; }
    });
    supersedeDependentRecords(conflict.candidates.filter((factId) => factId !== selectedId), `Conflict ${conflictId} was resolved to ${selectedId}; the cited alternative no longer controls.`);
    state.issues.forEach((issue) => { if (issue.conflictId === conflictId || (conflictId === "C01" && issue.id === "I01")) issue.status = "resolved"; });
    invalidateAttestations(`${state.workflow === "portfolio_monitor" || state.deal?.dealType === "Quarterly Monitor" ? "Quarterly-monitor" : "Credit-action"} conflict ${conflictId} was resolved to ${selectedId}.`);
    if (state.workflow === "portfolio_monitor" || state.deal?.dealType === "Quarterly Monitor") {
      if (state.monitor) state.monitor.reviewed = false;
      const reviewIssue = state.issues.find((issue) => issue.id === "MON-REVIEW");
      if (reviewIssue) {
        reviewIssue.status = "open";
        reviewIssue.detail = `A controlling monitor fact changed when conflict ${conflictId} was resolved. Reconfirm the extracted facts and refresh the PM conclusion before completion.`;
      } else {
        state.issues.push({ id: "MON-REVIEW", severity: "blocker", title: "Quarterly monitor review requires refresh", detail: `A controlling monitor fact changed when conflict ${conflictId} was resolved. Reconfirm the extracted facts and refresh the PM conclusion before completion.`, actionView: "monitor", status: "open", resolutionType: "system_control" });
      }
    } else {
      syncResolvedField(conflict, selectedFact);
    }
    delete pendingConflictSelection[conflictId];
    state.finalized = false;
    toast("Conflict resolved. The rejected value and rationale remain in the review pack.");
    renderViewPreservingDrafts();
  }

  function markNarrativeReviewRequired(detail) {
    state.staleNarrativeReviewRequired = true;
    invalidateAttestations(detail || "A governed record changed.");
    if (!state.issues.some((issue) => issue.id === "FACT-NARRATIVE-STALE" && issue.status === "open")) state.issues.push({
      id: "FACT-NARRATIVE-STALE",
      severity: "blocker",
      title: "Memo narratives require dependency review",
      detail: detail || "A governed record changed. Review affected narrative, risks, conditions and change rows.",
      actionView: "memo",
      status: "open",
      resolutionType: "system_control"
    });
  }

  function markScenarioStale(detail) {
    preserveRecordedScenarioAsStale(state, detail);
    state.stressReviewed = false;
    state.calculations = state.calculations.filter((calc) => !STRESS_CALCULATION_IDS.has(calc.id));
    state.finalized = false;
    if (!state.issues.some((issue) => issue.id === "STRESS-STALE" && issue.status === "open")) state.issues.push({ id: "STRESS-STALE", severity: "blocker", title: "Selected downside is not synchronized", detail: detail || "A fact or assumption changed. Recalculate and record the selected scenario before finalization.", actionView: "downside", status: "open" });
    markNarrativeReviewRequired(detail || "A controlling fact or scenario assumption changed. Review affected narrative, risks, conditions and change rows.");
  }

  function acceptCandidateFact(id) {
    const fact = factById(id);
    if (!fact || fact.status !== "candidate" || fact.conflictId) return;
    if (!entityApproved(fact)) return toast(`Register ${fact.entity || "the fact entity"} before accepting this fact.`, "error");
    const scopeKey = factScopeKey(fact);
    const displacedIds = state.facts.filter((item) => factScopeKey(item) === scopeKey && item.id !== fact.id && item.controlling).map((item) => item.id);
    state.facts.forEach((item) => { if (factScopeKey(item) === scopeKey) item.controlling = false; });
    fact.status = "accepted";
    fact.controlling = true;
    fact.acceptedAt = new Date().toISOString();
    supersedeDependentRecords(displacedIds, `${fact.id} replaced the cited controlling version for ${fact.path}.`);
    state.editHistory.push({ action: `Accepted ${fact.id} as controlling for ${fact.path}`, at: fact.acceptedAt });
    markScenarioStale(`${fact.label || fact.path} was accepted. Recalculate the selected scenario if it affects a decision metric.`);
  }

  function rejectCandidateFact(id) {
    const fact = factById(id);
    if (!fact || ["supported", "accepted", "rejected", "conflicted"].includes(fact.status)) return;
    fact.status = "rejected";
    fact.controlling = false;
    state.issues.forEach((issue) => { if (issue.relatedFactId === fact.id) { issue.status = "resolved"; issue.resolution = { type: "fact_rejected", rationale: "Candidate rejected from the controlling fact ledger.", resolvedAt: new Date().toISOString() }; } });
    state.editHistory.push({ action: `Rejected candidate ${fact.id} for ${fact.path}`, at: new Date().toISOString() });
    invalidateAttestations(`Candidate ${fact.id} was rejected.`);
  }

  function bindWorkbookObservation(id) {
    if (state.mode !== "live") return toast("Workbook metadata can be bound only in a live local deal.", "error");
    if (!workbookScopeIsCurrent()) return toast("Re-add the workbook for the current tab selection before reviewing its observations.", "error");
    const observations = Array.isArray(state.workbook?.metadataReviewRequiredFacts) ? state.workbook.metadataReviewRequiredFacts : [];
    const observation = observations.find((item) => item.id === id);
    if (!observation) return toast("That quarantined workbook observation is no longer available.", "error");
    const sourceId = state.workbook?.sourceId;
    const source = sourceById(sourceId);
    if (!sourceId || !source || source.status === "superseded") return toast("The observation is not tied to the current registered workbook version.", "error");

    const entityControl = document.querySelector(`[data-meta-entity="${CSS.escape(id)}"]`);
    const periodControl = document.querySelector(`[data-meta-period="${CSS.escape(id)}"]`);
    const dateControl = document.querySelector(`[data-meta-date="${CSS.escape(id)}"]`);
    const entity = registeredEntityName(entityControl?.value);
    const periodType = String(periodControl?.value || "");
    const asOfDate = String(dateControl?.value || "");
    const allowedPeriods = new Set(["as_of", "monthly", "quarterly", "annual", "ytd", "ttm", "projected", "cumulative", "not_applicable", "as_complete"]);
    if (!entity) return toast("Select a registered deal entity before binding this observation.", "error");
    if (!allowedPeriods.has(periodType)) return toast("Select an explicit reporting period before binding this observation.", "error");
    if (!isValidIsoDate(asOfDate)) return toast("Enter a real as-of date in YYYY-MM-DD format.", "error");
    if (!observation.path || !observation.locator || !["money", "percent", "multiple", "number", "text", "date"].includes(observation.valueType)) return toast("This workbook observation lacks required field or locator metadata.", "error");
    if (["money", "percent", "multiple", "number"].includes(observation.valueType) && !Number.isFinite(Number(observation.value))) return toast("This workbook observation does not contain a finite normalized value.", "error");

    const suffix = String(observation.id || "OBSERVATION").replace(/[^A-Za-z0-9_-]/g, "-").slice(0, 90);
    const candidateId = `${sourceId}-META-${suffix}`;
    if (factById(candidateId)) return toast("This workbook observation has already been bound.", "error");
    const boundAt = new Date().toISOString();
    const candidate = {
      ...observation,
      id: candidateId,
      sourceId,
      entity,
      periodType,
      asOfDate,
      status: "candidate",
      verification: "candidate",
      verified: false,
      controlling: false,
      eligibleForImport: true,
      eligibleForBulkAcceptance: false,
      requiresMetadataReview: true,
      metadataReviewBound: { entity, periodType, asOfDate, boundAt },
      reviewReason: "Metadata was explicitly bound by the PM; individual fact acceptance is still required."
    };
    mergeCandidateFact(candidate);
    state.workbook.metadataReviewRequiredFacts = observations.filter((item) => item.id !== id);
    state.workbook.mappedFacts = Number(state.workbook.mappedFacts || 0) + 1;
    state.editHistory.push({ action: `Bound ${observation.id} to ${entity}, ${periodType}, ${asOfDate}; created ${candidateId}`, at: boundAt });
    invalidateAttestations(`Workbook observation ${observation.id} was bound as candidate ${candidateId}.`);
    state.finalized = false;
    toast(candidate.status === "conflicted" ? "Metadata bound; the observation entered reconciliation because a same-period value differs." : "Metadata bound; the observation now awaits individual fact acceptance.");
    renderViewPreservingDrafts();
  }

  function bindWorkbookCovenant(id) {
    if (state.mode !== "live") return toast("Workbook covenant results can be reviewed only in a live local deal.", "error");
    if (!workbookScopeIsCurrent()) return toast("Re-add the workbook for the current tab selection before reviewing its covenant observations.", "error");
    const observations = Array.isArray(state.importedCovenants) ? state.importedCovenants : [];
    const observation = observations.find((item) => item.id === id);
    if (!observation) return toast("That workbook covenant observation is no longer available.", "error");
    const sourceId = state.workbook?.sourceId;
    const source = sourceById(sourceId);
    if (!sourceId || observation.sourceId !== sourceId || !source || source.status === "superseded") return toast("The covenant observation is not tied to the current registered workbook version.", "error");
    const entity = registeredEntityName(document.querySelector(`[data-cov-entity="${CSS.escape(id)}"]`)?.value);
    const asOfDate = String(document.querySelector(`[data-cov-date="${CSS.escape(id)}"]`)?.value || "");
    const status = String(document.querySelector(`[data-cov-status="${CSS.escape(id)}"]`)?.value || "");
    const allowedStatuses = new Set(["Compliant", "Noncompliant", "Waiver / exception", "Pending / not tested"]);
    if (!entity) return toast("Select a registered tested entity for this covenant result.", "error");
    if (!isValidIsoDate(asOfDate)) return toast("Enter a real covenant test date in YYYY-MM-DD format.", "error");
    if (!allowedStatuses.has(status)) return toast("Choose a valid reviewed covenant status.", "error");
    if (!observation.thresholdLocator || !observation.actualLocator || !Number.isFinite(Number(observation.threshold)) || !Number.isFinite(Number(observation.actual))) return toast("This covenant observation lacks a usable threshold, actual value or workbook locator.", "error");

    const thresholdNumber = Number(observation.threshold);
    const actualNumber = Number(observation.actual);
    const isMaximum = /maximum|max\b|not exceed/i.test(observation.name || "");
    const isMinimum = /minimum|min\b|not less/i.test(observation.name || "");
    const headroomValue = isMaximum ? thresholdNumber - actualNumber : actualNumber - thresholdNumber;
    const qualifier = isMaximum ? " maximum" : isMinimum ? " minimum" : "";
    const reviewedAt = new Date().toISOString();
    const record = {
      id: nextRecordId("COV", state.covenants),
      name: String(observation.name || "Workbook covenant").slice(0, 220),
      entity,
      asOfDate,
      frequency: String(observation.frequency || "Not stated").slice(0, 100),
      threshold: `${formatCovenantValue(thresholdNumber, observation.valueType)}${qualifier}`,
      actual: formatCovenantValue(actualNumber, observation.valueType),
      headroom: formatCovenantValue(headroomValue, observation.valueType),
      trend: `Single reviewed workbook observation${observation.periodLabel ? ` for ${observation.periodLabel}` : ""}; prior-period trend not inferred.`,
      status,
      valueType: observation.valueType,
      thresholdValue: thresholdNumber,
      actualValue: actualNumber,
      evidenceClassification: "workbook_observation",
      sourceId,
      sourceFactIds: [],
      thresholdLocator: observation.thresholdLocator,
      actualLocator: observation.actualLocator,
      evidenceNote: `${observation.thresholdLocator}; ${observation.actualLocator}`,
      reviewedAt
    };
    state.covenants.push(record);
    state.importedCovenants = observations.filter((item) => item.id !== id);
    markNarrativeReviewRequired(`The ${record.name} covenant result was added from reviewed workbook evidence; refresh the covenant and conclusion narratives.`);
    state.editHistory.push({ action: `Reviewed workbook covenant ${observation.name} as ${status} for ${entity} at ${asOfDate}`, at: reviewedAt });
    toast("Reviewed covenant result added with workbook threshold and actual locators.");
    renderViewPreservingDrafts();
  }

  function hasMeaningfulLiveWork() {
    if (state.mode !== "live") return false;
    const hasNamedDeal = state.deal?.id !== "NEW-DEAL" || !["", "Untitled deal"].includes(state.deal?.borrower || "");
    const hasNarrative = (state.memoSections || []).some((section) => String(section.narrative || "").trim());
    return Boolean(hasNamedDeal || state.workbook?.loaded || state.sources.length || state.facts.length || (state.importedPacketIds || []).length || state.risks.length || state.conditions.length || state.changes.length || state.covenants.length || hasNarrative);
  }

  function confirmLiveSessionReplacement(nextLabel) {
    if (!hasMeaningfulLiveWork() && !viewHasUnsavedInputs()) return true;
    return window.confirm(`Replace the current live local deal with ${nextLabel}? Unsaved in-tab deal data will be removed. Download a checkpoint first if it must be retained.`);
  }

  function openDealDialog(preferredWorkflow) {
    const dialog = document.getElementById("deal-dialog"), form = document.getElementById("deal-form");
    form.elements.borrower.value = state.mode === "demo" ? "" : state.authoring ? window.HBFAuthoring.borrower(state.authoring) : state.deal.borrower === "Untitled deal" ? "" : state.deal.borrower;
    form.elements.documentTitle.value = state.mode === "demo" ? "" : state.authoring ? window.HBFAuthoring.title(state.authoring) : state.deal.documentTitle || state.deal.dealType || "";
    form.elements.asOfDate.value = state.mode === "demo" ? "" : state.deal.asOfDate || "";
    form.elements.dealType.value = preferredWorkflow === "portfolio_monitor" ? "Quarterly Monitor" : preferredWorkflow === "credit_action" ? "Renewal" : state.deal.dealType || "Renewal";
    form.elements.facilityType.value = state.deal.facilityType || "Secured RLOC";
    dialog.showModal();
  }

  function firstIncompleteStage() {
    return window.HBF_Guided.progress(guidanceModel()).find((stage) => stage.status === "current")?.id || "deliver";
  }

  function loadSyntheticDemo() {
    if (!confirmLiveSessionReplacement("the synthetic demonstration")) return false;
    state = clone(window.HBF_DEMO);
    state.mode = "demo";
    state.applicability = normalizeApplicability(state.applicability);
    state.workbookScope = (window.HBF_CreditPath?.WORKBOOK_SCOPE_DEFINITIONS || []).map((item) => item.id);
    state.workbookTabs = (window.HBF_CreditPath?.WORKBOOK_SCOPE_DEFINITIONS || []).flatMap((item) => item.sheets);
    state.workbookScopeConfirmed = true;
    state.additionalDocumentIds = [];
    editingSectionId = null;
    pendingConflictSelection = {};
    landingMode = false;
    activeStage = "review";
    activeView = "brief";
    const result = calculateStress();
    if (result.status === "computed") syncScenarioCalculations(result);
    document.getElementById("deal-dialog").close();
    navigate("brief", { stage: "review", force: true });
    toast("Synthetic demonstration opened. Every borrower fact and source is fictional.");
    return true;
  }

  function toggleAdvancedNavigation() {
    const toggle = document.getElementById("advanced-toggle");
    const panel = document.getElementById("advanced-nav-panel");
    const open = panel.hidden;
    panel.hidden = !open;
    toggle.setAttribute("aria-expanded", String(open));
  }

  function closeSessionMenu() {
    document.getElementById("session-menu")?.removeAttribute("open");
  }

  function openWorkbookChooser() {
    if (!confirmViewNavigation()) return false;
    ensureLiveImportSession();
    if (state.workflow === "credit_action" && state.workbookScopeConfirmed !== true) {
      toast("Open Files, choose the individual underwriting tabs used, then confirm the selection before adding the workbook.", "error");
      return false;
    }
    document.getElementById("workbook-input").click();
    return true;
  }

  function openPacketDialog() {
    if (!confirmViewNavigation()) return false;
    ensureLiveImportSession();
    if (state.workflow === "credit_action" && !workbookScopeIsCurrent()) {
      toast("Add or re-add the workbook for the confirmed current tab selection before importing Opus evidence.", "error");
      return false;
    }
    document.getElementById("packet-dialog").showModal();
    return true;
  }

  function runGuidedAction() {
    const next = guidedSnapshot().next;
    if (!next) return;
    const nextStage = next.stage || activeStage;
    if (next.action === "navigate") { if (navigate(next.view, { stage: nextStage })) focusWorkTarget(next.anchor); return; }
    activeStage = nextStage;
    if (next.action === "trigger_workbook") {
      try { openWorkbookChooser(); } catch (error) { toast(error.message, "error"); }
      return;
    }
    if (next.action === "trigger_monitor") {
      if (!confirmViewNavigation()) return;
      try { ensureLiveImportSession(); document.getElementById("monitor-input").click(); } catch (error) { toast(error.message, "error"); }
      return;
    }
    if (next.action === "trigger_packet") {
      try { openPacketDialog(); } catch (error) { toast(error.message, "error"); }
    }
  }

  document.addEventListener("click", async (event) => {
    const button = event.target.closest("button");
    if (!button) return;
    if (button.dataset.startWorkflow !== undefined) { startDocument(button.dataset.startWorkflow); return; }
    if (button.dataset.editDocumentDetails !== undefined) { openDealDialog(); return; }
    if (button.dataset.continueDocument !== undefined) { navigate("draft", {force:true}); return; }
    if (button.dataset.startResume !== undefined) { document.getElementById("checkpoint-input").click(); return; }
    if (button.dataset.startDemo !== undefined) { loadSyntheticDemo(); return; }
    if (button.dataset.stage) { goToStage(button.dataset.stage); return; }
    if (button.dataset.creditTask) { openCreditTask(button.dataset.creditTask); return; }
    if (button.id === "guided-next") { runGuidedAction(); return; }
    if (button.id === "advanced-toggle") { toggleAdvancedNavigation(); return; }
    if (button.id === "issue-drawer-toggle") { setIssueDrawer(!issueDrawerOpen, false); return; }
    if (button.id === "close-issue-drawer" || button.id === "issue-backdrop") { setIssueDrawer(false, true); return; }
    if (button.matches(".nav-item[data-view]")) return navigate(button.dataset.view);
    if (button.dataset.viewLink) return navigate(button.dataset.viewLink);
    if (button.dataset.closeDeal !== undefined) { document.getElementById("deal-dialog").close(); return; }
    if (button.dataset.issueView) { navigate(button.dataset.issueView); return; }
    if (button.dataset.resolveIssue) { if (!confirmViewNavigation()) return; return openIssueResolution(button.dataset.resolveIssue); }
    if (button.dataset.evidence) return showEvidence(button.dataset.evidence);
    if (button.dataset.sourceDetail) return showEvidence(button.dataset.sourceDetail);
    if (button.dataset.acknowledge) { if (!confirmViewNavigation()) return; const issue = state.issues.find((item) => item.id === button.dataset.acknowledge); if (issue) { invalidateAttestations(`Open item ${issue.id} was acknowledged.`); issue.status = "resolved"; } renderView(); return; }
    if (button.dataset.confirmWorkbookScope !== undefined) {
      if (state.mode === "demo") return;
      state.workbookScopeConfirmed = true;
      sessionDirty = true;
      state.editHistory.push({ action: `PM confirmed individual underwriting tabs: ${(window.HBF_CreditPath?.selectedWorkbookTabs(state) || ["Exposure"]).join(", ")}`, at: new Date().toISOString() });
      toast("PM workbook-tab selection recorded. Add the workbook when ready.");
      renderViewPreservingDrafts();
      return;
    }
    if (button.dataset.triggerWorkbook !== undefined) { try { openWorkbookChooser(); } catch (error) { toast(error.message, "error"); } return; }
    if (button.dataset.triggerMonitor !== undefined) { if (!confirmViewNavigation()) return; try { ensureLiveImportSession(); document.getElementById("monitor-input").click(); } catch (error) { toast(error.message, "error"); } return; }
    if (button.dataset.triggerCheckpoint !== undefined) { if (confirmViewNavigation()) document.getElementById("checkpoint-input").click(); return; }
    if (button.dataset.triggerPacket !== undefined) { try { openPacketDialog(); } catch (error) { toast(error.message, "error"); } return; }
    if (button.dataset.confirmMonitor !== undefined) return confirmMonitorReview();
    if (button.dataset.confirmMonitorOfficer !== undefined) {
      if (!confirmViewNavigation()) return;
      if (!state.monitor) return toast("Load a quarterly monitor first.", "error");
      const model = guidanceModel();
      if (!model.monitorReviewed || model.candidates > 0 || model.conflicts > 0 || !model.monitorJudgmentComplete) return toast("Finish exception confirmation and the PM monitoring conclusion before closing the officer-draft review.", "error");
      state.monitor.officerDraftReviewed = true;
      sessionDirty = true;
      state.editHistory.push({ action: "PM review of the officer-facing quarterly draft completed", at: new Date().toISOString() });
      toast("Officer-facing draft review recorded. Continue to the unchanged final controls.");
      goToStage(firstIncompleteStage(), { force: true });
      return;
    }
    if (button.dataset.completeMonitorAction) {
      const action = state.monitor?.actions?.find((item) => item.id === button.dataset.completeMonitorAction);
      if (!action) return toast("Monitoring action not found.", "error");
      invalidateAttestations(`Monitoring action ${action.id} was completed.`);
      action.status = "Completed";
      action.completedAt = new Date().toISOString();
      state.editHistory.push({ action: `Completed monitoring action ${action.id}`, at: action.completedAt });
      toast("Monitoring action marked complete; evidence remains in the review record.");
      renderViewPreservingDrafts();
      return;
    }
    if (button.dataset.bindObservation) return bindWorkbookObservation(button.dataset.bindObservation);
    if (button.dataset.bindCovenant) return bindWorkbookCovenant(button.dataset.bindCovenant);
    if (button.dataset.recordStress !== undefined) return recordStressScenario();
    if (button.dataset.acceptFact) { acceptCandidateFact(button.dataset.acceptFact); renderViewPreservingDrafts(); return; }
    if (button.dataset.rejectFact) { rejectCandidateFact(button.dataset.rejectFact); renderViewPreservingDrafts(); return; }
    if (button.dataset.controlFact) { setControllingFact(button.dataset.controlFact); renderViewPreservingDrafts(); return; }
    if (button.dataset.acceptAllFacts !== undefined) {
      const accepted = state.facts.filter((fact) => fact.status === "candidate" && !fact.conflictId && entityApproved(fact) && !fact.requiresMetadataReview);
      accepted.forEach((fact) => {
        const scopeKey = factScopeKey(fact);
        const displacedIds = state.facts.filter((item) => factScopeKey(item) === scopeKey && item.id !== fact.id && item.controlling).map((item) => item.id);
        state.facts.forEach((item) => { if (factScopeKey(item) === scopeKey) item.controlling = false; });
        fact.status = "accepted"; fact.controlling = true; fact.acceptedAt = new Date().toISOString();
        supersedeDependentRecords(displacedIds, `${fact.id} replaced the cited controlling version for ${fact.path}.`);
      });
      if (!accepted.length) return toast("No bulk-eligible candidates remain; metadata-review facts require individual acceptance.", "error");
      state.editHistory.push({ action: `Bulk accepted ${accepted.length} non-conflicting facts`, at: new Date().toISOString() });
      invalidateAttestations("Candidate facts were bulk accepted."); markScenarioStale("Workbook/packet candidates were accepted. Recalculate and record the selected scenario."); toast(`${accepted.length} eligible candidate fact${accepted.length === 1 ? "" : "s"} accepted as controlling.`); renderViewPreservingDrafts(); return;
    }
    if (button.dataset.reviewWorkbookErrors !== undefined) {
      if (state.mode !== "live") return toast("The synthetic demo review is fixed as a non-deal specimen disposition.", "error");
      if (!workbookScopeIsCurrent()) return toast("Re-add the workbook for the confirmed current tab selection before recording its formula-error review.", "error");
      const formulaErrorCount = workbookFormulaErrorTotal(state.workbook);
      const confirmed = Boolean(document.getElementById("workbook-error-confirm")?.checked);
      const note = document.getElementById("workbook-error-note")?.value.trim() || "";
      if (!formulaErrorCount) return toast("This workbook has no reported formula-error population to review.", "error");
      if (!confirmed) return toast(`Confirm review of the complete ${formulaErrorCount}-error population.`, "error");
      if (note.length < 80) return toast("Document the affected modules and disposition in at least 80 characters.", "error");
      state.workbook.formulaErrorsReviewed = true;
      state.workbook.formulaErrorReviewConfirmed = true;
      state.workbook.formulaErrorReviewCount = formulaErrorCount;
      state.workbook.errorReviewNote = note;
      state.issues.forEach((issue) => { if (issue.id === "WB-ERRORS") issue.status = "resolved"; });
      invalidateAttestations("The workbook formula-error disposition changed."); state.editHistory.push({ action: `Workbook formula-error applicability review recorded for all ${formulaErrorCount} reported errors`, at: new Date().toISOString() }); toast("Exact-count workbook error review recorded; other workbook blockers still require a corrected file."); renderViewPreservingDrafts(); return;
    }
    if (button.dataset.acceptNarratives) { if (!confirmMemoEditorSwitch(null)) return; return acceptNarrativePacket(button.dataset.acceptNarratives); }
    if (button.dataset.completeNarrativeReview !== undefined) {
      if (!confirmMemoEditorSwitch(null)) return;
      if (!state.stressReviewed || state.memoSections.some((section) => section.narrative.trim().length < 60)) return toast("Record the refreshed downside and complete every memo section before closing the dependency review.", "error");
      state.staleNarrativeReviewRequired = false; state.issues.forEach((issue) => { if (["FACT-NARRATIVE-STALE", "AI-NARRATIVE-REVIEW"].includes(issue.id)) issue.status = "resolved"; }); (state.memoSections || []).forEach((section) => { section.aiDraftStaged = false; }); (state.importedNarratives || []).forEach((packet) => { if (packet.status === "staged for PM review") packet.status = "PM reviewed"; }); state.editHistory.push({ action: "PM fact-to-narrative dependency review completed", at: new Date().toISOString() }); invalidateAttestations("The PM fact-to-narrative dependency review was completed."); state.finalized = false; toast("PM dependency review recorded in the audit trail; current-revision attestations are required."); renderView(); return;
    }
    if (button.dataset.selectCandidate) { const conflict = state.conflicts.find((item) => item.id === button.dataset.conflict); if (conflictHasStaleWorkbookEvidence(conflict)) return toast("Re-add the workbook before selecting a controlling value in this conflict.", "error"); if (conflict && (conflict.status === "open" || !conflict.status)) pendingConflictSelection[button.dataset.conflict] = button.dataset.selectCandidate; renderViewPreservingDrafts(); return; }
    if (button.dataset.completeConflict) return completeConflict(button.dataset.completeConflict);
    if (button.dataset.reopenConflict) {
      const conflict = state.conflicts.find((item) => item.id === button.dataset.reopenConflict);
      if (conflictHasStaleWorkbookEvidence(conflict)) return toast("Re-add the workbook before reopening this conflict.", "error");
      if (conflict?.status === "resolved") { supersedeDependentRecords(conflict.candidates, `Conflict ${conflict.id} was reopened, so its prior controlling evidence is no longer settled.`); conflict.status = "open"; conflict.selectedFactId = null; conflict.candidates.forEach((id) => { const fact = factById(id); if (fact) { fact.status = "conflicted"; fact.controlling = false; } }); state.issues.forEach((issue) => { if (issue.conflictId === conflict.id || (conflict.id === "C01" && issue.id === "I01")) issue.status = "open"; }); markScenarioStale(`Conflict ${conflict.id} was reopened; its dependent analysis is no longer current.`); }
      else if (conflict?.status === "superseded") toast("Superseded reconciliation history is read-only; review surviving candidates in the fact queue.", "error");
      renderViewPreservingDrafts(); return;
    }
    if (button.dataset.resetStress !== undefined) { state.stress = clone(SELECTED_STRESS_PRESET); markScenarioStale("The selected assumptions were reset. Recalculate and record the scenario."); renderViewPreservingDrafts(); return; }
    if (button.dataset.editSection) { if (editingSectionId === button.dataset.editSection) { document.getElementById("memo-editor")?.focus(); return; } if (!confirmMemoEditorSwitch(button.dataset.editSection)) return; editingSectionId = button.dataset.editSection; renderView(); document.getElementById("memo-editor")?.focus(); return; }
    if (button.dataset.cancelSection !== undefined) { if (!confirmMemoEditorSwitch(null)) return; editingSectionId = null; renderView(); return; }
    if (button.dataset.saveSection) {
      const section = state.memoSections.find((item) => item.id === button.dataset.saveSection);
      const editor = document.getElementById("memo-editor");
      if (section && editor && editor.value.trim()) { invalidateAttestations(`Memo section ${section.id} changed.`); section.narrative = editor.value.trim(); section.generatedByScenario = false; section.aiDraftStaged = false; section.classification = "pm_judgment"; if (section.id === "downside") state.issues.forEach((issue) => { if (issue.id === "STRESS-NARRATIVE") issue.status = "resolved"; }); state.editHistory.push({ sectionId: section.id, action: "PM narrative edit and ownership classification", at: new Date().toISOString() }); editingSectionId = null; toast(section.narrative.length >= 60 ? "PM-owned narrative saved in this local session." : "Short draft saved. The final check will keep this section open until its explanation is complete."); renderViewPreservingDrafts(editor); }
      else toast("Enter narrative text before saving this section.", "error");
      return;
    }
    if (button.dataset.scrollSection) { document.getElementById(`memo-${button.dataset.scrollSection}`)?.scrollIntoView({ behavior: "smooth", block: "start" }); return; }
    if (button.dataset.copyPrompt !== undefined) {
      let promptBundle;
      try { promptBundle = opusPromptForBatch(button.dataset.copyPrompt); } catch (error) { toast(error.message, "error"); return; }
      try { await navigator.clipboard.writeText(promptBundle.prompt); toast(`${promptBundle.packetId} prompt copied. Paste it only into the approved internal Opus chat.`); }
      catch (_) {
        const area = document.createElement("textarea"); area.value = promptBundle.prompt; area.setAttribute("readonly", ""); area.style.position = "fixed"; area.style.opacity = "0"; document.body.appendChild(area); area.select(); document.execCommand("copy"); area.remove(); toast(`${promptBundle.packetId} prompt copied.`);
      }
      return;
    }
    if (button.dataset.downloadPrompt !== undefined) { try { const bundle = opusPromptForBatch(button.dataset.downloadPrompt); window.HBFExporters.downloadBlob(new Blob([bundle.prompt], { type: "text/plain" }), `${state.deal.id}-${bundle.packetId}-Opus-Extraction-Prompt.txt`); } catch (error) { toast(error.message, "error"); } return; }
    if (button.dataset.exportMemo !== undefined) { if (!confirmExportWithUnsavedInputs()) return; try { await window.HBFExporters.exportMemo(state); toast("Word memo created locally."); } catch (error) { toast(error.message, "error"); } return; }
    if (button.dataset.exportMonitor !== undefined) { if (!confirmExportWithUnsavedInputs()) return; try { await window.HBFExporters.exportMonitor(state); toast("Quarterly portfolio monitor created locally."); } catch (error) { toast(error.message, "error"); } return; }
    if (button.dataset.exportReview !== undefined) { if (!confirmOutputWithUnsavedInputs("Word review pack")) return; try { await window.HBFExporters.exportReviewPack(state); toast("Credit review pack created locally."); } catch (error) { toast(error.message, "error"); } return; }
    if (button.dataset.exportIssues !== undefined) { if (!confirmOutputWithUnsavedInputs("open-action CSV")) return; await window.HBFExporters.exportOpenItems(state); toast("Open-action register created locally."); return; }
    if (button.dataset.exportRollup !== undefined) { if (!confirmOutputWithUnsavedInputs("portfolio rollup CSV")) return; await window.HBFExporters.exportPortfolioRollup(state); toast("Portfolio rollup row created locally."); return; }
    if (button.dataset.exportCheckpoint !== undefined) { const hadUnsavedInputs = viewHasUnsavedInputs(); if (!confirmExportWithUnsavedInputs()) return; const startedState = state, savedRevision = state.contentRevision; await window.HBFExporters.exportCheckpoint(state); if (!hadUnsavedInputs && state === startedState && state.contentRevision === savedRevision) sessionDirty = false; toast(hadUnsavedInputs ? "Checkpoint downloaded with the last saved values; the unsaved screen edits still need to be saved." : "Integrity-tagged local checkpoint downloaded by user action."); return; }
    if (button.dataset.printMemo !== undefined) { if (!confirmOutputWithUnsavedInputs("printed memo / PDF")) return; try { await printFrozenOutput("memo"); } catch (error) { toast(error.message, "error"); } return; }
    if (button.dataset.printMonitor !== undefined) { if (!confirmOutputWithUnsavedInputs("printed monitor / PDF")) return; try { await printFrozenOutput("monitor"); } catch (error) { toast(error.message, "error"); } return; }
    if (button.dataset.finalize !== undefined) { if (gateRows().every((gate) => gate.pass) && openIssues("blocker").length === 0 && allAttested()) { const isMonitor = state.workflow === "portfolio_monitor" || state.deal?.dealType === "Quarterly Monitor"; const completionLabel = isMonitor ? "Review Package Complete" : "Review Ready"; state.finalized = true; state.finalizedAt = new Date().toISOString(); state.deal.status = completionLabel; if (window.HBFExporters?.evaluateReadiness && !window.HBFExporters.evaluateReadiness(state).ready) { state.finalized = false; state.deal.status = "Draft"; toast("The shared export readiness check found an unresolved control. Review the gate before finalizing.", "error"); renderView(); return; } sessionDirty = true; state.editHistory.push({ action: `${isMonitor ? "Quarterly monitor" : "Credit memo"} marked ${completionLabel} by PM attestation`, at: state.finalizedAt }); toast(`${completionLabel}. This is not an automated credit approval.`); renderView(); } return; }
  });

  document.addEventListener("input", (event) => {
    if (event.target.matches("[data-stress]")) {
      const stressKey = event.target.dataset.stress;
      const nextValue = Number(event.target.value);
      if (state.stress[stressKey] !== nextValue) {
        const alreadyStale = !state.stressReviewed && state.issues.some((issue) => issue.id === "STRESS-STALE" && issue.status === "open");
        if (!alreadyStale) markScenarioStale("A selected scenario assumption changed. Recalculate and record the new case.");
        state.stress[stressKey] = nextValue;
      }
      const output = document.getElementById(`output-${event.target.dataset.stress}`);
      if (output) output.textContent = `${event.target.value}${event.target.dataset.suffix || ""}`;
    }
    if (event.target.matches("[data-app-basis]")) {
      const item = (state.applicability || []).find((entry) => entry.id === event.target.dataset.appBasis);
      if (item) { if (item.basis !== event.target.value) invalidateAttestations(`Applicability basis ${item.id} changed.`); item.basis = event.target.value; }
    }
  });

  document.addEventListener("change", (event) => {
    if (event.target.matches("[data-stress]")) { renderViewPreservingDrafts(); }
    if (event.target.matches("[data-document-override]")) {
      const documentId = event.target.dataset.documentOverride;
      const allowed = new Set((window.HBF_CreditPath?.DOCUMENT_DEFINITIONS || []).map((item) => item.id));
      if (!allowed.has(documentId)) return;
      const selected = new Set(state.additionalDocumentIds || []);
      if (event.target.checked) selected.add(documentId); else selected.delete(documentId);
      state.additionalDocumentIds = Array.from(selected);
      invalidateAttestations(`Deal-specific document ${documentId} was ${event.target.checked ? "added" : "removed"}.`);
      state.editHistory.push({ action: `${event.target.checked ? "Added" : "Removed"} deal-specific source-document requirement ${documentId}`, at: new Date().toISOString() });
      sessionDirty = true;
      renderViewPreservingDisclosures();
      return;
    }
    if (event.target.matches("[data-workbook-tab]")) {
      const sheetName = event.target.dataset.workbookTab;
      const definitions = window.HBF_CreditPath?.WORKBOOK_SCOPE_DEFINITIONS || [];
      const allowed = new Set(definitions.flatMap((item) => item.sheets));
      if (!allowed.has(sheetName) || sheetName === "Exposure") return;
      const selected = new Set(window.HBF_CreditPath?.selectedWorkbookTabs(state) || ["Exposure"]);
      if (event.target.checked) selected.add(sheetName); else selected.delete(sheetName);
      selected.add("Exposure");
      state.workbookTabs = Array.from(selected);
      state.workbookScope = definitions.filter((item) => item.sheets.some((sheet) => selected.has(sheet))).map((item) => item.id);
      state.workbookScopeConfirmed = false;
      if (state.workbook?.loaded) {
        const importedTabs = Array.isArray(state.workbook.tabNames)
          ? state.workbook.tabNames
          : definitions.flatMap((item) => (state.workbook.scopeIds || []).includes(item.id) ? item.sheets : []);
        const scopeChanged = importedTabs.slice().sort().join("|") !== Array.from(selected).sort().join("|");
        state.workbook.scopeChangedAfterImport = scopeChanged;
        state.workbook.formulaErrorsReviewed = false;
        state.workbook.formulaErrorReviewConfirmed = false;
        state.workbook.formulaErrorReviewCount = 0;
        state.workbook.errorReviewNote = "";
        const existingScopeIssue = state.issues.find((item) => item.id === "WB-SCOPE");
        const detail = "The PM changed the selected individual workbook tabs after import. Re-add the workbook so facts, covenants and exact per-sheet diagnostics are rebuilt for the new scope.";
        if (scopeChanged) {
          if (existingScopeIssue) { existingScopeIssue.status = "open"; existingScopeIssue.detail = detail; }
          else state.issues.push({ id: "WB-SCOPE", severity: "blocker", title: "Re-add workbook for changed tab selection", detail, actionView: "sources", status: "open" });
          const affectedWorkbookFactIds = [];
          state.facts.forEach((fact) => {
            if (fact.sourceId !== state.workbook.sourceId || fact.status === "superseded") return;
            affectedWorkbookFactIds.push(fact.id);
            if (!fact.scopeStatusBeforeChange) { fact.scopeStatusBeforeChange = fact.status; fact.scopeControllingBeforeChange = Boolean(fact.controlling); }
            fact.status = "scope_stale"; fact.controlling = false;
          });
          quarantineScopeDependentRecords(state, affectedWorkbookFactIds, "A cited workbook fact is outside the PM's current exact tab selection.");
          state.covenants.forEach((covenant) => {
            if (covenant.sourceId !== state.workbook.sourceId || covenant.recordStatus === "superseded") return;
            if (!covenant.scopeRecordStatusBeforeChange) covenant.scopeRecordStatusBeforeChange = covenant.recordStatus || "current";
            covenant.recordStatus = "superseded";
            covenant.evidenceSupersededReason = "Workbook tab scope changed; re-add the workbook before relying on this record.";
          });
          const source = sourceById(state.workbook.sourceId);
          if (source && source.status !== "superseded") source.status = "warning";
        } else {
          if (existingScopeIssue) existingScopeIssue.status = "resolved";
          state.facts.forEach((fact) => {
            if (fact.sourceId !== state.workbook.sourceId || !fact.scopeStatusBeforeChange) return;
            fact.status = fact.scopeStatusBeforeChange; fact.controlling = Boolean(fact.scopeControllingBeforeChange);
            delete fact.scopeStatusBeforeChange; delete fact.scopeControllingBeforeChange;
          });
          state.covenants.forEach((covenant) => {
            if (covenant.sourceId !== state.workbook.sourceId || !covenant.scopeRecordStatusBeforeChange) return;
            covenant.recordStatus = covenant.scopeRecordStatusBeforeChange === "current" ? undefined : covenant.scopeRecordStatusBeforeChange;
            delete covenant.scopeRecordStatusBeforeChange;
            delete covenant.evidenceSupersededReason;
          });
          restoreScopeDependentRecords(state);
          const source = sourceById(state.workbook.sourceId);
          if (source && source.status === "warning") source.status = "supported";
        }
      }
      if (state.workbook?.scopeChangedAfterImport) markScenarioStale("The selected workbook tabs changed. Re-add the workbook, then recalculate the downside and review affected memo sections.");
      else invalidateAttestations(`Underwriting tab ${sheetName} was ${event.target.checked ? "included" : "excluded"}.`);
      state.editHistory.push({ action: `Updated PM-selected underwriting tabs: ${Array.from(selected).join(", ")}`, at: new Date().toISOString() });
      sessionDirty = true;
      renderViewPreservingDisclosures();
      return;
    }
    if (event.target.matches("[data-attestation]")) {
      const name = event.target.dataset.attestation;
      state.attestations[name] = event.target.checked;
      if (event.target.checked) state.attestationMetadata[name] = { revision: state.contentRevision, at: new Date().toISOString(), actor: state.deal.pmName || "Portfolio Manager" };
      else delete state.attestationMetadata[name];
      state.finalized = false;
      if (state.deal) state.deal.status = "Draft";
      sessionDirty = true;
      renderViewPreservingDrafts();
    }
    if (event.target.matches("[data-app-status]")) { const item = (state.applicability || []).find((entry) => entry.id === event.target.dataset.appStatus); if (item) { invalidateAttestations(`Applicability decision ${item.id} changed.`); item.status = event.target.value; renderViewPreservingDrafts(); } }
  });

  document.addEventListener("submit", (event) => {
    if (event.target.id === "issue-resolution-form" && !confirmViewNavigation()) { event.preventDefault(); return; }
    if (["issue-resolution-form", "entity-form", "change-form", "covenant-form", "decision-form", "risk-form", "condition-form"].includes(event.target.id)) invalidateAttestations(`${event.target.id} changed the governed record.`);
    if (event.target.id === "monitor-action-form") {
      event.preventDefault();
      if (!state.monitor) return toast("Load a quarterly monitor first.", "error");
      const values = new FormData(event.target);
      const selectedScope = String(values.get("reportingItemId") || "");
      const reportingItemId = selectedScope.startsWith("CONTROL:") || selectedScope.startsWith("COV:") ? "" : selectedScope;
      const relatedControlId = selectedScope.startsWith("CONTROL:") ? selectedScope.slice("CONTROL:".length) : "";
      const covenantId = selectedScope.startsWith("COV:") ? selectedScope.slice(4) : "";
      if (reportingItemId && !(state.monitor.reportingItems || []).some((item) => item.id === reportingItemId)) return toast("Choose a current reporting item.", "error");
      if (covenantId && !(state.monitor.covenants || []).some((item) => item.id === covenantId && covenantRequiresReview(item))) return toast("Choose a current covenant exception or review-required test.", "error");
      const record = {
        id: `MON-ACT-${String((state.monitor.actions || []).length + 1).padStart(3, "0")}`,
        reportingItemId,
        relatedControlId,
        covenantId,
        action: String(values.get("action") || "").trim(),
        owner: String(values.get("owner") || "").trim(),
        dueDate: String(values.get("dueDate") || ""),
        evidence: String(values.get("evidence") || "").trim(),
        status: "Open",
        recordedAt: new Date().toISOString()
      };
      if (record.action.length < 20 || record.owner.length < 2 || !isValidIsoDate(record.dueDate) || record.evidence.length < 5) return toast("Enter a specific action, owner, valid due date and evidence/verification method.", "error");
      if (state.monitor.reviewAsOfDate && record.dueDate < state.monitor.reviewAsOfDate) return toast("The action due date cannot precede the explicit review date.", "error");
      state.monitor.actions = Array.isArray(state.monitor.actions) ? state.monitor.actions : [];
      state.monitor.actions.push(record);
      invalidateAttestations(`Monitoring action ${record.id} was added.`);
      state.editHistory.push({ action: `Added monitoring action ${record.id}${reportingItemId ? ` for ${reportingItemId}` : covenantId ? ` for ${covenantId}` : ""}`, at: record.recordedAt });
      toast("Structured monitoring action added; final attestations were cleared.");
      renderViewPreservingDrafts(event.target);
      return;
    }
    if (event.target.id === "monitor-decision-form") {
      event.preventDefault();
      const values = new FormData(event.target);
      if (!state.monitor) return toast("Load a quarterly monitor first.", "error");
      const assessment = String(values.get("assessment") || "").trim();
      const recommendedRating = String(values.get("recommendedRating") || "").trim();
      const ratingRationale = String(values.get("ratingRationale") || "").trim();
      const conclusion = String(values.get("conclusion") || "").trim();
      if (assessment.length < 12 || recommendedRating.length < 1 || ratingRationale.length < 50 || conclusion.length < 80 || [assessment, recommendedRating, ratingRationale, conclusion].some(hasPlaceholderOrError)) return toast("Complete the assessment, rating rationale (50+ characters) and PM conclusion/actions (80+ characters) without placeholders or spreadsheet-error text.", "error");
      invalidateAttestations("The PM monitoring assessment, rating or output profile changed.");
      state.monitor.assessment = assessment;
      state.monitor.rating = state.monitor.rating || {};
      state.monitor.rating.recommended = recommendedRating;
      state.monitor.ratingRationale = ratingRationale;
      state.monitor.conclusion = conclusion;
      state.monitor.outputProfile = String(values.get("outputProfile") || "executive");
      state.monitor.includeFinancialTables = Boolean(values.get("includeFinancialTables"));
      state.monitor.includeBalanceSheetTable = Boolean(values.get("includeBalanceSheetTable"));
      state.deal.recommendation = assessment;
      state.deal.proposedRating = recommendedRating;
      state.editHistory.push({ action: "PM quarterly monitoring assessment and output profile updated", at: new Date().toISOString() });
      toast("PM monitoring judgment saved locally; attestations were cleared for renewed review.");
      renderViewPreservingDrafts(event.target);
      return;
    }
    if (event.target.id === "issue-resolution-form") {
      event.preventDefault(); const values = new FormData(event.target);
      const issue = state.issues.find((item) => item.id === String(values.get("issueId") || ""));
      const resolutionType = String(values.get("resolutionType") || "");
      const evidenceId = String(values.get("evidenceId") || "").trim();
      const rationale = String(values.get("rationale") || "").trim();
      if (!issueCanManualResolve(issue)) return toast("This item must be closed through its linked control.", "error");
      if (rationale.length < 20 || evidenceId.length < 2) return toast("Provide a specific evidence/record ID and at least 20 characters of rationale.", "error");
      if (resolutionType === "supplied_evidence" && !sourceById(evidenceId) && !factById(evidenceId)) return toast("Supplied-evidence resolutions must reference a registered source ID or fact ID.", "error");
      issue.status = "resolved"; issue.resolution = { type: resolutionType, evidenceId, rationale, resolvedAt: new Date().toISOString() };
      state.editHistory.push({ action: `Resolved ${issue.id} via ${resolutionType}; evidence ${evidenceId}`, at: issue.resolution.resolvedAt }); state.finalized = false;
      document.getElementById("issue-resolution-dialog").close(); toast("Open-item resolution retained in the audit trail."); renderView(); return;
    }
    if (event.target.id === "entity-form") {
      event.preventDefault(); const values = new FormData(event.target);
      const name = String(values.get("entityName") || "").trim().replace(/\s+/g, " ");
      const role = String(values.get("entityRole") || "Other reviewed entity").trim();
      if (!name) return toast("Enter the exact entity or market scope.", "error");
      if ((state.entities || []).some((entity) => normalizeEntity(entity.name) === normalizeEntity(name))) return toast("That entity is already registered.", "error");
      state.entities.push({ name, role, addedAt: new Date().toISOString() }); state.finalized = false;
      state.editHistory.push({ action: `Registered deal entity: ${name} (${role})`, at: new Date().toISOString() }); toast("Deal entity registered for candidate-fact review."); renderViewPreservingDrafts(event.target); return;
    }
    if (event.target.id === "change-form") {
      event.preventDefault(); const values = new FormData(event.target);
      const evidenceClassification = String(values.get("evidenceClassification") || "");
      const evidenceCheck = validateRecordEvidence(evidenceClassification, values.get("sourceFactIds"));
      if (!evidenceCheck.pass) return toast(evidenceCheck.message, "error");
      const record = {
        id: nextRecordId("CHG", state.changes),
        field: String(values.get("field") || "").trim(),
        prior: String(values.get("prior") || "").trim(),
        current: String(values.get("current") || "").trim(),
        proposed: String(values.get("proposed") || "").trim(),
        impact: String(values.get("impact") || "").trim(),
        evidenceClassification,
        sourceFactIds: evidenceCheck.references,
        evidenceNote: String(values.get("evidenceNote") || "").trim(),
        recordedAt: new Date().toISOString()
      };
      if ([record.field, record.prior, record.current, record.proposed, record.impact].some((value) => !value) || record.evidenceNote.length < 8) return toast("Complete the change comparison, credit impact and a specific evidence locator or PM basis.", "error");
      state.changes.push(record);
      markNarrativeReviewRequired(`Transaction change ${record.field} was added; refresh the request, risk and conclusion narratives.`);
      state.editHistory.push({ action: `Added governed transaction change ${record.id}: ${record.field}`, at: record.recordedAt });
      toast("Governed transaction change added with its evidence classification."); renderViewPreservingDrafts(event.target); return;
    }
    if (event.target.id === "covenant-form") {
      event.preventDefault(); const values = new FormData(event.target);
      const evidenceClassification = String(values.get("evidenceClassification") || "");
      const evidenceCheck = validateRecordEvidence(evidenceClassification, values.get("sourceFactIds"));
      if (!evidenceCheck.pass) return toast(evidenceCheck.message, "error");
      const entity = registeredEntityName(values.get("entity"));
      const asOfDate = String(values.get("asOfDate") || "");
      const status = String(values.get("status") || "");
      if (!entity) return toast("Choose a registered tested entity.", "error");
      if (!isValidIsoDate(asOfDate)) return toast("Enter a real covenant test date in YYYY-MM-DD format.", "error");
      if (!["Compliant", "Noncompliant", "Waiver / exception", "Pending / not tested"].includes(status)) return toast("Choose a valid reviewed covenant status.", "error");
      const record = {
        id: nextRecordId("COV", state.covenants),
        name: String(values.get("name") || "").trim(),
        entity,
        asOfDate,
        frequency: String(values.get("frequency") || "").trim(),
        threshold: String(values.get("threshold") || "").trim(),
        actual: String(values.get("actual") || "").trim(),
        headroom: String(values.get("headroom") || "").trim(),
        trend: String(values.get("trend") || "").trim(),
        status,
        evidenceClassification,
        sourceFactIds: evidenceCheck.references,
        evidenceNote: String(values.get("evidenceNote") || "").trim(),
        reviewedAt: new Date().toISOString()
      };
      if ([record.name, record.frequency, record.threshold, record.actual, record.headroom, record.trend].some((value) => !value) || record.evidenceNote.length < 8) return toast("Complete the covenant result, trend, headroom and a specific evidence locator or PM basis.", "error");
      state.covenants.push(record);
      markNarrativeReviewRequired(`The ${record.name} covenant result was added; refresh the covenant and conclusion narratives.`);
      state.editHistory.push({ action: `Added governed covenant ${record.id}: ${record.name} (${status})`, at: record.reviewedAt });
      toast("Governed covenant result added with its evidence classification."); renderViewPreservingDrafts(event.target); return;
    }
    if (event.target.id === "decision-form") {
      event.preventDefault(); const values = new FormData(event.target);
      const before = JSON.stringify([state.deal.request, state.deal.recommendation, state.deal.currentRating, state.deal.proposedRating]);
      state.deal.request = String(values.get("request") || "").trim(); state.deal.recommendation = String(values.get("recommendation") || "").trim(); state.deal.currentRating = String(values.get("currentRating") || "").trim(); state.deal.proposedRating = String(values.get("proposedRating") || "").trim(); state.finalized = false;
      let ratingFact = state.facts.find((fact) => fact.path === "credit.proposedRiskRating" && fact.provenance === "analyst_judgment");
      if (!ratingFact) { ratingFact = { id: `PM-RATING-${Date.now()}`, path: "credit.proposedRiskRating", label: "Proposed PM risk rating", valueType: "text", provenance: "analyst_judgment", sourceId: null, locator: "PM decision record", status: "accepted", entity: state.deal.borrower, periodType: "as_of", scenario: "actual", unit: "text", scale: 1, asOfDate: state.deal.asOfDate }; state.facts.push(ratingFact); }
      const priorRatingValue = ratingFact.value;
      state.facts.forEach((fact) => { if (fact.path === "credit.proposedRiskRating") fact.controlling = fact.id === ratingFact.id; });
      ratingFact.value = state.deal.proposedRating; ratingFact.status = "accepted"; ratingFact.controlling = true; ratingFact.asOfDate = state.deal.asOfDate; ratingFact.acceptedAt = new Date().toISOString();
      if (priorRatingValue != null && String(priorRatingValue) !== String(ratingFact.value)) supersedeDependentRecords([ratingFact.id], "The PM-owned proposed rating changed after this governed record was prepared.");
      if (before !== JSON.stringify([state.deal.request, state.deal.recommendation, state.deal.currentRating, state.deal.proposedRating])) {
        state.staleNarrativeReviewRequired = true;
        if (!state.issues.some((issue) => issue.id === "FACT-NARRATIVE-STALE" && issue.status === "open")) state.issues.push({ id: "FACT-NARRATIVE-STALE", severity: "blocker", title: "Memo narratives require dependency review", detail: "PM decision fields changed. Reconcile the request, recommendation, rating rationale, conclusion and any affected conditions before finalization.", actionView: "memo", status: "open", resolutionType: "system_control" });
      }
      state.editHistory.push({ action: "PM decision fields updated", at: new Date().toISOString() }); toast("PM decision fields saved in this local session."); renderViewPreservingDrafts(event.target); return;
    }
    if (event.target.id === "risk-form") {
      event.preventDefault(); const values = new FormData(event.target);
      const evidenceClassification = String(values.get("evidenceClassification") || "");
      const evidenceCheck = validateRecordEvidence(evidenceClassification, values.get("sourceFactIds"));
      if (!evidenceCheck.pass) return toast(evidenceCheck.message, "error");
      const record = { id: nextRecordId("R", state.risks), title: String(values.get("title") || "").trim(), owner: String(values.get("owner") || "PM").trim(), evidence: String(values.get("evidence") || "").trim(), consequence: String(values.get("consequence") || "").trim(), mitigant: String(values.get("mitigant") || "").trim(), type: String(values.get("type") || "Narrative only").trim(), residual: String(values.get("residual") || "").trim(), condition: String(values.get("condition") || "").trim(), evidenceClassification, sourceFactIds: evidenceCheck.references, recordedAt: new Date().toISOString() };
      if ([record.title, record.owner, record.evidence, record.consequence, record.mitigant, record.residual, record.condition].some((value) => !value)) return toast("Complete every link in the risk chain.", "error");
      state.risks.push(record); markNarrativeReviewRequired(`Risk chain ${record.id} was added; refresh the risk, condition and conclusion narratives.`); state.editHistory.push({ action: `Added governed risk chain ${record.id}: ${record.title}`, at: record.recordedAt }); toast("PM-owned risk chain added with its evidence classification."); renderViewPreservingDrafts(event.target); return;
    }
    if (event.target.id === "condition-form") {
      event.preventDefault(); const values = new FormData(event.target);
      const record = { id: nextRecordId("COND", state.conditions), phase: String(values.get("phase") || "").trim(), requirement: String(values.get("requirement") || "").trim(), purpose: String(values.get("purpose") || "").trim(), owner: String(values.get("owner") || "").trim(), verification: String(values.get("verification") || "").trim(), status: "Proposed", recordedAt: new Date().toISOString() };
      if ([record.phase, record.requirement, record.purpose, record.owner, record.verification].some((value) => !value)) return toast("Complete the condition timing, requirement, purpose, owner and verification method.", "error");
      state.conditions.push(record); markNarrativeReviewRequired(`Condition ${record.id} was added; refresh the condition and conclusion narratives.`); state.editHistory.push({ action: `Added approval condition ${record.id}`, at: record.recordedAt }); toast("Approval condition added."); renderViewPreservingDrafts(event.target); return;
    }
  });

  document.getElementById("deal-switcher").addEventListener("click", openDealDialog);
  document.getElementById("load-demo").addEventListener("click", loadSyntheticDemo);
  document.getElementById("load-workbook").addEventListener("click", () => { closeSessionMenu(); try { openWorkbookChooser(); } catch (error) { toast(error.message, "error"); } });
  document.getElementById("load-monitor").addEventListener("click", () => { closeSessionMenu(); if (!confirmViewNavigation()) return; try { ensureLiveImportSession(); document.getElementById("monitor-input").click(); } catch (error) { toast(error.message, "error"); } });
  document.getElementById("resume-checkpoint").addEventListener("click", () => { closeSessionMenu(); if (confirmViewNavigation()) document.getElementById("checkpoint-input").click(); });
  document.getElementById("import-opus").addEventListener("click", () => { closeSessionMenu(); try { openPacketDialog(); } catch (error) { toast(error.message, "error"); } });
  document.getElementById("clear-session").addEventListener("click", () => document.getElementById("confirm-dialog").showModal());
  document.getElementById("cancel-clear").addEventListener("click", () => document.getElementById("confirm-dialog").close());
  document.getElementById("confirm-clear").addEventListener("click", () => {
    state = emptyState(); activeView = "brief"; activeStage = "add"; landingMode = true; editingSectionId = null; pendingConflictSelection = {}; sessionDirty = false;
    document.getElementById("packet-paste").value = ""; document.getElementById("evidence-content").textContent = ""; document.getElementById("evidence-title").textContent = ""; document.getElementById("packet-input").value = ""; document.getElementById("workbook-input").value = ""; document.getElementById("monitor-input").value = ""; document.getElementById("checkpoint-input").value = ""; document.getElementById("issue-resolution-title").textContent = ""; document.getElementById("issue-resolution-form").reset(); document.getElementById("issue-resolution-id").value = "";
    document.getElementById("confirm-dialog").close(); closeSessionMenu(); renderView(); document.getElementById("view").focus({ preventScroll: true }); toast("Application-held deal data was cleared from this tab.");
  });
  document.getElementById("close-evidence").addEventListener("click", () => document.getElementById("evidence-dialog").close());
  document.getElementById("close-packet").addEventListener("click", () => document.getElementById("packet-dialog").close());
  document.getElementById("cancel-packet").addEventListener("click", () => document.getElementById("packet-dialog").close());
  document.getElementById("cancel-issue-resolution").addEventListener("click", () => document.getElementById("issue-resolution-dialog").close());
  document.getElementById("cancel-issue-resolution-2").addEventListener("click", () => document.getElementById("issue-resolution-dialog").close());
  document.getElementById("choose-packet-file").addEventListener("click", () => { try { ensureLiveImportSession(); document.getElementById("packet-dialog").close(); document.getElementById("packet-input").click(); } catch (error) { toast(error.message, "error"); } });
  document.getElementById("merge-packet").addEventListener("click", () => {
    try { const packetId = mergePacketText(document.getElementById("packet-paste").value); document.getElementById("packet-paste").value = ""; document.getElementById("packet-dialog").close(); activeStage = firstIncompleteStage(); toast(`${packetId} validated and merged. Review any created conflicts.`); renderView(); }
    catch (error) { toast(error.message, "error"); }
  });
  document.getElementById("deal-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const values = new FormData(event.currentTarget), asOfDate = String(values.get("asOfDate") || ""), type = String(values.get("dealType") || "Renewal");
    const workflow = type === "Quarterly Monitor" ? "portfolio_monitor" : "credit_action";
    if (asOfDate && !isValidIsoDate(asOfDate)) return toast("Enter a real review date or leave it blank while drafting.", "error");
    if (!['Renewal','New','Modification','Quarterly Monitor'].includes(type)) return toast("Choose the transaction type.", "error");
    if (state.mode !== "live" || landingMode) { if (!startDocument(workflow)) return; }
    if (workflow !== state.workflow) return toast("Start another document to switch between a memo and a quarterly review. This document is unchanged.", "error");
    const borrower = String(values.get("borrower") || ""), title = String(values.get("documentTitle") || "");
    if (state.authoring?.kind === "memo") {
      window.HBFTemplate.set(state.authoring.content, 'p19', borrower);
      window.HBFTemplate.set(state.authoring.content, 'control0', title);
    } else if (state.authoring?.kind === "qpr") {
      window.HBFAuthoring.setQPR(state.authoring, 'fields', 'borrower', borrower);
      window.HBFAuthoring.setQPR(state.authoring, 'title', 'title', title);
      window.HBFAuthoring.setQPR(state.authoring, 'dates', 'review', asOfDate);
    }
    const oldReviewDate = state.deal.asOfDate;
    state.deal.documentTitle = title;
    if (!state.sources.length) { state.deal.borrower = borrower || 'Untitled deal'; state.deal.relationship = borrower; state.entities = borrower ? [{ name: borrower, role: 'Borrower' }] : []; }
    state.deal.asOfDate = asOfDate; state.deal.preparedDate = asOfDate;
    state.deal.reviewDateConfirmedAt = asOfDate ? new Date().toISOString() : null;
    if (state.monitor && oldReviewDate !== asOfDate) { state.monitor.reviewDateBasis = 'draft_date_changed'; state.monitor.reviewed = false; }
    const typeChanged = state.deal.dealType !== type;
    state.deal.dealType = type; state.deal.facilityType = String(values.get('facilityType') || 'Secured RLOC');
    if (typeChanged && !state.workbook.loaded) { state.workbookScope = window.HBF_CreditPath.defaultWorkbookScope(type,state.deal.facilityType); state.workbookTabs = window.HBF_CreditPath.defaultWorkbookTabs(type,state.deal.facilityType); state.workbookScopeConfirmed = false; }
    invalidateAttestations('Document details changed.');
    state.editHistory.push({action:'PM edited optional document details; display title kept separate from transaction type',at:new Date().toISOString()});
    authoringController?.dispose(); authoringController = null; mountedAuthoring = null;
    document.getElementById("deal-dialog").close(); renderView(); toast("Document details saved.");
  });

  document.getElementById("workbook-input").addEventListener("change", async (event) => {
    const file = event.target.files && event.target.files[0];
    event.target.value = "";
    if (!file) return;
    try { await importWorkbook(file); landingMode = false; activeStage = firstIncompleteStage(); activeView = "sources"; navigate("sources", { stage: activeStage, force: true }); } catch (error) { toast(error.message, "error"); }
  });

  document.getElementById("monitor-input").addEventListener("change", async (event) => {
    const file = event.target.files && event.target.files[0];
    event.target.value = "";
    if (!file) return;
    try { await importMonitorWorkbook(file); landingMode = false; activeStage = firstIncompleteStage(); activeView = "monitor"; navigate("monitor", { stage: activeStage, force: true }); } catch (error) { toast(error.message, "error"); }
  });

  document.getElementById("checkpoint-input").addEventListener("change", async (event) => {
    const file = event.target.files && event.target.files[0];
    event.target.value = "";
    if (!file) return;
    try { await importCheckpoint(file); } catch (error) { toast(error.message, "error"); }
  });

  document.getElementById("packet-input").addEventListener("change", async (event) => {
    const file = event.target.files && event.target.files[0];
    event.target.value = "";
    if (!file) return;
    if (!/\.(?:json|txt)$/i.test(file.name || "")) return toast("Choose a .json or .txt Opus packet.", "error");
    if (file.size > 2000000) return toast("Packet exceeds the 2 MB safety limit.", "error");
    try { const packetId = mergePacketText(await file.text()); activeStage = firstIncompleteStage(); toast(`${packetId} validated and merged.`); renderView(); } catch (error) { toast(error.message, "error"); }
  });

  document.querySelectorAll("[data-issue-filter]").forEach((button) => button.addEventListener("click", () => {
    issueFilter = button.dataset.issueFilter;
    document.querySelectorAll("[data-issue-filter]").forEach((item) => { const active = item.dataset.issueFilter === issueFilter; item.classList.toggle("is-active", active); item.setAttribute("aria-pressed", String(active)); });
    renderIssueRail();
  }));

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && issueDrawerOpen) { setIssueDrawer(false, true); return; }
    if (event.key !== "Tab" || !issueDrawerOpen) return;
    const focusable = Array.from(document.querySelectorAll('#issue-rail button:not([disabled]), #issue-rail input:not([disabled]), #issue-rail select:not([disabled]), #issue-rail textarea:not([disabled]), #issue-rail a[href]')).filter((item) => item.offsetParent !== null);
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });

  window.addEventListener("beforeunload", (event) => {
    if (!viewHasUnsavedInputs() && (!sessionDirty || !hasMeaningfulLiveWork())) return;
    event.preventDefault();
    event.returnValue = "";
  });

  if (state.stressReviewed) { const initialScenario = calculateStress(); if (initialScenario.status === "computed") syncScenarioCalculations(initialScenario); }
  renderView();
  document.getElementById("view").focus({ preventScroll: true });
})();
