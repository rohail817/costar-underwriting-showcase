(function () {
  "use strict";

  const INTAKE_DEFINITIONS = Object.freeze([
    Object.freeze({ id: "workbook", label: "HBF workbook with the PM-selected tabs completed", owner: "Portfolio manager", why: "One workbook is loaded; unused tabs may remain blank when the PM excludes them from scope.", matcher: null }),
    Object.freeze({ id: "prior", label: "Prior approval and current loan terms", owner: "Portfolio manager / analyst", why: "Establishes the approved baseline and exact transaction changes.", matcher: /prior credit|prior approval|credit agreement|loan document|existing terms|executed/i }),
    Object.freeze({ id: "request", label: "Current request and proposed structure", owner: "Relationship manager / portfolio manager", why: "Defines what Credit is being asked to approve now.", matcher: /borrower request|renewal request|project memo|proposed terms|term sheet|transaction request/i }),
    Object.freeze({ id: "financial", label: "Borrower financial capacity", owner: "Portfolio manager / analyst", why: "Supports repayment capacity, trend, leverage, liquidity and coverage.", matcher: /financial statement|interim financial|financial spread|income statement|balance sheet/i }),
    Object.freeze({ id: "operations", label: "Sales, closings and inventory", owner: "Portfolio manager / analyst", why: "Shows demand quality, cash conversion and inventory risk.", matcher: /operating report|inventory|sales report|closings|backlog|borrowing base/i }),
    Object.freeze({ id: "support", label: "Project, collateral and guarantor support", owner: "Portfolio manager / analyst", why: "Tests completion sources, collateral control and secondary support.", matcher: /project|budget|cost.to.complete|appraisal|collateral|borrowing base|guarantor|personal financial/i }),
    Object.freeze({ id: "market", label: "Dated third-party market evidence", owner: "Portfolio manager", why: "Challenges borrower assumptions with a comparable geography and product set.", matcher: /market|zonda|supply|third.party/i })
  ]);

  const BATCH_DEFINITIONS = Object.freeze([
    Object.freeze({ id: "B01", label: "Request and existing credit", documentIds: Object.freeze(["request", "terms", "prior", "loan_docs", "ownership"]), purpose: "Lock the request, approved baseline, current terms, proposed changes and legal entities." }),
    Object.freeze({ id: "B02", label: "Financial and operating", documentIds: Object.freeze(["year_end", "interim", "debt_schedule", "sales", "inventory"]), purpose: "Build repayment capacity, financial trend, cash conversion and inventory evidence." }),
    Object.freeze({ id: "B03", label: "Internal, covenant and borrowing base", documentIds: Object.freeze(["internal", "deposits", "covenants", "borrowing_base", "unit_detail"]), purpose: "Establish bank exposure, internal relationship context, covenant results and collateral availability." }),
    Object.freeze({ id: "B04", label: "Collateral and project foundation", documentIds: Object.freeze(["appraisal", "environmental", "flood", "title", "project_budget"]), purpose: "Support collateral diligence, sources and uses, budget and project funding." }),
    Object.freeze({ id: "B05", label: "Execution and guarantor support", documentIds: Object.freeze(["project_execution", "guarantor_pfs", "guarantor_liquidity", "guarantor_global"]), purpose: "Support completion execution and secondary repayment capacity." }),
    Object.freeze({ id: "B06", label: "Market evidence", documentIds: Object.freeze(["market"]), purpose: "Challenge borrower absorption, price and inventory assumptions with dated third-party evidence." })
  ]);

  const WORKBOOK_SCOPE_DEFINITIONS = Object.freeze([
    Object.freeze({ id: "relationship", label: "Bank exposure", tabs: "Exposure", sheets: Object.freeze(["Exposure"]), always: true }),
    Object.freeze({ id: "banking", label: "Bank group, deposits and debt", tabs: "Bank Group; Deposits; Debt Listing", sheets: Object.freeze(["Bank Group", "Deposits", "Debt Listing"]) }),
    Object.freeze({ id: "financial", label: "Borrower financial analysis", tabs: "Balance Sheet; Income Statement; Net Income; Equity", sheets: Object.freeze(["Balance Sheet", "Income Statement", "Net Income", "Equity"]) }),
    Object.freeze({ id: "operating", label: "Sales, closings and inventory", tabs: "Heat Map; Revenue-Closings; Sales-Closings; Inventory-Units/Lots; Active Subdivision; Project Inventory", sheets: Object.freeze(["Heat Map", "Revenue-Closings", "Sales-Closings", "Inventory-Units", "Inventory-Lots", "Active Subdivision", "Project Inventory"]) }),
    Object.freeze({ id: "facility", label: "Facility, collateral and borrowing base", tabs: "RLOC; Unit Line Detail; Borrowing Base; Collateral Value; Curtailment", sheets: Object.freeze(["RLOC", "Unit Line Detail", "Borrowing Base", "Collateral Value", "Curtailment"]) }),
    Object.freeze({ id: "covenants", label: "Covenants", tabs: "Covenant Tracking", sheets: Object.freeze(["Covenant Tracking"]) }),
    Object.freeze({ id: "downside", label: "Downside and sensitivity", tabs: "Absorption Sensitivity; Sensitivity Analysis", sheets: Object.freeze(["Absorption Sensitivity", "Sensitivity Analysis"]) }),
    Object.freeze({ id: "project", label: "A&D or vertical project feasibility", tabs: "A&D Sources & Uses; Dev Budget; Project Equity; Vertical Construction; Contract Analysis", sheets: Object.freeze(["A&D Sources & Uses", "Dev Budget", "Project Equity", "Vertical Construction", "Contract Analysis"]) }),
    Object.freeze({ id: "guarantor", label: "Guarantor support", tabs: "Guarantor Aggregation", sheets: Object.freeze(["Guarantor Aggregation"]) }),
    Object.freeze({ id: "market", label: "Market support", tabs: "Market Snapshot", sheets: Object.freeze(["Market Snapshot"]) })
  ]);

  const DOCUMENT_DEFINITIONS = Object.freeze([
    Object.freeze({ id: "request", batch: "B01", label: "Current request or project memo", examples: "Borrower/project memo, completed deal questionnaire or RM request summary", matcher: /borrower request|renewal request|project memo|deal questionnaire|request summary|transaction request/i, required: () => true }),
    Object.freeze({ id: "terms", batch: "B01", label: "Proposed terms", examples: "Proposed term sheet, loan proposal or written structure summary", matcher: /proposed term|term sheet|loan proposal|proposed structure/i, required: () => true }),
    Object.freeze({ id: "prior", batch: "B01", label: "Most recent approved credit memo", examples: "Prior approval or last approved renewal/modification memo", matcher: /prior credit|prior approval|approved credit memo|last approval|renewal memo/i, required: (state) => /renewal|modification/i.test(clean(state?.deal?.dealType)) }),
    Object.freeze({ id: "loan_docs", batch: "B01", label: "Current loan documents", examples: "Executed note/loan agreement plus current amendments", matcher: /credit agreement|loan agreement|promissory note|executed note|loan amendment|current amendment/i, required: (state) => /renewal|modification/i.test(clean(state?.deal?.dealType)) }),
    Object.freeze({ id: "ownership", batch: "B01", label: "Ownership and entity chart", examples: "Organization chart, ownership schedule and borrower/guarantor identification", matcher: /organization chart|organizational chart|ownership schedule|entity structure|guarantor identification/i, required: (state) => clean(state?.deal?.dealType).toLowerCase() === "new" }),
    Object.freeze({ id: "year_end", batch: "B02", label: "Latest fiscal-year financial statements", examples: "Audited, reviewed or company-prepared year-end borrower statements", matcher: /audited financial|reviewed financial|year.end financial|fiscal.year financial|annual financial/i, required: () => true }),
    Object.freeze({ id: "interim", batch: "B02", label: "Current interim financial statements", examples: "Current borrower balance sheet and income statement with comparison period", matcher: /interim financial|current financial statement|interim balance sheet|interim income statement/i, required: () => true }),
    Object.freeze({ id: "debt_schedule", batch: "B02", label: "Current debt schedule", examples: "Lender, commitment, outstanding, collateral, maturity and payment terms", matcher: /debt schedule|debt listing|schedule of debt|notes payable schedule/i, required: () => true }),
    Object.freeze({ id: "sales", batch: "B02", label: "Current sales, closings and backlog report", examples: "Gross/net sales, cancellations, closings and backlog by project and period", matcher: /sales report|sales and closings|closings report|cancellation report|backlog report|sales backlog/i, required: () => true }),
    Object.freeze({ id: "inventory", batch: "B02", label: "Current inventory or lot-control report", examples: "Units/lots by stage, ownership/control, cost, value and aging", matcher: /inventory report|inventory schedule|lot control|lot schedule|unit inventory/i, required: () => true }),
    Object.freeze({ id: "internal", batch: "B03", label: "Internal exposure, balance, maturity and rating report", examples: "Current bank exposure/relationship report including outstanding, maturity and risk rating", matcher: /internal exposure|relationship report|loan balance|exposure report|risk rating report|maturity report/i, required: () => true }),
    Object.freeze({ id: "deposits", batch: "B03", label: "Internal deposits and profitability report", examples: "Current/average deposits, treasury services and relationship profitability", matcher: /deposit report|deposit summary|profitability report|relationship profitability|treasury report/i, required: (state) => selectedSheet(state, "Deposits") }),
    Object.freeze({ id: "covenants", batch: "B03", label: "Current covenant compliance support", examples: "Compliance certificate, covenant calculation and any waiver/amendment", matcher: /compliance certificate|covenant report|covenant calculation|covenant compliance|waiver/i, required: (state) => selectedSheet(state, "Covenant Tracking") }),
    Object.freeze({ id: "borrowing_base", batch: "B03", label: "Current borrowing-base certificate", examples: "Signed/current borrowing base with eligibility, advance rates and availability", matcher: /borrowing.base certificate|borrowing base report|borrowing base/i, required: (state) => selectedSheet(state, "Borrowing Base") }),
    Object.freeze({ id: "unit_detail", batch: "B03", label: "Current unit-line detail", examples: "Loan/unit detail by project, lot, stage, advance, value and curtailment", matcher: /unit.line detail|unit detail|loan unit schedule|collateral unit detail/i, required: (state) => selectedSheet(state, "Unit Line Detail") }),
    Object.freeze({ id: "appraisal", batch: "B04", label: "Current appraisal or evaluation", examples: "Most recent appraisal/evaluation and relevant updates", matcher: /appraisal|property evaluation|collateral evaluation/i, required: (state) => selectedSheet(state, "Collateral Value") }),
    Object.freeze({ id: "environmental", batch: "B04", label: "Environmental report", examples: "Phase I, environmental questionnaire or approved environmental screen", matcher: /environmental|phase i|phase one/i, required: () => false }),
    Object.freeze({ id: "flood", batch: "B04", label: "Flood determination", examples: "Current flood determination and insurance evidence when required", matcher: /flood determination|flood certificate|flood insurance/i, required: () => false }),
    Object.freeze({ id: "title", batch: "B04", label: "Title or lien support", examples: "Title commitment/report, lien search or approved collateral ownership evidence", matcher: /title commitment|title report|lien search|collateral ownership/i, required: () => false }),
    Object.freeze({ id: "project_budget", batch: "B04", label: "Project budget and sources/uses", examples: "Original/current budget, sources and uses, equity and contingency", matcher: /project budget|development budget|sources and uses|project equity|contingency budget/i, required: (state) => ["A&D Sources & Uses", "Dev Budget", "Project Equity", "Vertical Construction"].some((sheet) => selectedSheet(state, sheet)) }),
    Object.freeze({ id: "project_execution", batch: "B05", label: "Cost-to-complete and execution support", examples: "Cost-to-complete, draw/inspection report, schedule, permits and material contracts", matcher: /cost.to.complete|draw report|inspection report|development schedule|construction schedule|permit|construction contract/i, required: (state) => ["Dev Budget", "Vertical Construction", "Contract Analysis"].some((sheet) => selectedSheet(state, sheet)) }),
    Object.freeze({ id: "guarantor_pfs", batch: "B05", label: "Current guarantor personal financial statement", examples: "Signed/current PFS with assets, liabilities and contingent liabilities", matcher: /personal financial statement|guarantor pfs|\bpfs\b/i, required: (state) => selectedScope(state, "guarantor") }),
    Object.freeze({ id: "guarantor_liquidity", batch: "B05", label: "Guarantor liquidity verification", examples: "Bank/brokerage statements or other approved liquidity support", matcher: /liquidity verification|liquidity proof|bank statement|brokerage statement/i, required: (state) => selectedScope(state, "guarantor") }),
    Object.freeze({ id: "guarantor_global", batch: "B05", label: "Guarantor global debt and tax support", examples: "Global debt/contingent liability schedule and current tax return/K-1 support", matcher: /global debt|contingent liabilit|tax return|k-1|k1/i, required: (state) => selectedScope(state, "guarantor") }),
    Object.freeze({ id: "market", batch: "B06", label: "Dated third-party market support", examples: "Zonda/Metrostudy report or screenshots and comparable market evidence", matcher: /market report|zonda|metrostudy|months supply|third.party market/i, required: (state) => selectedSheet(state, "Market Snapshot") })
  ]);

  const FAMILY_CONSEQUENCES = Object.freeze({
    credit: "Can change the risk-rating recommendation and approval authority.",
    facility: "Can change the request, exposure, pricing, maturity or repayment requirement.",
    relationship: "Can change total bank exposure and relationship-level approval context.",
    collateral: "Can change advance availability, LTV and loss protection.",
    project: "Can change completion funding, equity timing and execution risk.",
    operating: "Can change absorption, cash conversion and maturity repayment capacity.",
    inventory: "Can change liquidity timing, borrowing-base eligibility and curtailment risk.",
    financial: "Can change leverage, liquidity, covenant capacity and rating support.",
    guarantor: "Can change secondary support and the size of any structural cure.",
    covenant: "Can create an exception, waiver requirement or monitoring action.",
    market: "Can change the credibility of absorption, pricing and inventory assumptions.",
    default: "Can change a memo statement and must be dispositioned before it can control output."
  });

  const clean = (value) => String(value == null ? "" : value).trim();
  const list = (value) => Array.isArray(value) ? value : [];
  const active = (record) => record && record.recordStatus !== "superseded";
  const accepted = (fact) => fact && ["supported", "accepted"].includes(fact.status);
  const placeholder = (value) => !clean(value) || /(?:not entered|required|not defined|\btbd\b|#(?:N\/A|REF!|VALUE!|DIV\/0!|NAME\?|NUM!))/i.test(clean(value));

  function searchableSource(source) {
    return [source?.name, source?.type, source?.detail].map(clean).join(" ");
  }

  function usableSource(source) {
    return source && !["rejected", "superseded", "reference_only"].includes(source.status);
  }

  function defaultWorkbookScope() {
    return ["relationship"];
  }

  function defaultWorkbookTabs() {
    return ["Exposure"];
  }

  function selectedWorkbookTabs(state) {
    const allowed = new Set(WORKBOOK_SCOPE_DEFINITIONS.flatMap((definition) => definition.sheets));
    const legacyScope = new Set(Array.isArray(state?.workbookScope)
      ? state.workbookScope
      : defaultWorkbookScope(state?.deal?.dealType, state?.deal?.facilityType));
    const declared = Array.isArray(state?.workbookTabs)
      ? state.workbookTabs
      : WORKBOOK_SCOPE_DEFINITIONS.flatMap((definition) => legacyScope.has(definition.id) ? definition.sheets : []);
    return Array.from(new Set(["Exposure", ...declared])).filter((sheet) => allowed.has(sheet));
  }

  function selectedSheet(state, sheetName) {
    return selectedWorkbookTabs(state).includes(clean(sheetName));
  }

  function selectedScope(state, id) {
    const definition = WORKBOOK_SCOPE_DEFINITIONS.find((item) => item.id === id);
    if (Array.isArray(state?.workbookTabs)) return id === "relationship" || Boolean(definition?.sheets.some((sheet) => state.workbookTabs.includes(sheet)));
    const declared = Array.isArray(state?.workbookScope)
      ? state.workbookScope
      : defaultWorkbookScope(state?.deal?.dealType, state?.deal?.facilityType);
    return id === "relationship" || declared.includes(id);
  }

  function workbookScopePlan(state) {
    const selectedTabs = new Set(selectedWorkbookTabs(state));
    return WORKBOOK_SCOPE_DEFINITIONS.map((definition) => {
      const selectedSheets = definition.sheets.filter((sheet) => selectedTabs.has(sheet));
      return {
        ...definition,
        selectedSheets,
        selectedCount: selectedSheets.length,
        selected: selectedSheets.length > 0,
        status: selectedSheets.length ? "included" : "not_applicable"
      };
    });
  }

  function workbookSheetScope(sheetName) {
    const name = clean(sheetName);
    return WORKBOOK_SCOPE_DEFINITIONS.find((definition) => definition.sheets.includes(name))?.id || null;
  }

  function workbookSheetSelected(state, sheetName) {
    const scopeId = workbookSheetScope(sheetName);
    if (scopeId) return selectedSheet(state, sheetName);
    return clean(sheetName) !== "Template Modifications";
  }

  function workbookRecordSelected(state, record) {
    const sheetName = clean(record?.sheet || clean(record?.locator).split("!")[0]);
    return !sheetName || workbookSheetSelected(state, sheetName);
  }

  function workbookScopeSignature(state) {
    const allSheets = WORKBOOK_SCOPE_DEFINITIONS.flatMap((item) => item.sheets);
    const sheetNames = selectedWorkbookTabs(state);
    const selected = new Set(sheetNames);
    const ids = WORKBOOK_SCOPE_DEFINITIONS.filter((item) => item.sheets.some((sheet) => selected.has(sheet))).map((item) => item.id);
    const bits = allSheets.map((sheet) => selected.has(sheet) ? "1" : "0").join("") || "1";
    return { ids, sheetNames, bits, code: Number.parseInt(bits, 2).toString(36).toUpperCase() };
  }

  function workbookScopeMatches(state) {
    if (!state?.workbook?.loaded) return false;
    const definitions = WORKBOOK_SCOPE_DEFINITIONS;
    const allowed = new Set(definitions.flatMap((item) => item.sheets));
    const current = selectedWorkbookTabs(state).filter((sheet) => allowed.has(sheet));
    let imported;
    if (Array.isArray(state.workbook.tabNames)) {
      if (!state.workbook.tabNames.includes("Exposure") || state.workbook.tabNames.some((sheet) => !allowed.has(sheet))) return false;
      imported = state.workbook.tabNames.slice();
    }
    else if (Array.isArray(state.workbook.scopeIds)) {
      const ids = new Set(state.workbook.scopeIds);
      imported = definitions.flatMap((item) => ids.has(item.id) ? item.sheets : []);
    } else if (state.mode === "demo") imported = definitions.flatMap((item) => item.sheets);
    else return false;
    const currentKey = Array.from(new Set(current)).sort().join("|");
    const importedKey = Array.from(new Set(imported)).sort().join("|");
    return Boolean(currentKey && currentKey === importedKey);
  }

  function scopeWorkbookResult(state, result) {
    const source = result && typeof result === "object" ? result : {};
    const mappedFacts = list(source.mappedFacts).filter((record) => workbookRecordSelected(state, record));
    const metadataReviewRequiredFacts = list(source.metadataReviewRequiredFacts).filter((record) => workbookRecordSelected(state, record));
    const covenants = list(source.covenants).filter((record) => workbookRecordSelected(state, record));
    const excludedScopeObservationCount = [...list(source.mappedFacts), ...list(source.metadataReviewRequiredFacts)].filter((record) => !workbookRecordSelected(state, record)).length;
    const sheetDiagnostics = list(source.sheetDiagnostics);
    const selectedSheetDiagnostics = sheetDiagnostics.filter((item) => workbookSheetSelected(state, item.sheet));
    const diagnosticTotal = (key, fallback) => selectedSheetDiagnostics.length
      ? selectedSheetDiagnostics.reduce((total, item) => total + Number(item?.[key] || 0), 0)
      : Number(fallback || 0);
    const formulaErrorSampleLimit = Number(source.formulaErrorSampleLimit) > 0 ? Number(source.formulaErrorSampleLimit) : 100;
    // Prefer per-sheet samples so selected tabs still retain examples when errors on
    // omitted sheets would otherwise consume the workbook-level sample budget.
    const perSheetFormulaErrorSamples = selectedSheetDiagnostics.flatMap((item) => list(item.formulaErrorSamples).map((sample) => ({ ...sample, sheet: sample.sheet || item.sheet })));
    const applicableFormulaErrorSamples = (perSheetFormulaErrorSamples.length
      ? perSheetFormulaErrorSamples
      : list(source.formulaErrorSamples || source.formulaErrors).filter((item) => workbookSheetSelected(state, item.sheet)))
      .slice(0, formulaErrorSampleLimit);
    return {
      ...workbookScopeSignature(state),
      mappedFacts,
      metadataReviewRequiredFacts,
      covenants,
      excludedScopeObservationCount,
      sheetDiagnostics,
      selectedSheetDiagnostics,
      applicableFormulaCount: diagnosticTotal("formulaCount", source.formulaCount),
      applicableFormulaErrorCount: diagnosticTotal("formulaErrorCount", source.formulaErrorCount),
      applicableFormulasWithoutCachedValues: diagnosticTotal("formulasWithoutCachedValues", source.formulasWithoutCachedValues),
      applicableExternalFormulaCount: diagnosticTotal("externalFormulaCount", source.externalFormulaCount),
      applicableFormulaErrorSamples,
      formulaErrorSampleLimit
    };
  }

  function documentPlan(state) {
    const sources = list(state?.sources).filter(usableSource);
    const additionalRequired = new Set(list(state?.additionalDocumentIds).map(clean));
    return DOCUMENT_DEFINITIONS.map((definition) => {
      const batch = BATCH_DEFINITIONS.find((item) => item.id === definition.batch);
      const slot = Math.max(0, batch?.documentIds.indexOf(definition.id) ?? -1) + 1;
      const slotCode = `S${String(slot).padStart(2, "0")}`;
      const matchedSources = sources.filter((source) => {
        const packet = clean(source.packet).toUpperCase();
        const revision = packet.startsWith(`${definition.batch}R`) ? Number(packet.slice(definition.batch.length + 1)) : null;
        const packetMatches = packet === definition.batch || Number.isSafeInteger(revision) && revision >= 2;
        const expectedSourceId = `${packet}-${slotCode}`;
        const sourceId = clean(source.id).toUpperCase();
        const sourceIdMatches = sourceId === expectedSourceId || sourceId.startsWith(`${expectedSourceId}-`) && /^[A-Z]$/.test(sourceId.slice(expectedSourceId.length + 1));
        const documentTypeMatches = clean(source.type).toLowerCase() === clean(definition.label).toLowerCase();
        return packetMatches && sourceIdMatches && documentTypeMatches;
      });
      const requiredByRule = Boolean(definition.required(state));
      const required = requiredByRule || additionalRequired.has(definition.id);
      return {
        id: definition.id,
        batch: definition.batch,
        expectedSourceId: `${definition.batch}-${slotCode}`,
        label: definition.label,
        examples: definition.examples,
        required,
        requiredByRule,
        addedByPm: !requiredByRule && additionalRequired.has(definition.id),
        complete: matchedSources.length > 0,
        status: matchedSources.length ? "added" : required ? "needed" : "if_applicable",
        matchedSourceIds: matchedSources.map((source) => source.id).filter(Boolean)
      };
    });
  }

  function intakePlan(state) {
    const sources = list(state?.sources).filter(usableSource);
    const dealType = clean(state?.deal?.dealType).toLowerCase();
    return INTAKE_DEFINITIONS.map((definition) => {
      const matchedSources = definition.id === "workbook"
        ? []
        : sources.filter((source) => definition.matcher.test(searchableSource(source)));
      const complete = definition.id === "workbook" ? Boolean(state?.workbook?.loaded) : matchedSources.length > 0;
      const required = definition.id === "workbook" || definition.id === "request" || definition.id === "financial" || definition.id === "operations" || (definition.id === "prior" && /renewal|modification/.test(dealType));
      return {
        ...definition,
        complete,
        required,
        status: complete ? "complete" : required ? "required" : "expected",
        matchedSourceIds: matchedSources.map((source) => source.id).filter(Boolean)
      };
    });
  }

  function batchPlan(state) {
    const sources = list(state?.sources).filter(usableSource);
    const documents = documentPlan(state);
    return BATCH_DEFINITIONS.map((definition) => {
      const includedDocuments = documents.filter((item) => item.required && definition.documentIds.includes(item.id));
      const pendingDocuments = includedDocuments.filter((item) => !item.complete);
      const currentSources = sources.filter((source) => {
        const packet = clean(source.packet).toUpperCase();
        return packet === definition.id || packet.startsWith(`${definition.id}R`);
      });
      return {
        ...definition,
        documents: includedDocuments,
        pendingDocuments,
        files: includedDocuments.map((item) => item.label).join(" · "),
        pendingFiles: pendingDocuments.map((item) => item.label).join(" · "),
        currentCount: currentSources.length,
        complete: includedDocuments.length > 0 && pendingDocuments.length === 0,
        sourceIds: currentSources.map((source) => source.id).filter(Boolean)
      };
    }).filter((batch) => batch.documents.length > 0 || batch.currentCount > 0);
  }

  function factFamily(path) {
    const family = clean(path).split(".")[0];
    return Object.prototype.hasOwnProperty.call(FAMILY_CONSEQUENCES, family) ? family : "default";
  }

  function candidateConsequence(fact) {
    if (fact?.status === "conflicted") return "Competing same-scope values can change calculations and memo language; select one controlling version with rationale.";
    if (fact?.status === "missing") return `Required evidence is absent. ${FAMILY_CONSEQUENCES[factFamily(fact?.path)]}`;
    if (fact?.status === "judgment_required") return `A named PM decision is required. ${FAMILY_CONSEQUENCES[factFamily(fact?.path)]}`;
    if (fact?.requiresMetadataReview) return "Entity, period or as-of metadata is incomplete; the value remains quarantined from calculations and output.";
    return FAMILY_CONSEQUENCES[factFamily(fact?.path)];
  }

  function candidatePriority(fact) {
    if (fact?.status === "conflicted") return { rank: 0, band: "Decision blocker" };
    if (fact?.status === "missing") return { rank: 1, band: "Missing support" };
    if (fact?.status === "judgment_required") return { rank: 2, band: "PM decision" };
    if (fact?.requiresMetadataReview) return { rank: 3, band: "Metadata review" };
    if (["credit", "facility", "collateral", "project", "financial", "guarantor"].includes(factFamily(fact?.path))) return { rank: 4, band: "Material fact" };
    return { rank: 5, band: "Supporting fact" };
  }

  function prioritizeCandidates(facts) {
    return list(facts)
      .filter((fact) => ["candidate", "conflicted", "missing", "judgment_required"].includes(fact?.status))
      .map((fact, index) => ({ ...fact, ...candidatePriority(fact), consequence: candidateConsequence(fact), originalIndex: index }))
      .sort((a, b) => a.rank - b.rank || clean(a.label || a.path).localeCompare(clean(b.label || b.path)) || a.originalIndex - b.originalIndex);
  }

  function recordComplete(record, fields) {
    return active(record) && fields.every((field) => clean(record[field]));
  }

  function ratingAligned(state) {
    const proposed = clean(state?.deal?.proposedRating);
    return !placeholder(proposed) && list(state?.facts).some((fact) => accepted(fact) && fact.provenance === "analyst_judgment" && fact.path === "credit.proposedRiskRating" && clean(fact.value) === proposed && fact.controlling !== false);
  }

  function applicabilityComplete(state) {
    const items = list(state?.applicability);
    return items.length > 0 && items.every((item) => {
      if (item.kind === "core") return item.status === "ready" && clean(item.basis).length >= 8;
      if (clean(state?.deal?.dealType) === "Modification" && item.id === "modification") return item.status === "ready" && clean(item.basis).length >= 8;
      return ["ready", "not_applicable"].includes(item.status) && clean(item.basis).length >= 8;
    });
  }

  function judgmentTasks(state, model) {
    const changesRequired = /renewal|modification/i.test(clean(state?.deal?.dealType));
    const currentChanges = list(state?.changes).filter(active);
    const currentRisks = list(state?.risks).filter(active);
    const conditions = list(state?.conditions);
    const sections = new Map(list(state?.memoSections).map((section) => [section.id, section]));
    const tasks = [
      { id: "changes", label: "Transaction changes", description: changesRequired ? "Compare prior approval, current position and proposed structure." : "State the proposed structure and credit impact.", complete: changesRequired ? currentChanges.length > 0 && currentChanges.every((record) => recordComplete(record, ["field", "prior", "current", "proposed", "impact"])) : !placeholder(state?.deal?.request), view: "workbench", anchor: "credit-change-work", owner: "Portfolio manager" },
      { id: "repayment", label: "Repayment sources", description: "Quantify amount, timing, weakest assumption and maturity connection.", complete: clean(sections.get("repayment")?.narrative).length >= 80, view: "memo", anchor: "memo-repayment", owner: "Portfolio manager" },
      { id: "downside", label: "Selected downside", description: "Record price, pace, cost, rate, cancellation and support consequences.", complete: Boolean(model?.stressCurrent), view: "downside", anchor: "downside-work", owner: "Portfolio manager" },
      { id: "risks", label: "Risks and mitigants", description: "Link evidence to consequence, real protection and residual risk.", complete: currentRisks.length > 0 && currentRisks.every((record) => recordComplete(record, ["title", "evidence", "consequence", "mitigant", "residual", "condition", "owner"])), view: "risks", anchor: "credit-risk-work", owner: "Portfolio manager" },
      { id: "conditions", label: "Conditions and monitoring", description: "Name timing, requirement, purpose, owner and verification.", complete: conditions.length > 0 && conditions.every((record) => recordComplete(record, ["phase", "requirement", "purpose", "owner", "verification"])), view: "risks", anchor: "credit-condition-work", owner: "Portfolio manager" },
      { id: "rating", label: "Rating judgment", description: "State the PM rating and contrary evidence; never system-assign it.", complete: ratingAligned(state) && clean(sections.get("rating")?.narrative).length >= 60, view: "memo", anchor: "decision-form", owner: "Portfolio manager" },
      { id: "applicability", label: "Applicability decisions", description: "Route every core and conditional topic with a documented basis.", complete: applicabilityComplete(state), view: "gate", anchor: "applicability-matrix", owner: "Portfolio manager / specialist" }
    ];
    return tasks.map((task) => ({ ...task, status: task.complete ? "complete" : "remaining" }));
  }

  function stageSummary(stage, state, model) {
    let checks = [];
    let owner = "Portfolio manager";
    if (stage === "add") {
      checks = [
        { label: "PM confirmed the individual workbook-tab selection", complete: state?.mode === "demo" || state?.workbookScopeConfirmed === true },
        { label: "HBF workbook added for the selected tab scope", complete: Boolean(state?.workbook?.loaded) && !state?.workbook?.scopeChangedAfterImport },
        { label: "At least one validated Opus JSON packet added", complete: list(state?.importedPacketIds).length > 0 },
        ...documentPlan(state).filter((item) => item.required).map((item) => ({ label: item.label, complete: item.complete }))
      ];
      owner = "Portfolio manager / analyst";
    } else if (stage === "verify") {
      const queue = prioritizeCandidates(state?.facts);
      checks = [
        { label: "All candidate facts dispositioned", complete: queue.length === 0 },
        { label: "All same-scope conflicts reconciled", complete: Number(model?.conflicts || 0) === 0 },
        { label: "Accepted facts retain source and locator", complete: list(state?.facts).filter(accepted).every((fact) => fact.provenance === "analyst_judgment" ? Boolean(clean(fact.locator)) : Boolean(clean(fact.sourceId) && clean(fact.locator))) }
      ];
      owner = "Portfolio manager";
    } else if (stage === "judgment") {
      checks = judgmentTasks(state, model).map((task) => ({ label: task.label, complete: task.complete }));
      owner = "Portfolio manager";
    } else if (stage === "review") {
      const sections = list(state?.memoSections);
      checks = [
        { label: `All 17 memo sections complete (${sections.filter((section) => clean(section.narrative).length >= 60).length}/17)`, complete: sections.length === 17 && sections.every((section) => clean(section.narrative).length >= 60) },
        { label: "Narratives current to controlling facts", complete: !state?.staleNarrativeReviewRequired },
        { label: "Credit Officer decision view assembled", complete: sections.length === 17 }
      ];
      owner = "Portfolio manager → Credit Officer";
    } else {
      const attested = Object.values(state?.attestations || {}).filter(Boolean).length;
      checks = [
        { label: "All readiness controls pass", complete: Number(model?.failedControls || 0) === 0 && Number(model?.blockers || 0) === 0 },
        { label: `Current-revision PM attestations (${attested}/4)`, complete: attested === 4 },
        { label: "Package marked Review Ready", complete: Boolean(model?.ready) }
      ];
      owner = "Portfolio manager";
    }
    return {
      stage,
      owner,
      completeCount: checks.filter((check) => check.complete).length,
      totalCount: checks.length,
      complete: checks.filter((check) => check.complete).map((check) => check.label),
      remaining: checks.filter((check) => !check.complete).map((check) => check.label)
    };
  }

  function officerExceptions(state) {
    const rows = [];
    list(state?.issues).filter((issue) => issue.status === "open" && issue.severity !== "note").forEach((issue) => rows.push({ id: issue.id, severity: issue.severity === "blocker" ? "blocker" : "warning", title: issue.title, detail: issue.detail, actionView: issue.actionView || "gate" }));
    list(state?.conflicts).filter((conflict) => !conflict.status || conflict.status === "open").forEach((conflict) => {
      if (!rows.some((row) => row.id === conflict.id || row.id === conflict.issueId)) rows.push({ id: conflict.id, severity: "blocker", title: conflict.field || "Material fact conflict", detail: "A controlling value and PM rationale are required before output can rely on this field.", actionView: "reconcile" });
    });
    const queue = prioritizeCandidates(state?.facts);
    if (queue.length) rows.push({ id: "FACT-QUEUE", severity: queue.some((item) => item.rank <= 2) ? "blocker" : "warning", title: `${queue.length} imported fact${queue.length === 1 ? "" : "s"} awaiting disposition`, detail: queue[0].consequence, actionView: "sources" });
    const applicability = list(state?.applicability).filter((item) => !["ready", "not_applicable"].includes(item.status) || item.kind === "core" && item.status !== "ready" || clean(item.basis).length < 8);
    if (applicability.length) rows.push({ id: "APPLICABILITY", severity: "blocker", title: `${applicability.length} applicability decision${applicability.length === 1 ? "" : "s"} incomplete`, detail: "Core and conditional routing must state Ready or Not applicable with a PM or specialist basis.", actionView: "gate" });
    return rows.sort((a, b) => (a.severity === "blocker" ? 0 : 1) - (b.severity === "blocker" ? 0 : 1) || clean(a.title).localeCompare(clean(b.title)));
  }

  function evidenceIdsForPaths(state, paths, maximum) {
    const wanted = new Set(list(paths));
    const ids = [];
    list(state?.facts).forEach((fact) => {
      if (!wanted.has(fact.path) || !accepted(fact) || fact.controlling === false || !fact.id || ids.includes(fact.id)) return;
      ids.push(fact.id);
    });
    return ids.slice(0, Number(maximum) || 8);
  }

  window.HBF_CreditPath = Object.freeze({
    INTAKE_DEFINITIONS,
    BATCH_DEFINITIONS,
    WORKBOOK_SCOPE_DEFINITIONS,
    DOCUMENT_DEFINITIONS,
    intakePlan,
    batchPlan,
    defaultWorkbookScope,
    defaultWorkbookTabs,
    selectedWorkbookTabs,
    selectedSheet,
    workbookScopePlan,
    workbookSheetScope,
    workbookSheetSelected,
    workbookRecordSelected,
    workbookScopeSignature,
    workbookScopeMatches,
    scopeWorkbookResult,
    documentPlan,
    candidateConsequence,
    prioritizeCandidates,
    judgmentTasks,
    stageSummary,
    officerExceptions,
    evidenceIdsForPaths
  });
})();
