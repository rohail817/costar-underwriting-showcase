(function () {
  "use strict";

  const MAX_FILE_BYTES = 15 * 1024 * 1024;
  const MAX_ZIP_ENTRIES = 10000;
  const MAX_ZIP_ENTRY_UNCOMPRESSED_BYTES = 25 * 1024 * 1024;
  const MAX_ZIP_TOTAL_UNCOMPRESSED_BYTES = 100 * 1024 * 1024;
  const MAX_SHARED_STRINGS_XML_CHARS = 8 * 1024 * 1024;
  const MAX_WORKBOOK_XML_CHARS = 2 * 1024 * 1024;
  const MAX_SHEET_XML_CHARS = 12 * 1024 * 1024;
  const MAX_CELLS = 125000;
  const MAX_FORMULA_ERROR_SAMPLES = 100;

  const APPROVED_SHEETS = [
    "Exposure", "Bank Group", "Covenant Tracking", "Unit Line Detail", "Borrowing Base",
    "Deposits", "RLOC", "Heat Map", "Revenue-Closings", "Sales-Closings", "Collateral Value",
    "Balance Sheet", "Inventory-Units", "Inventory-Lots", "Debt Listing", "Equity",
    "Income Statement", "Net Income", "Absorption Sensitivity", "Sensitivity Analysis",
    "A&D Sources & Uses", "Curtailment", "Active Subdivision", "Vertical Construction",
    "Contract Analysis", "Market Snapshot", "Guarantor Aggregation", "Project Inventory",
    "Dev Budget", "Project Equity", "Template Modifications"
  ];

  const PROFILE_SIGNATURES = [
    {
      id: "borrowing-base-layout",
      sheet: "Borrowing Base",
      anchors: [
        { address: "B2", labels: ["Net / Gross Facility"] },
        { address: "E2", labels: ["Principal Balance (UPB)"] },
        { address: "B22", labels: ["Proposed Max Commitment"] }
      ]
    },
    {
      id: "covenant-tracking-layout",
      sheet: "Covenant Tracking",
      anchors: [
        { address: "C3", labels: ["Covenant"] },
        { address: "D3", labels: ["Entity Tested"] },
        { address: "F3", labels: ["Requirement $000's"] }
      ]
    },
    {
      id: "balance-sheet-layout",
      sheet: "Balance Sheet",
      anchors: [
        { address: "B2", labels: ["Balance Sheet"] },
        { address: "B3", labels: ["(000's)"] },
        { address: "B19", labels: ["Tangible Net Worth"] },
        { address: "B24", labels: ["Current Ratio"] }
      ]
    },
    {
      id: "income-statement-layout",
      sheet: "Income Statement",
      anchors: [
        { address: "B2", labels: ["Income Statement Analysis"] },
        { address: "B4", labels: ["($000's)"] },
        { address: "B23", labels: ["EBITDA"] },
        { address: "B44", labels: ["Proposed Total Fixed Charge Coverage"] }
      ]
    },
    {
      id: "sources-and-uses-layout",
      sheet: "A&D Sources & Uses",
      anchors: [
        { address: "B2", labels: ["Source of Funds"] },
        { address: "E2", labels: ["Use of Funds"] },
        { address: "B9", labels: ["Total Source of Funds"] },
        { address: "E9", labels: ["Total Use of Funds"] }
      ]
    }
  ];

  // These markers are part of the approved v2.2 layout. Money observations from
  // these ranges are normalized to whole USD only when the exact marker matches.
  const SOURCE_SCALE_PROFILES = [
    { id: "balance-sheet-usd-thousands", sheet: "Balance Sheet", address: "B3", labels: ["(000's)"], factor: 1000, sourceUnit: "USD thousands" },
    { id: "income-statement-usd-thousands", sheet: "Income Statement", address: "B4", labels: ["($000's)"], factor: 1000, sourceUnit: "USD thousands" },
    { id: "revenue-closings-usd-thousands", sheet: "Revenue-Closings", address: "B3", labels: ["($000's)"], factor: 1000, sourceUnit: "USD thousands" },
    { id: "guarantor-usd-thousands", sheet: "Guarantor Aggregation", address: "B10", labels: ["Adjusted Balance Sheet Analysis - Combined (000's)"], factor: 1000, sourceUnit: "USD thousands" },
    { id: "covenant-tracking-usd-thousands", sheet: "Covenant Tracking", address: "F3", labels: ["Requirement $000's"], factor: 1000, sourceUnit: "USD thousands" }
  ];

  // Only the exact as-complete total is sufficiently self-describing to enter
  // mappedFacts. Ambiguous series are retained separately for explicit period /
  // entity binding and can never be bulk-accepted as mapped facts.
  const SAFE_FACT_RULES = [
    {
      id: "collateral-as-complete-total", sheet: "Collateral Value", anchorAddress: "H14",
      anchorLabels: ["Total Collateral Value"], valueAddresses: ["I14"],
      path: "collateral.asCompleteValue", label: "As-complete collateral value", type: "money",
      sourceScale: 1, sourceUnit: "USD", unit: "USD", periodType: "as_complete",
      entity: "Workbook collateral pool"
    }
  ];

  const REVIEW_REQUIRED_FACT_RULES = [
    {
      id: "borrowing-base-proposed-commitment", sheet: "Borrowing Base", anchorAddress: "B46",
      anchorLabels: ["Proposed Max Commitment"], valueAddresses: ["G46"],
      path: "facility.proposedCommitment", label: "Proposed max commitment", type: "money",
      sourceScale: 1, sourceUnit: "USD", unit: "USD", requiredMetadata: ["entity", "asOfDate"]
    },
    {
      id: "balance-sheet-tangible-net-worth", sheet: "Balance Sheet", anchorAddress: "B19",
      anchorLabels: ["Tangible Net Worth"], valueColumns: ["E", "F", "G", "H", "I", "J", "K", "L"],
      headerRows: [2, 3], path: "financial.tangibleNetWorth", label: "Tangible net worth", type: "money",
      scaleProfileId: "balance-sheet-usd-thousands", unit: "USD", requiredMetadata: ["entity", "periodEndDate"]
    },
    {
      id: "balance-sheet-working-capital", sheet: "Balance Sheet", anchorAddress: "C18",
      anchorLabels: ["Working Capital"], valueColumns: ["E", "F", "G", "H", "I", "J", "K", "L"],
      headerRows: [2, 3], path: "financial.workingCapital", label: "Working capital", type: "money",
      scaleProfileId: "balance-sheet-usd-thousands", unit: "USD", requiredMetadata: ["entity", "periodEndDate"]
    },
    {
      id: "balance-sheet-current-ratio", sheet: "Balance Sheet", anchorAddress: "B24",
      anchorLabels: ["Current Ratio"], valueColumns: ["E", "F", "G", "H", "I", "J", "K", "L"],
      headerRows: [2, 3], path: "financial.currentRatio", label: "Current ratio", type: "multiple",
      sourceScale: 1, sourceUnit: "ratio", unit: "x", requiredMetadata: ["entity", "periodEndDate"]
    },
    {
      id: "balance-sheet-leverage", sheet: "Balance Sheet", anchorAddress: "B25",
      anchorLabels: ["Debt / TNW"], valueColumns: ["E", "F", "G", "H", "I", "J", "K", "L"],
      headerRows: [2, 3], path: "financial.leverage", label: "Debt / TNW", type: "multiple",
      sourceScale: 1, sourceUnit: "ratio", unit: "x", requiredMetadata: ["entity", "periodEndDate"]
    },
    {
      id: "income-statement-revenue", sheet: "Income Statement", anchorAddress: "B9",
      anchorLabels: ["Revenues"], valueColumns: ["G", "H", "I", "J", "K", "L", "M", "N", "O"],
      headerRows: [3, 4], path: "financial.revenue", label: "Revenue", type: "money",
      scaleProfileId: "income-statement-usd-thousands", unit: "USD", requiredMetadata: ["entity", "periodEndDate", "periodType"]
    },
    {
      id: "income-statement-ebitda", sheet: "Income Statement", anchorAddress: "B23",
      anchorLabels: ["EBITDA"], valueColumns: ["G", "H", "I", "J", "K", "L", "M", "N", "O"],
      headerRows: [3, 4], path: "financial.ebitda", label: "EBITDA", type: "money",
      scaleProfileId: "income-statement-usd-thousands", unit: "USD", requiredMetadata: ["entity", "periodEndDate", "periodType"]
    },
    {
      id: "income-statement-fccr", sheet: "Income Statement", anchorAddress: "B44",
      anchorLabels: ["Proposed Total Fixed Charge Coverage"], valueColumns: ["G", "H", "I", "J", "K", "L", "M", "N", "O"],
      headerRows: [3, 4], path: "financial.fccr", label: "Fixed-charge coverage", type: "multiple",
      sourceScale: 1, sourceUnit: "ratio", unit: "x", requiredMetadata: ["entity", "periodEndDate", "periodType"]
    },
    {
      id: "revenue-closings-gross-revenue", sheet: "Revenue-Closings", anchorAddress: "B4",
      anchorLabels: ["Gross Revenue - Home Sales"], valueColumns: ["C", "D", "F", "H", "J"],
      headerRows: [2, 3], path: "operating.grossRevenue", label: "Gross home-sales revenue", type: "money",
      scaleProfileId: "revenue-closings-usd-thousands", unit: "USD", requiredMetadata: ["entity", "periodEndDate"]
    },
    {
      id: "revenue-closings-total-closings", sheet: "Revenue-Closings", anchorAddress: "B6",
      anchorLabels: ["Total Closings"], valueColumns: ["C", "D", "F", "H", "J"],
      headerRows: [2, 3], path: "operating.closings", label: "Closings", type: "number",
      sourceScale: 1, sourceUnit: "homes", unit: "homes", requiredMetadata: ["entity", "periodEndDate"]
    },
    {
      id: "revenue-closings-cancellation-rate", sheet: "Revenue-Closings", anchorAddress: "B9",
      anchorLabels: ["Cancellation Rate"], valueColumns: ["C", "D", "F", "H", "J"],
      headerRows: [2, 3], path: "operating.cancellationRate", label: "Cancellation rate", type: "percent",
      sourceScale: 1, sourceUnit: "ratio", unit: "decimal", requiredMetadata: ["entity", "periodEndDate"]
    },
    {
      id: "guarantor-combined-net-worth", sheet: "Guarantor Aggregation", anchorAddress: "B35",
      anchorLabels: ["NET WORTH"], valueAddresses: ["H35"], headerRows: [10, 11],
      path: "guarantor.netWorth", label: "Combined guarantor net worth", type: "money",
      scaleProfileId: "guarantor-usd-thousands", unit: "USD", entity: "Guarantor Combined",
      requiredMetadata: ["periodEndDate"]
    },
    {
      id: "ad-total-sources", sheet: "A&D Sources & Uses", anchorAddress: "B9",
      anchorLabels: ["Total Source of Funds"], valueAddresses: ["C9"],
      path: "project.totalSources", label: "Total sources", type: "money",
      sourceScale: 1, sourceUnit: "USD", unit: "USD", requiredMetadata: ["project", "asOfDate"]
    },
    {
      id: "ad-total-uses", sheet: "A&D Sources & Uses", anchorAddress: "E9",
      anchorLabels: ["Total Use of Funds"], valueAddresses: ["F9"],
      path: "project.totalUses", label: "Total uses", type: "money",
      sourceScale: 1, sourceUnit: "USD", unit: "USD", requiredMetadata: ["project", "asOfDate"]
    }
  ];

  function cellColumn(address) {
    const match = /^([A-Z]+)\d+$/.exec(address || "");
    if (!match) return -1;
    let value = 0;
    for (const letter of match[1]) value = value * 26 + letter.charCodeAt(0) - 64;
    return value - 1;
  }

  function cellRow(address) {
    const match = /^[A-Z]+(\d+)$/.exec(address || "");
    return match ? Number(match[1]) - 1 : -1;
  }

  function columnName(index) {
    let current = index + 1;
    let result = "";
    while (current > 0) {
      const remainder = (current - 1) % 26;
      result = String.fromCharCode(65 + remainder) + result;
      current = Math.floor((current - 1) / 26);
    }
    return result;
  }

  function cleanText(value) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  }

  function normalizeLabel(value) {
    return cleanText(value).toLowerCase().replace(/[:*\[\]()]/g, "").replace(/\s+/g, " ");
  }

  function checkProfileSignatures(sheetMap) {
    return PROFILE_SIGNATURES.map((signature) => {
      const sheet = sheetMap.get(signature.sheet);
      const anchors = signature.anchors.map((anchor) => {
        const cell = sheet && sheet.cells ? sheet.cells.get(anchor.address) : null;
        const actual = cell ? cleanText(cell.value).slice(0, 160) : "";
        const normalizedActual = normalizeLabel(actual);
        const matched = anchor.labels.some((label) => normalizeLabel(label) === normalizedActual);
        return {
          address: anchor.address,
          expected: anchor.labels.slice(),
          actual: actual || null,
          matched
        };
      });
      return {
        id: signature.id,
        sheet: signature.sheet,
        sheetPresent: Boolean(sheet),
        matched: Boolean(sheet) && anchors.every((anchor) => anchor.matched),
        anchors
      };
    });
  }

  function checkScaleProfiles(sheetMap) {
    return SOURCE_SCALE_PROFILES.map((profile) => {
      const sheet = sheetMap.get(profile.sheet);
      const cell = sheet && sheet.cells ? sheet.cells.get(profile.address) : null;
      const actual = cell ? cleanText(cell.value).slice(0, 200) : "";
      const matched = Boolean(sheet) && profile.labels.some((label) => normalizeLabel(label) === normalizeLabel(actual));
      return {
        id: profile.id,
        sheet: profile.sheet,
        address: profile.address,
        expected: profile.labels.slice(),
        actual: actual || null,
        factor: profile.factor,
        sourceUnit: profile.sourceUnit,
        matched
      };
    });
  }

  function evaluateProfile(sheetNames, sheetMap) {
    const missingSheets = APPROVED_SHEETS.filter((name) => !sheetNames.includes(name));
    const unexpectedSheets = sheetNames.filter((name) => !APPROVED_SHEETS.includes(name));
    const unreadableSheets = APPROVED_SHEETS.filter((name) => {
      const sheet = sheetMap.get(name);
      return !sheet || sheet.missing;
    });
    const exactSheetCount = sheetNames.length === APPROVED_SHEETS.length;
    const sheetNamesMatched = exactSheetCount && missingSheets.length === 0 && unexpectedSheets.length === 0;
    const readableSheetsMatched = unreadableSheets.length === 0;
    const signatureChecks = checkProfileSignatures(sheetMap);
    const matchedSignatureCount = signatureChecks.filter((check) => check.matched).length;
    const signaturesMatched = matchedSignatureCount === PROFILE_SIGNATURES.length;
    const scaleChecks = checkScaleProfiles(sheetMap);
    const matchedScaleProfileCount = scaleChecks.filter((check) => check.matched).length;
    const scaleProfilesMatched = matchedScaleProfileCount === SOURCE_SCALE_PROFILES.length;
    return {
      profileMatched: sheetNamesMatched && readableSheetsMatched && signaturesMatched && scaleProfilesMatched,
      sheetNamesMatched,
      readableSheetsMatched,
      exactSheetCount,
      expectedSheetCount: APPROVED_SHEETS.length,
      actualSheetCount: sheetNames.length,
      missingSheets,
      unexpectedSheets,
      unreadableSheets,
      signaturesMatched,
      requiredSignatureCount: PROFILE_SIGNATURES.length,
      matchedSignatureCount,
      signatureChecks,
      scaleProfilesMatched,
      requiredScaleProfileCount: SOURCE_SCALE_PROFILES.length,
      matchedScaleProfileCount,
      scaleChecks
    };
  }

  function safeNumber(value) {
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value !== "string") return null;
    const cleaned = value.replace(/[$,%x()\s]/gi, "").replace(/,/g, "");
    if (!cleaned || /^#/.test(cleaned) || /^n\/?a$/i.test(cleaned)) return null;
    const number = Number(cleaned);
    if (!Number.isFinite(number)) return null;
    return value.includes("(") ? -number : number;
  }

  function parseXml(text, name, maxCharacters) {
    if (typeof text !== "string") throw new Error(`The ${name} XML could not be read as text.`);
    if (text.length > maxCharacters) {
      throw new Error(`The ${name} XML exceeds the ${maxCharacters.toLocaleString()}-character safety limit.`);
    }
    const doc = new DOMParser().parseFromString(text, "application/xml");
    if (doc.querySelector("parsererror")) throw new Error(`The ${name} XML is malformed.`);
    return doc;
  }

  function textOf(element) {
    if (!element) return "";
    return Array.from(element.getElementsByTagName("t")).map((node) => node.textContent || "").join("") || element.textContent || "";
  }

  async function sha256(buffer) {
    if (!window.crypto?.subtle && !window.HBFCrypto) return "Unavailable in this browser";
    const digest = window.HBFCrypto ? await window.HBFCrypto.sha256(buffer.slice(0)) : await window.crypto.subtle.digest("SHA-256", buffer.slice(0));
    return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  async function readSharedStrings(zip) {
    const item = zip.file("xl/sharedStrings.xml");
    if (!item) return [];
    const doc = parseXml(await item.async("string"), "shared strings", MAX_SHARED_STRINGS_XML_CHARS);
    return Array.from(doc.getElementsByTagName("si")).map(textOf);
  }

  function interpretCalcMode(calcPrPresent, rawAttribute) {
    const calcModeAttribute = calcPrPresent && rawAttribute ? cleanText(rawAttribute) : null;
    const calcMode = calcPrPresent ? calcModeAttribute || "auto" : "unknown";
    const calcModeRecognized = Boolean(calcPrPresent) && (calcModeAttribute === null || calcModeAttribute === "auto");
    const calcModeBasis = !calcPrPresent
      ? "calcPr missing"
      : calcModeAttribute === null
        ? "calcPr present; calcMode omitted (OOXML default auto)"
        : `calcPr calcMode=${calcModeAttribute}`;
    return { calcMode, calcModeAttribute, calcModeRecognized, calcModeBasis };
  }

  async function workbookManifest(zip) {
    const workbookFile = zip.file("xl/workbook.xml");
    const relsFile = zip.file("xl/_rels/workbook.xml.rels");
    if (!workbookFile || !relsFile) throw new Error("The file does not contain a readable Excel workbook manifest.");

    const workbookDoc = parseXml(await workbookFile.async("string"), "workbook", MAX_WORKBOOK_XML_CHARS);
    const relsDoc = parseXml(await relsFile.async("string"), "workbook relationships", MAX_WORKBOOK_XML_CHARS);
    const relationships = new Map();
    Array.from(relsDoc.getElementsByTagName("Relationship")).forEach((rel) => {
      relationships.set(rel.getAttribute("Id"), rel.getAttribute("Target"));
    });

    const calcPr = workbookDoc.getElementsByTagName("calcPr")[0];
    const calculationMode = interpretCalcMode(Boolean(calcPr), calcPr ? calcPr.getAttribute("calcMode") : null);
    // ECMA-376 defines omitted calcMode as automatic. We accept that default
    // only when a calcPr element is actually present; a missing calculation
    // declaration is not silently upgraded to automatic mode.
    const sheets = Array.from(workbookDoc.getElementsByTagName("sheet")).map((sheet) => {
      const relId = sheet.getAttribute("r:id") || sheet.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
      let target = relationships.get(relId) || "";
      target = target.replace(/^\//, "");
      if (!target.startsWith("xl/")) target = `xl/${target}`;
      return { name: sheet.getAttribute("name") || "Unnamed sheet", target };
    });

    return { sheets, ...calculationMode };
  }

  async function readSheet(zip, manifestEntry, sharedStrings, budget) {
    const file = zip.file(manifestEntry.target);
    if (!file) return { name: manifestEntry.name, cells: new Map(), formulas: [], errors: [], errorCount: 0, missing: true };
    const doc = parseXml(await file.async("string"), manifestEntry.name, MAX_SHEET_XML_CHARS);
    const cells = new Map();
    const formulas = [];
    const errors = [];
    let errorCount = 0;

    for (const cell of Array.from(doc.getElementsByTagName("c"))) {
      budget.count += 1;
      if (budget.count > MAX_CELLS) throw new Error(`Workbook exceeds the ${MAX_CELLS.toLocaleString()}-cell safety limit.`);
      const address = cell.getAttribute("r");
      if (!address) continue;
      const type = cell.getAttribute("t") || "n";
      const formulaNode = cell.getElementsByTagName("f")[0];
      const valueNode = cell.getElementsByTagName("v")[0];
      const inlineNode = cell.getElementsByTagName("is")[0];
      let value = null;

      if (type === "s" && valueNode) value = sharedStrings[Number(valueNode.textContent)] ?? "";
      else if (type === "inlineStr") value = textOf(inlineNode);
      else if (type === "str") value = valueNode ? valueNode.textContent || "" : "";
      else if (type === "b") value = valueNode ? valueNode.textContent === "1" : false;
      else if (type === "e") value = valueNode ? valueNode.textContent || "#ERROR" : "#ERROR";
      else if (valueNode && valueNode.textContent !== "") {
        const parsed = Number(valueNode.textContent);
        value = Number.isFinite(parsed) ? parsed : valueNode.textContent;
      }

      const hasFormula = Boolean(formulaNode);
      const formula = hasFormula ? formulaNode.textContent || "" : null;
      if (hasFormula) formulas.push({ address, formula, cachedValue: value });
      if (type === "e" || (typeof value === "string" && /^#(?:REF!|VALUE!|DIV\/0!|N\/A|NAME\?|NUM!|NULL!)/.test(value))) {
        errorCount += 1;
        if (errors.length < MAX_FORMULA_ERROR_SAMPLES) errors.push({ address, value });
      }
      cells.set(address, { address, row: cellRow(address), column: cellColumn(address), value, formula, hasFormula, type });
    }
    return { name: manifestEntry.name, cells, formulas, errors, errorCount, missing: false };
  }

  function sourceScaleForRule(rule, sheetMap) {
    if (Number.isFinite(rule.sourceScale)) {
      return { matched: true, factor: rule.sourceScale, sourceUnit: rule.sourceUnit || "source units", profileId: null };
    }
    const profile = SOURCE_SCALE_PROFILES.find((item) => item.id === rule.scaleProfileId);
    const check = checkScaleProfiles(sheetMap).find((item) => item.id === rule.scaleProfileId);
    if (!profile || !check || !check.matched) return { matched: false, factor: null, sourceUnit: null, profileId: rule.scaleProfileId || null };
    return { matched: true, factor: profile.factor, sourceUnit: profile.sourceUnit, profileId: profile.id };
  }

  function ruleAddresses(rule) {
    if (Array.isArray(rule.valueAddresses)) return rule.valueAddresses.slice();
    const row = cellRow(rule.anchorAddress) + 1;
    return (rule.valueColumns || []).map((column) => `${column}${row}`);
  }

  function sourceHeaders(rule, sheet, valueAddress) {
    const column = (/^([A-Z]+)/.exec(valueAddress) || [null, ""])[1];
    if (!column) return [];
    return (rule.headerRows || []).map((row) => {
      const address = `${column}${row}`;
      const cell = sheet.cells.get(address);
      return { address, value: cell && cell.value != null ? cleanText(cell.value) : null };
    });
  }

  function anchorMatches(rule, sheet) {
    const anchor = sheet && sheet.cells ? sheet.cells.get(rule.anchorAddress) : null;
    if (!anchor) return null;
    const matched = rule.anchorLabels.some((label) => normalizeLabel(label) === normalizeLabel(anchor.value));
    return matched ? anchor : null;
  }

  function normalizedObservation(rule, sheet, cell, scale, index, reviewRequired) {
    const sourceValue = safeNumber(cell.value);
    // A zero in the distributed blank template is not evidence that the
    // underlying borrower value is actually zero; omit it conservatively.
    if (sourceValue === null || sourceValue === 0) return null;
    let value = sourceValue;
    if (rule.type === "money") value *= scale.factor;
    if (rule.type === "percent" && Math.abs(value) > 1 && Math.abs(value) <= 100) value /= 100;
    const headers = sourceHeaders(rule, sheet, cell.address);
    const headerText = headers.filter((item) => item.value).map((item) => `${item.address}: ${item.value}`).join("; ");
    return {
      id: `${reviewRequired ? "WB-META" : "WB"}-${rule.id}-${index + 1}`,
      path: rule.path,
      label: rule.label,
      value,
      valueType: rule.type,
      unit: rule.unit || null,
      scale: 1,
      sourceValue,
      sourceUnit: scale.sourceUnit,
      sourceScale: scale.factor,
      normalizationFactor: rule.type === "money" ? scale.factor : 1,
      scaleProfileId: scale.profileId,
      sourceId: "WB-IMPORTED",
      locator: `${rule.sheet}!${cell.address}`,
      anchorLocator: `${rule.sheet}!${rule.anchorAddress}`,
      sourceHeaders: headers,
      entity: rule.entity || null,
      periodType: rule.periodType || null,
      asOfDate: null,
      excerpt: `${rule.label}: ${cleanText(cell.value)}${headerText ? ` (${headerText})` : ""}`,
      status: reviewRequired ? "metadata_review_required" : "candidate",
      verification: reviewRequired ? "metadata_review_required" : "candidate",
      verified: false,
      eligibleForImport: !reviewRequired,
      eligibleForBulkAcceptance: !reviewRequired,
      metadataReviewRequired: reviewRequired ? (rule.requiredMetadata || []).slice() : [],
      reviewReason: reviewRequired
        ? `Bind ${humanList(rule.requiredMetadata || ["period/entity metadata"])} before this observation can become a controlling fact.`
        : null,
      provenance: cell.hasFormula || cell.formula !== null ? "workbook" : "source_fact",
      formula: cell.formula || null
    };
  }

  function humanList(items) {
    return items.length > 1 ? `${items.slice(0, -1).join(", ")} and ${items[items.length - 1]}` : items[0] || "required metadata";
  }

  function extractFactsForRules(sheetMap, rules, reviewRequired) {
    const facts = [];
    for (const rule of rules) {
      const sheet = sheetMap.get(rule.sheet);
      const anchor = anchorMatches(rule, sheet);
      if (!anchor) continue;
      const scale = sourceScaleForRule(rule, sheetMap);
      if (!scale.matched) continue;
      ruleAddresses(rule).forEach((address) => {
        const cell = sheet.cells.get(address);
        if (!cell) return;
        const observation = normalizedObservation(rule, sheet, cell, scale, facts.length, reviewRequired);
        if (observation) facts.push(observation);
      });
    }
    return facts;
  }

  function extractAnchoredFacts(sheetMap) {
    return extractFactsForRules(sheetMap, SAFE_FACT_RULES, false);
  }

  function extractReviewRequiredFacts(sheetMap) {
    return extractFactsForRules(sheetMap, REVIEW_REQUIRED_FACT_RULES, true);
  }

  function parseThreshold(value) {
    const numeric = safeNumber(value);
    if (numeric !== null) return numeric;
    const percent = /(\d+(?:\.\d+)?)\s*%/.exec(cleanText(value));
    return percent ? Number(percent[1]) / 100 : null;
  }

  function extractCovenants(sheet, sheetMap) {
    if (!sheet) return [];
    const scale = sourceScaleForRule({ scaleProfileId: "covenant-tracking-usd-thousands" }, sheetMap);
    if (!scale.matched) return [];
    const results = [];
    for (let row = 4; row <= 10; row += 1) {
      const nameCell = sheet.cells.get(`C${row}`);
      const name = nameCell ? cleanText(nameCell.value) : "";
      if (!/minimum|maximum|max distributions|liquidity|net worth|tnw|dtnw|ratio/i.test(name)) continue;
      const entityCell = sheet.cells.get(`D${row}`);
      const frequencyCell = sheet.cells.get(`E${row}`);
      const thresholdCell = sheet.cells.get(`F${row}`);
      const actualCandidates = [];
      for (let column = cellColumn("G1"); column <= cellColumn("O1"); column += 1) {
        const address = `${columnName(column)}${row}`;
        const cell = sheet.cells.get(address);
        const number = cell ? safeNumber(cell.value) : null;
        if (number !== null) actualCandidates.push({ cell, number });
      }
      if (!thresholdCell || !actualCandidates.length) continue;
      const selected = actualCandidates[actualCandidates.length - 1];
      const isMoney = /liquidity|net worth|tnw/i.test(name) && !/ratio|dtnw/i.test(name);
      const isPercent = /spec ratio|distributions/i.test(name);
      const thresholdSourceValue = parseThreshold(thresholdCell.value);
      if (thresholdSourceValue === null) continue;
      const factor = isMoney ? scale.factor : 1;
      const periodHeader = sheet.cells.get(`${columnName(selected.cell.column)}3`);
      results.push({
        name,
        entity: entityCell ? cleanText(entityCell.value) || null : null,
        frequency: frequencyCell ? cleanText(frequencyCell.value) || null : null,
        threshold: thresholdSourceValue * factor,
        actual: selected.number * factor,
        valueType: isMoney ? "money" : isPercent ? "percent" : "multiple",
        unit: isMoney ? "USD" : isPercent ? "decimal" : "x",
        scale: 1,
        sourceThreshold: thresholdSourceValue,
        sourceActual: selected.number,
        sourceUnit: isMoney ? scale.sourceUnit : isPercent ? "ratio" : "ratio",
        sourceScale: factor,
        normalizationFactor: factor,
        thresholdLocator: `Covenant Tracking!F${row}`,
        actualLocator: `Covenant Tracking!${selected.cell.address}`,
        locator: `Covenant Tracking!${selected.cell.address}`,
        periodLabel: periodHeader ? cleanText(periodHeader.value) || null : null,
        asOfDate: null,
        status: "metadata_review_required",
        eligibleForDecision: false,
        eligibleForBulkAcceptance: false,
        metadataReviewRequired: ["asOfDate"]
      });
    }
    return results.slice(0, 12);
  }

  function summarizeFormulaErrors(sheets, sampleLimit = MAX_FORMULA_ERROR_SAMPLES) {
    const safeLimit = Number.isSafeInteger(sampleLimit) && sampleLimit >= 0 ? sampleLimit : MAX_FORMULA_ERROR_SAMPLES;
    let count = 0;
    const samples = [];
    for (const sheet of sheets) {
      const sheetErrors = Array.isArray(sheet.errors) ? sheet.errors : [];
      const sheetCount = Number.isSafeInteger(sheet.errorCount) && sheet.errorCount >= sheetErrors.length
        ? sheet.errorCount
        : sheetErrors.length;
      count += sheetCount;
      for (const error of sheetErrors) {
        if (samples.length >= safeLimit) break;
        samples.push({ sheet: sheet.name, ...error });
      }
    }
    return { count, samples, sampleLimit: safeLimit, samplesTruncated: count > samples.length };
  }

  function validateZipMetadata(zip, entries) {
    let totalUncompressedBytes = 0;
    let largestEntry = { name: "", uncompressedBytes: 0 };
    for (const name of entries) {
      const entry = zip.files[name];
      if (!entry || entry.dir) continue;
      const uncompressedBytes = entry._data && entry._data.uncompressedSize;
      if (!Number.isSafeInteger(uncompressedBytes) || uncompressedBytes < 0) {
        throw new Error(`Workbook entry metadata is unavailable or invalid for ${name}.`);
      }
      if (uncompressedBytes > MAX_ZIP_ENTRY_UNCOMPRESSED_BYTES) {
        throw new Error(`Workbook entry ${name} declares more than the ${Math.round(MAX_ZIP_ENTRY_UNCOMPRESSED_BYTES / 1024 / 1024)} MB per-entry uncompressed safety limit.`);
      }
      totalUncompressedBytes += uncompressedBytes;
      if (!Number.isSafeInteger(totalUncompressedBytes) || totalUncompressedBytes > MAX_ZIP_TOTAL_UNCOMPRESSED_BYTES) {
        throw new Error(`Workbook package exceeds the ${Math.round(MAX_ZIP_TOTAL_UNCOMPRESSED_BYTES / 1024 / 1024)} MB total uncompressed safety limit.`);
      }
      if (uncompressedBytes > largestEntry.uncompressedBytes) largestEntry = { name, uncompressedBytes };
    }
    return { totalUncompressedBytes, largestEntry };
  }

  async function inspect(file) {
    if (!window.JSZip) throw new Error("The local Excel parser did not load.");
    if (!file || !/\.xlsx$/i.test(file.name)) throw new Error("Select an .xlsx workbook. Macro-enabled and legacy formats are not accepted.");
    if (file.size > MAX_FILE_BYTES) throw new Error(`Workbook is larger than the ${Math.round(MAX_FILE_BYTES / 1024 / 1024)} MB safety limit.`);

    const buffer = await file.arrayBuffer();
    const signature = new Uint8Array(buffer.slice(0, 4));
    if (signature[0] !== 0x50 || signature[1] !== 0x4b) throw new Error("The selected file is not a valid Office Open XML package.");
    const digest = await sha256(buffer);
    const metadataZip = await window.JSZip.loadAsync(buffer, { checkCRC32: false });
    const entries = Object.keys(metadataZip.files);
    if (entries.length > MAX_ZIP_ENTRIES) throw new Error("Workbook contains too many package entries.");
    if (entries.some((name) => /vbaProject\.bin$/i.test(name))) throw new Error("Macro content was detected. The local prototype accepts macro-free .xlsx files only.");
    const packageMetrics = validateZipMetadata(metadataZip, entries);
    const zip = await window.JSZip.loadAsync(buffer, { checkCRC32: true });

    const externalLinks = entries.filter((name) => /^xl\/externalLinks\//i.test(name));
    const sharedStrings = await readSharedStrings(zip);
    const manifest = await workbookManifest(zip);
    const budget = { count: 0 };
    const sheetMap = new Map();
    const parsedSheets = [];
    const sheetDiagnostics = [];
    let formulaCount = 0;
    let formulasWithoutCachedValues = 0;
    let externalFormulaCount = 0;

    for (const entry of manifest.sheets) {
      const sheet = await readSheet(zip, entry, sharedStrings, budget);
      sheetMap.set(sheet.name, sheet);
      parsedSheets.push(sheet);
      formulaCount += sheet.formulas.length;
      formulasWithoutCachedValues += sheet.formulas.filter((formula) => formula.cachedValue == null || formula.cachedValue === "").length;
      externalFormulaCount += sheet.formulas.filter((formula) => /\[[^\]]+\]/.test(formula.formula)).length;
      sheetDiagnostics.push({
        sheet: sheet.name,
        formulaCount: sheet.formulas.length,
        formulaErrorCount: Number.isSafeInteger(sheet.errorCount) ? sheet.errorCount : sheet.errors.length,
        formulaErrorSamples: sheet.errors.map((error) => ({ sheet: sheet.name, ...error })),
        formulasWithoutCachedValues: sheet.formulas.filter((formula) => formula.cachedValue == null || formula.cachedValue === "").length,
        externalFormulaCount: sheet.formulas.filter((formula) => /\[[^\]]+\]/.test(formula.formula)).length
      });
    }

    const formulaErrorDiagnostics = summarizeFormulaErrors(parsedSheets);
    const profileCheck = evaluateProfile(manifest.sheets.map((sheet) => sheet.name), sheetMap);
    const mappedFacts = profileCheck.profileMatched ? extractAnchoredFacts(sheetMap) : [];
    const metadataReviewRequiredFacts = profileCheck.profileMatched ? extractReviewRequiredFacts(sheetMap) : [];
    const covenants = profileCheck.profileMatched ? extractCovenants(sheetMap.get("Covenant Tracking"), sheetMap) : [];

    return {
      fileName: file.name.replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").slice(0, 180),
      fileSize: file.size,
      digest,
      profile: profileCheck.profileMatched ? "HBF-UW-v2.2" : "Unsupported / changed profile",
      profileMatched: profileCheck.profileMatched,
      sheetNamesMatched: profileCheck.sheetNamesMatched,
      readableSheetsMatched: profileCheck.readableSheetsMatched,
      sheets: manifest.sheets.length,
      sheetNames: manifest.sheets.map((sheet) => sheet.name),
      expectedSheetCount: profileCheck.expectedSheetCount,
      missingSheets: profileCheck.missingSheets,
      unexpectedSheets: profileCheck.unexpectedSheets,
      unreadableSheets: profileCheck.unreadableSheets,
      signaturesMatched: profileCheck.signaturesMatched,
      requiredSignatureCount: profileCheck.requiredSignatureCount,
      matchedSignatureCount: profileCheck.matchedSignatureCount,
      signatureChecks: profileCheck.signatureChecks,
      scaleProfilesMatched: profileCheck.scaleProfilesMatched,
      requiredScaleProfileCount: profileCheck.requiredScaleProfileCount,
      matchedScaleProfileCount: profileCheck.matchedScaleProfileCount,
      scaleChecks: profileCheck.scaleChecks,
      cells: budget.count,
      formulaCount,
      formulaErrorCount: formulaErrorDiagnostics.count,
      formulaErrorSamples: formulaErrorDiagnostics.samples,
      formulaErrorSampleCount: formulaErrorDiagnostics.samples.length,
      formulaErrorSampleLimit: formulaErrorDiagnostics.sampleLimit,
      formulaErrorSamplesTruncated: formulaErrorDiagnostics.samplesTruncated,
      // Backward-compatible sample alias. Consumers must use formulaErrorCount
      // for the detected total, never this bounded array's length.
      formulaErrors: formulaErrorDiagnostics.samples,
      sheetDiagnostics,
      formulasWithoutCachedValues,
      savedFormulaValuesComplete: formulaCount > 0 && formulasWithoutCachedValues === 0,
      calcMode: manifest.calcMode,
      calcModeAttribute: manifest.calcModeAttribute,
      calcModeRecognized: manifest.calcModeRecognized,
      calcModeBasis: manifest.calcModeBasis,
      externalLinks: externalLinks.length,
      externalFormulaCount,
      packageUncompressedBytes: packageMetrics.totalUncompressedBytes,
      largestPackageEntry: packageMetrics.largestEntry,
      mappedFacts,
      metadataReviewRequiredFacts,
      covenants,
      recalculatedConfirmed: false
    };
  }

  window.HBFWorkbook = {
    inspect,
    approvedSheets: APPROVED_SHEETS.slice(),
    profileSignatures: PROFILE_SIGNATURES.map((signature) => ({
      id: signature.id,
      sheet: signature.sheet,
      anchors: signature.anchors.map((anchor) => ({ address: anchor.address, labels: anchor.labels.slice() }))
    })),
    safetyLimits: {
      maxFileBytes: MAX_FILE_BYTES,
      maxZipEntries: MAX_ZIP_ENTRIES,
      maxZipEntryUncompressedBytes: MAX_ZIP_ENTRY_UNCOMPRESSED_BYTES,
      maxZipTotalUncompressedBytes: MAX_ZIP_TOTAL_UNCOMPRESSED_BYTES,
      maxSharedStringsXmlCharacters: MAX_SHARED_STRINGS_XML_CHARS,
      maxWorkbookXmlCharacters: MAX_WORKBOOK_XML_CHARS,
      maxSheetXmlCharacters: MAX_SHEET_XML_CHARS,
      maxCells: MAX_CELLS,
      maxFormulaErrorSamples: MAX_FORMULA_ERROR_SAMPLES
    },
    _test: {
      evaluateProfile,
      checkProfileSignatures,
      checkScaleProfiles,
      validateZipMetadata,
      extractAnchoredFacts,
      extractReviewRequiredFacts,
      extractCovenants,
      summarizeFormulaErrors,
      interpretCalcMode,
      parseXml
    }
  };
})();
