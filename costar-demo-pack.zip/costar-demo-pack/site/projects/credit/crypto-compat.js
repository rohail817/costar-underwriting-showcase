(function (g) {
  'use strict';
  // Keep native Web Crypto where available. The bundled SHA-256 implementation
  // supplies the same digest in local browser contexts without SubtleCrypto.
  function uuid() {
    if (typeof g.crypto?.randomUUID === 'function') return g.crypto.randomUUID();
    if (typeof g.crypto?.getRandomValues !== 'function') throw new Error('This browser cannot create a secure document identifier. Open the Studio in a current browser.');
    const bytes = g.crypto.getRandomValues(new Uint8Array(16));
    bytes[6] = (bytes[6] & 15) | 64;
    bytes[8] = (bytes[8] & 63) | 128;
    const h = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
    return h.slice(0, 8) + '-' + h.slice(8, 12) + '-' + h.slice(12, 16) + '-' + h.slice(16, 20) + '-' + h.slice(20);
  }
  async function sha256(value) {
    const bytes = typeof value === 'string' ? new TextEncoder().encode(value) : value;
    if (g.crypto?.subtle) return g.crypto.subtle.digest('SHA-256', bytes);
    if (typeof g.sha256?.arrayBuffer !== 'function') throw new Error('A cryptographic file check is unavailable. Your current draft is unchanged.');
    return g.sha256.arrayBuffer(bytes);
  }
  g.HBFCrypto = Object.freeze({uuid, sha256});
})(globalThis);
