(function () {
  "use strict";

  const APP_VERSION = "0.2.0";
  const EXPORTER_VERSION = "2.0";
  const STRESS_INPUT_PATHS = [
    "facility.proposedCommitment", "facility.outstanding", "facility.projectedPeak", "facility.proposedMaturity",
    "collateral.asCompleteValue", "project.totalCost", "project.remainingCosts", "project.modeledEligibleFutureAdvances",
    "project.committedEquity", "project.remainingContingencyAndInterest", "operating.planAbsorption",
    "operating.netPaydownPerClosing", "guarantor.availableLiquidityAfterCalls"
  ];
  const MEMO_SECTION_IDS = ["executive", "request", "relationship", "repayment", "financial", "performance", "project", "collateral", "downside", "market", "guarantor", "covenants", "rating", "exceptions", "risks", "conditions", "conclusion"];
  const WORKBOOK_SCOPE_EXPORT_LABELS = Object.freeze({
    relationship: "Bank exposure — Exposure",
    banking: "Bank group, deposits and debt — Bank Group; Deposits; Debt Listing",
    financial: "Borrower financial analysis — Balance Sheet; Income Statement; Net Income; Equity",
    operating: "Sales, closings and inventory — Heat Map; Revenue-Closings; Sales-Closings; Inventory; Active Subdivision; Project Inventory",
    facility: "Facility, collateral and borrowing base — RLOC; Unit Line Detail; Borrowing Base; Collateral Value; Curtailment",
    covenants: "Covenants — Covenant Tracking",
    downside: "Downside and sensitivity — Absorption Sensitivity; Sensitivity Analysis",
    project: "Project feasibility — A&D Sources & Uses; Dev Budget; Project Equity; Vertical Construction; Contract Analysis",
    guarantor: "Guarantor support — Guarantor Aggregation",
    market: "Market support — Market Snapshot"
  });
  const WORKBOOK_SCOPE_EXPORT_SHEETS = Object.freeze({
    relationship: Object.freeze(["Exposure"]),
    banking: Object.freeze(["Bank Group", "Deposits", "Debt Listing"]),
    financial: Object.freeze(["Balance Sheet", "Income Statement", "Net Income", "Equity"]),
    operating: Object.freeze(["Heat Map", "Revenue-Closings", "Sales-Closings", "Inventory-Units", "Inventory-Lots", "Active Subdivision", "Project Inventory"]),
    facility: Object.freeze(["RLOC", "Unit Line Detail", "Borrowing Base", "Collateral Value", "Curtailment"]),
    covenants: Object.freeze(["Covenant Tracking"]),
    downside: Object.freeze(["Absorption Sensitivity", "Sensitivity Analysis"]),
    project: Object.freeze(["A&D Sources & Uses", "Dev Budget", "Project Equity", "Vertical Construction", "Contract Analysis"]),
    guarantor: Object.freeze(["Guarantor Aggregation"]),
    market: Object.freeze(["Market Snapshot"])
  });
  const DEMO_SECTION_EVIDENCE = {
    executive: ["F003", "F004", "F005", "F006"], request: ["F003", "F004", "F009", "F011"], relationship: ["F005", "F006", "F007"], repayment: ["F009", "F024", "F025", "F039"], financial: ["F030", "F031", "F032", "F034", "F036", "F037"], performance: ["F020", "F022", "F023", "F027", "F028", "F029"], project: ["F016", "F017", "F018", "F019"], collateral: ["F014", "F015", "F005"], downside: ["F009", "F025", "F039"], market: ["F041", "F042", "F043"], guarantor: ["F038", "F039", "F040"], covenants: ["F034", "F035", "F036", "F044", "F045", "F046"], rating: ["F012", "F013", "F036"], risks: ["F024", "F029", "F036", "F039"], conditions: ["F004", "F018", "F038"], conclusion: ["F006", "F009", "F014", "F016", "F017"]
  };

  function clean(value) {
    return String(value == null ? "" : value)
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, "")
      .slice(0, 12000);
  }

  function isMonitorWorkflow(state) {
    return state?.workflow === "portfolio_monitor" || state?.deal?.dealType === "Quarterly Monitor";
  }

  function workflowCompletionLabel(state, uppercase) {
    const label = isMonitorWorkflow(state) ? "Review Package Complete" : "Review Ready";
    return uppercase ? label.toUpperCase() : label;
  }

  function executiveExcerpt(value, limit, fallback) {
    const suffix = "… [Full text retained in credit review pack]";
    const source = clean(value) || clean(fallback || "Not provided");
    if (!Number.isFinite(Number(limit)) || source.length <= Number(limit)) return source;
    const available = Math.max(40, Number(limit) - suffix.length);
    const candidate = source.slice(0, available);
    const boundary = candidate.lastIndexOf(" ");
    const body = boundary >= Math.floor(available * 0.65) ? candidate.slice(0, boundary) : candidate;
    return `${body.trimEnd()}${suffix}`;
  }

  function executiveLabel(value, limit, fallback) {
    const source = clean(value) || clean(fallback || "Not provided");
    if (!Number.isFinite(Number(limit)) || source.length <= Number(limit)) return source;
    const available = Math.max(12, Number(limit) - 1);
    const candidate = source.slice(0, available);
    const boundary = candidate.lastIndexOf(" ");
    const body = boundary >= Math.floor(available * 0.65) ? candidate.slice(0, boundary) : candidate;
    return `${body.trimEnd()}…`;
  }

  function shortFileDigest(value) {
    let primary = 0x811c9dc5;
    let secondary = 0x9e3779b9;
    for (let index = 0; index < value.length; index += 1) {
      const code = value.charCodeAt(index);
      primary = Math.imul(primary ^ code, 0x01000193);
      secondary = Math.imul(secondary ^ (code + index), 0x85ebca6b);
      secondary ^= secondary >>> 13;
    }
    return `${(primary >>> 0).toString(16).padStart(8, "0")}${(secondary >>> 0).toString(16).padStart(8, "0")}`.slice(0, 12);
  }

  function safeFileName(value) {
    const normalized = clean(value).replace(/[^a-z0-9._-]+/gi, "-").replace(/^-+|-+$/g, "") || "HBF-Credit-Memo";
    if (normalized.length <= 72) return normalized;
    const extensionMatch = normalized.match(/(\.[a-z0-9]{1,10})$/i);
    const extension = extensionMatch ? extensionMatch[1] : "";
    const stem = extension ? normalized.slice(0, -extension.length) : normalized;
    const stemLimit = Math.max(1, 72 - extension.length);
    const digest = shortFileDigest(stem);
    const tailLength = Math.min(34, Math.max(24, Math.floor(stemLimit * 0.48)));
    const headLength = Math.max(1, stemLimit - tailLength - digest.length - 2);
    const head = stem.slice(0, headLength).replace(/[-._]+$/g, "");
    const tail = stem.slice(-tailLength).replace(/^[-._]+/g, "");
    return `${head}-${digest}-${tail}${extension}`.slice(0, 72);
  }

  function normalizeState(input) {
    const state = input && typeof input === "object" && !Array.isArray(input) ? input : {};
    return {
      ...state,
      deal: state.deal && typeof state.deal === "object" && !Array.isArray(state.deal) ? state.deal : {},
      sources: Array.isArray(state.sources) ? state.sources.filter(Boolean) : [],
      facts: Array.isArray(state.facts) ? state.facts.filter(Boolean) : [],
      calculations: Array.isArray(state.calculations) ? state.calculations.filter(Boolean) : [],
      conflicts: Array.isArray(state.conflicts) ? state.conflicts.filter(Boolean) : [],
      issues: Array.isArray(state.issues) ? state.issues.filter(Boolean) : [],
      covenants: Array.isArray(state.covenants) ? state.covenants.filter(Boolean) : [],
      changes: Array.isArray(state.changes) ? state.changes.filter(Boolean) : [],
      risks: Array.isArray(state.risks) ? state.risks.filter(Boolean) : [],
      conditions: Array.isArray(state.conditions) ? state.conditions.filter(Boolean) : [],
      memoSections: Array.isArray(state.memoSections) ? state.memoSections.filter(Boolean) : [],
      actions: Array.isArray(state.actions) ? state.actions.filter(Boolean) : [],
      monitor: state.monitor && typeof state.monitor === "object" && !Array.isArray(state.monitor) ? state.monitor : null,
      attestations: state.attestations && typeof state.attestations === "object" && !Array.isArray(state.attestations) ? state.attestations : {},
      workbook: state.workbook && typeof state.workbook === "object" && !Array.isArray(state.workbook) ? state.workbook : {}
    };
  }

  function canonicalJson(value) {
    if (Array.isArray(value)) return `[${value.map((item) => canonicalJson(item)).join(",")}]`;
    if (value && typeof value === "object") {
      return `{${Object.keys(value).filter((key) => value[key] !== undefined).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`;
    }
    return JSON.stringify(value);
  }

  async function digestCanonical(value) {
    const text = canonicalJson(value);
    if ((!window.crypto?.subtle && !window.HBFCrypto) || typeof TextEncoder === "undefined") throw new Error("A cryptographic file check is required to freeze or verify an export snapshot.");
    const digest = window.HBFCrypto ? await window.HBFCrypto.sha256(text) : await window.crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  async function freezeExportSnapshot(input) {
    const state = normalizeState(JSON.parse(JSON.stringify(input || {})));
    const generatedAt = new Date().toISOString();
    const digest = await digestCanonical(state);
    return {
      state,
      generatedAt,
      digest,
      snapshotId: `${clean(state.deal.id || state.monitor?.reviewId || "HBF").replace(/[^A-Za-z0-9_-]/g, "-").slice(0, 24)}-${digest.slice(0, 12)}`,
      applicationVersion: APP_VERSION,
      exporterVersion: EXPORTER_VERSION
    };
  }

  function unresolvedConflicts(state) {
    return (state && Array.isArray(state.conflicts) ? state.conflicts : [])
      .filter((conflict) => conflict && (!conflict.status || conflict.status === "open"));
  }

  function validIsoDate(value) {
    if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const date = new Date(`${value}T00:00:00Z`);
    return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
  }

  function dayDifference(start, end) {
    if (!validIsoDate(start) || !validIsoDate(end)) return null;
    return Math.round((Date.parse(`${end}T00:00:00Z`) - Date.parse(`${start}T00:00:00Z`)) / 86400000);
  }

  function verifiedMaturityDays(monitor) {
    return dayDifference(monitor?.reviewAsOfDate, monitor?.facility?.lineMaturity);
  }

  function normalizedStatus(value) {
    return clean(value).trim().toLowerCase().replace(/[\s_-]+/g, " ");
  }

  function monitorActionIsTerminal(action) {
    return ["completed", "closed", "cancelled"].includes(normalizedStatus(action?.status));
  }

  function monitorActionIsCancelled(action) {
    return normalizedStatus(action?.status) === "cancelled";
  }

  function completeMonitorAction(action) {
    return Boolean(action && clean(action.action).length >= 20 && clean(action.owner).length >= 2 && validIsoDate(action.dueDate) && clean(action.evidence).length >= 5 && !monitorActionIsCancelled(action));
  }

  function covenantIsException(item) {
    return item?.reportedOutcome === "Noncompliant" || item?.computedStatus === "Noncompliant";
  }

  function covenantRequiresReview(item) {
    if (covenantIsException(item) || item?.comparable === false) return true;
    if (item?.reportedOutcome) return item.reportedOutcome !== "Compliant";
    return !/^(?:compliant|pass|passed)$/i.test(clean(item?.status));
  }

  function confirmedCovenantBreach(item) {
    return Boolean(item && item.comparable !== false && item.reportedOutcome === "Noncompliant" && item.computedStatus === "Noncompliant" && item.outcomeMismatch !== true);
  }

  function covenantResultLabel(item) {
    const reported = item?.reportedOutcome || item?.sourceStatus || item?.status || "Review required";
    const computed = item?.computedStatus || (item?.comparable === false ? "Review required" : item?.status || "Review required");
    if (item?.outcomeMismatch) return `MISMATCH — reported ${reported}; computed ${computed}`;
    if (item?.comparable === false) return `Review required — values not comparable; reported ${reported}`;
    return reported === computed ? clean(reported) : `${reported} / ${computed}`;
  }

  function seriesAtOrBefore(series, cutoff) {
    return (Array.isArray(series) ? series : []).filter((item) => item?.periodEnd && (!cutoff || item.periodEnd <= cutoff)).sort((a, b) => clean(a.periodEnd).localeCompare(clean(b.periodEnd)));
  }

  function latestAtOrBefore(series, cutoff) {
    return seriesAtOrBefore(series, cutoff).slice(-1)[0] || null;
  }

  function monitorFactValueMatches(actual, expected) {
    if (typeof expected === "number" && Number.isFinite(expected)) return Number.isFinite(Number(actual)) && Math.abs(Number(actual) - expected) <= Math.max(1e-8, Math.abs(expected) * 1e-9);
    return clean(actual) === clean(expected);
  }

  function comparablePriorYear(current, prior) {
    if (!validIsoDate(current?.periodEnd) || !validIsoDate(prior?.periodEnd)) return false;
    const currentDate = new Date(`${current.periodEnd}T00:00:00Z`);
    const priorDate = new Date(`${prior.periodEnd}T00:00:00Z`);
    return currentDate.getUTCFullYear() - priorDate.getUTCFullYear() === 1 && currentDate.getUTCMonth() === priorDate.getUTCMonth() && currentDate.getUTCDate() === priorDate.getUTCDate();
  }

  function relativeChange(current, prior) {
    return Number.isFinite(Number(current)) && Number.isFinite(Number(prior)) && Number(prior) !== 0 ? (Number(current) - Number(prior)) / Math.abs(Number(prior)) : null;
  }

  function monitorReadinessControls(state) {
    const monitor = state.monitor;
    if (!monitor) return false;
    const reviewDate = monitor.reviewAsOfDate;
    const sourceDatesValid = validIsoDate(reviewDate) && monitor.reviewDateBasis === "user_explicit" &&
      validIsoDate(monitor.financialPeriodEnd) && validIsoDate(monitor.inventoryPeriodEnd) &&
      monitor.financialPeriodEnd <= reviewDate && monitor.inventoryPeriodEnd <= reviewDate;
    const latestBank = latestAtOrBefore(monitor.bankingSeries, reviewDate);
    const bankingValid = Boolean(latestBank && validIsoDate(latestBank.periodEnd) && latestBank.periodEnd <= reviewDate);
    const latestQuarter = latestAtOrBefore(monitor.financial?.quarterly, monitor.financialPeriodEnd);
    const balance = latestAtOrBefore(monitor.balanceSheets, monitor.financialPeriodEnd);
    const inventory = latestAtOrBefore(monitor.inventorySeries, monitor.inventoryPeriodEnd);
    const monitorFacts = (state.facts || []).filter((fact) => fact.sourceId === monitor.workbookSourceId);
    const acceptedMonitorFacts = monitorFacts.filter((fact) => ["accepted", "supported"].includes(fact.status));
    const monitorSource = (state.sources || []).find((source) => source.id === monitor.workbookSourceId && source.status !== "superseded");
    const sourceBound = Boolean(monitorSource && (state.mode === "demo" || (state.monitorWorkbook?.loaded && state.monitorWorkbook.sourceId === monitor.workbookSourceId && state.monitorWorkbook.digest && monitorSource.fingerprint === state.monitorWorkbook.digest)));
    const rejectedMonitorFacts = monitorFacts.filter((fact) => fact.status === "rejected");
    const materialFacts = [
      ["borrower.legalName", reviewDate, monitor.identity?.borrower],
      ["credit.currentRiskRating", reviewDate, monitor.rating?.current],
      ["facility.lineMaturity", reviewDate, monitor.facility?.lineMaturity],
      ["facility.grossCommitment", latestBank?.periodEnd, latestBank?.grossCommitment],
      ["relationship.outstanding", latestBank?.periodEnd, latestBank?.outstanding],
      ["relationship.averageDeposits", latestBank?.periodEnd, latestBank?.deposits],
      ["financial.revenueQuarter", latestQuarter?.periodEnd, latestQuarter?.revenue],
      ["financial.netIncomeQuarter", latestQuarter?.periodEnd, latestQuarter?.netIncome],
      ["operating.closingsQuarter", latestQuarter?.periodEnd, latestQuarter?.closings],
      ["financial.totalAssets", balance?.periodEnd, balance?.totalAssets],
      ["financial.totalLiabilities", balance?.periodEnd, balance?.totalLiabilities],
      ["financial.reportedTangibleNetWorth", balance?.periodEnd, balance?.tangibleNetWorth],
      ["inventory.totalUnits", inventory?.periodEnd, inventory?.totalUnits],
      ["inventory.lotsOwnedControlled", inventory?.periodEnd, inventory?.lotsOwnedControlled]
    ];
    const materialCoverage = state.mode === "demo" ? acceptedMonitorFacts.length >= 3 : materialFacts.every(([path, asOfDate, value]) => value != null && acceptedMonitorFacts.some((fact) => fact.controlling === true && fact.path === path && fact.asOfDate === asOfDate && monitorFactValueMatches(fact.value, value)));
    const factsReviewed = Boolean(monitor.reviewed) && monitorFacts.length >= 3 && materialCoverage && rejectedMonitorFacts.length === 0 && monitorFacts.every((fact) => ["accepted", "supported", "superseded"].includes(fact.status));
    const blockingAnomalies = (monitor.anomalies || []).filter((item) => item.severity === "blocker" && item.status !== "resolved");
    const reportingExceptionsAddressed = (monitor.reportingItems || []).filter((item) => ["Past due", "Review required"].includes(item.status)).every((item) => (monitor.actions || []).some((action) =>
      action.reportingItemId === item.id && completeMonitorAction(action)
    ));
    const reportingDatesValid = (monitor.reportingItems || []).every((item) => !item.lastReceivedPeriodEnd || validIsoDate(item.lastReceivedPeriodEnd) && item.lastReceivedPeriodEnd <= reviewDate);
    const covenantReviewItems = (monitor.covenants || []).filter(covenantRequiresReview);
    const covenantActionsReady = covenantReviewItems.every((item) => (monitor.actions || []).some((action) => action.covenantId === item.id && completeMonitorAction(action)));
    const covenantsValid = (monitor.covenants || []).length > 0 && (monitor.covenants || []).every((item) =>
      item.name && validIsoDate(item.testDate) && item.testDate <= reviewDate && item.threshold != null && item.actual != null && item.status && item.reportedOutcome !== "Review required" && !item.outcomeMismatch && (item.comparable !== false || monitor.covenantReviewConfirmed)
    ) && covenantActionsReady;
    const crossFootDisposition = (monitor.actions || []).some((action) => action.relatedControlId === "balance_crossfoot" && completeMonitorAction(action));
    const balanceValid = Boolean(balance && balance.crossFootDifference != null && (Math.abs(Number(balance.crossFootDifference)) < 1 || crossFootDisposition));
    const judgment = [monitor.assessment, monitor.conclusion, monitor.ratingRationale, monitor.rating?.current, monitor.rating?.recommended].map((value) => clean(value));
    const judgmentValid = judgment[0].length >= 12 && judgment[1].length >= 80 && judgment[2].length >= 50 && judgment[3].length >= 1 && judgment[4].length >= 1 &&
      !judgment.some((value) => /(?:\brequired\b|\btbd\b|not entered|#(?:n\/a|ref!|value!|div\/0!|name\?|num!))/i.test(value));
    const maturityDays = verifiedMaturityDays(monitor);
    const maturityCalc = (monitor.calculations || []).find((item) => item.id === "MON-MAT-001");
    const maturityStatus = maturityDays == null ? "review" : maturityDays < 365 ? "watch" : "pass";
    const maturityCalculationValid = maturityDays != null && Number(maturityCalc?.result) === maturityDays && normalizedStatus(maturityCalc?.status) === maturityStatus;
    const expiredMaturityAddressed = maturityDays == null || maturityDays >= 0 || (monitor.actions || []).some((action) => action.relatedControlId === "line_maturity" && completeMonitorAction(action));
    const coreDataValid = Boolean(monitor.identity?.borrower && monitor.identity?.obligorNumber && monitor.facility?.type && monitor.facility?.grossCommitment != null && validIsoDate(monitor.facility?.lineMaturity) && latestBank?.outstanding != null && latestQuarter?.periodEnd && latestQuarter.revenue != null && latestQuarter.netIncome != null);
    return Boolean(monitor.profileMatched && sourceBound && sourceDatesValid && bankingValid && coreDataValid && maturityCalculationValid && expiredMaturityAddressed && factsReviewed && monitor.anomalyDispositionReviewed && !blockingAnomalies.length && monitor.reportingReviewed && reportingDatesValid && reportingExceptionsAddressed && monitor.covenantReviewConfirmed && covenantsValid && balanceValid && judgmentValid);
  }

  function creditReadinessDiagnostics(state) {
    const currentFacts = (state.facts || []).filter((fact) => fact?.status !== "superseded");
    const factsResolved = currentFacts.every((fact) => ["supported", "accepted", "rejected"].includes(fact.status));
    const accepted = currentFacts.filter((fact) => ["supported", "accepted"].includes(fact.status));
    const factLineage = accepted.length > 0 && accepted.every((fact) => factEntityAndSourceValid(state, fact));
    const controllingFactsValid = !controllingAmbiguities(state);
    const formulaErrors = workbookFormulaErrorTotal(state.workbook || {});
    const formulaReview = formulaErrors === 0 || Boolean(state.workbook?.formulaErrorsReviewed && state.workbook?.formulaErrorReviewConfirmed && Number(state.workbook?.formulaErrorReviewCount) === formulaErrors && clean(state.workbook?.errorReviewNote).length >= 80);
    const scopeMatches = exactWorkbookScopeMatches(state);
    const workbookValid = state.mode === "demo"
      ? Boolean(state.workbook?.loaded && !state.workbook?.scopeChangedAfterImport && state.workbook?.profileMatched && state.workbook?.reviewedAsNonDealEvidence && state.workbook?.formulaErrorsReviewed && clean(state.workbook?.errorReviewNote).length >= 80)
      : Boolean(state.workbookScopeConfirmed === true && state.workbook?.loaded && !state.workbook?.scopeChangedAfterImport && scopeMatches && state.workbook?.profileMatched && state.workbook?.recalculatedConfirmed && formulaReview);
    const sections = state.memoSections || [];
    const sectionIds = new Set(sections.map((section) => section?.id));
    const narrativesValid = sections.length === MEMO_SECTION_IDS.length && sectionIds.size === MEMO_SECTION_IDS.length && MEMO_SECTION_IDS.every((id) => sectionIds.has(id)) && sections.every((section) => clean(section.narrative).length >= 60 && !/(?:\bTBD\b|\bXX+\b|\binsert\b|choose an item|#(?:N\/A|REF!|VALUE!|DIV\/0!|NAME\?|NUM!))/i.test(section.narrative || ""));
    const narrativeGroundingValid = sections.every((section) => memoSectionGrounded(state, section));
    const primaryRepaymentValid = sections.some((section) => section.id === "repayment" && clean(section.narrative).length > 80);
    const stressValid = Boolean(state.stressReviewed && state.scenarioResults?.status === "computed" && state.scenarioResults?.inputFingerprint === stressInputFingerprint(state) && scenarioCalculationLedgerMatches(state));
    const currentRisks = currentRecords(state.risks);
    const currentChanges = currentRecords(state.changes);
    const currentCovenants = currentRecords(state.covenants);
    const risksValid = currentRisks.length > 0 && currentRisks.every((risk) => [risk.evidence, risk.consequence, risk.mitigant, risk.residual, risk.condition].every((value) => Boolean(clean(value))) && governedRecordEvidenceValid(state, risk));
    const changesRequired = ["Renewal", "Modification"].includes(state.deal?.dealType);
    const changesValid = (!changesRequired || currentChanges.length > 0) && currentChanges.every((change) => [change.field, change.prior, change.current, change.proposed, change.impact].every((value) => Boolean(clean(value))) && governedRecordEvidenceValid(state, change) && (state.mode === "demo" || clean(change.evidenceNote).length >= 8));
    const covenantScopeSelected = Array.isArray(state.workbookTabs) ? state.workbookTabs.includes("Covenant Tracking") : !Array.isArray(state.workbookScope) || state.workbookScope.includes("covenants");
    const covenantRowsValid = currentCovenants.length > 0 && currentCovenants.every((covenant) => [covenant.name, covenant.threshold, covenant.actual, covenant.headroom, covenant.trend, covenant.status].every((value) => Boolean(clean(value))) && governedRecordEvidenceValid(state, covenant) && (state.mode === "demo" || registeredEntity(state, covenant.entity) && validIsoDate(covenant.asOfDate) && clean(covenant.evidenceNote).length >= 8));
    const covenantsValid = covenantRowsValid || (!covenantScopeSelected && currentCovenants.length === 0);
    const conditionsValid = (state.conditions || []).length > 0 && state.conditions.every((condition) => [condition.phase, condition.requirement, condition.purpose, condition.owner, condition.verification].every((value) => Boolean(clean(value))));
    const recordsValid = risksValid && changesValid && covenantsValid && conditionsValid;
    const documentPlan = typeof window !== "undefined" && window.HBF_CreditPath?.documentPlan ? window.HBF_CreditPath.documentPlan(state) : null;
    const requiredDocuments = Array.isArray(documentPlan) ? documentPlan.filter((item) => item.required) : [];
    const documentsValid = state.mode === "demo" || !Array.isArray(documentPlan) || requiredDocuments.length > 0 && requiredDocuments.every((item) => item.complete);
    const applicability = state.applicability || [];
    const applicabilityValid = applicability.length > 0 && applicability.every((item) => ["ready", "not_applicable"].includes(item.status) && !(item.kind === "core" && item.status !== "ready") && clean(item.basis).length >= 8) && (state.deal?.dealType !== "Modification" || applicability.some((item) => item.id === "modification" && item.status === "ready"));
    const decisionText = [state.deal?.request, state.deal?.recommendation, state.deal?.proposedRating].map(clean);
    const decisionValid = decisionText.every((value) => value && !/(?:\brequired\b|\btbd\b|not entered|not defined|#(?:N\/A|REF!|VALUE!|DIV\/0!|NAME\?|NUM!))/i.test(value));
    const ratingFact = factByPath(state, "credit.proposedRiskRating");
    const ratingValid = Boolean(ratingFact && clean(ratingFact.value) === clean(state.deal?.proposedRating) && ratingFact.provenance === "analyst_judgment");
    const narrativesCurrent = !state.staleNarrativeReviewRequired;
    const ready = Boolean(documentsValid && workbookValid && factsResolved && factLineage && controllingFactsValid && narrativesValid && narrativeGroundingValid && primaryRepaymentValid && stressValid && recordsValid && applicabilityValid && decisionValid && ratingValid && narrativesCurrent);
    return { ready, documentsValid, workbookValid, workbookScopeConfirmed: state.mode === "demo" || state.workbookScopeConfirmed === true, scopeMatches, factsResolved, factLineage, controllingFactsValid, narrativesValid, narrativeGroundingValid, primaryRepaymentValid, stressValid, recordsValid, risksValid, changesValid, covenantsValid, covenantScopeSelected, conditionsValid, applicabilityValid, decisionValid, ratingValid, narrativesCurrent };
  }

  function creditReadinessControls(state) {
    return creditReadinessDiagnostics(state).ready;
  }

  function stressInputFingerprint(state) {
    const facts = STRESS_INPUT_PATHS.map((path) => {
      const fact = factByPath(state, path);
      return fact ? [path, fact.id, fact.value, fact.unit || "", fact.scale || 1, fact.entity || "", fact.asOfDate || "", fact.periodType || "", fact.scenario || "actual"] : [path, null];
    });
    return JSON.stringify({ facts, dealAsOfDate: state.deal?.asOfDate || "", assumptions: state.stress || {}, ruleVersion: "HBF-STRESS-1.1" });
  }

  function scenarioCalculationLedgerMatches(state) {
    const scenario = state?.scenarioResults;
    const inputs = scenario?.inputs;
    if (scenario?.status !== "computed" || !inputs || typeof inputs !== "object") return false;
    const expected = new Map([
      ["CALC02", inputs.collateral > 0 ? inputs.proposed / inputs.collateral : NaN],
      ["CALC03", inputs.totalCost > 0 ? inputs.proposed / inputs.totalCost : NaN],
      ["CALC04", scenario.completionCushion],
      ["CALC06", scenario.baseRunway],
      ["CALC07", scenario.maturityRunway],
      ["CALC09", scenario.sponsorNeed],
      ["CALC10", scenario.supportCoverage],
      ["CALC11", scenario.maturityBalloon],
      ["CALC12", scenario.incrementalInterest]
    ]);
    const sameNumber = (actual, expectedValue) => {
      if (expectedValue == null) return actual == null;
      const left = Number(actual);
      const right = Number(expectedValue);
      return Number.isFinite(left) && Number.isFinite(right) && Math.abs(left - right) <= Math.max(1e-8, Math.abs(right) * 1e-9);
    };
    return Array.from(expected).every(([id, expectedValue]) => sameNumber((state.calculations || []).find((item) => item.id === id)?.result, expectedValue));
  }

  function currentRecords(records) {
    return (Array.isArray(records) ? records : []).filter((record) => record && record.recordStatus !== "superseded");
  }

  function recordState(record) {
    if (record && record.recordStatus === "superseded") {
      const when = record.supersededAt ? ` ${record.supersededAt}` : "";
      const reason = record.evidenceSupersededReason ? ` — ${record.evidenceSupersededReason}` : "";
      return `SUPERSEDED${when}${reason}`;
    }
    return "CURRENT";
  }

  function evidenceIds(record) {
    const ids = Array.isArray(record && record.sourceFactIds)
      ? record.sourceFactIds
      : record && record.sourceFactId
        ? [record.sourceFactId]
        : [];
    return ids.length ? ids.join(", ") : (record && (record.sourceId || record.evidenceNote)) || "PM judgment / not stated";
  }

  function evaluateReadiness(state) {
    const current = normalizeState(state);
    const openBlockers = current.issues.filter((issue) => issue.status === "open" && issue.severity === "blocker");
    const conflicts = unresolvedConflicts(current);
    const attestations = current.attestations;
    const requiredAttestations = ["facts", "calculations", "judgment", "rating"];
    const extraIncomplete = Object.entries(attestations).some(([name, value]) => !requiredAttestations.includes(name) && typeof value === "boolean" && value !== true);
    const revisionValid = Number.isSafeInteger(current.contentRevision) && current.contentRevision >= 0;
    const allAttested = revisionValid && !extraIncomplete && requiredAttestations.every((name) => attestations[name] === true &&
      current.attestationMetadata?.[name]?.revision === current.contentRevision);
    const isMonitor = current.workflow === "portfolio_monitor" || current.deal.dealType === "Quarterly Monitor";
    const monitorBlockers = isMonitor && current.monitor ? (current.monitor.anomalies || []).filter((item) => item.severity === "blocker" && item.status !== "resolved") : [];
    const monitorControls = !isMonitor || monitorReadinessControls(current);
    const creditDiagnostics = isMonitor ? { ready: true } : creditReadinessDiagnostics(current);
    const creditControls = creditDiagnostics.ready;
    return {
      ready: !current.authoring && Boolean(current.finalized) && openBlockers.length === 0 && conflicts.length === 0 && allAttested && monitorControls && creditControls,
      openBlockers,
      conflicts,
      allAttested,
      monitorControls,
      creditControls,
      creditDiagnostics,
      monitorBlockers
    };
  }

  function isReviewReady(state) {
    return evaluateReadiness(state).ready;
  }

  function money(value) {
    if (value == null || value === "") return "—";
    if (!Number.isFinite(Number(value))) return "—";
    const number = Number(value);
    const absolute = Math.abs(number);
    if (absolute >= 1000000) return `${number < 0 ? "(" : ""}$${(absolute / 1000000).toFixed(1)}MM${number < 0 ? ")" : ""}`;
    if (absolute >= 1000) return `${number < 0 ? "(" : ""}$${(absolute / 1000).toLocaleString("en-US", { maximumFractionDigits: 1 })}K${number < 0 ? ")" : ""}`;
    return number.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
  }

  function factScopeKey(fact) {
    const item = fact || {};
    return [item.entity || "", item.path || "", item.periodType || "as_of", item.asOfDate || "", item.scenario || "actual", item.unit || ""].join("|").toLowerCase();
  }

  function eligibleFacts(state, path, scope) {
    const filter = scope || {};
    return (state && Array.isArray(state.facts) ? state.facts : []).filter((fact) =>
      fact && fact.path === path && ["accepted", "supported"].includes(fact.status) &&
      (!filter.entity || clean(fact.entity).toLowerCase() === clean(filter.entity).toLowerCase()) &&
      (!filter.periodType || (fact.periodType || "as_of") === filter.periodType) &&
      (!filter.asOfDate || fact.asOfDate === filter.asOfDate) &&
      (!filter.scenario || (fact.scenario || "actual") === filter.scenario) &&
      (!filter.unit || (fact.unit || "") === filter.unit)
    );
  }

  function factByPath(state, path, scope) {
    const filter = scope || {};
    const eligible = (state && Array.isArray(state.facts) ? state.facts : []).filter((fact) =>
      fact && fact.path === path && ["accepted", "supported"].includes(fact.status) &&
      (!filter.entity || String(fact.entity || "").trim().toLowerCase() === String(filter.entity || "").trim().toLowerCase()) &&
      (!filter.periodType || (fact.periodType || "as_of") === filter.periodType) &&
      (!filter.asOfDate || fact.asOfDate === filter.asOfDate) &&
      (!filter.scenario || (fact.scenario || "actual") === filter.scenario) &&
      (!filter.unit || (fact.unit || "") === filter.unit)
    );
    if (!eligible.length) return null;
    if (scope && Object.keys(scope).length) {
      const explicit = eligible.filter((fact) => fact.controlling === true);
      if (explicit.length === 1) return explicit[0];
      return explicit.length > 1 || eligible.length > 1 ? null : eligible[0];
    }
    const explicit = eligible.filter((fact) => fact.controlling === true);
    if (!explicit.length) return eligible.length === 1 ? eligible[0] : null;
    const latestDate = explicit.map((fact) => fact.asOfDate || "").sort().slice(-1)[0];
    const latest = explicit.filter((fact) => (fact.asOfDate || "") === latestDate);
    return latest.length === 1 ? latest[0] : null;
  }

  function parseFactReferences(value) {
    const source = Array.isArray(value) ? value : String(value || "").split(/[,;\s]+/);
    return Array.from(new Set(source.map((item) => clean(item).trim()).filter(Boolean)));
  }

  function registeredEntity(state, value) {
    const normalized = clean(value).trim().replace(/\s+/g, " ").toLowerCase();
    return Boolean(normalized && (state.entities || []).some((entity) => clean(entity?.name).trim().replace(/\s+/g, " ").toLowerCase() === normalized));
  }

  function factEntityAndSourceValid(state, fact) {
    if (!fact) return false;
    if (fact.provenance === "analyst_judgment" || state.mode === "demo") return Boolean(clean(fact.locator));
    const source = (state.sources || []).find((item) => item.id === fact.sourceId && item.status !== "superseded");
    return Boolean(source && registeredEntity(state, fact.entity) && clean(fact.locator));
  }

  function controllingFactReference(state, id) {
    const fact = (state.facts || []).find((item) => item.id === id && ["accepted", "supported"].includes(item.status));
    if (!fact || !factEntityAndSourceValid(state, fact)) return null;
    const controlling = factByPath(state, fact.path, { entity: fact.entity, periodType: fact.periodType || "as_of", asOfDate: fact.asOfDate, scenario: fact.scenario || "actual", unit: fact.unit || "" });
    return controlling?.id === fact.id ? fact : null;
  }

  function controllingAmbiguities(state) {
    const groups = new Map();
    (state.facts || []).filter((fact) => ["accepted", "supported"].includes(fact.status)).forEach((fact) => {
      const key = factScopeKey(fact);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(fact);
    });
    return Array.from(groups.values()).some((facts) => facts.length > 1 && facts.filter((fact) => fact.controlling === true).length !== 1);
  }

  function governedRecordEvidenceValid(state, record) {
    if (!record || record.recordStatus === "superseded") return false;
    const ids = parseFactReferences(record.sourceFactIds || record.sourceFactId || "");
    if (ids.length) return ids.every((id) => Boolean(controllingFactReference(state, id)));
    if (record.evidenceClassification === "workbook_observation") {
      const source = (state.sources || []).find((item) => item.id === record.sourceId && item.status !== "superseded");
      return Boolean(source && state.workbook?.sourceId === record.sourceId && record.actualLocator && record.thresholdLocator && record.reviewedAt);
    }
    if (record.evidenceClassification === "pm_judgment") return true;
    return state.mode === "demo";
  }

  function memoSectionEvidence(state, section) {
    const explicitIds = parseFactReferences(section?.supportingFactIds || "");
    const candidateIds = explicitIds.length ? explicitIds : state.mode === "demo" ? (DEMO_SECTION_EVIDENCE[section?.id] || []) : [];
    const resolved = candidateIds.filter((id) => Boolean(controllingFactReference(state, id)) || state.mode === "demo" && (state.facts || []).some((fact) => fact.id === id && ["accepted", "supported"].includes(fact.status)));
    const unresolved = candidateIds.filter((id) => !resolved.includes(id));
    const classification = section?.aiDraftStaged
      ? "AI draft — PM review required"
      : section?.classification === "pm_judgment"
        ? "PM judgment"
        : section?.classification === "deterministic_calculation"
          ? "Deterministic calculation"
          : resolved.length && !unresolved.length
            ? "Accepted-fact grounded"
            : "Basis not recorded — review required";
    const shown = candidateIds.slice(0, 8);
    const keys = shown.length ? `${shown.join(", ")}${candidateIds.length > shown.length ? ` (+${candidateIds.length - shown.length} more)` : ""}${unresolved.length ? `; unresolved: ${unresolved.join(", ")}` : ""}` : "None recorded";
    return { ids: candidateIds, resolved, unresolved, classification, label: `Evidence keys: ${keys} • Classification: ${classification}` };
  }

  function memoSectionGrounded(state, section) {
    if (state.mode === "demo") return !section?.aiDraftStaged;
    if (section?.aiDraftStaged) return false;
    if (section?.classification === "pm_judgment") return true;
    const evidence = memoSectionEvidence(state, section);
    return evidence.ids.length > 0 && evidence.unresolved.length === 0;
  }

  function workbookFormulaErrorTotal(workbook) {
    if (Number.isFinite(Number(workbook?.applicableFormulaErrorCount)) && Number(workbook.applicableFormulaErrorCount) >= 0) return Number(workbook.applicableFormulaErrorCount);
    const samples = Array.isArray(workbook?.formulaErrorSamples) ? workbook.formulaErrorSamples : Array.isArray(workbook?.formulaErrors) ? workbook.formulaErrors : [];
    const counts = [workbook?.formulaErrorCount, workbook?.formulaWarnings, samples.length].map(Number).filter((value) => Number.isFinite(value) && value >= 0);
    return counts.length ? Math.max(...counts) : 0;
  }

  function exactWorkbookScopeMatches(state) {
    const workbook = state?.workbook || {};
    if (!workbook.loaded) return false;
    const allIds = Object.keys(WORKBOOK_SCOPE_EXPORT_SHEETS);
    const allSheets = allIds.flatMap((id) => WORKBOOK_SCOPE_EXPORT_SHEETS[id]);
    const allowed = new Set(allSheets);
    const expandGroups = (ids) => allIds.flatMap((id) => (ids || []).includes(id) ? WORKBOOK_SCOPE_EXPORT_SHEETS[id] : []);
    const current = Array.isArray(state?.workbookTabs)
      ? state.workbookTabs.filter((sheet) => allowed.has(sheet))
      : expandGroups(Array.isArray(state?.workbookScope) ? state.workbookScope : []);
    if (Array.isArray(workbook.tabNames) && (!workbook.tabNames.includes("Exposure") || workbook.tabNames.some((sheet) => !allowed.has(sheet)))) return false;
    const imported = Array.isArray(workbook.tabNames)
      ? workbook.tabNames.slice()
      : Array.isArray(workbook.scopeIds)
        ? expandGroups(workbook.scopeIds)
        : state?.mode === "demo" ? allSheets : null;
    if (!imported) return false;
    const currentKey = Array.from(new Set(["Exposure", ...current])).sort().join("|");
    const importedKey = Array.from(new Set(imported)).sort().join("|");
    return Boolean(currentKey && currentKey === importedKey);
  }

  function underwritingScopeRows(state) {
    const workbook = state?.workbook || {};
    const allIds = Object.keys(WORKBOOK_SCOPE_EXPORT_LABELS);
    const allSheets = allIds.flatMap((id) => WORKBOOK_SCOPE_EXPORT_SHEETS[id]);
    const expandGroups = (ids) => allIds.flatMap((id) => (ids || []).includes(id) ? WORKBOOK_SCOPE_EXPORT_SHEETS[id] : []);
    const currentRecorded = Array.isArray(state?.workbookTabs)
      ? state.workbookTabs
      : expandGroups(Array.isArray(state?.workbookScope) ? state.workbookScope : Array.isArray(workbook.scopeIds) ? workbook.scopeIds : allIds);
    const importedRecorded = Array.isArray(workbook.tabNames) ? workbook.tabNames : expandGroups(Array.isArray(workbook.scopeIds) ? workbook.scopeIds : allIds);
    const currentSelected = new Set(["Exposure", ...currentRecorded]);
    const importedSelected = new Set(["Exposure", ...importedRecorded]);
    const selectedTabs = allSheets.filter((sheet) => currentSelected.has(sheet));
    const omittedTabs = allSheets.filter((sheet) => !currentSelected.has(sheet));
    const importedTabs = allSheets.filter((sheet) => importedSelected.has(sheet));
    const selectedGroupLabels = allIds.filter((id) => WORKBOOK_SCOPE_EXPORT_SHEETS[id].some((sheet) => currentSelected.has(sheet))).map((id) => WORKBOOK_SCOPE_EXPORT_LABELS[id]);
    const scopeMismatch = allSheets.some((sheet) => currentSelected.has(sheet) !== importedSelected.has(sheet));
    const applicableErrors = workbookFormulaErrorTotal(workbook);
    const totalErrors = Number.isFinite(Number(workbook.totalFormulaErrorCount)) ? Number(workbook.totalFormulaErrorCount) : applicableErrors;
    const applicableMissingCache = Number(workbook.formulasWithoutCachedValues || 0);
    const totalMissingCache = Number.isFinite(Number(workbook.totalFormulasWithoutCachedValues)) ? Number(workbook.totalFormulasWithoutCachedValues) : applicableMissingCache;
    const errorSamples = (Array.isArray(workbook.formulaErrorSamples) ? workbook.formulaErrorSamples : Array.isArray(workbook.formulaErrors) ? workbook.formulaErrors : []).slice(0, 12);
    const errorSampleLocators = errorSamples.map((sample) => `${sample.sheet || "Unknown sheet"}!${sample.address || "unknown cell"} = ${sample.value || "saved error"}`).join("; ") || "No selected-scope error samples retained.";
    const reviewedCount = Number.isFinite(Number(workbook.formulaErrorReviewCount)) ? Number(workbook.formulaErrorReviewCount) : "not recorded";
    return [
      ["Selected individual workbook tabs — current PM scope", selectedTabs.join("; ") || "Exposure", "Only these exact workbook tabs are included by the PM."],
      ["Omitted individual workbook tabs — current PM scope", omittedTabs.join("; ") || "None", "Omitted tabs may remain blank and require a supported or PM-owned N/A memo conclusion."],
      ["Selected workbook categories — summary", selectedGroupLabels.join("; ") || "Bank exposure only", "Categories only organize the checklist; the individual-tab rows control scope."],
      ["Imported workbook tabs", importedTabs.join("; ") || "Exposure", scopeMismatch || workbook.scopeChangedAfterImport ? "MISMATCH — these are the exact tabs inspected on the current workbook source; re-add the workbook for the current PM scope before reliance." : "Matches the current PM selection."],
      ["Workbook source binding", `${workbook.sourceId || "Not loaded"}; fingerprint ${workbook.digest || "not available"}`, workbook.scopeChangedAfterImport || scopeMismatch ? "SCOPE CHANGED — re-add workbook before reliance" : "Scope and source version are current"],
      ["Saved formula errors", `${applicableErrors} applicable / ${totalErrors} full workbook`, `${Math.max(0, totalErrors - applicableErrors)} retained outside the selected scope; errors are never converted to zero or blank.`],
      ["Selected-scope formula-error review", applicableErrors ? `${workbook.formulaErrorsReviewed ? "Reviewed" : "Not reviewed"}; exact-count confirmation ${workbook.formulaErrorReviewConfirmed ? "recorded" : "not recorded"}; review count ${reviewedCount} of ${applicableErrors}` : "No selected-scope saved formula errors", clean(workbook.errorReviewNote) || "No PM formula-error review basis recorded."],
      ["Retained selected-scope formula-error samples", `${errorSamples.length} sample locator${errorSamples.length === 1 ? "" : "s"}; ${applicableErrors} applicable errors`, errorSampleLocators],
      ["Formulas without saved values", `${applicableMissingCache} applicable / ${totalMissingCache} full workbook`, `${Math.max(0, totalMissingCache - applicableMissingCache)} retained outside the selected scope; selected-scope defects block readiness.`],
      ["Scope-filtered observations", `${Number(workbook.excludedScopeObservationCount || 0)} excluded from active ledger`, "Counts are retained for review; excluded observations cannot control memo values."]
    ];
  }

  function selectedScenarioRows(state) {
    const scenario = state?.scenarioResults || {};
    let recordedStress = scenario.assumptions && typeof scenario.assumptions === "object" && !Array.isArray(scenario.assumptions) ? scenario.assumptions : null;
    if (!recordedStress && typeof scenario.inputFingerprint === "string") {
      try {
        const parsedFingerprint = JSON.parse(scenario.inputFingerprint);
        if (parsedFingerprint?.assumptions && typeof parsedFingerprint.assumptions === "object" && !Array.isArray(parsedFingerprint.assumptions)) recordedStress = parsedFingerprint.assumptions;
      } catch (_) { /* The exact opaque fingerprint is still exported below. */ }
    }
    recordedStress = recordedStress || {};
    const currentStress = state?.stress || {};
    const recordedAvailable = ["computed", "stale"].includes(scenario.status);
    const fingerprintCurrent = Boolean(state?.stressReviewed && scenario.status === "computed" && scenario.inputFingerprint && scenario.inputFingerprint === stressInputFingerprint(state) && scenarioCalculationLedgerMatches(state));
    const recorded = (value, unit) => Number.isFinite(Number(value)) ? `${clean(value)}${unit || ""}` : "Not recorded";
    const currentSelection = [
      `price ${recorded(currentStress.priceDecline, "%")}`,
      `absorption ${recorded(currentStress.absorptionSlowdown, "%")}`,
      `cost ${recorded(currentStress.costOverrun, "%")}`,
      `rate ${recorded(currentStress.rateShock, " bp")}`,
      `cancellation ${recorded(currentStress.cancellationIncrease, "%")}`
    ].join("; ");
    return [
      ["Recorded price decline", recorded(recordedStress.priceDecline, "%"), "Reduction from the accepted price assumption"],
      ["Recorded absorption slowdown", recorded(recordedStress.absorptionSlowdown, "%"), "Reduction from accepted plan absorption"],
      ["Recorded remaining-cost overrun", recorded(recordedStress.costOverrun, "%"), "Increase applied to remaining project costs"],
      ["Recorded interest-rate shock", recorded(recordedStress.rateShock, " basis points"), "Increment applied to modeled borrowing cost"],
      ["Recorded additional cancellation drag", recorded(recordedStress.cancellationIncrease, "%"), "Additional reduction applied to net-closing conversion"],
      ["Scenario rule / currency", `${scenario.ruleVersion || "HBF-STRESS-1.1"} / ${!recordedAvailable ? "not recorded" : fingerprintCurrent ? "current" : "STALE — facts or selected sliders differ"}`, [scenario.recordedAt || "Recorded time not available", scenario.staleReason || ""].filter(Boolean).join("; ")],
      ["Recorded input fingerprint", scenario.inputFingerprint || "Not recorded", "Exact fact IDs, values, units, scope and assumptions used to establish scenario currency"],
      ["Current slider selection", currentSelection, fingerprintCurrent ? "Matches the recorded scenario." : "Pending selection only; not the basis of the recorded calculations above."]
    ];
  }

  function factDisplay(state, path) {
    const fact = factByPath(state, path);
    if (!fact) return "—";
    if (fact.valueType === "money") return money(fact.value);
    if (fact.valueType === "percent") return Number.isFinite(Number(fact.value)) ? `${(Number(fact.value) * 100).toFixed(1)}%` : "—";
    if (fact.valueType === "multiple") return Number.isFinite(Number(fact.value)) ? `${Number(fact.value).toFixed(2)}x` : "—";
    return clean(fact.value);
  }

  function factValue(fact) {
    if (!fact || typeof fact !== "object") return "—";
    if (fact.valueType === "money") return money(fact.value);
    if (fact.valueType === "percent") return Number.isFinite(Number(fact.value)) ? `${(Number(fact.value) * 100).toFixed(1)}%` : "—";
    if (fact.valueType === "multiple") return Number.isFinite(Number(fact.value)) ? `${Number(fact.value).toFixed(2)}x` : "—";
    return fact.value == null || fact.value === "" ? "—" : clean(fact.value);
  }

  function applicabilityDecision(value) {
    const normalized = clean(value || "pending").toLowerCase();
    if (normalized === "ready") return "Required — ready";
    if (normalized === "not_applicable" || normalized === "not applicable") return "Not applicable";
    if (normalized === "pending") return "Pending";
    return clean(value || "Not stated");
  }

  function applicabilityRows(state) {
    if (!Object.prototype.hasOwnProperty.call(state, "applicability")) return null;
    const matrix = state.applicability;
    const entries = Array.isArray(matrix)
      ? matrix.map((item, index) => [String(index + 1), item])
      : matrix && Array.isArray(matrix.sections)
        ? matrix.sections.map((item, index) => [String(index + 1), item])
        : matrix && typeof matrix === "object"
          ? Object.entries(matrix)
          : [];

    return entries.map(([key, item]) => {
      if (!item || typeof item !== "object" || Array.isArray(item)) {
        return [clean(item || key || "Not stated"), "Not stated", "Not stated", "Not stated", "Not stated"];
      }
      const section = item.label || item.topic || item.section || item.title || item.name || item.id || key;
      const kind = item.kind || item.applicabilityStatus || item.applicability ||
        (typeof item.applicable === "boolean" ? (item.applicable ? "Applicable" : "Not applicable") : "Not stated");
      const status = item.status || item.readiness || item.readinessStatus || item.completionStatus || "pending";
      const basis = item.basis || item.rationale || item.reason || "Not stated";
      const requiredAction = item.requiredAction || item.required_action || item.decidedBy || item.owner || item.reviewer || "Not stated";
      return [section, kind, applicabilityDecision(status), basis, requiredAction];
    });
  }

  function applicabilityContent(state, h, title) {
    const rows = applicabilityRows(state);
    if (rows === null) return [];
    const widths = h.contentWidth > 10800
      ? [2300, 1100, 1800, 4600, 4600]
      : [1800, 900, 1500, 3300, 3300];
    return [
      h.heading(title),
      rows.length
        ? h.table(["Control", "Type", "Decision", "Basis", "Required action / owner"], rows, widths)
        : h.p("No applicability decisions are recorded in the active deal record.")
    ];
  }

  function downloadBlob(blob, fileName) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = safeFileName(fileName);
    anchor.rel = "noopener";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  function requireDocx() {
    if (!window.docx) throw new Error("The local Word export library did not load.");
    return window.docx;
  }

  function createDocHelpers(landscape) {
    const d = requireDocx();
    const navy = "0B2538";
    const teal = "09626A";
    const gray = "5D6F79";
    const line = "D9E1E5";
    const paleBlue = "EEF4F7";
    const paleRed = "FBE8E7";

    const contentWidth = landscape ? 14400 : 10800;
    const text = (value, options) => new d.TextRun({ text: clean(value), font: "Arial", size: 19, color: "253640", ...options });
    const p = (value, options) => new d.Paragraph({ children: [text(value)], spacing: { after: 130, line: 310 }, ...options });
    const heading = (value, level) => new d.Paragraph({
      text: clean(value),
      heading: level || d.HeadingLevel.HEADING_1,
      spacing: { before: level === d.HeadingLevel.HEADING_2 ? 220 : 320, after: 130 },
      keepNext: true
    });
    const pageHeading = (value, level) => new d.Paragraph({
      text: clean(value),
      heading: level || d.HeadingLevel.HEADING_1,
      pageBreakBefore: true,
      spacing: { before: 0, after: 130 },
      keepNext: true
    });
    const cell = (value, options) => new d.TableCell({
      children: [new d.Paragraph({ children: [text(value, { size: landscape ? 17 : 20, ...(options && options.bold ? { bold: true } : {}) })], spacing: { after: 0, line: landscape ? 250 : 310 } })],
      shading: options && options.shading ? { fill: options.shading } : undefined,
      width: options && options.width ? { size: options.width, type: d.WidthType.DXA } : undefined,
      margins: landscape ? { top: 65, bottom: 65, left: 80, right: 80 } : { top: 90, bottom: 90, left: 110, right: 110 },
      verticalAlign: d.VerticalAlign.CENTER
    });
    const table = (headers, rows, widths) => new d.Table({
      width: { size: contentWidth, type: d.WidthType.DXA },
      layout: d.TableLayoutType.FIXED,
      rows: [
        new d.TableRow({ tableHeader: true, cantSplit: true, children: headers.map((header, index) => cell(header, { bold: true, shading: paleBlue, width: widths?.[index] })) }),
        ...rows.map((row) => new d.TableRow({ cantSplit: true, children: row.map((value, index) => cell(value, { width: widths?.[index] })) }))
      ],
      columnWidths: widths,
      borders: {
        top: { style: d.BorderStyle.SINGLE, size: 1, color: line },
        bottom: { style: d.BorderStyle.SINGLE, size: 1, color: line },
        left: { style: d.BorderStyle.SINGLE, size: 1, color: line },
        right: { style: d.BorderStyle.SINGLE, size: 1, color: line },
        insideHorizontal: { style: d.BorderStyle.SINGLE, size: 1, color: line },
        insideVertical: { style: d.BorderStyle.SINGLE, size: 1, color: line }
      }
    });
    const bullet = (value) => new d.Paragraph({
      children: [text(value)],
      bullet: { level: 0 },
      spacing: { after: 85, line: 290 }
    });

    return { d, navy, teal, gray, line, paleBlue, paleRed, text, p, heading, pageHeading, cell, table, bullet, contentWidth };
  }

  function baseDocumentOptions(state, title, children, options) {
    const current = normalizeState(state);
    const h = createDocHelpers();
    const { d, navy, teal, gray, line, text } = h;
    const landscape = Boolean(options && options.landscape);
    const snapshot = current._export || {};
    const header = () => new d.Header({
      children: [new d.Paragraph({
        children: [text("HOME BUILDER FINANCE", { size: 16, bold: true, color: gray, characterSpacing: 75 }), text(`   |   ${current.deal.id || current.monitor?.reviewId || "Record ID not entered"}`, { size: 16, color: gray })],
        border: { bottom: { color: line, size: 4, style: d.BorderStyle.SINGLE, space: 5 } }
      })]
    });
    const footer = () => new d.Footer({
      children: [new d.Paragraph({
        alignment: d.AlignmentType.RIGHT,
        children: [text(`${options?.footerNote ? `${options.footerNote}   •   ` : ""}Confidential credit work product   •   ${snapshot.snapshotId || "unfrozen draft"}   •   `, { size: options?.footerNote ? 13 : 15, color: gray }), new d.TextRun({ children: [d.PageNumber.CURRENT], font: "Arial", size: options?.footerNote ? 13 : 15, color: gray })]
      })]
    });
    return new d.Document({
      creator: "HBF Credit Decision Studio",
      title: clean(title),
      subject: `Evidence-bound credit analysis for ${clean(current.deal.borrower || "active deal")}`,
      description: "Generated locally from the active deal record for human review.",
      styles: {
        default: { document: { run: { font: "Arial", size: 19, color: "253640" }, paragraph: { spacing: { line: 285 } } } },
        paragraphStyles: [
          { id: "Title", name: "Title", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: "Arial", size: 46, bold: true, color: navy }, paragraph: { spacing: { after: 150 } } },
          { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: "Arial", size: 28, bold: true, color: navy }, paragraph: { spacing: { before: 280, after: 110 }, border: { bottom: { color: teal, size: 8, style: d.BorderStyle.SINGLE, space: 6 } } } },
          { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: "Arial", size: 23, bold: true, color: navy }, paragraph: { spacing: { before: 220, after: 90 } } }
        ]
      },
      sections: [{
        properties: {
          page: {
            margin: { top: 720, right: 720, bottom: 720, left: 720 },
            size: { width: 12240, height: 15840, orientation: landscape ? d.PageOrientation.LANDSCAPE : d.PageOrientation.PORTRAIT }
          },
          titlePage: false
        },
        headers: { default: header(), first: header(), even: header() },
        footers: { default: footer(), first: footer(), even: footer() },
        children
      }]
    });
  }

  function titleBlock(state, label, h) {
    const current = normalizeState(state);
    const { d, navy, teal, gray, text, p, table } = h;
    const blockerCount = current.issues.filter((issue) => issue.status === "open" && issue.severity === "blocker").length;
    const conflictCount = unresolvedConflicts(current).length;
    const ready = isReviewReady(current);
    const monitorWorkflow = isMonitorWorkflow(current);
    const completeLabel = workflowCompletionLabel(current);
    return [
      new d.Paragraph({ children: [text(label.toUpperCase(), { size: 17, bold: true, color: teal, characterSpacing: 80 })], spacing: { after: 90 } }),
      new d.Paragraph({ text: clean(current.deal.borrower || "Borrower not entered"), style: "Title" }),
      new d.Paragraph({ children: [text(`${current.deal.dealType || "Deal type not entered"} • ${current.deal.facilityType || "Facility type not entered"}`, { size: 23, color: gray })], spacing: { after: 230 } }),
      table(
        [monitorWorkflow ? "Package status" : "Decision status", "Request", "Current / proposed rating", "As-of date"],
        [[ready ? workflowCompletionLabel(current, true) : "DRAFT — OPEN ITEMS", current.deal.request || "Not entered", `${current.deal.currentRating || "Not entered"} / ${current.deal.proposedRating || "Not entered"}`, current.deal.asOfDate || "Not entered"]],
        h.contentWidth > 10800 ? [2600, 4300, 4300, 3200] : [2400, 3000, 3200, 2200]
      ),
      new d.Paragraph({ spacing: { before: 220, after: 100 }, children: [text("Recommendation", { size: 18, bold: true, color: gray, characterSpacing: 50 })] }),
      new d.Paragraph({ children: [text(current.deal.recommendation || "PM recommendation not entered", { size: 32, bold: true, color: navy })], spacing: { after: 180 } }),
      p(ready
        ? monitorWorkflow
          ? `${completeLabel} means the quarterly workflow gates passed. It is not credit approval, a covenant waiver, risk-rating approval or independent source validation.`
          : "This document was compiled locally from the active deal record. Review Ready means the workflow gates passed; it is not an automated approval or an independent validation of source facts or calculations."
        : `This document was compiled locally from the active deal record and remains a working draft. Open approval blockers: ${blockerCount}; unresolved conflicts: ${conflictCount}.`)
    ];
  }

  function decisionMetrics(state, h) {
    const calculations = state && Array.isArray(state.calculations) ? state.calculations : [];
    const selected = ["CALC02", "CALC03", "CALC04", "CALC06", "CALC07", "CALC09"]
      .map((id) => calculations.find((calc) => calc && calc.id === id)).filter(Boolean);
    return h.table(
      ["Decision metric", "Result", "Requirement / interpretation", "Status"],
      selected.map((calc) => [calc.name, calc.display, calc.comparison, calc.status === "pass" ? "Within selected case" : calc.status === "fail" ? "Outside selected case" : "Review required"]),
      [2600, 1500, 4200, 2500]
    );
  }

  function controllingLabel(state, fact) {
    if (!fact || !fact.path || !["accepted", "supported"].includes(fact.status)) return "No";
    const controlling = factByPath(state, fact.path, {
      entity: fact.entity,
      periodType: fact.periodType || "as_of",
      asOfDate: fact.asOfDate,
      scenario: fact.scenario || "actual",
      unit: fact.unit || ""
    });
    if (!controlling || controlling.id !== fact.id) return "No";
    return fact.controlling === true ? "Yes — explicit" : "Yes — sole eligible";
  }

  function conflictNarrative(state, conflict) {
    const item = conflict && typeof conflict === "object" ? conflict : {};
    const status = clean(item.status || "open").toLowerCase();
    const label = item.label || item.fieldPath || item.id || "Unlabeled reconciliation";
    const rationale = item.rationale || "not entered";
    if (status === "resolved") {
      const selected = item.selectedFactId ? state.facts.find((fact) => fact.id === item.selectedFactId) : null;
      const selectedValue = selected ? factValue(selected) : (item.selectedFactId || "selection not recorded");
      return `${label}: Resolved to ${selectedValue}; rationale: ${rationale}.`;
    }
    if (status === "superseded") {
      return `${label}: Superseded — the prior reconciliation was retired after its source version was replaced; rationale / provenance note: ${rationale}.`;
    }
    if (status === "open") return `${label}: UNRESOLVED — competing facts remain.`;
    return `${label}: Recorded as ${status || "not stated"}; rationale / provenance note: ${rationale}.`;
  }

  function issueResolution(issue) {
    const resolution = issue && issue.resolution && typeof issue.resolution === "object" ? issue.resolution : {};
    return {
      type: resolution.type || (issue && issue.status === "resolved" ? "Resolved — type not recorded" : "—"),
      evidence: resolution.evidenceId || "—",
      rationale: resolution.rationale || (issue && issue.status === "resolved" ? "Resolution rationale not recorded" : "—"),
      resolvedAt: resolution.resolvedAt || "—"
    };
  }

  function monitorValue(value, type) {
    if (value == null || value === "" || !Number.isFinite(Number(value))) return "Not provided";
    const number = Number(value);
    if (type === "money") return money(number);
    if (type === "percent") return `${(number * 100).toFixed(1)}%`;
    if (type === "percentage_points") return `${number >= 0 ? "+" : ""}${(number * 100).toFixed(1)} pts`;
    if (type === "multiple") return `${number.toFixed(2)}x`;
    if (type === "months") return `${number.toFixed(1)} mos.`;
    if (type === "days") return `${Math.round(number).toLocaleString("en-US")} days`;
    return number.toLocaleString("en-US", { maximumFractionDigits: 1 });
  }

  function monitorObservationCutoff(monitor, observation) {
    const path = clean(observation?.path).toLowerCase();
    if (path.startsWith("inventory.")) return monitor?.inventoryPeriodEnd;
    if (path.startsWith("financial.") || path.startsWith("operating.")) return monitor?.financialPeriodEnd;
    return monitor?.reviewAsOfDate;
  }

  function activeMonitorObservations(monitor, state) {
    const seen = new Set();
    const staged = (monitor?.observations || []).length
      ? monitor.observations
      : (state?.facts || []).filter((fact) => fact.sourceId === monitor?.workbookSourceId);
    return staged.filter((observation) => {
      const cutoff = monitorObservationCutoff(monitor, observation);
      const key = [observation?.path, observation?.asOfDate, observation?.entity, observation?.periodType, observation?.scenario || "actual", observation?.unit].join("|");
      if (!validIsoDate(observation?.asOfDate) || !validIsoDate(cutoff) || observation.asOfDate > cutoff || seen.has(key)) return false;
      seen.add(key);
      return true;
    }).sort((a, b) => clean(a.asOfDate).localeCompare(clean(b.asOfDate)) || clean(a.path).localeCompare(clean(b.path)));
  }

  function observationDisplay(observation) {
    if (["money", "percent", "multiple", "months", "days", "number"].includes(observation?.valueType)) return monitorValue(observation.value, observation.valueType);
    return clean(observation?.value || "Not provided");
  }

  function monitorPeriodRow(period, label) {
    const current = period || {};
    return [
      label || current.periodEnd || "Not provided",
      money(current.revenue),
      monitorValue(current.grossMargin, "percent"),
      money(current.netIncome),
      monitorValue(current.netMargin, "percent"),
      monitorValue(current.closings, "number"),
      monitorValue(current.netSales, "number")
    ];
  }

  function sortedExceptions(monitor) {
    const priority = { blocker: 0, warning: 1, note: 2, informational: 3 };
    const combined = [
      ...(monitor?.watchItems || []).filter((item) => String(item.status || "open").toLowerCase() !== "resolved"),
      ...(monitor?.anomalies || []).filter((item) => String(item.status || "open").toLowerCase() !== "resolved")
    ];
    const seen = new Set();
    return combined.filter((item) => {
      const key = `${clean(item.title).toLowerCase()}|${clean(item.detail).toLowerCase()}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }).sort((a, b) => (priority[a.severity] ?? 9) - (priority[b.severity] ?? 9) || clean(a.title).localeCompare(clean(b.title)));
  }

  function monitorActionRows(state) {
    const monitor = state.monitor || {};
    return [
      ...(monitor.actions || []).filter((item) => !monitorActionIsTerminal(item)).map((item) => ({
        severity: "action", itemId: item.id, scopeType: item.reportingItemId ? "Reporting" : item.covenantId ? "Covenant" : item.relatedControlId ? "Control" : "Monitoring", scopeId: item.reportingItemId || item.covenantId || item.relatedControlId || "general", reportingItemId: item.reportingItemId || "", covenantId: item.covenantId || "", relatedControlId: item.relatedControlId || "", item: item.action || item.title, detail: "Structured monitoring action", owner: item.owner, timing: item.timing || "", dueDate: validIsoDate(item.dueDate) ? item.dueDate : "", status: item.status || "Open", evidence: item.evidence || "", verification: item.verification || "", recordedAt: item.recordedAt || ""
      })),
      ...(monitor.reportingItems || []).filter((item) => item.status !== "Current").map((item) => ({
        severity: ["Past due", "Review required"].includes(item.status) ? "blocker" : "warning", itemId: item.id, scopeType: "Reporting", scopeId: item.id, reportingItemId: item.id, item: item.name, detail: `${item.status}; due ${item.dueDate || "not stated"}`, owner: "Portfolio Manager", timing: item.frequency || "", dueDate: validIsoDate(item.dueDate) ? item.dueDate : "", status: "Open", evidence: item.locator || "", verification: ""
      })),
      ...(monitor.covenants || []).filter(covenantRequiresReview).map((item) => ({
        severity: covenantIsException(item) ? "blocker" : "warning", itemId: item.id, scopeType: "Covenant", scopeId: item.id, covenantId: item.id, item: item.name, detail: item.comparable === false ? (item.note || "Requirement and actual are not comparable") : `${item.sourceStatus || item.status}; computed ${item.computedStatus || "not available"}`, owner: "Portfolio Manager", timing: item.testDate || "", dueDate: "", status: "Open", evidence: item.locator || "", verification: ""
      })),
      ...(monitor.watchItems || []).filter((item) => normalizedStatus(item.status) !== "resolved" && !["Reporting", "Covenants"].includes(item.module)).map((item) => ({
        severity: item.severity || "warning", itemId: item.id, scopeType: item.module || "Monitoring", scopeId: item.id, item: item.title, detail: item.detail, owner: item.owner || "Portfolio Manager", timing: item.timing || "", dueDate: validIsoDate(item.dueDate) ? item.dueDate : "", status: item.status || "Open", evidence: item.locator || "", verification: ""
      })),
      ...(state.conditions || []).filter((item) => !["completed", "closed", "satisfied"].includes(normalizedStatus(item.status))).map((item) => ({
        severity: "condition", itemId: item.id, scopeType: "Condition", scopeId: item.id, item: item.requirement, detail: item.purpose, owner: item.owner, timing: item.phase || "", dueDate: validIsoDate(item.dueDate) ? item.dueDate : "", status: item.status || "Open", evidence: item.evidence || "", verification: item.verification || ""
      }))
    ];
  }

  async function exportAuthoredDraft(input) {
    if (!window.HBFAuthoring) throw new Error("Reopen this working file in the current Studio to download its document.");
    const snapshot = JSON.parse(JSON.stringify(input));
    window.HBFAuthoring.validate(snapshot.authoring, snapshot.workflow);
    const data = await window.HBFAuthoring.exportBytes(snapshot.authoring, snapshot);
    const title = window.HBFAuthoring.title(snapshot.authoring) || (snapshot.authoring.kind === 'qpr' ? 'Quarterly-review' : 'Credit-memo');
    const borrower = window.HBFAuthoring.borrower(snapshot.authoring);
    downloadBlob(new Blob([data], {type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'}), safeFileName((borrower ? borrower + '-' : '') + title) + '.docx');
  }

  async function exportMonitor(input) {
    if (input.authoring) return exportAuthoredDraft(input);
    const frozen = await freezeExportSnapshot(input);
    const state = frozen.state;
    state._export = frozen;
    const monitor = state.monitor;
    if (!monitor) throw new Error("No quarterly monitor is loaded.");
    const h = createDocHelpers(true);
    const { d, text, p, heading, pageHeading, table, paleRed, paleBlue } = h;
    const ready = isReviewReady(state);
    const latestBank = latestAtOrBefore(monitor.bankingSeries, monitor.reviewAsOfDate) || {};
    const quarterSeries = seriesAtOrBefore(monitor.financial?.quarterly, monitor.financialPeriodEnd);
    const ytdSeries = seriesAtOrBefore(monitor.financial?.ytd, monitor.financialPeriodEnd);
    const ttmSeries = seriesAtOrBefore(monitor.financial?.ttm, monitor.financialPeriodEnd);
    const latestQuarter = quarterSeries.slice(-1)[0] || {};
    const currentYtd = ytdSeries.slice(-1)[0] || {};
    const priorYtdCandidate = ytdSeries.length >= 2 ? ytdSeries.at(-2) : null;
    const priorYtd = comparablePriorYear(currentYtd, priorYtdCandidate) ? priorYtdCandidate : {};
    const latestTtm = ttmSeries.slice(-1)[0] || {};
    const latestBalance = latestAtOrBefore(monitor.balanceSheets, monitor.financialPeriodEnd) || {};
    const latestInventory = latestAtOrBefore(monitor.inventorySeries, monitor.inventoryPeriodEnd) || {};
    const exceptions = sortedExceptions(monitor);
    const includeFinancialAppendix = monitor.outputProfile === "standard" || monitor.outputProfile === "full" || monitor.includeFinancialTables;
    const includeBalanceAppendix = monitor.outputProfile === "standard" || monitor.outputProfile === "full" || monitor.includeBalanceSheetTable;
    const compactAppendices = monitor.outputProfile === "standard";
    const covenantRows = [
      ...(monitor.covenants || []).filter(covenantRequiresReview),
      ...(monitor.covenants || []).filter((item) => !covenantRequiresReview(item))
    ].slice(0, 3);
    const reportingRank = { "Past due": 0, "Review required": 1, "Due soon": 2, Current: 3 };
    const reportingRows = [...(monitor.reportingItems || [])].sort((a, b) => (reportingRank[a.status] ?? 9) - (reportingRank[b.status] ?? 9) || clean(a.dueDate || "9999").localeCompare(clean(b.dueDate || "9999"))).slice(0, 3);
    const officerActions = [...(monitor.actions || [])].sort((a, b) => Number(monitorActionIsTerminal(a)) - Number(monitorActionIsTerminal(b)) || clean(a.dueDate || "9999").localeCompare(clean(b.dueDate || "9999"))).slice(0, 1);
    const executiveConclusion = executiveExcerpt(monitor.conclusion, 290, "Portfolio manager conclusion required.");
    const executiveRatingRationale = executiveExcerpt(monitor.ratingRationale, 180, "Portfolio manager rating rationale required.");
    const borrowerLabel = executiveLabel(monitor.identity?.borrower || state.deal.borrower, 44, "Borrower not entered");
    const relationshipLabel = executiveLabel(monitor.identity?.relationship || state.deal.relationship, 55, "Relationship not entered");
    const currentRatingLabel = executiveLabel(monitor.rating?.current, 10, "Not entered");
    const recommendedRatingLabel = executiveLabel(monitor.rating?.recommended, 10, "Not entered");
    const assessmentLabel = executiveLabel(monitor.assessment, 50, "PM assessment required");
    const facilityTypeLabel = executiveLabel(monitor.facility?.type, 22, "Not stated");
    const statusLabel = ready ? "REVIEW PACKAGE COMPLETE" : "DRAFT — CONTROLS OPEN";
    const children = [
      new d.Paragraph({ children: [text("QUARTERLY PORTFOLIO MONITOR", { size: 17, bold: true, color: h.teal, characterSpacing: 80 })], spacing: { after: 80 } }),
      new d.Paragraph({ text: borrowerLabel, style: "Title" }),
      new d.Paragraph({ children: [text(`${relationshipLabel}  •  Review as of ${monitor.reviewAsOfDate || "not entered"}`, { size: 21, color: h.gray })], spacing: { after: 150 } }),
      table(["Package status", "Risk rating", "Facility", "PM assessment"], [[statusLabel, `${currentRatingLabel} → ${recommendedRatingLabel}`, `${facilityTypeLabel}; ${money(latestBank.applicableCommitment ?? monitor.facility?.grossCommitment)}`, assessmentLabel]], [2600, 2600, 3500, 5700]),
      heading("Officer decision brief", d.HeadingLevel.HEADING_2),
      p(executiveConclusion),
      p(`Cutoff integrity: review ${monitor.reviewAsOfDate || "not entered"}; financial ${monitor.financialPeriodEnd || "not entered"}; inventory ${monitor.inventoryPeriodEnd || "not entered"}; banking ${latestBank.periodEnd || "not entered"}. Computer date is not used.`),
      table(
        ["Banking cutoff", "Outstanding", "Utilization", "Deposits / UPB", "Line maturity", "Days to maturity"],
        [[latestBank.periodEnd || "Not provided", money(latestBank.outstanding), monitorValue(latestBank.utilization, "percent"), monitorValue(latestBank.depositCoverage, "percent"), monitor.facility?.lineMaturity || "Not provided", monitorValue(verifiedMaturityDays(monitor), "days")]],
        [2100, 2200, 1900, 2200, 2400, 3600]
      ),
      heading("Performance at the review cutoff", d.HeadingLevel.HEADING_2),
      table(
        ["Period", "Revenue", "Gross margin", "Net income", "Net margin", "Closings", "Net sales"],
        [monitorPeriodRow(latestQuarter, `Quarter ${latestQuarter.periodEnd || ""}`), monitorPeriodRow(currentYtd, `YTD ${currentYtd.periodEnd || ""}`), monitorPeriodRow(latestTtm, `TTM ${latestTtm.periodEnd || ""}`)],
        [2500, 2300, 1900, 2100, 1700, 1900, 2000]
      ),
      heading("Directional indicators", d.HeadingLevel.HEADING_2),
      table(["Indicator", "Current", "Comparable", "Movement / interpretation"], [
        ["YTD revenue", money(currentYtd.revenue), money(priorYtd.revenue), monitorValue(relativeChange(currentYtd.revenue, priorYtd.revenue), "percent")],
        ["YTD closings", monitorValue(currentYtd.closings, "number"), monitorValue(priorYtd.closings, "number"), monitorValue(relativeChange(currentYtd.closings, priorYtd.closings), "percent")],
        ["YTD gross margin", monitorValue(currentYtd.grossMargin, "percent"), monitorValue(priorYtd.grossMargin, "percent"), monitorValue(Number.isFinite(Number(currentYtd.grossMargin)) && Number.isFinite(Number(priorYtd.grossMargin)) ? Number(currentYtd.grossMargin) - Number(priorYtd.grossMargin) : null, "percentage_points")]
      ], [3300, 2500, 2500, 6100]),
      heading("PM rating judgment", d.HeadingLevel.HEADING_2),
      p(executiveRatingRationale),
      pageHeading("Exceptions, controls and required action"),
      table(["Priority", "Exception / signal", "Why it matters", "Module / locator"], (exceptions.length ? exceptions.slice(0, 2) : [{ severity: "note", title: "No open exceptions", detail: "No exception was recorded in the active snapshot.", module: "Monitor" }]).map((item) => [clean(item.severity || "note").toUpperCase(), executiveLabel(item.title, 110, "Untitled item"), executiveExcerpt(item.detail, 250, "No detail recorded"), executiveLabel(item.module || item.locator, 90, "Monitor")]), [1500, 3600, 6200, 3100]),
      heading("Covenant position", d.HeadingLevel.HEADING_2),
      table(["Covenant", "Requirement", "Actual", "Headroom", "Result", "Evidence"], covenantRows.map((item) => [executiveLabel(item.name, 70, "Not stated"), monitorValue(item.threshold, item.valueType), monitorValue(item.actual, item.valueType), item.comparable === false ? "Not comparable" : monitorValue(item.headroom, item.valueType), executiveLabel(covenantResultLabel(item), 80, "Review required"), executiveLabel(item.locator, 80, "Not supplied")]), [3100, 2000, 2000, 2100, 2100, 3100]),
      heading("Balance sheet and inventory", d.HeadingLevel.HEADING_2),
      table(["Financial cutoff", "Cash", "Tangible net worth", "Assets / liabilities", "Inventory cutoff", "Lots / total units"], [[latestBalance.periodEnd || "Not provided", money(latestBalance.cash), money(latestBalance.tangibleNetWorth), `${money(latestBalance.totalAssets)} / ${money(latestBalance.totalLiabilities)}`, latestInventory.periodEnd || "Not provided", `${monitorValue(latestInventory.lotsOwnedControlled, "number")} / ${monitorValue(latestInventory.totalUnits, "number")}`]], [2100, 2000, 2500, 3200, 2100, 2500]),
      heading("Reporting and follow-up", d.HeadingLevel.HEADING_2),
      table(["Item", "Last received", "Next due", "Status"], reportingRows.map((item) => [executiveLabel(item.name, 70, "Not stated"), item.lastReceivedPeriodEnd || "Not provided", item.dueDate || "Not provided", executiveLabel(item.status, 40, "Review required")]), [5200, 2800, 2800, 3600]),
      ...((monitor.actions || []).length ? [
        heading("Immediate structured action", d.HeadingLevel.HEADING_2),
        table(["Scope", "Action", "Owner / due", "Status", "Evidence"], officerActions.map((item) => [executiveLabel(item.reportingItemId || item.covenantId || item.relatedControlId, 40, "General"), executiveExcerpt(item.action, 180, "Not stated"), `${executiveLabel(item.owner, 40, "Unassigned")}; ${item.dueDate || "not dated"}`, executiveLabel(item.status, 20, "Open"), executiveExcerpt(item.evidence, 100, "Not supplied")]), [1700, 6000, 2800, 1500, 2400])
      ] : [p("No structured monitoring action is recorded.")]),
      p(`Executive cells use bounded display; full text remains in the credit review pack. Full registers retain ${Math.max(0, exceptions.length - 2)} additional signal(s), ${Math.max(0, (monitor.covenants || []).length - covenantRows.length)} covenant test(s), ${Math.max(0, (monitor.reportingItems || []).length - reportingRows.length)} reporting line(s) and ${Math.max(0, (monitor.actions || []).length - officerActions.length)} structured action(s); ${monitorActionRows(state).length} open record(s) total.`)
    ];

    if (includeFinancialAppendix) {
      children.push(new d.Paragraph({ children: [new d.PageBreak()] }), heading("Appendix A — Financial statement trend"));
      const appendixSeries = (series) => compactAppendices ? seriesAtOrBefore(series, monitor.financialPeriodEnd).slice(-2) : seriesAtOrBefore(series, monitor.financialPeriodEnd);
      const periods = [
        ...appendixSeries(monitor.financial?.quarterly).map((item) => monitorPeriodRow(item, `Quarter ${item.periodEnd}`)),
        ...appendixSeries(monitor.financial?.ytd).map((item) => monitorPeriodRow(item, `YTD ${item.periodEnd}`)),
        ...appendixSeries(monitor.financial?.ttm).map((item) => monitorPeriodRow(item, `TTM ${item.periodEnd}`))
      ];
      children.push(table(["Period", "Revenue", "Gross margin", "Net income", "Net margin", "Closings", "Net sales"], periods, [2500, 2300, 1900, 2100, 1700, 1900, 2000]));
    }
    if (includeBalanceAppendix) {
      children.push(new d.Paragraph({ children: [new d.PageBreak()] }), heading("Appendix B — Quarterly balance sheet"));
      const balancePeriods = seriesAtOrBefore(monitor.balanceSheets, monitor.financialPeriodEnd);
      children.push(table(["Period", "Cash", "Current assets", "Total assets", "Current liabilities", "Total liabilities", "Tangible net worth"], (compactAppendices ? balancePeriods.slice(-4) : balancePeriods).map((item) => [item.periodEnd || "Not provided", money(item.cash), money(item.currentAssets), money(item.totalAssets), money(item.currentLiabilities), money(item.totalLiabilities), money(item.tangibleNetWorth)]), [1900, 1900, 2200, 2200, 2200, 2200, 1800]));
    }
    if (monitor.outputProfile === "full") {
      const observationRows = activeMonitorObservations(monitor, state);
      children.push(new d.Paragraph({ children: [new d.PageBreak()] }), heading("Appendix C — Dated observation ledger"));
      children.push(table(
        ["Field / label", "Entity", "Period", "As-of", "Value", "Source locator"],
        observationRows.map((item) => [`${item.path || "Unmapped"} — ${item.label || "Observation"}`, item.entity || "Not stated", item.periodType || "Not stated", item.asOfDate || "Not stated", observationDisplay(item), item.locator || "Not supplied"]),
        [3500, 2200, 1700, 1500, 2100, 3400]
      ));
      children.push(p(`Profile-bound staged observations only: ${observationRows.length} record(s) at or before the applicable review, financial or inventory cutoff. Additional workbook values outside the mapped observation contract are not represented as ledger facts.`));
    }

    const document = baseDocumentOptions(state, `${monitor.identity?.borrower || state.deal.borrower || "Borrower"} Quarterly Portfolio Monitor`, children, { landscape: true, footerNote: ready ? "Workflow complete ≠ approval, waiver or automated rating" : "DRAFT — controls remain open" });
    const blob = await h.d.Packer.toBlob(document);
    downloadBlob(blob, `${safeFileName(monitor.identity?.borrower || state.deal.borrower || "Borrower")}-${safeFileName(monitor.reportingPeriodEnd || "Quarterly")}-Portfolio-Monitor.docx`);
  }

  async function exportMemo(state) {
    if (state.authoring) return exportAuthoredDraft(state);
    const frozen = await freezeExportSnapshot(state);
    state = frozen.state;
    state._export = frozen;
    const h = createDocHelpers();
    const { d, p, heading, table, bullet, text, paleRed } = h;
    const openIssues = (state.issues || []).filter((issue) => issue.status === "open");
    const openBlockers = openIssues.filter((issue) => issue.severity === "blocker");
    const nonBlockingIssues = openIssues.filter((issue) => issue.severity !== "blocker");
    const currentChanges = currentRecords(state.changes);
    const currentRisks = currentRecords(state.risks);
    const currentCovenants = currentRecords(state.covenants);
    const ready = isReviewReady(state);
    const children = [
      ...titleBlock(state, "Credit memorandum", h),
      new d.Paragraph({ children: [new d.PageBreak()] }),
      heading("Credit officer decision brief"),
      table(
        ["Current commitment", "Proposed commitment", "Outstanding", "Pro forma relationship"],
        [[factDisplay(state, "facility.currentCommitment"), factDisplay(state, "facility.proposedCommitment"), factDisplay(state, "facility.outstanding"), factDisplay(state, "relationship.proFormaExposure")]]
      ),
      heading("Decision metrics", d.HeadingLevel.HEADING_2),
      decisionMetrics(state, h),
      heading("Underwriting scope and workbook controls", d.HeadingLevel.HEADING_2),
      table(["Control", "Recorded value", "Credit review meaning"], underwritingScopeRows(state), [3200, 6000, 5200]),
      heading("Selected downside scenario controls", d.HeadingLevel.HEADING_2),
      table(["Assumption / control", "Recorded value", "Application"], selectedScenarioRows(state), [3400, 5200, 5800]),
      ...applicabilityContent(state, h, "Applicability matrix"),
      heading("Open approval blockers", d.HeadingLevel.HEADING_2),
      ...(openBlockers.length ? openBlockers.map((issue) => bullet(`${issue.title || "Untitled blocker"} — ${issue.detail || "No detail recorded"}`)) : [p("No open approval blockers.")]),
      ...(nonBlockingIssues.length ? [
        heading("Warning register", d.HeadingLevel.HEADING_2),
        ...nonBlockingIssues.map((issue) => bullet(`${clean(issue.severity || "note").toUpperCase()}: ${issue.title || "Untitled item"} — ${issue.detail || "No detail recorded"}`))
      ] : []),
      heading("What changed", d.HeadingLevel.HEADING_2),
      table(["Field", "Prior approval", "Current", "Proposed", "Credit impact"], currentChanges.map((change) => [change.field, change.prior, change.current, change.proposed, change.impact]), [1800, 1400, 1400, 1600, 4600]),
      new d.Paragraph({ children: [new d.PageBreak()] })
    ];

    (state.memoSections || []).forEach((section, index) => {
      children.push(heading(section.title || "Untitled memo section"));
      const sectionEvidence = memoSectionEvidence(state, section);
      const narrativeLines = clean(section.narrative || "Not yet completed.").replace(/\r\n?/g, "\n").split("\n");
      children.push(new d.Paragraph({
        children: [
          ...narrativeLines.map((line, lineIndex) => text(line || " ", lineIndex ? { break: 1 } : undefined)),
          text(sectionEvidence.label, { break: 1, size: 16, color: h.gray, italics: true })
        ],
        spacing: { line: 285, after: 110 }
      }));
      if (section.id === "covenants" && currentCovenants.length) {
        children.push(table(
          ["Covenant / test", "Requirement", "Actual", "Headroom", "Trend", "Status"],
          currentCovenants.map((covenant) => [covenant.name || "Not stated", covenant.threshold || "Not stated", covenant.actual || "Not stated", covenant.headroom || "Not stated", covenant.trend || "Not stated", covenant.status || "Not stated"]),
          [2100, 1800, 1500, 1500, 3000, 1500]
        ));
      }
      if (section.id === "risks") {
        children.push(table(
          ["Risk", "Evidence / consequence", "Mitigant", "Residual risk", "Condition / trigger"],
          currentRisks.map((risk) => [risk.title || "Not stated", `${risk.evidence || "Not stated"} ${risk.consequence || ""}`.trim(), `${risk.mitigant || "Not stated"}${risk.type ? ` (${risk.type})` : ""}`, risk.residual || "Not stated", risk.condition || "Not stated"]),
          [1800, 2800, 2200, 1800, 2200]
        ));
      }
      if (section.id === "conditions") {
        children.push(table(
          ["Timing", "Requirement", "Credit purpose", "Owner / verification"],
          state.conditions.map((condition) => [condition.phase || "Not stated", condition.requirement || "Not stated", condition.purpose || "Not stated", `${condition.owner || "Not stated"}; ${condition.verification || "Not stated"}`]),
          [1600, 3900, 2600, 2700]
        ));
      }
      if (index === 7) children.push(new d.Paragraph({ children: [new d.PageBreak()] }));
    });

    if (!ready) {
      children.push(heading("Draft limitation"));
      children.push(new d.Table({
        width: { size: 100, type: d.WidthType.PERCENTAGE },
        rows: [new d.TableRow({ children: [new d.TableCell({
          shading: { fill: paleRed },
          margins: { top: 140, bottom: 140, left: 150, right: 150 },
          children: [new d.Paragraph({ children: [text("WORKING DRAFT", { bold: true, color: "A23632" })] }), p("This memo is not Review Ready. Finalization requires zero open approval blockers, zero unresolved conflicts and completion of all required portfolio-manager attestations.")]
        })] })]
      }));
    }

    const document = baseDocumentOptions(state, `${state.deal.borrower || "Untitled Deal"} Credit Memorandum`, children);
    const blob = await h.d.Packer.toBlob(document);
    downloadBlob(blob, `${safeFileName(state.deal.borrower || "Untitled-Deal")}-${safeFileName(state.deal.dealType || "Draft")}-Credit-Memo.docx`);
  }

  async function exportReviewPack(state) {
    const frozen = await freezeExportSnapshot(state);
    state = frozen.state;
    state._export = frozen;
    const h = createDocHelpers(true);
    const { d, p, heading, table, bullet } = h;
    const ready = isReviewReady(state);
    const lineageHeaders = ["Fact ID", "Canonical field", "Entity", "Period / scenario", "As-of", "Value", "Source / locator", "Ledger state / controlling"];
    const lineageWidths = [800, 2200, 1500, 1500, 1100, 1200, 3200, 2900];
    const lineageRows = state.facts.map((fact) => [
      fact.id || "—",
      fact.path || "Not stated",
      fact.entity || "Not stated",
      `${fact.periodType || "Not stated"} / ${fact.scenario || "actual"}`,
      fact.asOfDate || "Not stated",
      factValue(fact),
      `${fact.sourceId || "PM"} • ${fact.locator || "Not supplied"}`,
      `${fact.status || "Not stated"} / ${controllingLabel(state, fact)}`
    ]);
    const lineageChunks = [];
    for (let index = 0; index < lineageRows.length; index += 10) lineageChunks.push(lineageRows.slice(index, index + 10));
    if (!lineageChunks.length) lineageChunks.push([]);
    const lineageContent = [];
    lineageChunks.forEach((chunk, index) => {
      if (index) {
        lineageContent.push(new d.Paragraph({ children: [new d.PageBreak()] }));
        lineageContent.push(heading("3. Material fact lineage (continued)", d.HeadingLevel.HEADING_2));
      }
      lineageContent.push(table(lineageHeaders, chunk, lineageWidths));
    });
    const children = [
      ...titleBlock(state, "Credit review pack", h),
      new d.Paragraph({ children: [new d.PageBreak()] }),
      heading("1. Decision metrics and formulas"),
      table(
        ["ID", "Calculation / formula", "Named inputs", "Full precision / display", "Comparison", "Status"],
        state.calculations.map((calc) => [calc.id || "—", `${calc.name || "Not stated"} — ${calc.formula || "Formula not stated"}`, Array.isArray(calc.inputs) && calc.inputs.length ? calc.inputs.join(", ") : "Not stated", `${calc.result == null ? "Not recorded" : clean(calc.result)} / ${calc.display || "No display value"}`, calc.comparison || "Not stated", clean(calc.status || "review").toUpperCase()]),
        [800, 2800, 3000, 2400, 3600, 1800]
      ),
      heading("1A. Selected downside scenario controls", d.HeadingLevel.HEADING_2),
      table(["Assumption / control", "Recorded value", "Application / lineage"], selectedScenarioRows(state), [3400, 5200, 5800]),
      heading("2. Source register"),
      table(
        ["ID", "Source", "Type", "As-of", "Packet", "Status"],
        state.sources.map((source) => [source.id || "—", source.name || "Not stated", source.type || "Not stated", source.asOfDate || "Not stated", source.packet || "—", source.status || "Not stated"]),
        [900, 4600, 3100, 1600, 1400, 1800]
      ),
      heading("2A. Underwriting scope and workbook controls", d.HeadingLevel.HEADING_2),
      table(["Control", "Recorded value", "Review meaning"], underwritingScopeRows(state), [3200, 6000, 5200]),
      new d.Paragraph({ children: [new d.PageBreak()] }),
      heading("3. Material fact lineage"),
      ...lineageContent,
      new d.Paragraph({ children: [new d.PageBreak()] }),
      heading("4. Conflicts and resolutions"),
      ...(state.conflicts.length ? state.conflicts.map((conflict) => bullet(conflictNarrative(state, conflict))) : [p("No conflicts identified.")]),
      heading("5. Transaction-change and covenant history"),
      table(
        ["Record state", "Field", "Prior", "Current", "Proposed", "Credit impact", "Evidence"],
        state.changes.map((change) => [recordState(change), change.field || "Not stated", change.prior || "Not stated", change.current || "Not stated", change.proposed || "Not stated", change.impact || "Not stated", evidenceIds(change)]),
        [1900, 1700, 1300, 1300, 1500, 4300, 2600]
      ),
      table(
        ["Record state", "Covenant / test", "Requirement", "Actual", "Headroom", "Trend", "Result", "Evidence"],
        state.covenants.map((covenant) => [recordState(covenant), covenant.name || "Not stated", covenant.threshold || "Not stated", covenant.actual || "Not stated", covenant.headroom || "Not stated", covenant.trend || "Not stated", covenant.status || "Not stated", evidenceIds(covenant)]),
        [1900, 2300, 1600, 1300, 1300, 2800, 1500, 2300]
      ),
      heading("6. Risks, mitigants and conditions"),
      table(
        ["Record state", "Risk", "Evidence", "Consequence", "Mitigant / type", "Residual risk", "Condition"],
        state.risks.map((risk) => [recordState(risk), risk.title || "Not stated", risk.evidence || "Not stated", risk.consequence || "Not stated", `${risk.mitigant || "Not stated"}${risk.type ? ` ${risk.type}` : ""}`, risk.residual || "Not stated", risk.condition || "Not stated"]),
        [1900, 1800, 2300, 2000, 2300, 2100, 2300]
      ),
      heading("Condition register", d.HeadingLevel.HEADING_2),
      table(
        ["ID / timing", "Requirement", "Credit purpose", "Owner", "Verification / status"],
        state.conditions.map((condition) => [`${condition.id || "—"} / ${condition.phase || "Not stated"}`, condition.requirement || "Not stated", condition.purpose || "Not stated", condition.owner || "Not stated", `${condition.verification || "Not stated"}; ${condition.status || "Status not stated"}`]),
        [1900, 4300, 3200, 1800, 3200]
      ),
      heading("7. Open-item and warning register"),
      table(
        ["Severity", "Item", "Detail", "Status / resolution type", "Resolution evidence", "Resolution rationale", "Resolved at"],
        state.issues.map((issue) => {
          const resolution = issueResolution(issue);
          return [clean(issue.severity || "note").toUpperCase(), issue.title || "Untitled item", issue.detail || "No detail recorded", `${issue.status || "Not stated"} / ${resolution.type}`, resolution.evidence, resolution.rationale, resolution.resolvedAt];
        }),
        [1000, 2300, 2700, 1800, 1700, 3300, 1600]
      ),
      heading("Governed edit history", d.HeadingLevel.HEADING_2),
      table(
        ["Recorded at", "Section / record", "Action"],
        (state.editHistory || []).map((entry) => [entry.at || "Time not recorded", entry.sectionId || entry.recordId || "Deal record", entry.action || "Action not stated"]),
        [2400, 2700, 9300]
      )
    ];

    if (state.monitor) {
      const monitor = state.monitor;
      const latestBalance = latestAtOrBefore(monitor.balanceSheets, monitor.financialPeriodEnd) || {};
      const latestInventory = latestAtOrBefore(monitor.inventorySeries, monitor.inventoryPeriodEnd) || {};
      const includesFinancialAppendix = monitor.outputProfile === "standard" || monitor.outputProfile === "full" || monitor.includeFinancialTables;
      const includesBalanceAppendix = monitor.outputProfile === "standard" || monitor.outputProfile === "full" || monitor.includeBalanceSheetTable;
      children.push(
        new d.Paragraph({ children: [new d.PageBreak()] }),
        heading("8. Quarterly-monitor diagnostics"),
        table(["Control", "Recorded value", "Evidence / disposition"], [
          ["Review cutoff", monitor.reviewAsOfDate || "Not entered", "Explicit date; no computer-clock substitution"],
          ["Financial cutoff", monitor.financialPeriodEnd || "Not entered", monitor.financialNarrative || "No financial narrative"],
          ["Inventory cutoff", monitor.inventoryPeriodEnd || "Not entered", "Latest mapped observation on or before cutoff"],
          ["Workbook profile", monitor.profile || "Not entered", monitor.profileMatched ? "Exact profile matched" : "Profile mismatch"],
          ["Output profile", monitor.outputProfile || "executive", `Financial appendix ${includesFinancialAppendix ? "included" : "omitted"}; balance-sheet appendix ${includesBalanceAppendix ? "included" : "omitted"}; staged-observation ledger ${monitor.outputProfile === "full" ? "included" : "omitted"}`]
        ], [3200, 3000, 8200]),
        heading("PM assessment and rating judgment", d.HeadingLevel.HEADING_2),
        table(["Judgment", "Recorded conclusion / rationale"], [
          ["Assessment", monitor.assessment || "Not entered"],
          ["Current → recommended rating", `${monitor.rating?.current || "Not entered"} → ${monitor.rating?.recommended || "Not entered"}`],
          ["Rating rationale", monitor.ratingRationale || "Not entered"],
          ["Portfolio conclusion", monitor.conclusion || "Not entered"]
        ], [3800, 10600]),
        heading("Monitor watch-item register", d.HeadingLevel.HEADING_2),
        table(["Severity", "ID", "Signal", "Detail", "Module", "Owner", "Status"], (monitor.watchItems || []).map((item) => [clean(item.severity || "note").toUpperCase(), item.id || "—", item.title || "Untitled", item.detail || "No detail", item.module || "Monitor", item.owner || "Portfolio Manager", item.status || "open"]), [1300, 1200, 2700, 4800, 1800, 1900, 1200]),
        heading("Workbook anomalies", d.HeadingLevel.HEADING_2),
        table(["Severity", "Code", "Anomaly", "Disposition / locator"], (monitor.anomalies || []).map((item) => [clean(item.severity || "note").toUpperCase(), item.id || "—", `${item.title || "Untitled"}: ${item.detail || "No detail"}`, `${item.status || "open"}; ${item.locator || "not supplied"}`]), [1500, 1600, 7600, 3700]),
        heading("Reporting schedule", d.HeadingLevel.HEADING_2),
        table(["Item", "Frequency", "Last received", "Due", "Status", "Locator"], (monitor.reportingItems || []).map((item) => [item.name || "Not stated", item.frequency || "Not stated", item.lastReceivedPeriodEnd || "Not supplied", item.dueDate || "Not supplied", item.status || "Review required", item.locator || "Not supplied"]), [3900, 1700, 2200, 2200, 1700, 2700]),
        heading("Covenant tests", d.HeadingLevel.HEADING_2),
        table(["ID", "Covenant", "Test date", "Requirement", "Actual", "Headroom", "Reported / computed", "Locator"], (monitor.covenants || []).map((item) => [item.id || "—", item.name || "Not stated", item.testDate || "Not supplied", monitorValue(item.threshold, item.valueType), monitorValue(item.actual, item.valueType), item.comparable === false ? "Not comparable" : monitorValue(item.headroom, item.valueType), `${item.sourceStatus || item.status || "Review required"} / ${item.computedStatus || "Review required"}${item.outcomeMismatch ? " — MISMATCH" : ""}`, item.locator || "Not supplied"]), [1300, 2600, 1600, 1800, 1800, 1800, 2800, 2500]),
        heading("Structured monitoring actions", d.HeadingLevel.HEADING_2),
        table(["ID", "Scope", "Action", "Owner", "Due", "Status", "Evidence"], (monitor.actions || []).map((item) => [item.id || "—", item.reportingItemId || item.covenantId || item.relatedControlId || "General", item.action || "Not stated", item.owner || "Unassigned", item.dueDate || "Not dated", item.status || "Open", item.evidence || "Not supplied"]), [1500, 2200, 4700, 1900, 1500, 1500, 3200]),
        heading("Balance-sheet and inventory reconciliation", d.HeadingLevel.HEADING_2),
        table(["Control", "Period", "Recorded value", "Reconciliation / limitation"], [
          ["Balance-sheet cross-foot", latestBalance.periodEnd || "Not supplied", money(latestBalance.crossFootDifference), latestBalance.crossFootDifference == null ? "Cannot be evaluated" : Math.abs(Number(latestBalance.crossFootDifference)) < 1 ? "Assets = liabilities + net worth" : "Difference requires structured disposition"],
          ["Tangible net worth", latestBalance.periodEnd || "Not supplied", money(latestBalance.tangibleNetWorth), latestBalance.riskAssets == null ? "Risk assets not supplied; not treated as zero" : `Risk assets ${money(latestBalance.riskAssets)}`],
          ["Owned / controlled lots", latestInventory.periodEnd || "Not supplied", monitorValue(latestInventory.lotsOwnedControlled, "number"), `${monitorValue(latestInventory.lotMonthsSupply, "months")} workbook supply; ${latestInventory.dataGranularity || "granularity not stated"}`],
          ["Owned units / backlog", latestInventory.periodEnd || "Not supplied", `${monitorValue(latestInventory.totalUnits, "number")} / ${monitorValue(latestInventory.backlog, "number")}`, "Latest observation at or before inventory cutoff"]
        ], [3300, 2100, 3000, 6000]),
        heading("Monitor calculations", d.HeadingLevel.HEADING_2),
        table(["ID", "Calculation", "Result", "Formula", "Comparison", "Status"], (monitor.calculations || []).map((item) => [item.id || "—", item.name || "Not stated", monitorValue(item.result, item.valueType), item.formula || "Not stated", item.comparison || "Not stated", item.status || "review"]), [1700, 2600, 1700, 3300, 3500, 1600])
      );
    }

    const applicability = applicabilityContent(state, h, `${state.monitor ? "9" : "8"}. Applicability matrix`);
    children.push(...applicability);
    children.push(
      heading(`${state.monitor ? "10" : applicability.length ? "9" : "8"}. PM attestations and version record`),
      table(
        ["Control", "Status", "Attestation evidence"],
        [
          ["Source facts reviewed", state.attestations.facts ? "Attested" : "Not attested", state.attestationMetadata?.facts ? `${state.attestationMetadata.facts.actor || "Portfolio Manager"}; ${state.attestationMetadata.facts.at || "time not recorded"}; revision ${state.attestationMetadata.facts.revision ?? "not recorded"}` : "Not recorded"],
          ["Recorded calculations and assumptions reviewed", state.attestations.calculations ? "Attested" : "Not attested", state.attestationMetadata?.calculations ? `${state.attestationMetadata.calculations.actor || "Portfolio Manager"}; ${state.attestationMetadata.calculations.at || "time not recorded"}; revision ${state.attestationMetadata.calculations.revision ?? "not recorded"}` : "Not recorded"],
          ["Narrative and credit judgments owned by PM", state.attestations.judgment ? "Attested" : "Not attested", state.attestationMetadata?.judgment ? `${state.attestationMetadata.judgment.actor || "Portfolio Manager"}; ${state.attestationMetadata.judgment.at || "time not recorded"}; revision ${state.attestationMetadata.judgment.revision ?? "not recorded"}` : "Not recorded"],
          ["Risk rating selected and owned by PM", state.attestations.rating ? "Attested" : "Not attested", state.attestationMetadata?.rating ? `${state.attestationMetadata.rating.actor || "Portfolio Manager"}; ${state.attestationMetadata.rating.at || "time not recorded"}; revision ${state.attestationMetadata.rating.revision ?? "not recorded"}` : "Not recorded"],
          ["Application profile", `HBF Credit Decision Studio v${APP_VERSION}`, "Application version"],
          ["Workbook profile", state.monitor ? state.monitorWorkbook?.profile || state.monitor.profile || "Not loaded" : state.workbook.profile || "Not loaded", "Profile-bound adapter"],
          ["Frozen snapshot", state._export?.snapshotId || "Not available", "SHA-256-derived short snapshot ID"],
          ["Snapshot digest", state._export?.digest || "Not available", "Unkeyed SHA-256 corruption checksum; not source authentication"],
          ["Generated locally", state._export?.generatedAt || "Not available", "User-initiated export"],
          ["Packet schema", state.schemaVersion || "1.0", "State contract"],
          ["Finalization state", ready ? workflowCompletionLabel(state) : "Draft", "Workflow completion only; not credit approval"]
        ],
        [5000, 3300, 6100]
      )
    );

    const document = baseDocumentOptions(state, `${state.deal.borrower || "Untitled Deal"} Credit Review Pack`, children, { landscape: true });
    const blob = await h.d.Packer.toBlob(document);
    downloadBlob(blob, `${safeFileName(state.deal.borrower || "Untitled-Deal")}-${safeFileName(state.deal.dealType || "Draft")}-Credit-Review-Pack.docx`);
  }

  function csvText(rows) {
    return rows.map((row) => row.map((value) => {
      const cleaned = clean(value);
      const leftTrimmed = cleaned.replace(/^[\s\uFEFF]+/, "");
      const numericCandidate = leftTrimmed.replace(/[\s\uFEFF]+$/, "");
      const ordinaryNegativeNumber = /^-\d+(?:,\d{3})*(?:\.\d+)?(?:[eE][+-]?\d+)?$/.test(numericCandidate);
      const neutralized = /^[=+\-@]/.test(leftTrimmed) && !ordinaryNegativeNumber
        ? `'${cleaned}`
        : cleaned;
      return `"${neutralized.replace(/"/g, '""')}"`;
    }).join(",")).join("\r\n");
  }

  async function exportOpenItems(input) {
    const frozen = await freezeExportSnapshot(input);
    const state = frozen.state;
    const actions = [
      ...state.issues.filter((item) => item.status === "open").map((item) => ({ priority: item.severity, category: "Issue", itemId: item.id, scopeType: item.actionView || "Workflow", scopeId: item.actionView || item.id, item: item.title, detail: item.detail, owner: item.owner, timing: item.timing || "", dueDate: validIsoDate(item.dueDate) ? item.dueDate : "", status: item.status, evidence: item.evidenceId || "", verification: item.verification || "" })),
      ...unresolvedConflicts(state).map((item) => ({ priority: "blocker", category: "Conflict", itemId: item.id, scopeType: "Canonical fact", scopeId: item.fieldPath || item.path || item.id, item: item.label || item.fieldPath || "Fact conflict", detail: "Select the controlling same-scope fact and record rationale.", owner: "Portfolio Manager", timing: "Before review", dueDate: "", status: item.status || "open", evidence: (item.candidates || []).join(" | "), verification: "Controlling fact selection and PM rationale" })),
      ...monitorActionRows(state).map((item) => ({ priority: item.severity, category: "Monitor", ...item }))
    ];
    const rank = { blocker: 0, condition: 1, warning: 2, action: 3, note: 4 };
    actions.sort((a, b) => (rank[a.priority] ?? 9) - (rank[b.priority] ?? 9) || clean(a.dueDate || "9999").localeCompare(clean(b.dueDate || "9999")));
    const rows = [["Borrower", "Deal ID", "Review ID", "Workflow", "Priority", "Category", "Item ID", "Scope type", "Scope ID", "Action / item", "Detail", "Owner", "Timing", "Due date", "Status", "Evidence", "Verification", "Reporting Item ID", "Covenant ID", "Related Control ID", "Recorded at", "Snapshot ID"], ...actions.map((item) => [state.deal.borrower || state.monitor?.identity?.borrower || "Not entered", state.deal.id || "", state.monitor?.reviewId || "", state.workflow || "credit_action", item.priority || "note", item.category || "Action", item.itemId || "", item.scopeType || "Workflow", item.scopeId || item.itemId || "", item.item || "Untitled action", item.detail || "", item.owner || "Unassigned", item.timing || "", validIsoDate(item.dueDate) ? item.dueDate : "", item.status || "Open", item.evidence || "", item.verification || "", item.reportingItemId || "", item.covenantId || "", item.relatedControlId || "", item.recordedAt || "", frozen.snapshotId])];
    downloadBlob(new Blob([csvText(rows)], { type: "text/csv;charset=utf-8" }), `${safeFileName(state.deal.borrower || "Untitled-Deal")}-Open-Actions.csv`);
  }

  async function exportPortfolioRollup(input) {
    const frozen = await freezeExportSnapshot(input);
    const state = frozen.state;
    const monitor = state.monitor;
    if (!monitor) throw new Error("No quarterly monitor is loaded.");
    const bank = latestAtOrBefore(monitor.bankingSeries, monitor.reviewAsOfDate) || {};
    const quarter = latestAtOrBefore(monitor.financial?.quarterly, monitor.financialPeriodEnd) || {};
    const ttm = latestAtOrBefore(monitor.financial?.ttm, monitor.financialPeriodEnd) || {};
    const balance = latestAtOrBefore(monitor.balanceSheets, monitor.financialPeriodEnd) || {};
    const inventory = latestAtOrBefore(monitor.inventorySeries, monitor.inventoryPeriodEnd) || {};
    const openExceptions = sortedExceptions(monitor);
    const pastDue = (monitor.reportingItems || []).filter((item) => item.status === "Past due");
    const covenantBreaches = (monitor.covenants || []).filter(confirmedCovenantBreach);
    const covenantReviewRequired = (monitor.covenants || []).filter((item) => covenantRequiresReview(item) && !confirmedCovenantBreach(item));
    const rows = [
      ["Borrower", "Obligor number", "Review date", "Financial period", "Inventory cutoff", "Inventory period", "Banking period", "Current rating", "Recommended rating", "Assessment", "Commitment (USD)", "Outstanding (USD)", "Utilization (decimal)", "Deposits (USD)", "Deposits / UPB (decimal)", "Quarter revenue (USD)", "Quarter net income (USD)", "TTM revenue (USD)", "TTM net income (USD)", "TTM gross margin (decimal)", "Tangible net worth (USD)", "Lots controlled (count)", "Open signals (count)", "Past-due reports (count)", "Covenant breaches (count)", "Covenant review-required / non-comparable (count)", "Days to maturity (days)", "Package status", "Snapshot ID", "Snapshot digest (SHA-256)"],
      [monitor.identity?.borrower || state.deal.borrower || "", monitor.identity?.obligorNumber || "", monitor.reviewAsOfDate || "", monitor.financialPeriodEnd || "", monitor.inventoryPeriodEnd || "", inventory.periodEnd || "", bank.periodEnd || "", monitor.rating?.current || "", monitor.rating?.recommended || "", monitor.assessment || "", bank.applicableCommitment ?? monitor.facility?.grossCommitment ?? "", bank.outstanding ?? "", bank.utilization ?? "", bank.deposits ?? "", bank.depositCoverage ?? "", quarter.revenue ?? "", quarter.netIncome ?? "", ttm.revenue ?? "", ttm.netIncome ?? "", ttm.grossMargin ?? "", balance.tangibleNetWorth ?? "", inventory.lotsOwnedControlled ?? "", openExceptions.length, pastDue.length, covenantBreaches.length, covenantReviewRequired.length, verifiedMaturityDays(monitor) ?? "", isReviewReady(state) ? "Review Package Complete" : "Draft", frozen.snapshotId, frozen.digest]
    ];
    downloadBlob(new Blob([csvText(rows)], { type: "text/csv;charset=utf-8" }), `${safeFileName(monitor.identity?.borrower || "Borrower")}-${safeFileName(monitor.reportingPeriodEnd || "Quarterly")}-Portfolio-Rollup.csv`);
  }

  function checkpointPreflight(state) {
    if (state.authoring) {
      if (!window.HBFAuthoring) throw new Error('The document editor is unavailable. Your current draft is unchanged.');
      window.HBFAuthoring.validate(state.authoring,state.workflow);
    }
    window.HBFAuthoringLegacy?.validate(state.authoringMigration);
    const limits = { sources: 500, facts: 20000, calculations: 5000, conflicts: 5000, issues: 10000, risks: 2000, conditions: 2000, covenants: 5000, changes: 5000, memoSections: 100 };
    for (const [key, limit] of Object.entries(limits)) {
      if (!Array.isArray(state[key])) throw new Error(`Checkpoint ${key} must be an array.`);
      if (state[key].length > limit) throw new Error(`Checkpoint ${key} exceeds the ${limit.toLocaleString()}-record safety limit.`);
    }
    const encoded = new TextEncoder().encode(JSON.stringify(state));
    if (encoded.byteLength > 10 * 1024 * 1024) throw new Error("Checkpoint exceeds the 10 MB safety limit and was not created.");
  }

  async function exportCheckpoint(input) {
    const state = normalizeState(JSON.parse(JSON.stringify(input || {})));
    checkpointPreflight(state);
    const stateDigest = await digestCanonical(state);
    const envelope = {
      checkpointFormat: "HBF-CDS-CHECKPOINT",
      checkpointVersion: state.authoring ? "1.3" : "1.1",
      applicationVersion: APP_VERSION,
      exportedAt: new Date().toISOString(),
      stateDigest,
      digestAlgorithm: "SHA-256 over canonical JSON",
      notice: "User-initiated local checkpoint. The unkeyed SHA-256 value detects accidental corruption; it does not authenticate who created or modified the file. Store only in an approved bank location. Customer data is not transmitted by this application.",
      state
    };
    const payload = `${JSON.stringify(envelope, null, 2)}\n`;
    const payloadBytes = new TextEncoder().encode(payload).byteLength;
    if (payloadBytes > 10 * 1024 * 1024) throw new Error("Final checkpoint envelope exceeds the 10 MB import safety limit and was not created.");
    downloadBlob(new Blob([payload], { type: "application/json" }), `${safeFileName(state.deal.id || state.monitor?.reviewId || "Untitled-Deal")}-Local-Checkpoint.json`);
  }

  function htmlEscape(value) {
    return clean(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function printTable(headers, rows) {
    return `<table class="print-table"><thead><tr>${headers.map((item) => `<th>${htmlEscape(item)}</th>`).join("")}</tr></thead><tbody>${rows.map((row) => `<tr>${row.map((item) => `<td>${htmlEscape(item == null ? "" : item)}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
  }

  function printPage(frozen, title, subtitle, body, draft) {
    return `<section class="print-page"><header class="print-header"><span>Home Builder Finance</span><span>${htmlEscape(frozen.state.deal.id || frozen.state.monitor?.reviewId || "Record")}</span></header>${draft ? '<div class="print-draft">DRAFT</div>' : ""}<h1 class="print-title">${htmlEscape(title)}</h1><p class="print-subtitle">${htmlEscape(subtitle)}</p>${body}<footer class="print-footer"><span>Confidential credit work product</span><span>${htmlEscape(frozen.snapshotId)}</span></footer></section>`;
  }

  async function buildPrintHtml(input, kind) {
    const frozen = await freezeExportSnapshot(input);
    const state = frozen.state;
    const ready = isReviewReady(state);
    if (kind === "monitor") {
      const monitor = state.monitor;
      if (!monitor) throw new Error("No quarterly monitor is loaded.");
      const bank = latestAtOrBefore(monitor.bankingSeries, monitor.reviewAsOfDate) || {};
      const quarter = latestAtOrBefore(monitor.financial?.quarterly, monitor.financialPeriodEnd) || {};
      const ytd = latestAtOrBefore(monitor.financial?.ytd, monitor.financialPeriodEnd) || {};
      const ttm = latestAtOrBefore(monitor.financial?.ttm, monitor.financialPeriodEnd) || {};
      const balance = latestAtOrBefore(monitor.balanceSheets, monitor.financialPeriodEnd) || {};
      const inventory = latestAtOrBefore(monitor.inventorySeries, monitor.inventoryPeriodEnd) || {};
      const executiveConclusion = executiveExcerpt(monitor.conclusion, 290, "PM conclusion required.");
      const executiveRatingRationale = executiveExcerpt(monitor.ratingRationale, 180, "Required");
      const borrowerLabel = executiveLabel(monitor.identity?.borrower || state.deal.borrower, 44, "Borrower");
      const currentRatingLabel = executiveLabel(monitor.rating?.current, 10, "—");
      const recommendedRatingLabel = executiveLabel(monitor.rating?.recommended, 10, "—");
      const assessmentLabel = executiveLabel(monitor.assessment, 50, "Required");
      const pageOne = `<div class="print-decision-strip"><div><small>PM assessment</small><strong>${htmlEscape(assessmentLabel)}</strong><span>${htmlEscape(ready ? "Review package complete" : "Controls remain open")}</span></div><div><small>Risk rating</small><strong>${htmlEscape(`${currentRatingLabel} → ${recommendedRatingLabel}`)}</strong></div><div><small>Outstanding</small><strong>${htmlEscape(money(bank.outstanding))}</strong><span>${htmlEscape(monitorValue(bank.utilization, "percent"))} utilized</span></div><div><small>Deposits / UPB</small><strong>${htmlEscape(monitorValue(bank.depositCoverage, "percent"))}</strong><span>${htmlEscape(bank.periodEnd || "No cutoff")}</span></div><div><small>Maturity</small><strong>${htmlEscape(monitor.facility?.lineMaturity || "Not provided")}</strong></div></div><div class="print-card"><h2>Officer decision brief</h2><p>${htmlEscape(executiveConclusion)}</p></div><h2 class="print-section-title">Performance at cutoff</h2>${printTable(["Period", "Revenue", "Gross margin", "Net income", "Closings", "Net sales"], [monitorPeriodRow(quarter, `Quarter ${quarter.periodEnd || ""}`).filter((_, index) => index !== 4), monitorPeriodRow(ytd, `YTD ${ytd.periodEnd || ""}`).filter((_, index) => index !== 4), monitorPeriodRow(ttm, `TTM ${ttm.periodEnd || ""}`).filter((_, index) => index !== 4)])}<div class="print-grid-2" style="margin-top:8px"><div class="print-card"><h2>Rating rationale</h2><p>${htmlEscape(executiveRatingRationale)}</p></div><div class="print-card"><h2>Cutoff integrity</h2><p>Review ${htmlEscape(monitor.reviewAsOfDate || "—")}; financial ${htmlEscape(monitor.financialPeriodEnd || "—")}; inventory ${htmlEscape(monitor.inventoryPeriodEnd || "—")}; banking ${htmlEscape(bank.periodEnd || "—")}. Computer date is not used.</p></div></div>`;
      const allExceptions = sortedExceptions(monitor);
      const exceptionItems = allExceptions.slice(0, 2);
      const covenantItems = [...(monitor.covenants || []).filter(covenantRequiresReview), ...(monitor.covenants || []).filter((item) => !covenantRequiresReview(item))].slice(0, 3);
      const reportingRank = { "Past due": 0, "Review required": 1, "Due soon": 2, Current: 3 };
      const reportingItems = [...(monitor.reportingItems || [])].sort((a, b) => (reportingRank[a.status] ?? 9) - (reportingRank[b.status] ?? 9) || clean(a.dueDate || "9999").localeCompare(clean(b.dueDate || "9999"))).slice(0, 3);
      const actionItems = [...(monitor.actions || [])].sort((a, b) => Number(monitorActionIsTerminal(a)) - Number(monitorActionIsTerminal(b)) || clean(a.dueDate || "9999").localeCompare(clean(b.dueDate || "9999"))).slice(0, 1);
      const exceptionRows = exceptionItems.map((item) => [clean(item.severity || "note").toUpperCase(), executiveLabel(item.title, 110, "Untitled"), executiveExcerpt(item.detail, 250, "No detail recorded"), executiveLabel(item.module || item.locator, 90, "Monitor")]);
      const structuredActions = actionItems.map((item) => [executiveLabel(item.reportingItemId || item.covenantId || item.relatedControlId, 40, "General"), executiveExcerpt(item.action, 180, "Not stated"), executiveLabel(item.owner, 40, "Unassigned"), item.dueDate || "Not dated", executiveLabel(item.status, 20, "Open"), executiveExcerpt(item.evidence, 100, "Not supplied")]);
      const omitted = [allExceptions.length - exceptionItems.length, (monitor.covenants || []).length - covenantItems.length, (monitor.reportingItems || []).length - reportingItems.length, (monitor.actions || []).length - actionItems.length];
      const pageTwo = `<h2 class="print-section-title">Exceptions and signals</h2>${printTable(["Priority", "Signal", "Why it matters", "Module / locator"], exceptionRows.length ? exceptionRows : [["NOTE", "No open exceptions", "No exception recorded", "Monitor"]])}<h2 class="print-section-title">Covenant position</h2>${printTable(["Covenant", "Requirement", "Actual", "Headroom", "Result"], covenantItems.map((item) => [executiveLabel(item.name, 70, "Not stated"), monitorValue(item.threshold, item.valueType), monitorValue(item.actual, item.valueType), item.comparable === false ? "Not comparable" : monitorValue(item.headroom, item.valueType), executiveLabel(covenantResultLabel(item), 80, "Review required")]))}<div class="print-grid-2" style="margin-top:8px"><div class="print-card"><h2>Balance sheet</h2><p>${htmlEscape(balance.periodEnd || "—")}: cash ${htmlEscape(money(balance.cash))}; assets ${htmlEscape(money(balance.totalAssets))}; liabilities ${htmlEscape(money(balance.totalLiabilities))}; TNW ${htmlEscape(money(balance.tangibleNetWorth))}. Cross-foot ${htmlEscape(money(balance.crossFootDifference))}; risk assets ${balance.riskAssets == null ? "not supplied and not treated as zero" : htmlEscape(money(balance.riskAssets))}.</p></div><div class="print-card"><h2>Inventory</h2><p>${htmlEscape(inventory.periodEnd || "—")}: ${htmlEscape(monitorValue(inventory.totalUnits, "number"))} owned units plus ${htmlEscape(monitorValue(inventory.backlog, "number"))} backlog; ${htmlEscape(monitorValue(inventory.lotsOwnedControlled, "number"))} owned/controlled lots; ${htmlEscape(monitorValue(inventory.lotMonthsSupply, "months"))} lot supply.</p></div></div><h2 class="print-section-title">Reporting schedule</h2>${printTable(["Item", "Last received", "Due", "Status"], reportingItems.map((item) => [executiveLabel(item.name, 70, "Not stated"), item.lastReceivedPeriodEnd, item.dueDate, executiveLabel(item.status, 40, "Review required")]))}<h2 class="print-section-title">Structured actions and verification</h2>${structuredActions.length ? printTable(["Scope", "Action", "Owner", "Due", "Status", "Evidence"], structuredActions) : "<p>No structured monitoring action is recorded.</p>"}<p class="print-citations">Executive cells use bounded display; full text is in the credit review pack. Additional retained records: ${Math.max(0, omitted[0])} exceptions, ${Math.max(0, omitted[1])} covenants, ${Math.max(0, omitted[2])} reporting lines and ${Math.max(0, omitted[3])} actions. Review Package Complete is not an approval, waiver or automated risk-rating decision.</p>`;
      const pages = [
        printPage(frozen, `${borrowerLabel} — Quarterly Portfolio Monitor`, `Review as of ${monitor.reviewAsOfDate || "not entered"}`, pageOne, !ready),
        printPage(frozen, "Controls and exceptions", `Financial period ${monitor.financialPeriodEnd || "not entered"}`, pageTwo, !ready)
      ];
      const includeFinancialAppendix = monitor.outputProfile === "standard" || monitor.outputProfile === "full" || monitor.includeFinancialTables;
      const includeBalanceAppendix = monitor.outputProfile === "standard" || monitor.outputProfile === "full" || monitor.includeBalanceSheetTable;
      const compactAppendices = monitor.outputProfile === "standard";
      if (includeFinancialAppendix) {
        const appendixSeries = (series) => compactAppendices ? seriesAtOrBefore(series, monitor.financialPeriodEnd).slice(-2) : seriesAtOrBefore(series, monitor.financialPeriodEnd);
        const rows = [
          ...appendixSeries(monitor.financial?.quarterly).map((item) => monitorPeriodRow(item, `Quarter ${item.periodEnd}`)),
          ...appendixSeries(monitor.financial?.ytd).map((item) => monitorPeriodRow(item, `YTD ${item.periodEnd}`)),
          ...appendixSeries(monitor.financial?.ttm).map((item) => monitorPeriodRow(item, `TTM ${item.periodEnd}`))
        ];
        pages.push(printPage(frozen, "Appendix A — Financial statement trend", `Observations through ${monitor.financialPeriodEnd || "the stated cutoff"}`, `${printTable(["Period", "Revenue", "Gross margin", "Net income", "Net margin", "Closings", "Net sales"], rows)}<p class="print-citations">Saved workbook observations only; this browser does not perform a full Excel recalculation.</p>`, !ready));
      }
      if (includeBalanceAppendix) {
        const balancePeriods = seriesAtOrBefore(monitor.balanceSheets, monitor.financialPeriodEnd);
        const rows = (compactAppendices ? balancePeriods.slice(-4) : balancePeriods).map((item) => [item.periodEnd, money(item.cash), money(item.currentAssets), money(item.totalAssets), money(item.currentLiabilities), money(item.totalLiabilities), money(item.tangibleNetWorth)]);
        pages.push(printPage(frozen, "Appendix B — Quarterly balance sheet", `Observations through ${monitor.financialPeriodEnd || "the stated cutoff"}`, `${printTable(["Period", "Cash", "Current assets", "Total assets", "Current liabilities", "Total liabilities", "Tangible net worth"], rows)}<p class="print-citations">Missing values remain missing and cannot improve the monitoring conclusion.</p>`, !ready));
      }
      if (monitor.outputProfile === "full") {
        const observations = activeMonitorObservations(monitor, state);
        const rows = observations.map((item) => [`${item.path || "Unmapped"} — ${item.label || "Observation"}`, item.entity || "Not stated", item.periodType || "Not stated", item.asOfDate || "Not stated", observationDisplay(item), item.locator || "Not supplied"]);
        pages.push(printPage(frozen, "Appendix C — Dated observation ledger", "Profile-bound staged observations through the applicable cutoff", `${printTable(["Field / label", "Entity", "Period", "As-of", "Value", "Source locator"], rows)}<p class="print-citations">${rows.length} staged record(s). Additional workbook values outside the mapped observation contract are not represented as ledger facts.</p>`, !ready));
      }
      return { orientation: "landscape", snapshotId: frozen.snapshotId, html: `<article class="print-document landscape">${pages.join("")}</article>` };
    }

    const summary = `<div class="print-decision-strip"><div><small>Recommendation</small><strong>${htmlEscape(state.deal.recommendation || "Required")}</strong><span>${htmlEscape(ready ? "Review Ready" : "Draft — controls open")}</span></div><div><small>Request</small><strong>${htmlEscape(state.deal.request || "Not entered")}</strong></div><div><small>Current rating</small><strong>${htmlEscape(state.deal.currentRating || "—")}</strong></div><div><small>Proposed rating</small><strong>${htmlEscape(state.deal.proposedRating || "—")}</strong></div><div><small>As of</small><strong>${htmlEscape(state.deal.asOfDate || "—")}</strong></div></div><h2 class="print-section-title">Decision metrics</h2>${printTable(["Metric", "Result", "Interpretation", "Status"], (state.calculations || []).slice(0, 8).map((item) => [item.name, item.display || monitorValue(item.result, item.valueType), item.comparison, item.status]))}<h2 class="print-section-title">Open approval blockers</h2>${printTable(["Item", "Detail"], state.issues.filter((item) => item.status === "open" && item.severity === "blocker").map((item) => [item.title, item.detail]))}`;
    const pages = [printPage(frozen, `${state.deal.borrower || "Borrower not entered"} — Credit Memorandum`, `${state.deal.dealType || "Credit action"} • ${state.deal.facilityType || "Facility not entered"}`, summary, !ready)];
    for (let index = 0; index < state.memoSections.length; index += 4) {
      const group = state.memoSections.slice(index, index + 4);
      const body = group.map((item) => {
        const sectionEvidence = memoSectionEvidence(state, item);
        return `<div class="print-card" style="margin-bottom:8px"><h2>${htmlEscape(item.title || "Untitled section")}</h2><p>${htmlEscape(item.narrative || "Not completed")}<br><span class="print-citations">${htmlEscape(sectionEvidence.label)}</span></p></div>`;
      }).join("");
      pages.push(printPage(frozen, index ? "Credit analysis — continued" : "Credit analysis", `Sections ${index + 1}–${index + group.length}`, body, !ready));
    }
    return { orientation: "portrait", snapshotId: frozen.snapshotId, html: `<article class="print-document">${pages.join("")}</article>` };
  }

  window.HBFExporters = {
    exportMemo,
    exportMonitor,
    exportReviewPack,
    exportOpenItems,
    exportPortfolioRollup,
    exportCheckpoint,
    buildPrintHtml,
    freezeExportSnapshot,
    evaluateReadiness,
    digestCanonical,
    canonicalJson,
    downloadBlob,
    _test: { factScopeKey, factByPath, monitorActionRows, sortedExceptions, csvText, stressInputFingerprint, scenarioCalculationLedgerMatches, latestAtOrBefore, creditReadinessDiagnostics, executiveExcerpt, confirmedCovenantBreach, safeFileName }
  };
})();
