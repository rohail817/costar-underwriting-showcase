(function () {
  "use strict";

  const PROFILE = "HBF-QPM-v2.1-family";
  const MAX_FILE_BYTES = 15 * 1024 * 1024;
  const MAX_ZIP_ENTRIES = 10000;
  const MAX_ZIP_ENTRY_UNCOMPRESSED_BYTES = 25 * 1024 * 1024;
  const MAX_ZIP_TOTAL_UNCOMPRESSED_BYTES = 100 * 1024 * 1024;
  const MAX_XML_CHARS = 14 * 1024 * 1024;
  const MAX_CELLS = 150000;
  const MAX_ERROR_SAMPLES = 120;

  const EXPECTED_SHEETS = [
    "Summary", "Update Monthly >>", "Tracking & Banking", "Inventory", "Income Stmt",
    "Balance Sheet", "Covenants", "Heat Map", ">>", "Budget", "Graph Support",
    "Quarterly PR", "Lists", "Ratio Analysis"
  ];

  const SIGNATURES = [
    ["Summary", "B4", "Borrower Information"],
    ["Summary", "B14", "Facility Information"],
    ["Summary", "B51", "Borrower Tracking Items"],
    ["Summary", "B72", "Quarterly Income Statement"],
    ["Summary", "B88", "Quarterly Balance Sheet Summary ($000s)"],
    ["Tracking & Banking", "C7", "FACILITY AMOUNT & OUTSTANDING BALANCES"],
    ["Tracking & Banking", "C24", "BORROWER TRACKING ITEMS"],
    ["Inventory", "B2", "GLOBAL INVENTORY REPORTS"],
    ["Income Stmt", "B2", "Income Statement ($000s)"],
    ["Balance Sheet", "B2", "Summary Balance Sheet ($000s)"],
    ["Covenants", "B2", "Covenant Analysis"],
    ["Heat Map", "D4", "Tier Guideline Heat Map"],
    ["Quarterly PR", "B3", "REGION PORTFOLIO SUMMARY ($000s)"],
    ["Quarterly PR", "B9", "CENTRAL REGION PORTFOLIO BREAKEVEN SUMMARY"],
    ["Summary", "B74", "Revenue"],
    ["Summary", "B75", "Average Unit Price"],
    ["Summary", "B76", "Gross Profit"],
    ["Summary", "B77", "% Gross Margin"],
    ["Summary", "B78", "Operating Expenses"],
    ["Summary", "B79", "% Opex of Revenue"],
    ["Summary", "B80", "Net Profit"],
    ["Summary", "B81", "% Net Margin"],
    ["Summary", "B83", "Unit Closings"],
    ["Summary", "B84", "Unit Sales"],
    ["Summary", "B85", "Breakeven Unit Closings"],
    ["Summary", "B86", "Velocity %"],
    ["Summary", "B90", "Cash & Equivalent"],
    ["Summary", "B91", "Current Assets"],
    ["Summary", "B92", "Total Assets"],
    ["Summary", "B93", "Current Liabilities"],
    ["Summary", "B94", "Total Liabilities"],
    ["Summary", "B95", "Total Net Worth"],
    ["Summary", "B96", "Intangibles (Bank)"],
    ["Summary", "B97", "Tangible Net Worth"],
    ["Summary", "B98", "Subordinated Debt"],
    ["Summary", "B99", "Effective TNW"]
  ];

  const FINANCIAL_ROWS = {
    revenue: 74,
    averageUnitPrice: 75,
    grossProfit: 76,
    grossMargin: 77,
    operatingExpenses: 78,
    operatingExpenseRatio: 79,
    netIncome: 80,
    netMargin: 81,
    closings: 83,
    netSales: 84,
    breakEvenClosings: 85,
    salesVelocityVariance: 86
  };

  const BALANCE_ROWS = {
    cash: 90,
    currentAssets: 91,
    totalAssets: 92,
    currentLiabilities: 93,
    totalLiabilities: 94,
    netWorth: 95,
    intangibles: 96,
    tangibleNetWorth: 97,
    subordinatedDebt: 98,
    effectiveTangibleNetWorth: 99
  };

  const INVENTORY_ROWS = {
    netSales: 4,
    closings: 6,
    backlog: 18,
    specUnderConstruction: 19,
    specCompleted: 20,
    models: 21,
    totalUnits: 22,
    totalUnitsWithBacklog: 23,
    lotsOwnedControlled: 32,
    lotMonthsSupply: 34,
    inventoryMonthsSupply: 39,
    specMonthsSupply: 40,
    completedSpecMonthsSupply: 41
  };

  function cleanText(value) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  }

  function normalizeLabel(value) {
    return cleanText(value).toLowerCase().replace(/\bfsb\b/g, 'bank').replace(/[:*\[\]()]/g, "").replace(/\s+/g, " ");
  }

  function safeNumber(value) {
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value !== "string") return null;
    const text = value.trim();
    if (!text || /^#|^n\/?a$|^-$|^—$/i.test(text)) return null;
    const negative = /^\(.*\)$/.test(text);
    const parsed = Number(text.replace(/[$,%x(),\s]/gi, "").replace(/,/g, ""));
    return Number.isFinite(parsed) ? (negative ? -parsed : parsed) : null;
  }

  function excelDate(value) {
    if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
    const number = safeNumber(value);
    if (number == null || number < 20000 || number > 90000) return null;
    const date = new Date(Date.UTC(1899, 11, 30) + Math.round(number) * 86400000);
    return Number.isNaN(date.getTime()) ? null : date.toISOString().slice(0, 10);
  }

  function columnName(index) {
    let current = index + 1;
    let result = "";
    while (current > 0) {
      const remainder = (current - 1) % 26;
      result = String.fromCharCode(65 + remainder) + result;
      current = Math.floor((current - 1) / 26);
    }
    return result;
  }

  function cell(sheetMap, sheetName, address) {
    return sheetMap.get(sheetName)?.cells?.get(address) || null;
  }

  function value(sheetMap, sheetName, address) {
    const item = cell(sheetMap, sheetName, address);
    return item ? item.value : null;
  }

  function textValue(sheetMap, sheetName, address) {
    return cleanText(value(sheetMap, sheetName, address)) || null;
  }

  function scaledMoney(sheetMap, sheetName, address, factor) {
    const raw = safeNumber(value(sheetMap, sheetName, address));
    return raw == null ? null : raw * (factor || 1);
  }

  function percentValue(raw) {
    if (typeof raw === "number" && Number.isFinite(raw)) return raw;
    const number = safeNumber(raw);
    if (number == null) return null;
    return typeof raw === "string" && /%/.test(raw) ? number / 100 : number;
  }

  function dayDifference(startDate, endDate) {
    if (!startDate || !endDate) return null;
    const start = Date.parse(`${startDate}T00:00:00Z`);
    const end = Date.parse(`${endDate}T00:00:00Z`);
    return Number.isFinite(start) && Number.isFinite(end) ? Math.round((end - start) / 86400000) : null;
  }

  function seriesAtOrBefore(series, cutoff) {
    return (Array.isArray(series) ? series : [])
      .filter((item) => item?.periodEnd && (!cutoff || item.periodEnd <= cutoff))
      .sort((a, b) => cleanText(a.periodEnd).localeCompare(cleanText(b.periodEnd)));
  }

  function addDays(dateText, days) {
    const parsed = Date.parse(`${dateText || ""}T00:00:00Z`);
    if (!Number.isFinite(parsed) || !Number.isFinite(Number(days))) return null;
    return new Date(parsed + Number(days) * 86400000).toISOString().slice(0, 10);
  }

  function factScopeKey(fact) {
    const current = fact || {};
    return [current.entity || "", current.path || "", current.periodType || "as_of", current.asOfDate || "", current.scenario || "actual", current.unit || ""].join("|").toLowerCase();
  }

  function matchesScope(fact, scope) {
    const current = scope || {};
    return (!current.entity || cleanText(fact.entity).toLowerCase() === cleanText(current.entity).toLowerCase()) &&
      (!current.periodType || fact.periodType === current.periodType) &&
      (!current.asOfDate || fact.asOfDate === current.asOfDate) &&
      (!current.scenario || (fact.scenario || "actual") === current.scenario) &&
      (!current.unit || (fact.unit || "") === current.unit) &&
      (!current.throughDate || !fact.asOfDate || fact.asOfDate <= current.throughDate);
  }

  function factSeries(facts, path, scope) {
    return (Array.isArray(facts) ? facts : [])
      .filter((fact) => fact && fact.path === path && ["accepted", "supported"].includes(fact.status) && matchesScope(fact, scope))
      .sort((a, b) => String(a.asOfDate || "").localeCompare(String(b.asOfDate || "")));
  }

  function factAt(facts, path, scope) {
    const eligible = factSeries(facts, path, scope);
    const explicit = eligible.filter((fact) => fact.controlling === true);
    if (explicit.length === 1) return explicit[0];
    if (explicit.length > 1) return null;
    return eligible.length === 1 ? eligible[0] : null;
  }

  function latestFact(facts, path, scope) {
    const eligible = factSeries(facts, path, scope);
    if (!eligible.length) return null;
    const latestDate = eligible[eligible.length - 1].asOfDate || "";
    const latest = eligible.filter((fact) => (fact.asOfDate || "") === latestDate);
    const explicit = latest.filter((fact) => fact.controlling === true);
    if (explicit.length === 1) return explicit[0];
    return latest.length === 1 ? latest[0] : null;
  }

  function checkProfile(sheetNames, sheetMap) {
    const missingSheets = EXPECTED_SHEETS.filter((name) => !sheetNames.includes(name));
    const unexpectedSheets = sheetNames.filter((name) => !EXPECTED_SHEETS.includes(name));
    const unreadableSheets = EXPECTED_SHEETS.filter((name) => !sheetMap.get(name) || sheetMap.get(name).missing);
    const signatureChecks = SIGNATURES.map(([sheetName, address, expected]) => {
      const actual = textValue(sheetMap, sheetName, address);
      return { sheet: sheetName, address, expected, actual, matched: normalizeLabel(actual) === normalizeLabel(expected) };
    });
    return {
      profileMatched: sheetNames.length === EXPECTED_SHEETS.length && !missingSheets.length && !unexpectedSheets.length && !unreadableSheets.length && signatureChecks.every((item) => item.matched),
      missingSheets,
      unexpectedSheets,
      unreadableSheets,
      signatureChecks,
      matchedSignatureCount: signatureChecks.filter((item) => item.matched).length,
      requiredSignatureCount: signatureChecks.length
    };
  }

  function extractFinancialPeriods(sheetMap) {
    const quarterly = ["C", "D", "E", "F"].map((column) => {
      const periodEnd = excelDate(value(sheetMap, "Summary", `${column}73`));
      const result = { periodEnd, periodType: "quarterly", sourceScale: 1000, sourceUnit: "USD thousands" };
      Object.entries(FINANCIAL_ROWS).forEach(([key, row]) => {
        const raw = safeNumber(value(sheetMap, "Summary", `${column}${row}`));
        result[key] = raw == null ? null : ["revenue", "averageUnitPrice", "grossProfit", "operatingExpenses", "netIncome"].includes(key) ? raw * 1000 : ["grossMargin", "operatingExpenseRatio", "netMargin", "salesVelocityVariance"].includes(key) ? percentValue(raw) : raw;
        result[`${key}Locator`] = `Summary!${column}${row}`;
      });
      return result;
    }).filter((item) => item.periodEnd);

    const ytd = ["H", "I"].map((column) => {
      const periodEnd = excelDate(value(sheetMap, "Summary", `${column}73`));
      const result = { periodEnd, periodType: "ytd", sourceScale: 1000, sourceUnit: "USD thousands" };
      Object.entries(FINANCIAL_ROWS).forEach(([key, row]) => {
        const raw = safeNumber(value(sheetMap, "Summary", `${column}${row}`));
        result[key] = raw == null ? null : ["revenue", "averageUnitPrice", "grossProfit", "operatingExpenses", "netIncome"].includes(key) ? raw * 1000 : ["grossMargin", "operatingExpenseRatio", "netMargin", "salesVelocityVariance"].includes(key) ? percentValue(raw) : raw;
        result[`${key}Locator`] = `Summary!${column}${row}`;
      });
      return result;
    }).filter((item) => item.periodEnd);

    const ttm = ["M", "N"].map((column) => {
      const periodEnd = excelDate(value(sheetMap, "Summary", `${column}73`));
      const result = { periodEnd, periodType: "ttm", sourceScale: 1000, sourceUnit: "USD thousands" };
      Object.entries(FINANCIAL_ROWS).forEach(([key, row]) => {
        const raw = safeNumber(value(sheetMap, "Summary", `${column}${row}`));
        result[key] = raw == null ? null : ["revenue", "averageUnitPrice", "grossProfit", "operatingExpenses", "netIncome"].includes(key) ? raw * 1000 : ["grossMargin", "operatingExpenseRatio", "netMargin", "salesVelocityVariance"].includes(key) ? percentValue(raw) : raw;
        result[`${key}Locator`] = `Summary!${column}${row}`;
      });
      return result;
    }).filter((item) => item.periodEnd);
    return { quarterly, ytd, ttm };
  }

  function extractBalanceSheets(sheetMap) {
    return ["C", "D", "E", "F"].map((column) => {
      const periodEnd = excelDate(value(sheetMap, "Summary", `${column}89`));
      const result = { periodEnd, sourceScale: 1000, sourceUnit: "USD thousands" };
      Object.entries(BALANCE_ROWS).forEach(([key, row]) => {
        result[key] = scaledMoney(sheetMap, "Summary", `${column}${row}`, 1000);
        result[`${key}Locator`] = `Summary!${column}${row}`;
      });
      result.crossFootDifference = result.totalAssets == null || result.totalLiabilities == null || result.netWorth == null ? null : result.totalAssets - result.totalLiabilities - result.netWorth;
      result.riskAssets = null;
      return result;
    }).filter((item) => item.periodEnd);
  }

  function repeatedQuarterlyAllocation(series) {
    if (!series.length) return false;
    const groups = [];
    for (let index = 2; index < series.length; index += 3) {
      const group = series.slice(index - 2, index + 1);
      if (group.length === 3) groups.push(group);
    }
    const repeatedGroups = groups.filter((group) => group.every((item) => item.value != null && item.value === group[0].value));
    return repeatedGroups.length >= 2 && repeatedGroups.length / groups.length >= 0.75;
  }

  function comparablePriorYear(current, prior) {
    if (!current?.periodEnd || !prior?.periodEnd) return false;
    const currentDate = new Date(`${current.periodEnd}T00:00:00Z`);
    const priorDate = new Date(`${prior.periodEnd}T00:00:00Z`);
    return !Number.isNaN(currentDate.getTime()) && !Number.isNaN(priorDate.getTime()) && currentDate.getUTCFullYear() - priorDate.getUTCFullYear() === 1 && currentDate.getUTCMonth() === priorDate.getUTCMonth() && currentDate.getUTCDate() === priorDate.getUTCDate();
  }

  function extractInventorySeries(sheetMap) {
    const series = [];
    for (let index = 2; index <= 13; index += 1) {
      const column = columnName(index);
      const periodEnd = excelDate(value(sheetMap, "Graph Support", `${column}3`));
      if (!periodEnd) continue;
      const point = { periodEnd, source: "Graph Support verification range" };
      Object.entries(INVENTORY_ROWS).forEach(([key, row]) => {
        point[key] = safeNumber(value(sheetMap, "Graph Support", `${column}${row}`));
        point[`${key}Locator`] = `Graph Support!${column}${row}`;
      });
      series.push(point);
    }
    const repeated = repeatedQuarterlyAllocation(series.map((item) => ({ value: item.netSales })));
    return series.map((item) => ({ ...item, dataGranularity: repeated ? "quarterly_allocated_monthly" : "monthly" }));
  }

  function extractBankingSeries(sheetMap, reviewAsOfDate) {
    const points = [];
    const tracking = sheetMap.get("Tracking & Banking");
    const headerColumns = Array.from(tracking?.cells?.keys?.() || []).map((address) => {
      const match = /^([A-Z]+)8$/.exec(address);
      if (!match) return -1;
      let result = 0;
      for (const letter of match[1]) result = result * 26 + letter.charCodeAt(0) - 64;
      return result - 1;
    }).filter((index) => index >= 2).sort((a, b) => a - b);
    for (const index of headerColumns) {
      const column = columnName(index);
      const periodEnd = excelDate(value(sheetMap, "Tracking & Banking", `${column}8`));
      if (!periodEnd || (reviewAsOfDate && periodEnd > reviewAsOfDate)) continue;
      const grossCommitment = scaledMoney(sheetMap, "Tracking & Banking", `${column}9`, 1);
      const netCommitment = scaledMoney(sheetMap, "Tracking & Banking", `${column}10`, 1);
      const outstanding = scaledMoney(sheetMap, "Tracking & Banking", `${column}20`, 1);
      const deposits = scaledMoney(sheetMap, "Tracking & Banking", `${column}21`, 1);
      if (![grossCommitment, netCommitment, outstanding, deposits].some((item) => item != null && item !== 0)) continue;
      const applicableCommitment = netCommitment && netCommitment > 0 ? netCommitment : grossCommitment;
      points.push({
        periodEnd,
        grossCommitment,
        netCommitment,
        applicableCommitment,
        outstanding,
        deposits,
        utilization: applicableCommitment && outstanding != null ? outstanding / applicableCommitment : null,
        depositCoverage: outstanding && deposits != null ? deposits / outstanding : null,
        locator: `Tracking & Banking!${column}8:${column}22`
      });
    }
    return points;
  }

  function extractReportingItems(sheetMap, reviewAsOfDate) {
    const items = [];
    for (const row of [...Array.from({ length: 5 }, (_, index) => 53 + index), ...Array.from({ length: 6 }, (_, index) => 62 + index)]) {
      const name = textValue(sheetMap, "Summary", `B${row}`);
      if (!name || /^(?:n\/?a|-|—)$/i.test(name)) continue;
      const daysAfter = safeNumber(value(sheetMap, "Summary", `D${row}`));
      const lastReceivedPeriodEnd = excelDate(value(sheetMap, "Summary", `E${row}`));
      const nextPeriodEnd = excelDate(value(sheetMap, "Summary", `F${row}`));
      const dueDate = nextPeriodEnd && daysAfter != null ? addDays(nextPeriodEnd, daysAfter) : null;
      const daysUntilDue = dayDifference(reviewAsOfDate, dueDate);
      items.push({
        id: `REPORT-${row}`,
        name,
        frequency: textValue(sheetMap, "Summary", `C${row}`) || "Not stated",
        daysAfterPeriodEnd: daysAfter,
        lastReceivedPeriodEnd,
        nextPeriodEnd,
        dueDate,
        status: !reviewAsOfDate || !dueDate || !lastReceivedPeriodEnd ? "Review required" : daysUntilDue < 0 ? "Past due" : daysUntilDue <= 14 ? "Due soon" : "Current",
        daysUntilDue,
        population: row >= 62 ? "Guarantor" : "Borrower",
        locator: `Summary!B${row}:I${row}`
      });
    }
    return items;
  }

  function covenantDirection(name) {
    if (/liquidity|net worth|coverage/i.test(name)) return "minimum";
    if (/leverage|investments|housing inventory|letters of credit/i.test(name)) return "maximum";
    return "review";
  }

  function covenantValueType(name) {
    if (/liquidity|net worth|investments|letters of credit/i.test(name)) return "money";
    if (/leverage/i.test(name)) return "percent";
    if (/coverage/i.test(name)) return "multiple";
    if (/housing inventory/i.test(name)) return "number";
    return "number";
  }

  function extractCovenants(sheetMap) {
    const rows = [];
    const testDate = excelDate(value(sheetMap, "Summary", "L89"));
    for (let row = 90; row <= 96; row += 1) {
      const name = textValue(sheetMap, "Summary", `H${row}`);
      if (!name) continue;
      const type = covenantValueType(name);
      const factor = type === "money" ? 1000 : 1;
      const threshold = safeNumber(value(sheetMap, "Summary", `K${row}`));
      const actual = safeNumber(value(sheetMap, "Summary", `L${row}`));
      const direction = covenantDirection(name);
      const comparable = threshold != null && actual != null && !(name === "Maximum Housing Inventory" && threshold < 1 && actual > 1);
      const normalizedThreshold = threshold == null ? null : type === "money" ? threshold * factor : type === "percent" ? percentValue(threshold) : threshold;
      const normalizedActual = actual == null ? null : type === "money" ? actual * factor : type === "percent" ? percentValue(actual) : actual;
      const headroom = comparable ? direction === "minimum" ? normalizedActual - normalizedThreshold : direction === "maximum" ? normalizedThreshold - normalizedActual : null : null;
      const relativeHeadroom = comparable && normalizedThreshold ? headroom / Math.abs(normalizedThreshold) : null;
      const sourceStatus = textValue(sheetMap, "Summary", `N${row}`) || "Review required";
      const reportedOutcome = /^(?:compliant|pass|passed)$/i.test(sourceStatus) ? "Compliant" : /^(?:noncompliant|non-compliant|breach|violation|failed?|waiver|exception)$/i.test(sourceStatus) ? "Noncompliant" : "Review required";
      const computedStatus = !comparable || headroom == null ? "Review required" : headroom >= 0 ? "Compliant" : "Noncompliant";
      const outcomeMismatch = comparable && reportedOutcome !== "Review required" && reportedOutcome !== computedStatus;
      rows.push({
        id: `MON-COV-${row}`,
        name,
        entity: textValue(sheetMap, "Summary", `J${row}`) || "Borrower",
        testDate,
        direction,
        valueType: type,
        threshold: normalizedThreshold,
        actual: normalizedActual,
        headroom,
        relativeHeadroom,
        status: comparable ? sourceStatus : `Review required — values not comparable; reported ${sourceStatus}`,
        sourceStatus,
        reportedOutcome,
        computedStatus,
        outcomeMismatch,
        sourceCushion: safeNumber(value(sheetMap, "Summary", `O${row}`)),
        sourceCushionPercent: percentValue(value(sheetMap, "Summary", `P${row}`)),
        comparable,
        locator: `Summary!H${row}:P${row}`,
        note: comparable ? null : "Workbook threshold and actual are not in comparable units; PM review required."
      });
    }
    return rows;
  }

  function buildObservations(monitor) {
    const borrower = monitor.identity.borrower || "Workbook borrower";
    const observations = [];
    let sequence = 1;
    const add = (path, label, rawValue, valueType, unit, periodType, asOfDate, locator, sourceScale, sourceUnit) => {
      if (rawValue == null || rawValue === "") return;
      observations.push({
        id: `MON-F${String(sequence++).padStart(3, "0")}`,
        path, label, value: rawValue, valueType, unit, periodType, asOfDate,
        entity: borrower, scenario: "actual", status: "candidate", controlling: false,
        provenance: "workbook", sourceId: "QPM-IMPORTED", locator,
        sourceScale: sourceScale || 1, sourceUnit: sourceUnit || unit || "source units",
        eligibleForBulkAcceptance: true
      });
    };
    add("borrower.legalName", "Borrower legal name", monitor.identity?.borrower, "text", "text", "as_of", monitor.reviewAsOfDate, "Summary!C7", 1, "text");
    add("credit.currentRiskRating", "Current risk rating", monitor.rating?.current, "text", "text", "as_of", monitor.reviewAsOfDate, "Summary!C28", 1, "text");
    add("facility.lineMaturity", "Line maturity", monitor.facility?.lineMaturity, "date", "date", "as_of", monitor.reviewAsOfDate, "Summary!C17", 1, "date");
    const latestBank = monitor.bankingSeries[monitor.bankingSeries.length - 1];
    if (latestBank) {
      add("facility.grossCommitment", "Gross commitment", latestBank.grossCommitment, "money", "USD", "monthly", latestBank.periodEnd, latestBank.locator, 1, "USD");
      add("relationship.outstanding", "Relationship outstanding", latestBank.outstanding, "money", "USD", "monthly", latestBank.periodEnd, latestBank.locator, 1, "USD");
      add("relationship.averageDeposits", "Relationship deposits", latestBank.deposits, "money", "USD", "monthly", latestBank.periodEnd, latestBank.locator, 1, "USD");
    }
    monitor.financial.quarterly.forEach((period) => {
      add("financial.revenueQuarter", "Quarterly revenue", period.revenue, "money", "USD", "quarterly", period.periodEnd, period.revenueLocator, 1000, "USD thousands");
      add("financial.grossProfitQuarter", "Quarterly gross profit", period.grossProfit, "money", "USD", "quarterly", period.periodEnd, period.grossProfitLocator, 1000, "USD thousands");
      add("financial.netIncomeQuarter", "Quarterly net income", period.netIncome, "money", "USD", "quarterly", period.periodEnd, period.netIncomeLocator, 1000, "USD thousands");
      add("operating.closingsQuarter", "Quarterly closings", period.closings, "number", "homes", "quarterly", period.periodEnd, period.closingsLocator, 1, "homes");
      add("operating.netSalesQuarter", "Quarterly net sales", period.netSales, "number", "homes", "quarterly", period.periodEnd, period.netSalesLocator, 1, "homes");
    });
    monitor.financial.ttm.forEach((period) => {
      add("financial.revenueTtm", "TTM revenue", period.revenue, "money", "USD", "ttm", period.periodEnd, period.revenueLocator, 1000, "USD thousands");
      add("financial.grossProfitTtm", "TTM gross profit", period.grossProfit, "money", "USD", "ttm", period.periodEnd, period.grossProfitLocator, 1000, "USD thousands");
      add("financial.netIncomeTtm", "TTM net income", period.netIncome, "money", "USD", "ttm", period.periodEnd, period.netIncomeLocator, 1000, "USD thousands");
    });
    monitor.balanceSheets.forEach((period) => {
      add("financial.cash", "Cash and equivalents", period.cash, "money", "USD", "as_of", period.periodEnd, period.cashLocator, 1000, "USD thousands");
      add("financial.totalAssets", "Total assets", period.totalAssets, "money", "USD", "as_of", period.periodEnd, period.totalAssetsLocator, 1000, "USD thousands");
      add("financial.totalLiabilities", "Total liabilities", period.totalLiabilities, "money", "USD", "as_of", period.periodEnd, period.totalLiabilitiesLocator, 1000, "USD thousands");
      add("financial.netWorth", "Net worth", period.netWorth, "money", "USD", "as_of", period.periodEnd, period.netWorthLocator, 1000, "USD thousands");
      add("financial.reportedTangibleNetWorth", "Reported tangible net worth", period.tangibleNetWorth, "money", "USD", "as_of", period.periodEnd, period.tangibleNetWorthLocator, 1000, "USD thousands");
    });
    const latestInventory = seriesAtOrBefore(monitor.inventorySeries, monitor.inventoryPeriodEnd).slice(-1)[0] || null;
    if (latestInventory) {
      add("inventory.totalUnits", "Owned inventory units", latestInventory.totalUnits, "number", "homes", "as_of", latestInventory.periodEnd, latestInventory.locator || "Graph Support / Inventory", 1, "homes");
      add("inventory.backlog", "Backlog", latestInventory.backlog, "number", "homes", "as_of", latestInventory.periodEnd, latestInventory.locator || "Graph Support / Inventory", 1, "homes");
      add("inventory.lotsOwnedControlled", "Owned and controlled lots", latestInventory.lotsOwnedControlled, "number", "lots", "as_of", latestInventory.periodEnd, latestInventory.locator || "Graph Support / Inventory", 1, "lots");
    }
    return observations;
  }

  function inferAssessment(monitor) {
    const warnings = monitor.watchItems.filter((item) => item.severity === "warning" || item.severity === "blocker");
    return warnings.length ? "PM review required" : "Stable — PM confirmation required";
  }

  function buildWatchItems(monitor) {
    const items = [];
    let index = 1;
    const add = (severity, title, detail, module, owner) => items.push({ id: `MON-W${String(index++).padStart(2, "0")}`, severity, title, detail, module, owner: owner || "Portfolio Manager", status: "open" });
    const ytdThroughCutoff = seriesAtOrBefore(monitor.financial.ytd, monitor.financialPeriodEnd);
    const currentYtd = ytdThroughCutoff.slice(-1)[0] || null;
    const priorYearYtd = ytdThroughCutoff.length >= 2 ? ytdThroughCutoff.at(-2) : null;
    if (comparablePriorYear(currentYtd, priorYearYtd)) {
      const change = (key) => priorYearYtd[key] ? (currentYtd[key] - priorYearYtd[key]) / Math.abs(priorYearYtd[key]) : null;
      const closingsChange = change("closings");
      const revenueChange = change("revenue");
      const incomeChange = change("netIncome");
      if (revenueChange != null && revenueChange <= -0.08) add("warning", "Revenue is below the comparable period", `YTD revenue declined ${(Math.abs(revenueChange) * 100).toFixed(1)}% from the comparable prior-year period.`, "Financial performance");
      if (closingsChange != null && closingsChange <= -0.10) add("warning", "Closings declined year over year", `YTD closings declined ${(Math.abs(closingsChange) * 100).toFixed(1)}% from the comparable prior-year period.`, "Operating performance");
      if (incomeChange != null && incomeChange <= -0.20) add("warning", "Net income deterioration", `YTD net income declined ${(Math.abs(incomeChange) * 100).toFixed(1)}% from the comparable prior-year period.`, "Financial performance");
      if (currentYtd.grossMargin != null && priorYearYtd.grossMargin != null && currentYtd.grossMargin < priorYearYtd.grossMargin - 0.02) add("warning", "Gross-margin compression", `YTD gross margin declined ${((priorYearYtd.grossMargin - currentYtd.grossMargin) * 100).toFixed(1)} percentage points.`, "Financial performance");
    }
    const maturityDays = dayDifference(monitor.reviewAsOfDate, monitor.facility?.lineMaturity);
    if (maturityDays != null && maturityDays < 0) add("blocker", "Facility maturity has passed", `The stated line maturity preceded the review cutoff by ${Math.abs(maturityDays)} days; document the controlling extension, payoff or escalation.`, "Facility", "Portfolio Manager");
    else if (maturityDays != null && maturityDays < 365) add("warning", "Facility is within one year of maturity", `${maturityDays} days remain from the explicit review cutoff to the stated line maturity; confirm the renewal or repayment path.`, "Facility", "Portfolio Manager");
    const latestInventory = seriesAtOrBefore(monitor.inventorySeries, monitor.inventoryPeriodEnd).slice(-1)[0] || null;
    if (latestInventory?.lotMonthsSupply > 60) add("warning", "Long lot supply", `Latest lot supply is ${latestInventory.lotMonthsSupply.toFixed(1)} months at the workbook pace; validate controlled-lot strategy and takedown obligations.`, "Inventory");
    if (latestInventory && latestInventory.dataGranularity === "quarterly_allocated_monthly") add("note", "Inventory trend has quarterly granularity", "The workbook repeats quarter-end observations across monthly chart columns; the Studio labels these as quarterly allocations and does not infer monthly movement.", "Data quality");
    monitor.reportingItems.filter((item) => item.status === "Past due").forEach((item) => add("blocker", `${item.name} is past due`, `${item.name} was due ${item.dueDate}; document receipt or a follow-up action.`, "Reporting", "Portfolio Manager"));
    monitor.reportingItems.filter((item) => item.status === "Review required").forEach((item) => add("blocker", `${item.name} reporting status requires review`, `${item.name} lacks a usable last-received period, contractual due-date input or explicit review cutoff.`, "Reporting", "Portfolio Manager"));
    monitor.reportingItems.filter((item) => item.status === "Due soon").forEach((item) => add("warning", `${item.name} is due soon`, `${item.name} is due ${item.dueDate}; confirm the collection plan.`, "Reporting", "Portfolio Manager"));
    monitor.covenants.filter((item) => item.reportedOutcome === "Noncompliant" || item.computedStatus === "Noncompliant").forEach((item) => add("blocker", `Covenant exception: ${item.name}`, `${item.name} is reported as ${item.sourceStatus || item.status}; computed result is ${item.computedStatus || "not available"}.`, "Covenants"));
    return items;
  }

  function buildAnomalies(sheetMap, diagnostics, packageDiagnostics, financial, balanceSheets, inventorySeries, covenants) {
    const anomalies = [];
    const add = (severity, code, title, detail, locator) => anomalies.push({ id: code, severity, title, detail, locator, status: "open" });
    const summaryUpbFormula = cleanText(cell(sheetMap, "Summary", "F5")?.formula);
    const summaryDepositsFormula = cleanText(cell(sheetMap, "Summary", "F7")?.formula);
    if (/TODAY\s*\(/i.test(`${summaryUpbFormula} ${summaryDepositsFormula}`)) add("warning", "MON-A01", "Volatile TODAY-driven summary fields", "The workbook summary selects banking values from the computer date. The Studio instead uses the explicit review cutoff and latest populated period on or before it.", "Summary!F5/F7");
    const marginOutlier = financial.ttm.find((period) => Math.abs(period.grossMargin || 0) > 0.6);
    if (marginOutlier) add("warning", "MON-A02", "Historical gross-margin outlier", `A historical TTM gross margin of ${(marginOutlier.grossMargin * 100).toFixed(1)}% is implausible and is retained as an anomaly rather than used for an unqualified trend conclusion.`, marginOutlier.grossMarginLocator);
    if (balanceSheets.length && balanceSheets.every((period) => period.riskAssets == null)) add("warning", "MON-A03", "Risk assets were not supplied", "Missing risk assets remain missing. They are not converted to zero and cannot improve tier or risk conclusions.", "Balance Sheet / Heat Map");
    if (inventorySeries.some((item) => item.dataGranularity === "quarterly_allocated_monthly")) add("note", "MON-A04", "Quarterly values repeated in monthly chart support", "Repeated quarter-end inventory and operating values are labeled as quarterly allocations and excluded from genuine monthly trend claims.", "Graph Support!C3:N41");
    const staleBorrower = textValue(sheetMap, "Quarterly PR", "C54");
    const currentBorrower = textValue(sheetMap, "Summary", "C7");
    if (staleBorrower && currentBorrower && normalizeLabel(staleBorrower) !== normalizeLabel(currentBorrower)) add("warning", "MON-A05", "Stale legacy borrower block excluded", `${staleBorrower} appears in a legacy Quarterly PR block and is excluded from controlling output for ${currentBorrower}.`, "Quarterly PR!C54");
    if (packageDiagnostics.externalLinks > 0 && packageDiagnostics.externalFormulaCount === 0) add("note", "MON-A06", "Unused external-link artifact", `${packageDiagnostics.externalLinks} external-link package artifact(s) exist, but no parsed formula actively references an external workbook.`, "OOXML package");
    if (packageDiagnostics.externalFormulaCount > 0) add("blocker", "MON-A07", "Active external-workbook formulas detected", `${packageDiagnostics.externalFormulaCount} formula(s) reference an external workbook; replace them with approved local values before reliance.`, "Workbook formulas");
    if (packageDiagnostics.conditionalReferenceErrors > 0) add("warning", "MON-A08", "Conditional-format reference errors", `${packageDiagnostics.conditionalReferenceErrors} conditional-format formula(s) contain #REF! and are retained as a workbook diagnostic.`, "Workbook conditional formatting");
    if (diagnostics.blockerCount > 0) add("blocker", "MON-A09", "Active monitor formula errors", `${diagnostics.blockerCount} saved formula error(s) intersect the active Summary decision area or extracted active-period dependency.`, "Workbook saved values");
    if (diagnostics.warningCount > 0) add("warning", "MON-A10", "Historical or chart-support formula errors", `${diagnostics.warningCount} saved error cell(s) were classified as mapped-history or chart-support warnings.`, "Workbook saved values");
    if (diagnostics.informationalCount > 0) add("note", "MON-A11", "Unused/future formula errors retained", `${diagnostics.informationalCount} saved error cell(s) occur in future or unused ranges and remain visible in the review pack.`, "Workbook saved values");
    const covenantMismatches = (covenants || []).filter((item) => item.outcomeMismatch);
    if (covenantMismatches.length) add("blocker", "MON-A12", "Reported covenant status conflicts with computed headroom", `${covenantMismatches.length} covenant result(s) are labeled ${covenantMismatches.map((item) => `${item.name}: ${item.sourceStatus} versus computed ${item.computedStatus}`).join("; ")}. Resolve the source or calculation before reliance.`, covenantMismatches.map((item) => item.locator).join("; "));
    if (packageDiagnostics.calcModeRecognized === false) add("blocker", "MON-A13", "Workbook calculation mode is not recognized as automatic", `The workbook declares ${packageDiagnostics.calcMode || "no recognized calculation mode"}. Open it in Excel, enable automatic calculation, fully recalculate, save and re-import before reliance.`, "xl/workbook.xml calcPr");
    const missing = packageDiagnostics.missingCachedDiagnostics || {};
    if (missing.blockerCount > 0) add("blocker", "MON-A14", "Active monitor formulas lack saved results", `${missing.blockerCount} formula(s) without cached results intersect an actively consumed decision range. Recalculate, save and re-import.`, "Workbook formula cache");
    if (missing.warningCount > 0) add("warning", "MON-A15", "Historical formulas lack saved results", `${missing.warningCount} formula(s) without cached results occur in mapped history. They remain visible and cannot support an unqualified trend conclusion.`, "Workbook formula cache");
    if (missing.informationalCount > 0) add("note", "MON-A16", "Unused or future formulas lack saved results", `${missing.informationalCount} formula(s) without cached results occur outside the active consumed ranges and are retained as diagnostics.`, "Workbook formula cache");
    return anomalies;
  }

  function normalizedCutoffs(input) {
    if (typeof input === "string") return { financialDate: input, inventoryDate: input, reviewAsOfDate: input };
    const current = input && typeof input === "object" ? input : {};
    return {
      financialDate: current.financialDate || current.financialCutoff || current.financialPeriodEnd || null,
      inventoryDate: current.inventoryDate || current.inventoryCutoff || current.inventoryPeriodEnd || null,
      reviewAsOfDate: current.reviewAsOfDate || current.reviewCutoff || current.bankingDate || null
    };
  }

  function periodRelevance(sheet, column, headerRow, cutoff, addressRow, groupColumns) {
    const hasPopulatedCellMap = Boolean(sheet?.cells && typeof sheet.cells.get === "function" && Number(sheet.cells.size) > 0);
    const periodEnd = excelDate(sheet?.cells?.get(`${column}${headerRow}`)?.value);
    if (periodEnd && cutoff && periodEnd > cutoff) return { severity: "informational", periodEnd, cutoff };
    if (periodEnd) {
      const eligibleDates = (groupColumns || [column])
        .map((candidate) => excelDate(sheet?.cells?.get(`${candidate}${headerRow}`)?.value))
        .filter((date) => date && (!cutoff || date <= cutoff))
        .sort();
      const activeDate = eligibleDates.at(-1) || periodEnd;
      return { severity: periodEnd === activeDate ? "blocker" : "warning", periodEnd, cutoff };
    }
    if (!hasPopulatedCellMap) return { severity: "blocker", periodEnd: null, cutoff };
    return { severity: addressRow === headerRow ? "blocker" : "informational", periodEnd: null, cutoff };
  }

  function formulaRelevance(sheetOrName, address, cutoffInput) {
    const sheet = typeof sheetOrName === "string" ? { name: sheetOrName, cells: new Map() } : sheetOrName || { name: "", cells: new Map() };
    const sheetName = sheet.name || "";
    const cutoffs = normalizedCutoffs(cutoffInput);
    const match = /^([A-Z]+)(\d+)$/.exec(address || "");
    if (!match) return { severity: "informational", periodEnd: null, cutoff: null };
    const column = match[1];
    const row = Number(match[2]);
    if (sheetName === "Summary") {
      const identityFacilityRating = (column === "C" && row >= 5 && row <= 30) || (column === "F" && row >= 9 && row <= 21) || (column === "B" && [31, 35, 100].includes(row));
      const reporting = ["B", "C", "D", "E", "F"].includes(column) && ((row >= 53 && row <= 57) || (row >= 62 && row <= 67));
      const financial = ["C", "D", "E", "F", "H", "I", "M", "N"].includes(column) && row >= 73 && row <= 86;
      const balance = ["C", "D", "E", "F"].includes(column) && row >= 89 && row <= 99;
      const covenant = address === "L89" || (["H", "J", "K", "L", "N", "O", "P"].includes(column) && row >= 90 && row <= 96);
      if (financial) {
        const columns = ["C", "D", "E", "F"].includes(column) ? ["C", "D", "E", "F"] : ["H", "I"].includes(column) ? ["H", "I"] : ["M", "N"];
        return periodRelevance(sheet, column, 73, cutoffs.financialDate, row, columns);
      }
      if (balance) return periodRelevance(sheet, column, 89, cutoffs.financialDate, row, ["C", "D", "E", "F"]);
      if (identityFacilityRating || reporting || covenant) return { severity: "blocker", periodEnd: null, cutoff: cutoffs.financialDate };
    }
    if (sheetName === "Tracking & Banking" && [8, 9, 10, 20, 21].includes(row)) {
      const columns = sheet.cells && typeof sheet.cells.keys === "function" ? [...new Set([...sheet.cells.keys()].map((address) => /^([A-Z]+)8$/.exec(address)?.[1]).filter(Boolean))] : [];
      return periodRelevance(sheet, column, 8, cutoffs.reviewAsOfDate, row, columns.length ? columns : [column]);
    }
    if (sheetName === "Graph Support" && ["C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N"].includes(column) && [3, 4, 6, 18, 19, 20, 21, 22, 23, 32, 34, 39, 40, 41].includes(row)) return periodRelevance(sheet, column, 3, cutoffs.inventoryDate, row, ["C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N"]);
    if (["Income Stmt", "Balance Sheet", "Inventory", "Covenants", "Quarterly PR"].includes(sheetName)) return { severity: "warning", periodEnd: null, cutoff: cutoffs.financialDate };
    return { severity: "informational", periodEnd: null, cutoff: null };
  }

  function classifyFormulaPopulation(sheets, cutoffInput, selector) {
    const result = { total: 0, blockerCount: 0, warningCount: 0, informationalCount: 0, samples: [] };
    for (const sheet of sheets) {
      for (const item of selector(sheet) || []) {
        result.total += 1;
        const relevance = formulaRelevance(sheet, item.address, cutoffInput);
        const severity = relevance.severity;
        if (severity === "blocker") result.blockerCount += 1;
        else if (severity === "warning") result.warningCount += 1;
        else result.informationalCount += 1;
        if (result.samples.length < MAX_ERROR_SAMPLES) result.samples.push({ sheet: sheet.name, address: item.address, value: item.value ?? item.cachedValue ?? null, severity, periodEnd: relevance.periodEnd, cutoff: relevance.cutoff });
      }
    }
    return result;
  }

  function classifyFormulaErrors(sheets, cutoffInput) {
    return classifyFormulaPopulation(sheets, cutoffInput, (sheet) => sheet.errors || []);
  }

  function classifyMissingCachedValues(sheets, cutoffInput) {
    return classifyFormulaPopulation(sheets, cutoffInput, (sheet) => (sheet.formulas || []).filter((item) => item.cachedValue == null || item.cachedValue === ""));
  }

  function extractMonitor(sheetMap, options) {
    const financial = extractFinancialPeriods(sheetMap);
    const balanceSheets = extractBalanceSheets(sheetMap);
    const inventorySeries = extractInventorySeries(sheetMap);
    const provisionalBanking = extractBankingSeries(sheetMap, options?.reviewAsOfDate || null);
    const lastBankingDate = provisionalBanking[provisionalBanking.length - 1]?.periodEnd || null;
    const financialDate = excelDate(value(sheetMap, "Summary", "K2"));
    const inventoryDate = excelDate(value(sheetMap, "Summary", "P2"));
    const reviewAsOfDate = options?.reviewAsOfDate || lastBankingDate || [financialDate, inventoryDate].filter(Boolean).sort().pop() || null;
    const bankingSeries = extractBankingSeries(sheetMap, reviewAsOfDate);
    const monitor = {
      workflow: "portfolio_monitor",
      reviewId: `QPR-${financialDate || "UNSET"}`,
      reviewAsOfDate,
      reviewDateBasis: options?.reviewAsOfDate ? "user_explicit" : "derived_latest_banking",
      reportingPeriodEnd: financialDate,
      financialPeriodEnd: financialDate,
      inventoryPeriodEnd: inventoryDate,
      priorSnapshotId: null,
      workbookSourceId: "QPM-IMPORTED",
      profile: PROFILE,
      profileMatched: true,
      reviewed: false,
      anomalyDispositionReviewed: false,
      reportingReviewed: false,
      covenantReviewConfirmed: false,
      outputProfile: "executive",
      includeFinancialTables: false,
      includeBalanceSheetTable: false,
      assessment: "PM review required",
      conclusion: "Portfolio manager conclusion required.",
      ratingRationale: "Portfolio manager rating rationale required.",
      identity: {
        rmPm: textValue(sheetMap, "Summary", "C5"),
        relationship: textValue(sheetMap, "Summary", "C6"),
        borrower: textValue(sheetMap, "Summary", "C7"),
        obligorNumber: textValue(sheetMap, "Summary", "C8"),
        headquarters: textValue(sheetMap, "Summary", "C9"),
        established: textValue(sheetMap, "Summary", "F9"),
        guarantors: textValue(sheetMap, "Summary", "C10")
      },
      facility: {
        type: textValue(sheetMap, "Summary", "C15"),
        secured: textValue(sheetMap, "Summary", "F15"),
        approvedDate: excelDate(value(sheetMap, "Summary", "C16")),
        closedDate: excelDate(value(sheetMap, "Summary", "F16")),
        lineMaturity: excelDate(value(sheetMap, "Summary", "C17")),
        noteMaturity: excelDate(value(sheetMap, "Summary", "F17")),
        grossCommitment: scaledMoney(sheetMap, "Summary", "C19", 1),
        netCommitment: scaledMoney(sheetMap, "Summary", "F19", 1),
        pricing: textValue(sheetMap, "Summary", "C20"),
        floor: textValue(sheetMap, "Summary", "F20"),
        syndicated: textValue(sheetMap, "Summary", "C21"),
        holdPercentage: percentValue(value(sheetMap, "Summary", "F21")),
        markets: textValue(sheetMap, "Summary", "C22"),
        collateral: textValue(sheetMap, "Summary", "C23"),
        purpose: textValue(sheetMap, "Summary", "C24")
      },
      rating: {
        borrowerTier: textValue(sheetMap, "Summary", "C27"),
        current: textValue(sheetMap, "Summary", "C28"),
        recommended: textValue(sheetMap, "Summary", "C29"),
        policyException: textValue(sheetMap, "Summary", "C30"),
        notes: textValue(sheetMap, "Summary", "B31")
      },
      relationshipNarrative: textValue(sheetMap, "Summary", "B35"),
      financialNarrative: textValue(sheetMap, "Summary", "B100"),
      financial,
      balanceSheets,
      inventorySeries,
      bankingSeries,
      reportingItems: extractReportingItems(sheetMap, reviewAsOfDate),
      covenants: extractCovenants(sheetMap),
      calculations: [],
      anomalies: [],
      watchItems: [],
      actions: []
    };

    const latestBank = bankingSeries[bankingSeries.length - 1] || null;
    const ytdThroughCutoff = seriesAtOrBefore(financial.ytd, financialDate);
    const ttmThroughCutoff = seriesAtOrBefore(financial.ttm, financialDate);
    const currentYtd = ytdThroughCutoff.slice(-1)[0] || null;
    const priorYtd = ytdThroughCutoff.length >= 2 ? ytdThroughCutoff.at(-2) : null;
    const latestTtm = ttmThroughCutoff.slice(-1)[0] || null;
    const priorTtm = ttmThroughCutoff.length >= 2 ? ttmThroughCutoff.at(-2) : null;
    const latestBalance = seriesAtOrBefore(balanceSheets, financialDate).slice(-1)[0] || null;
    const currentInventory = seriesAtOrBefore(inventorySeries, inventoryDate).slice(-1)[0] || null;
    const maturityDays = dayDifference(reviewAsOfDate, monitor.facility.lineMaturity);
    const calc = (id, name, result, valueType, comparison, formula, inputs, status) => monitor.calculations.push({ id, name, result, valueType, comparison, formula, inputs, status });
    calc("MON-UTIL-001", "Facility utilization", latestBank?.utilization ?? null, "percent", "Outstanding ÷ applicable gross/net commitment", "relationship outstanding ÷ applicable commitment", [latestBank?.locator].filter(Boolean), latestBank?.utilization == null ? "review" : latestBank.utilization > 0.85 ? "watch" : "pass");
    calc("MON-DEP-001", "Deposits / relationship UPB", latestBank?.depositCoverage ?? null, "percent", "Relationship deposits ÷ relationship outstanding", "average deposits ÷ relationship UPB", [latestBank?.locator].filter(Boolean), latestBank?.depositCoverage == null ? "review" : "pass");
    calc("MON-MAT-001", "Days to maturity", maturityDays, "days", "Contractual maturity less explicit review date", "line maturity − reviewAsOfDate", [monitor.facility.lineMaturity, reviewAsOfDate], maturityDays == null ? "review" : maturityDays < 365 ? "watch" : "pass");
    if (comparablePriorYear(currentYtd, priorYtd)) {
      calc("MON-REV-001", "YTD revenue change", priorYtd.revenue ? (currentYtd.revenue - priorYtd.revenue) / Math.abs(priorYtd.revenue) : null, "percent", "Current YTD versus comparable prior-year YTD", "(current YTD revenue − prior YTD revenue) ÷ |prior YTD revenue|", [currentYtd.revenueLocator, priorYtd.revenueLocator], "review");
      calc("MON-CLOSE-001", "YTD closings change", priorYtd.closings ? (currentYtd.closings - priorYtd.closings) / Math.abs(priorYtd.closings) : null, "percent", "Current YTD versus comparable prior-year YTD", "(current YTD closings − prior YTD closings) ÷ |prior YTD closings|", [currentYtd.closingsLocator, priorYtd.closingsLocator], "review");
      calc("MON-MARGIN-001", "YTD gross-margin change", currentYtd.grossMargin != null && priorYtd.grossMargin != null ? currentYtd.grossMargin - priorYtd.grossMargin : null, "percentage_points", "Current YTD versus comparable prior-year YTD", "current YTD gross margin − prior YTD gross margin", [currentYtd.grossMarginLocator, priorYtd.grossMarginLocator], "review");
    }
    if (latestTtm) {
      const breakEven = Number.isFinite(latestTtm.operatingExpenses) && Number.isFinite(latestTtm.grossProfit) && latestTtm.grossProfit > 0 && Number.isFinite(latestTtm.closings) && latestTtm.closings > 0 ? latestTtm.operatingExpenses / (latestTtm.grossProfit / latestTtm.closings) : null;
      calc("MON-BE-001", "TTM break-even closings", breakEven, "number", "Operating expenses ÷ gross profit per closing", "TTM operating expenses ÷ (TTM gross profit ÷ TTM closings)", [latestTtm.operatingExpensesLocator, latestTtm.grossProfitLocator, latestTtm.closingsLocator], breakEven == null ? "review" : latestTtm.closings >= breakEven ? "pass" : "watch");
    }
    if (latestBalance) calc("MON-XFOOT-001", "Balance-sheet cross-foot", latestBalance.crossFootDifference, "money", "Total assets − liabilities − net worth; expected $0", "total assets − total liabilities − net worth", [latestBalance.totalAssetsLocator, latestBalance.totalLiabilitiesLocator, latestBalance.netWorthLocator], latestBalance.crossFootDifference === 0 ? "pass" : "watch");
    if (currentInventory && latestTtm) {
      const lotSupply = Number.isFinite(currentInventory.lotsOwnedControlled) && Number.isFinite(latestTtm.closings) && latestTtm.closings > 0 ? currentInventory.lotsOwnedControlled / (latestTtm.closings / 12) : null;
      calc("MON-LOT-001", "Lot supply at TTM closing pace", lotSupply, "months", "Lots owned & controlled ÷ TTM monthly closings", "lots owned & controlled ÷ (TTM closings ÷ 12)", [currentInventory.lotsOwnedControlledLocator, latestTtm.closingsLocator], lotSupply == null ? "review" : "pass");
    }
    if (comparablePriorYear(latestTtm, priorTtm)) calc("MON-TTM-REV-001", "TTM revenue change", priorTtm.revenue ? (latestTtm.revenue - priorTtm.revenue) / Math.abs(priorTtm.revenue) : null, "percent", "Current TTM versus prior TTM", "(current TTM revenue − prior TTM revenue) ÷ |prior TTM revenue|", [latestTtm.revenueLocator, priorTtm.revenueLocator], "review");
    monitor.observations = buildObservations(monitor);
    monitor.watchItems = buildWatchItems(monitor);
    monitor.assessment = inferAssessment(monitor);
    if (window.HBFQPRSource) monitor.draftSource = window.HBFQPRSource.extract(sheetMap, monitor);
    return monitor;
  }

  function parseXml(text, name, maximum) {
    if (typeof text !== "string" || text.length > maximum) throw new Error(`${name} XML is missing or exceeds the safety limit.`);
    const document = new DOMParser().parseFromString(text, "application/xml");
    if (document.querySelector("parsererror")) throw new Error(`${name} XML is malformed.`);
    return document;
  }

  function textOf(element) {
    if (!element) return "";
    return Array.from(element.getElementsByTagName("t")).map((node) => node.textContent || "").join("") || element.textContent || "";
  }

  async function sha256(buffer) {
    if (!window.crypto?.subtle && !window.HBFCrypto) return "Unavailable in this browser";
    const digest = window.HBFCrypto ? await window.HBFCrypto.sha256(buffer.slice(0)) : await window.crypto.subtle.digest("SHA-256", buffer.slice(0));
    return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  function validateZip(zip, entries) {
    let total = 0;
    for (const name of entries) {
      const item = zip.files[name];
      if (!item || item.dir) continue;
      const size = item._data?.uncompressedSize;
      if (!Number.isSafeInteger(size) || size < 0 || size > MAX_ZIP_ENTRY_UNCOMPRESSED_BYTES) throw new Error(`Workbook entry metadata is invalid or too large for ${name}.`);
      total += size;
      if (!Number.isSafeInteger(total) || total > MAX_ZIP_TOTAL_UNCOMPRESSED_BYTES) throw new Error("Workbook package exceeds the total uncompressed safety limit.");
    }
    return total;
  }

  async function manifest(zip) {
    const workbookFile = zip.file("xl/workbook.xml");
    const relsFile = zip.file("xl/_rels/workbook.xml.rels");
    if (!workbookFile || !relsFile) throw new Error("The workbook manifest is missing.");
    const workbook = parseXml(await workbookFile.async("string"), "workbook", 2 * 1024 * 1024);
    const rels = parseXml(await relsFile.async("string"), "workbook relationships", 2 * 1024 * 1024);
    const relationships = new Map();
    Array.from(rels.getElementsByTagName("Relationship")).forEach((relationship) => relationships.set(relationship.getAttribute("Id"), relationship.getAttribute("Target")));
    const calcPr = workbook.getElementsByTagName("calcPr")[0];
    const calcModeAttribute = calcPr ? calcPr.getAttribute("calcMode") : null;
    const calcModeRecognized = Boolean(calcPr) && (!calcModeAttribute || calcModeAttribute === "auto");
    const sheets = Array.from(workbook.getElementsByTagName("sheet")).map((sheet) => {
      const relId = sheet.getAttribute("r:id") || sheet.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
      let target = relationships.get(relId) || "";
      target = target.replace(/^\//, "");
      if (!target.startsWith("xl/")) target = `xl/${target}`;
      return { name: sheet.getAttribute("name") || "Unnamed sheet", target };
    });
    return { sheets, calcMode: calcModeAttribute || (calcPr ? "auto" : "unknown"), calcModeRecognized };
  }

  async function readSharedStrings(zip) {
    const file = zip.file("xl/sharedStrings.xml");
    if (!file) return [];
    const document = parseXml(await file.async("string"), "shared strings", 8 * 1024 * 1024);
    return Array.from(document.getElementsByTagName("si")).map(textOf);
  }

  function cellColumn(address) {
    const match = /^([A-Z]+)\d+$/.exec(address || "");
    if (!match) return -1;
    let result = 0;
    for (const letter of match[1]) result = result * 26 + letter.charCodeAt(0) - 64;
    return result - 1;
  }

  function cellRow(address) {
    const match = /^[A-Z]+(\d+)$/.exec(address || "");
    return match ? Number(match[1]) - 1 : -1;
  }

  async function readSheet(zip, entry, sharedStrings, budget) {
    const file = zip.file(entry.target);
    if (!file) return { name: entry.name, cells: new Map(), formulas: [], errors: [], missing: true };
    const document = parseXml(await file.async("string"), entry.name, MAX_XML_CHARS);
    const cells = new Map();
    const formulas = [];
    const errors = [];
    for (const node of Array.from(document.getElementsByTagName("c"))) {
      budget.count += 1;
      if (budget.count > MAX_CELLS) throw new Error(`Workbook exceeds the ${MAX_CELLS.toLocaleString()}-cell safety limit.`);
      const address = node.getAttribute("r");
      if (!address) continue;
      const type = node.getAttribute("t") || "n";
      const formulaNode = node.getElementsByTagName("f")[0];
      const valueNode = node.getElementsByTagName("v")[0];
      const inlineNode = node.getElementsByTagName("is")[0];
      let parsedValue = null;
      if (type === "s" && valueNode) parsedValue = sharedStrings[Number(valueNode.textContent)] ?? "";
      else if (type === "inlineStr") parsedValue = textOf(inlineNode);
      else if (type === "str") parsedValue = valueNode ? valueNode.textContent || "" : "";
      else if (type === "b") parsedValue = valueNode ? valueNode.textContent === "1" : false;
      else if (type === "e") parsedValue = valueNode ? valueNode.textContent || "#ERROR" : "#ERROR";
      else if (valueNode && valueNode.textContent !== "") {
        const number = Number(valueNode.textContent);
        parsedValue = Number.isFinite(number) ? number : valueNode.textContent;
      }
      const formula = formulaNode ? formulaNode.textContent || "" : null;
      if (formulaNode) formulas.push({ address, formula, cachedValue: parsedValue });
      if (type === "e" || (typeof parsedValue === "string" && /^#(?:REF!|VALUE!|DIV\/0!|N\/A|NAME\?|NUM!|NULL!)/.test(parsedValue))) errors.push({ address, value: parsedValue });
      cells.set(address, { address, row: cellRow(address), column: cellColumn(address), value: parsedValue, formula, hasFormula: Boolean(formulaNode), type });
    }
    return { name: entry.name, cells, formulas, errors, missing: false };
  }

  async function inspect(file, options) {
    if (!window.JSZip) throw new Error("The local Excel parser did not load.");
    if (!file || !/\.xlsx$/i.test(file.name || "")) throw new Error("Choose a macro-free .xlsx quarterly monitor workbook.");
    if (file.size > MAX_FILE_BYTES) throw new Error("Quarterly monitor workbook exceeds the 15 MB safety limit.");
    const buffer = await file.arrayBuffer();
    const signature = new Uint8Array(buffer.slice(0, 4));
    if (signature[0] !== 0x50 || signature[1] !== 0x4b) throw new Error("The selected file is not a valid Office Open XML package.");
    const metadataZip = await window.JSZip.loadAsync(buffer, { checkCRC32: false });
    const entries = Object.keys(metadataZip.files);
    if (entries.length > MAX_ZIP_ENTRIES) throw new Error("Workbook contains too many package entries.");
    if (entries.some((name) => /vbaProject\.bin$/i.test(name))) throw new Error("Macro content was detected. Only macro-free .xlsx files are accepted.");
    const packageUncompressedBytes = validateZip(metadataZip, entries);
    const zip = await window.JSZip.loadAsync(buffer, { checkCRC32: true });
    const workbookManifest = await manifest(zip);
    const sharedStrings = await readSharedStrings(zip);
    const budget = { count: 0 };
    const sheetMap = new Map();
    const sheets = [];
    let formulaCount = 0;
    let externalFormulaCount = 0;
    for (const entry of workbookManifest.sheets) {
      const sheet = await readSheet(zip, entry, sharedStrings, budget);
      sheets.push(sheet);
      sheetMap.set(sheet.name, sheet);
      formulaCount += sheet.formulas.length;
      externalFormulaCount += sheet.formulas.filter((item) => /\[[^\]]+\][^!]{0,128}!/.test(item.formula)).length;
    }
    const profileCheck = checkProfile(workbookManifest.sheets.map((item) => item.name), sheetMap);
    if (!profileCheck.profileMatched) {
      return {
        fileName: cleanText(file.name).slice(0, 180),
        fileSize: file.size,
        digest: await sha256(buffer),
        profile: "Unsupported / changed profile",
        profileMatched: false,
        sheets: workbookManifest.sheets.length,
        sheetNames: workbookManifest.sheets.map((item) => item.name),
        ...profileCheck
      };
    }
    const monitor = extractMonitor(sheetMap, options);
    const cutoffs = {
      financialCutoff: monitor.financialPeriodEnd,
      inventoryCutoff: monitor.inventoryPeriodEnd,
      reviewCutoff: monitor.reviewAsOfDate
    };
    const errorDiagnostics = classifyFormulaErrors(sheets, cutoffs);
    const missingCachedDiagnostics = classifyMissingCachedValues(sheets, cutoffs);
    let conditionalReferenceErrors = 0;
    for (const name of entries.filter((item) => /^xl\/worksheets\/sheet\d+\.xml$/i.test(item))) {
      const xml = await zip.file(name).async("string");
      conditionalReferenceErrors += (xml.match(/<cfRule\b[\s\S]*?<formula>[^<]*#REF![^<]*<\/formula>[\s\S]*?<\/cfRule>/gi) || []).length;
    }
    const packageDiagnostics = {
      externalLinks: entries.filter((name) => /^xl\/externalLinks\/externalLink\d+\.xml$/i.test(name)).length,
      externalFormulaCount,
      conditionalReferenceErrors,
      calcMode: workbookManifest.calcMode,
      calcModeRecognized: workbookManifest.calcModeRecognized,
      missingCachedDiagnostics
    };
    monitor.anomalies = buildAnomalies(sheetMap, errorDiagnostics, packageDiagnostics, monitor.financial, monitor.balanceSheets, monitor.inventorySeries, monitor.covenants);
    monitor.watchItems = buildWatchItems(monitor);
    monitor.assessment = inferAssessment(monitor);
    return {
      fileName: cleanText(file.name).replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").slice(0, 180),
      fileSize: file.size,
      digest: await sha256(buffer),
      profile: PROFILE,
      profileMatched: true,
      sheets: workbookManifest.sheets.length,
      sheetNames: workbookManifest.sheets.map((item) => item.name),
      cells: budget.count,
      formulaCount,
      formulasWithoutCachedValues: missingCachedDiagnostics.total,
      missingCachedDiagnostics,
      calcMode: workbookManifest.calcMode,
      calcModeRecognized: workbookManifest.calcModeRecognized,
      formulaErrorCount: errorDiagnostics.total,
      formulaErrorDiagnostics: errorDiagnostics,
      formulaErrorSamples: errorDiagnostics.samples,
      packageUncompressedBytes,
      ...packageDiagnostics,
      ...profileCheck,
      monitor
    };
  }

  window.HBFMonitor = {
    inspect,
    profile: PROFILE,
    expectedSheets: EXPECTED_SHEETS.slice(),
    factScopeKey,
    factAt,
    factSeries,
    latestFact,
    _test: {
      checkProfile,
      extractMonitor,
      extractFinancialPeriods,
      extractBalanceSheets,
      extractInventorySeries,
      extractBankingSeries,
      extractReportingItems,
      extractCovenants,
      buildAnomalies,
      buildWatchItems,
      classifyFormulaErrors,
      classifyMissingCachedValues,
      excelDate,
      safeNumber
    }
  };
})();
