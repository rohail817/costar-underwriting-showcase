(function(g){
  'use strict';
  const K=g.HBFTemplate,D=K.D;
  const field=(key,label)=>({key,label});
  const choice=(keys,label,labels=['Yes','No'])=>({keys,label,labels});
  const range=(prefix,start,end)=>Array.from({length:end-start+1},(_,i)=>prefix+(start+i));
  const table=(id,title,rows,labels,tableId=id)=>({id,title,table:tableId,rows,labels});
  const groups=[
    {id:'cover',label:'Cover details',fields:D.quick.map(q=>q.members.length===1?field(q.members[0],q.label):choice(q.members,q.label,q.labels))},
    {id:'actions',label:'Credit actions',fields:[]},
    {id:'narrative',label:'Transaction & repayment',fields:[field('p108','Transaction overview & rationale'),field('p144','PSOR — Sale of Real Estate'),field('p150','SSOR — Cash Flow from Business Operations'),field('p155','TSOR — Guarantor Support / Liquidation')]},
    {id:'facility',label:'Facility & terms',fields:[field('p161','Facility borrower / obligor'),choice(['control17','control18'],'Facility borrower relationship',['New','Existing']),field('p166','Facility loan number'),field('p169','Current balance / original balance'),field('p172','Credit facility type'),field('p180','Net line limit'),field('p183','Gross line limit'),field('p248','New / Renewal terms'),field('p251','Line maturity'),field('p252','Note maturity'),field('p256','Repayment terms'),field('p257','Prepayment provision'),field('p260','Unit loan release amount'),field('p261','Collateral release amount'),field('p263','A&D lot release provisions'),field('p389','Property type'),field('p392','Facility structure'),field('p459','Loan purpose / use of proceeds'),field('p462','Completion / stabilization date')]},
    {id:'advances',label:'Advance rates & renewals',tables:[table('table8','Advance rates',range('row',35,39),['Type','LTV %','LTC %','Initial term','1st renewal','2nd renewal','Maximum term']),table('table11','Renewal options',range('row',57,64),['Type','1st renewal term','1st renewal reduction','1st renewal fee','2nd renewal term','2nd renewal reduction','2nd renewal fee'])]},
    {id:'pricing',label:'Pricing & fees',fields:[field('p280','Prepayment penalty terms')],tables:[table('table9','Interest rate',range('row',46,47),['Rate type','Current rate','Description and spread','Rate floor']),table('table10','Fees',range('row',51,53),['Fee type','Amount','Frequency','Period','Description'])]},
    {id:'collateral',label:'Collateral & guarantees',fields:[field('p381','Collateral description'),field('p382','Cross-default / cross-collateralization'),field('p383','Security interest and assignment'),field('p398','Appraisal review'),field('p404','Original appraisal — As Is date'),field('p405','Original appraisal — As Complete date'),field('p408','As Is value'),field('p409','As Complete value'),field('p412','Appraisal firm'),field('p414','Date of appraisal'),field('p420','Field exam / inspection frequency'),field('p452','Guarantee terms'),field('p453','Guarantor credit report authorization')],tables:[table('table13','Guarantors',range('row',80,82),['Guarantor','Credit score','Date','Type','Amount','Security'])]},
    {id:'covenants',label:'Covenants & reporting',tables:[table('table14','Financial covenants',range('row',89,91),['Covenant','Requirement','Frequency','Actual / date','Due date','Testing','Compliant']),table('table15','Financial reporting',range('row',94,99),['Requirement #','Borrower / guarantor','Report / type','New / Existing','Frequency','Actual date','Due date','Next test date','Compliant'])]},
    {id:'exceptions',label:'Exceptions, strengths & risks',fields:[choice(['control19','control20'],'Layered credit risk'),field('p650','Layered credit risk rationale')],tables:[table('table16','Credit exceptions',range('row',101,103),['Item','Type','Credit exception','Rationale']),table('strengths','Strengths',range('row',107,109),['Strength'],'table18'),table('risks','Risks & mitigants',range('row',111,113),['Risk','Mitigant'],'table18')]},
    {id:'diligence',label:'Due diligence',fields:[field('control35','Leveraged loan'),field('p871','Leveraged loan comments'),field('control36','Higher-risk C&I — Original balance'),field('control37','Higher-risk C&I — Purpose'),field('control38','Higher-risk C&I — Materiality'),field('control39','Higher-risk C&I — Leverage'),field('control40','Higher-risk C&I — Determination'),field('p883','Higher-risk C&I — Comments')],tables:[table('table20','Additional due diligence',range('row',134,138),['Check','Complete','Explanation / date']),table('table21','Interest reserve & retainage',range('row',139,140),['Item','Applies','Comments']),table('table24','ECP borrower', ['row148'],['Borrower','Eligible','Definition']),table('table25','ECP guarantor',['row150'],['Loan guarantor','Swap guarantor','Definition','Active role'])]},
    {id:'ratings',label:'Risk rating & conclusion',fields:[field('p57','Existing risk rating'),field('p51','New / proposed risk rating'),field('p911','Risk-rating downgrade triggers'),choice(['control41','control42'],'Risk-rating determination',['Agree with Model','Override'])],bodies:[{title:'Risk-rating justification / override rationale',keys:range('p',923,929)},{title:'CrDD summary / conclusion',keys:range('p',965,971)}]}
  ];
  const allTables=groups.flatMap(group=>group.tables||[]);
  function rowHidden(s,id){const r=D.rows[id]||s.extraRows.find(x=>x.id===id);if(!r)return true;if(s.hiddenRows.includes(id))return true;const t=D.tables[r.table];return s.hiddenRows.some(x=>D.rows[x]&&D.rows[x].start<t.start&&D.rows[x].end>t.end);}
  function rows(s,spec){
    const out=[],counts=new Set(spec.rows.map(id=>D.rows[id].cells.length));for(const id of D.tables[spec.table].rows){if(spec.rows.includes(id)&&!rowHidden(s,id))out.push({id,source:true});for(const r of s.extraRows.filter(x=>x.table===spec.table&&x.after===id&&(spec.rows.includes(x.sourceRow)||counts.has(x.values.length)))){if(!rowHidden(s,r.id))out.push({id:r.id,source:false});}}
    for(const r of s.extraRows.filter(x=>x.table===spec.table&&!x.sourceRow&&x.values.length===spec.labels.length)){if(!rowHidden(s,r.id))out.push({id:r.id,source:false});}return out;
  }
  function rowFields(s,spec,id){
    if(rowHidden(s,id))return [];
    const r=D.rows[id];if(!r){const extra=s.extraRows.find(x=>x.id===id);if(!extra||extra.table!==spec.table)return [];return extra.values.map((v,i)=>({extra:id+':'+i,label:spec.labels[i]||'Cell '+(i+1)}));}
    return r.cells.flatMap((ps,i)=>{
      const controls=Object.values(D.controls).filter(c=>c.parentRow===id&&ps.some(p=>{const rec=D.paragraphs[p];return c.start>=rec.start&&c.end<=rec.end;}));
      if(controls.length){if(controls.every(c=>c.kind==='checkbox'))return [choice(controls.map(c=>c.id),spec.labels[i]||'Choice')];return controls.map(c=>field(c.id,spec.labels[i]||'Choice'));}
      return ps.filter(p=>D.fields[p]).map((p,j)=>field(p,(spec.labels[i]||'Cell '+(i+1))+(ps.length>1?' — paragraph '+(j+1):'')));
    });
  }
  function value(s,entry){if(entry.extra){const[id,col]=entry.extra.split(':');return s.extraRows.find(x=>x.id===id)?.values[Number(col)]??'';}const v=K.get(s,entry.key);return !Object.hasOwn(s.values,entry.key)&&typeof v==='string'?v.replace(/^\t+/,''):v;}
  function fields(s,group){const result=[...(group.fields||[])];for(const body of group.bodies||[])for(const [i,key] of body.keys.entries())if(i===0||String(K.get(s,key)||'').trim())result.push(field(key,body.title+(i?' — paragraph '+(i+1):'')));return result.filter(e=>{const keys=e.keys||[e.key];return keys.every(k=>{const row=D.paragraphs[k]?.row||D.controls[k]?.parentRow;return !row||!rowHidden(s,row);});});}
  function context(key,tableId){
    if(['p913','p914','p915','p916'].includes(key))return null;
    if(K.ratingLinks.some(x=>x.cover===key||x.paragraph===key)||/^p(90[5-9]|91\d|92\d|96\d|97[01])$/.test(key||''))return 'ratings';
    for(const group of groups){if((group.fields||[]).some(e=>(e.keys||[e.key]).includes(key)))return group.id;if((group.tables||[]).some(t=>t.table===tableId))return group.id;}
    if(tableId==='table5'||key==='p99')return 'actions';
    const n=Number(String(key).replace(/^p/,''));if(n>=107&&n<158)return 'narrative';if(n>=158&&n<524)return 'facility';return null;
  }
  function ratingNotices(s){return K.ratingLinks.flatMap(link=>{const paragraph=K.get(s,link.paragraph),cover=K.get(s,link.cover),parts=K.ratingParts(paragraph,link);if(!Object.hasOwn(s.values,link.paragraph)&&!Object.hasOwn(s.values,link.cover))return [];if(!parts||/[\r\n]/.test(cover))return [{...link,message:link.label+': custom wording is retained. Review the cover and rating paragraph directly.'}];if(parts.value.trim()!==String(cover).trim())return [{...link,message:link.label+': the cover and rating paragraph differ. Edit either value to reconcile them.'}];return [];});}
  function setExtra(s,reference,text){const[id,index]=reference.split(':'),r=s.extraRows.find(x=>x.id===id),col=Number(index);if(!r||!/^\d+$/.test(index)||!Number.isInteger(col)||col>=r.values.length||rowHidden(s,id))throw new Error('Choose a visible table cell.');const next=K.clone(s);next.extraRows.find(x=>x.id===id).values[col]=text;K.validate(next);if(r.values[col]!==text){r.values[col]=text;K.changed(s);}}
  g.HBFQuickFill={groups,allTables,fields,rows,rowFields,rowHidden,value,context,ratingNotices,setExtra};
})(globalThis);
