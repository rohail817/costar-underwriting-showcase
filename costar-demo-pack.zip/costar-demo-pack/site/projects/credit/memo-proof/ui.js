(function () {
  'use strict';
  const M = HBFProofModel, $ = id => document.getElementById(id);
  let state = M.create(), undoState = null, dirty = false, exporting = false;
  const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const labels = {title:'Document title',borrower:'Borrower',relationship:'Relationship',decisionDate:'Decision Date',loanNumber:'Loan number (optional)',rm:'Relationship Manager',pm:'Portfolio Manager',transactionNarrative:'Transaction narrative',psor:'Primary Source of Repayment (PSOR)',ssor:'Secondary Source of Repayment (SSOR)',tsor:'Tertiary Source of Repayment (TSOR)',exposureNarrative:'Exposure narrative',supportNarrative:'Supporting analysis narrative',conclusion:'CrDD SUMMARY/CONCLUSION'};
  function field(path, label, placeholder = '', extra = '') {
    return `<textarea rows="1" class="inline-field ${extra}" data-path="${path}" aria-label="${esc(label)}" placeholder="${esc(placeholder)}">${esc(M.get(state,path))}</textarea>`;
  }
  const labelled = key => `<div><span class="field-label">${labels[key]}</span>${field('fields.'+key, labels[key], 'Type here…')}</div>`;
  const remove = (kind, i) => `<td class="cell-actions"><button class="row-remove" data-command="remove-${kind}" data-index="${i}" aria-label="Remove ${kind} row ${i+1}">×</button></td>`;
  function actionTable() {
    return `<div class="table-scroll"><table class="memo-table"><colgroup><col style="width:44%"><col><col><col><col style="width:35px"></colgroup><thead><tr><th>Credit action</th><th>From</th><th>To</th><th>Difference</th><th class="cell-actions"></th></tr></thead><tbody>${state.actions.map((a,i)=>`<tr>${['action','from','to','difference'].map(k=>`<td>${field(`actions.${i}.${k}`,`Action ${i+1}: ${k}`,k==='action'?`${i+1}. Type a credit action…`:'Type any value…')}</td>`).join('')}${remove('action',i)}</tr>`).join('')}</tbody></table></div>`;
  }
  function exposureTable() {
    return `<div class="table-scroll" tabindex="0" aria-label="Exposure table; scroll horizontally to see all columns"><table class="memo-table exposure-table"><thead><tr>${M.EXPOSURE_HEADERS.map(h=>`<th>${esc(h)}</th>`).join('')}<th class="cell-actions"></th></tr></thead><tbody>${state.exposure.map((r,i)=>`<tr>${r.cells.map((c,j)=>`<td>${field(`exposure.${i}.cells.${j}`,`Exposure row ${i+1}: ${M.EXPOSURE_HEADERS[j]}`)}</td>`).join('')}${remove('exposure',i)}</tr>`).join('')}</tbody></table></div>`;
  }
  function supportTable() {
    const t=state.support.table;
    return `<div class="table-scroll"><table class="memo-table" style="min-width:${Math.max(300,t.headers.length*110)}px"><thead><tr>${t.headers.map((v,i)=>`<th>${field(`support.table.headers.${i}`,`Column ${i+1} heading`,'Column heading')}<button class="row-remove" data-command="remove-column" data-index="${i}" aria-label="Remove column ${i+1}">×</button></th>`).join('')}<th class="cell-actions"></th></tr></thead><tbody>${t.rows.map((r,i)=>`<tr>${r.map((v,j)=>`<td>${field(`support.table.rows.${i}.${j}`,`Supporting table row ${i+1}, column ${j+1}`)}</td>`).join('')}${remove('support',i)}</tr>`).join('')}</tbody></table></div>`;
  }
  function imageBlock() {
    const im=state.support.image;
    if (!im) return '<p class="hint">Paste or insert a chart or picture below your narrative.</p>';
    return `<div class="image-wrap"><img class="support-image" src="${im.data}" alt="${esc(im.alt)}" style="width:${im.widthPercent}%"></div><div class="image-controls"><label>Image width <input aria-label="Image width" type="range" min="20" max="100" value="${im.widthPercent}" data-path="support.image.widthPercent"></label><button data-command="remove-image">Remove image</button></div>${field('support.image.alt','Image description and caption','Add a caption or description…')}`;
  }
  function renderQuick() {
    $('quick-fields').innerHTML = ['title','borrower','relationship','decisionDate','loanNumber','rm','pm'].map(labelled).join('')+
      `<details open><summary>Credit actions</summary>${state.actions.map((a,i)=>`<h3>Action ${i+1}</h3>${['action','from','to','difference'].map(k=>`<span class="field-label">${k[0].toUpperCase()+k.slice(1)}</span>${field(`actions.${i}.${k}`,`Quick fill action ${i+1}: ${k}`,'Type any value…')}`).join('')}`).join('')}<button data-command="add-action">+ Add credit action</button></details>`+
      `<details><summary>Narratives & repayment</summary>${['transactionNarrative','psor','ssor','tsor','exposureNarrative','supportNarrative','conclusion'].map(labelled).join('')}</details>`;
  }
  function render() {
    $('document').innerHTML = `<section class="paper" id="request"><div class="document-top"><img class="bank-logo" src="${HBFProofAssets.logo}" alt="Example Bank"><span class="draft-badge">WORKING DRAFT</span></div>${state.sample?'<div class="example-note">SYNTHETIC EXAMPLE · All borrower names and figures are fictional.</div>':''}${field('fields.title','Document title','Name this request…','memo-title')}<div class="details">${['borrower','relationship','decisionDate','loanNumber','rm','pm'].map(labelled).join('')}<div><span class="field-label">Request type</span><select class="inline-select" id="transaction-type" aria-label="Request type">${['Preliminary','New','Renewal','Modification'].map(v=>`<option${state.transactionType===v?' selected':''}>${v}</option>`).join('')}</select></div></div><h2>REQUEST</h2>${actionTable()}<div class="section-actions"><button data-command="add-action">+ Add credit action</button></div><p class="hint">From, To and Difference accept any text. No calculation is required.</p></section>`+
      `<section class="paper" id="exposure"><h2>EXPOSURE</h2>${field('fields.exposureNarrative','Exposure narrative','Add narrative above the exposure table…')}${exposureTable()}<div class="section-actions"><button data-command="add-exposure">+ Add exposure row</button></div><p class="hint">Paste Excel cells into a table cell. All 13 source columns export on a landscape Word page.</p></section>`+
      `<section class="paper" id="transaction"><h2>TRANSACTION NARRATIVE & RATIONALE</h2>${field('fields.transactionNarrative','Transaction narrative','Type or paste the transaction narrative…')}${actionTable()}<p class="hint">These are the same credit actions shown in Request.</p>${['psor','ssor','tsor'].map(k=>`<h3>${labels[k]}</h3>${field('fields.'+k,labels[k],'Type or paste your analysis…')}`).join('')}</section>`+
      `<section class="paper" id="support"><h2>SUPPORTING ANALYSIS</h2><label class="inclusion"><input id="include-support" type="checkbox"${state.support.included?' checked':''}> Include supporting analysis in this memo</label>${state.support.included?`${field('fields.supportNarrative','Supporting analysis narrative','Write the analysis above the table or chart…')}${supportTable()}<div class="section-actions"><button data-command="add-support">+ Add row</button><button data-command="add-column">+ Add column</button><button data-command="paste-table">Paste table…</button><button data-command="insert-image">${state.support.image?'Replace':'Insert'} image…</button></div>${imageBlock()}`:'<p class="excluded">This section is excluded from Word. Your narrative, table and image are retained here for later.</p>'}</section>`+
      `<section class="paper" id="conclusion"><h2>ATTESTATION</h2>${state.attestation.map((p,i)=>field(`attestation.${i}`,`Standard attestation paragraph ${i+1}`)).join('')}<h2>FOLLOW APPROPRIATE CREDIT AUTHORITIES POLICY</h2><div class="table-scroll"><table class="memo-table signature-table"><thead><tr><th>Title</th><th>Name</th><th>Signature</th><th class="cell-actions"></th></tr></thead><tbody>${state.signatures.map((s,i)=>`<tr>${['title','name','signature'].map(k=>`<td>${field(`signatures.${i}.${k}`,`Signatory ${i+1}: ${k}`,k==='signature'?'Signature space':'Type here…')}</td>`).join('')}${remove('signature',i)}</tr>`).join('')}</tbody></table></div><div class="section-actions"><button data-command="add-signature">+ Add signatory</button></div><p class="hint">Signature cells remain editable in Word for your bank’s signing process.</p><h2>CrDD SUMMARY/CONCLUSION</h2>${field('fields.conclusion','CrDD summary and conclusion','Type or paste your conclusion…')}</section>`;
    renderQuick(); resizeAll(); updateReview(); $('undo').disabled=!undoState;
  }
  function resize(el) { if (el.tagName==='TEXTAREA' && el.offsetParent !== null) { el.style.height='auto'; el.style.height=Math.max(32,el.scrollHeight+2)+'px'; } }
  function resizeAll() { document.querySelectorAll('.inline-field').forEach(resize); }
  function status(message, error=false) { $('status').textContent=message; $('status').classList.toggle('error',error); }
  function updateReview() { $('review').checked=state.reviewedRevision===state.revision; }
  function edited() { dirty=true; updateReview(); status('Draft · Edits in this window · Download a working file to keep them'); }
  function mutate(fn) { const prior=M.clone(state); try { fn(); M.validate(state); M.changed(state); undoState=prior; edited(); render(); } catch (e) { state=prior; status(e.message,true); } }
  function download(blob,name) { const url=URL.createObjectURL(blob), a=document.createElement('a'); a.href=url; a.download=name; a.click(); setTimeout(()=>URL.revokeObjectURL(url),30000); }
  const filename=()=>((state.fields.title||'Credit-memo').replace(/[^a-z0-9]+/gi,'-').replace(/^-|-$/g,'').slice(0,70)||'Credit-memo');
  function toggleQuick(show) { $('quick').hidden=!show; $('quick-toggle').setAttribute('aria-expanded',String(show)); document.querySelector('.workspace').classList.toggle('with-quick',show); resizeAll(); }
  function replaceDocument(next) { if (dirty && !confirm('Replace this draft? Download a working file first if you want to keep it.')) return false; undoState=M.clone(state); state=next; dirty=true; render(); status('Draft · Document opened in this window'); return true; }
  async function decodeImage(data) { return new Promise((resolve,reject)=>{ const img=new Image(); img.onload=()=>resolve(img); img.onerror=()=>reject(new Error('The image cannot be decoded. Your current document is unchanged.')); img.src=data; }); }
  async function insertImage(file) {
    if (!file) return;
    if (!['image/png','image/jpeg'].includes(file.type) || file.size>6*1024*1024) throw new Error('Choose a PNG or JPEG under 6 MB.');
    const session=state.sessionId;
    const data=await new Promise((resolve,reject)=>{ const r=new FileReader(); r.onload=()=>resolve(r.result); r.onerror=()=>reject(new Error('Could not read the image.')); r.readAsDataURL(file); });
    const img=await decodeImage(data);
    if (img.naturalWidth>6000 || img.naturalHeight>6000 || img.naturalWidth*img.naturalHeight>20000000) throw new Error('Choose an image under 6,000 pixels per side and 20 megapixels.');
    const canvas=document.createElement('canvas'); canvas.width=img.naturalWidth; canvas.height=img.naturalHeight; canvas.getContext('2d').drawImage(img,0,0);
    const png=canvas.toDataURL('image/png'), info=M.pngInfo(png);
    if (session!==state.sessionId) throw new Error('The document changed while the image was opening. Insert the image again.');
    mutate(()=>{state.support.image={data:png,width:info.width,height:info.height,widthPercent:80,alt:''};});
  }
  document.addEventListener('input',e=>{
    const path=e.target.dataset.path; if (!path) return;
    try { M.set(state,path,e.target.type==='range'?Number(e.target.value):e.target.value); undoState=null; $('undo').disabled=true; document.querySelectorAll('[data-path]').forEach(el=>{if (el!==e.target && el.dataset.path===path){el.value=M.get(state,path);resize(el);}}); resize(e.target); if (path==='support.image.widthPercent') document.querySelector('.support-image').style.width=state.support.image.widthPercent+'%'; if (path==='support.image.alt') document.querySelector('.support-image').alt=state.support.image.alt; edited(); } catch(err){status(err.message,true);}
  });
  document.addEventListener('change',e=>{
    if (e.target.id==='transaction-type') mutate(()=>{state.transactionType=e.target.value;});
    if (e.target.id==='include-support') mutate(()=>{state.support.included=e.target.checked;});
  });
  document.addEventListener('toggle',e=>{if(e.target.tagName==='DETAILS') resizeAll();},true);
  document.addEventListener('paste',e=>{
    const path=e.target.dataset.path;
    if (!path) return;
    const text=e.clipboardData?.getData('text/plain') || '';
    const cell=path.match(/^exposure\.(\d+)\.cells\.(\d+)$/) || path.match(/^support\.table\.rows\.(\d+)\.(\d+)$/);
    if(cell && text.includes('\t')) { e.preventDefault(); try {const grid=M.parseTable(text); mutate(()=>M.pasteGrid(state,path.startsWith('exposure')?'exposure':'support',Number(cell[1]),Number(cell[2]),grid));}catch(err){status(err.message,true);} }
    else if (path==='fields.supportNarrative' && e.clipboardData?.files.length) { e.preventDefault(); insertImage(e.clipboardData.files[0]).catch(err=>status(err.message,true)); }
  });
  document.addEventListener('click',e=>{
    const b=e.target.closest('[data-command]'); if(!b) return; const i=Number(b.dataset.index), command=b.dataset.command;
    const handlers={
      'add-action':()=>{state.actions.push(M.emptyAction());},'remove-action':()=>{state.actions.splice(i,1);},
      'add-exposure':()=>{state.exposure.push(M.emptyExposure());},'remove-exposure':()=>{state.exposure.splice(i,1);},
      'add-support':()=>{state.support.table.rows.push(state.support.table.headers.map(()=>''));},'remove-support':()=>{state.support.table.rows.splice(i,1);},
      'add-column':()=>{state.support.table.headers.push('');state.support.table.rows.forEach(r=>r.push(''));},
      'remove-column':()=>{if(state.support.table.headers.length===1) throw new Error('Keep at least one column.');state.support.table.headers.splice(i,1);state.support.table.rows.forEach(r=>r.splice(i,1));},
      'add-signature':()=>{state.signatures.push({title:'',name:'',signature:''});},'remove-signature':()=>{state.signatures.splice(i,1);},'remove-image':()=>{state.support.image=null;}
    };
    if(handlers[command]) mutate(handlers[command]);
    if(command==='insert-image') $('image-upload').click();
    if(command==='paste-table') { $('paste-error').textContent=''; $('paste-text').value=''; $('paste-dialog').showModal(); }
  });
  $('paste-apply').onclick=()=>{try{const rows=M.parseTable($('paste-text').value), headers=$('paste-header').checked?rows.shift():rows[0].map((v,i)=>`Column ${i+1}`);if(rows.length>200)throw new Error('Paste up to 200 data rows.');mutate(()=>{state.support.table={headers,rows};});$('paste-dialog').close();}catch(e){$('paste-error').textContent=e.message;}};
  $('quick-toggle').onclick=()=>toggleQuick($('quick').hidden); $('quick-close').onclick=()=>toggleQuick(false);
  $('file-toggle').onclick=()=>{ $('file-menu').hidden=!$('file-menu').hidden; $('file-toggle').setAttribute('aria-expanded',String(!$('file-menu').hidden)); };
  $('new').onclick=()=>{if(replaceDocument(M.create())) $('file-menu').hidden=true;};
  $('sample').onclick=()=>{if(replaceDocument(M.sample())) $('file-menu').hidden=true;};
  $('undo').onclick=()=>{if(undoState){const old=state;state=undoState;undoState=old;M.changed(state);edited();render();status('Draft · Structural change restored');}};
  $('review').onchange=()=>{state.reviewedRevision=$('review').checked?state.revision:null;dirty=true;status(state.reviewedRevision===null?'Draft · Review mark cleared':'Draft · Reviewed for this revision; this is not bank approval');};
  $('save').onclick=async()=>{try{const frozen=M.clone(state), savedName=filename();const text=await M.checkpoint(frozen);download(new Blob([text],{type:'application/json'}),savedName+'.working.json');if(state.sessionId===frozen.sessionId && state.revision===frozen.revision && state.reviewedRevision===frozen.reviewedRevision)dirty=false;status(dirty?'Draft · Working file downloaded; newer edits still need saving':'Draft · Working file downloaded');}catch(e){status(e.message,true);}};
  $('open').onclick=()=>$('working-upload').click();
  $('working-upload').onchange=async e=>{const file=e.target.files[0];e.target.value='';if(!file)return;try{if(file.size>M.MAX_FILE_BYTES)throw new Error('Choose a working file under 12 MB.');const next=await M.restore(await file.text());if(next.support.image)await decodeImage(next.support.image.data);replaceDocument(next);}catch(err){status(err.message,true);}};
  $('image-upload').onchange=async e=>{const file=e.target.files[0];e.target.value='';try{await insertImage(file);}catch(err){status(err.message,true);}};
  $('export').onclick=async()=>{if(exporting)return;exporting=true;$('export').disabled=true;try{const frozen=M.clone(state), name=filename();status('Preparing your Word draft…');const blob=await HBFProofExport.blob(frozen);download(blob,name+'.docx');status('Draft · Word downloaded · Use Working file to keep an editable session');}catch(e){status(e.message,true);}finally{exporting=false;$('export').disabled=false;}};
  window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
  window.addEventListener('resize',resizeAll);
  render();
})();
