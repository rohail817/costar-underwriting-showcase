(function (g) {
  'use strict';
  const FORMAT = 'HBF-CDS-DOCUMENT-PROOF';
  const VERSION = '1.0';
  const MAX_FILE_BYTES = 12 * 1024 * 1024;
  const EXPOSURE_HEADERS = ['Borrower', 'Facility Type', 'Bank Group Commitment', 'Existing Lender Commitment', 'Proposed Commitment', 'Outstanding Balance', 'Note Maturity', 'RR', 'Interest Rate', 'Floor', 'Fee', 'Repay', 'Coll'];
  const FIELDS = ['title', 'borrower', 'relationship', 'decisionDate', 'loanNumber', 'rm', 'pm', 'transactionNarrative', 'psor', 'ssor', 'tsor', 'exposureNarrative', 'supportNarrative', 'conclusion'];
  const clone = value => JSON.parse(JSON.stringify(value));
  const uid = () => g.crypto.randomUUID();
  const emptyAction = () => ({ id: uid(), action: '', from: '', to: '', difference: '' });
  const emptyExposure = () => ({ id: uid(), cells: EXPOSURE_HEADERS.map(() => '') });
  function create() {
    const fields = Object.fromEntries(FIELDS.map(key => [key, '']));
    fields.title = 'Credit request';
    return { schema: 'document-proof-1', sessionId: uid(), transactionType: 'Preliminary', fields,
      actions: [emptyAction()], exposure: [emptyExposure()],
      support: { included: true, table: { headers: ['Period', 'Sales', 'Closings'], rows: [['', '', '']] }, image: null },
      attestation: clone(g.HBFProofAssets.attestation), signatures: [{ title: '', name: '', signature: '' }],
      revision: 0, reviewedRevision: null, sample: false };
  }
  function get(state, path) { return path.split('.').reduce((v, k) => v[k], state); }
  function editablePath(path) {
    return /^fields\.(title|borrower|relationship|decisionDate|loanNumber|rm|pm|transactionNarrative|psor|ssor|tsor|exposureNarrative|supportNarrative|conclusion)$/.test(path)
      || /^actions\.\d+\.(action|from|to|difference)$/.test(path)
      || /^exposure\.\d+\.cells\.\d+$/.test(path)
      || /^support\.table\.(headers\.\d+|rows\.\d+\.\d+)$/.test(path)
      || /^attestation\.[01]$/.test(path)
      || /^signatures\.\d+\.(title|name|signature)$/.test(path)
      || /^support\.image\.(alt|widthPercent)$/.test(path);
  }
  function changed(state) { state.revision += 1; state.reviewedRevision = null; }
  function set(state, path, value) {
    if (!editablePath(path)) throw new Error('This field is not editable.');
    const keys = path.split('.'), last = keys.pop();
    const target = keys.reduce((v, k) => v[k], state);
    if (!target || !(last in target)) throw new Error('The field no longer exists.');
    if (path.endsWith('.widthPercent')) {
      if (!Number.isFinite(value) || value < 20 || value > 100) throw new Error('Choose an image width between 20% and 100%.');
    } else if (typeof value !== 'string') throw new Error('Enter text in this field.');
    if (target[last] !== value) { target[last] = value; changed(state); }
  }
  function canonical(value) {
    if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
    if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + canonical(value[k])).join(',') + '}';
    return JSON.stringify(value);
  }
  async function hash(value) {
    if (!g.crypto?.subtle) throw new Error('Open this file in a current version of Edge, Chrome, Firefox or Safari to save working files.');
    const digest = await g.crypto.subtle.digest('SHA-256', new TextEncoder().encode(canonical(value)));
    return Array.from(new Uint8Array(digest), n => n.toString(16).padStart(2, '0')).join('');
  }
  const bytes = s => new TextEncoder().encode(s).byteLength;
  function exactKeys(obj, expected, label) {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj) || Object.keys(obj).sort().join('|') !== expected.slice().sort().join('|')) throw new Error(label + ' has unsupported or missing content. The current document has not been replaced.');
  }
  function string(value) { if (typeof value !== 'string' || /[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(value)) throw new Error('A text field contains an unsupported value or control character.'); }
  function strings(arr) { if (!Array.isArray(arr)) throw new Error('Expected table text.'); arr.forEach(string); }
  function array(arr, max, label) { if (!Array.isArray(arr) || arr.length > max) throw new Error(label + ' exceeds the supported number of rows.'); }
  function pngInfo(data) {
    if (typeof data !== 'string' || !/^data:image\/png;base64,[A-Za-z0-9+/]*={0,2}$/.test(data)) throw new Error('Use a PNG or JPEG image added through Insert image.');
    let raw;
    try { raw = g.atob(data.split(',')[1]); } catch (_) { throw new Error('The image is not readable.'); }
    const b = Uint8Array.from(raw, c => c.charCodeAt(0));
    if (b.length > 6 * 1024 * 1024 || b.length < 45 || [137,80,78,71,13,10,26,10].some((v,i) => b[i] !== v)) throw new Error('The image is invalid or exceeds 6 MB.');
    const v = new DataView(b.buffer), width = v.getUint32(16), height = v.getUint32(20);
    if (!width || !height || width > 6000 || height > 6000 || width * height > 20000000) throw new Error('Use an image under 6,000 pixels per side and 20 megapixels.');
    let p = 8, end = false, idat = false;
    while (p + 12 <= b.length) {
      const len = v.getUint32(p), name = String.fromCharCode(...b.slice(p + 4, p + 8));
      if (p + 12 + len > b.length || (p === 8 && (name !== 'IHDR' || len !== 13))) throw new Error('The PNG image is incomplete.');
      if (name === 'IDAT') idat = true;
      p += len + 12;
      if (name === 'IEND') { end = len === 0 && p === b.length; break; }
    }
    if (!end || !idat) throw new Error('The PNG image is incomplete.');
    return { width, height, data: b };
  }
  function validate(s) {
    exactKeys(s, ['schema','sessionId','transactionType','fields','actions','exposure','support','attestation','signatures','revision','reviewedRevision','sample'], 'Document');
    if (s.schema !== 'document-proof-1' || !/^[a-f\d-]{36}$/i.test(s.sessionId)) throw new Error('This document format is not supported.');
    if (!['Preliminary','New','Renewal','Modification'].includes(s.transactionType)) throw new Error('The transaction type is invalid.');
    if (typeof s.sample !== 'boolean' || !Number.isSafeInteger(s.revision) || s.revision < 0 || !(s.reviewedRevision === null || s.reviewedRevision === s.revision)) throw new Error('The draft review state is invalid.');
    exactKeys(s.fields, FIELDS, 'Document fields'); Object.values(s.fields).forEach(string);
    array(s.actions, 100, 'Credit actions'); array(s.exposure, 200, 'Exposure table'); array(s.signatures, 30, 'Signature table');
    const ids = new Set();
    s.actions.forEach(a => { exactKeys(a, ['id','action','from','to','difference'], 'Credit action'); Object.values(a).forEach(string); if (!a.id || ids.has(a.id)) throw new Error('Credit action IDs are duplicated.'); ids.add(a.id); });
    s.exposure.forEach(r => { exactKeys(r, ['id','cells'], 'Exposure row'); string(r.id); strings(r.cells); if (r.cells.length !== 13 || !r.id || ids.has(r.id)) throw new Error('Exposure table structure is invalid.'); ids.add(r.id); });
    strings(s.attestation); if (s.attestation.length !== 2) throw new Error('The attestation structure is invalid.');
    s.signatures.forEach(r => { exactKeys(r, ['title','name','signature'], 'Signature row'); Object.values(r).forEach(string); });
    exactKeys(s.support, ['included','table','image'], 'Supporting section');
    if (typeof s.support.included !== 'boolean') throw new Error('Attachment selection is invalid.');
    exactKeys(s.support.table, ['headers','rows'], 'Supporting table');
    const t = s.support.table; strings(t.headers); array(t.rows, 200, 'Supporting table');
    if (!t.headers.length || t.headers.length > 20) throw new Error('A supporting table can have 1 to 20 columns.');
    t.rows.forEach(r => { strings(r); if (r.length !== t.headers.length) throw new Error('Supporting table rows must have the same number of columns.'); });
    if (s.support.image !== null) {
      exactKeys(s.support.image, ['data','width','height','widthPercent','alt'], 'Image');
      const info = pngInfo(s.support.image.data); string(s.support.image.alt);
      if (info.width !== s.support.image.width || info.height !== s.support.image.height || !Number.isFinite(s.support.image.widthPercent) || s.support.image.widthPercent < 20 || s.support.image.widthPercent > 100) throw new Error('The saved image dimensions are invalid.');
    }
    return s;
  }
  async function checkpoint(state) {
    const frozen = validate(clone(state));
    const value = { format: FORMAT, version: VERSION, document: frozen, sha256: await hash(frozen) };
    const text = JSON.stringify(value, null, 2);
    if (bytes(text) > MAX_FILE_BYTES) throw new Error('This working file exceeds 12 MB. Download Word to preserve the document, then reduce an image or table before saving a working file. Nothing was removed.');
    return text;
  }
  async function restore(text) {
    if (typeof text !== 'string' || bytes(text) > MAX_FILE_BYTES) throw new Error('Choose a working file under 12 MB.');
    let e;
    try { e = JSON.parse(text, (key, value) => { if (['__proto__','prototype','constructor'].includes(key)) throw new Error('unsafe'); return value; }); } catch (_) { throw new Error('This working file is not valid. Your current document is unchanged.'); }
    if (e?.checkpointFormat === 'HBF-CDS-CHECKPOINT') throw new Error('Open this older working file in the current Studio. This small editing example does not migrate older deals.');
    exactKeys(e, ['format','version','document','sha256'], 'Working file');
    if (e.format !== FORMAT || e.version !== VERSION) throw new Error('This working file needs a different version of the Studio. Your current document is unchanged.');
    validate(e.document);
    if (e.sha256 !== await hash(e.document)) throw new Error('This working file has changed or is incomplete. Your current document is unchanged.');
    // A checksum detects corruption; it does not authenticate evidence or approval.
    e.document.reviewedRevision = null;
    return e.document;
  }
  function parseTable(text) {
    if (typeof text !== 'string' || bytes(text) > MAX_FILE_BYTES) throw new Error('The pasted table is too large.');
    const input = text.replace(/\r\n?/g, '\n');
    const rows = []; let row = [], cell = '', quoted = false, closed = false;
    for (let i = 0; i < input.length; i++) {
      const c = input[i];
      if (quoted) { if (c === '"') { if (input[i+1] === '"') { cell += '"'; i++; } else { quoted = false; closed = true; } } else cell += c; }
      else if (c === '"' && cell === '' && !closed) quoted = true;
      else if (c === '\t') { row.push(cell); cell = ''; closed = false; }
      else if (c === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; closed = false; }
      else { if (closed) throw new Error('The pasted table contains invalid quoted text. Paste as plain text or correct the cell.'); cell += c; }
    }
    if (quoted) throw new Error('The pasted table has an unfinished quoted cell.');
    if (row.length || cell || !rows.length || closed) { row.push(cell); rows.push(row); }
    const n = Math.max(...rows.map(r => r.length));
    if (rows.length > 201 || n > 20) throw new Error('Paste up to 200 data rows and 20 columns.');
    return rows.map(r => [...r, ...Array(n - r.length).fill('')]);
  }
  function pasteGrid(state, target, startRow, startCol, grid) {
    if (!['exposure','support'].includes(target) || !Number.isInteger(startRow) || startRow < 0 || !Number.isInteger(startCol) || startCol < 0) throw new Error('Select a valid table cell.');
    grid.forEach(strings);
    const rows = clone(target === 'exposure' ? state.exposure.map(r => r.cells) : state.support.table.rows);
    const cols = target === 'exposure' ? 13 : state.support.table.headers.length;
    if (startRow + grid.length > 200 || grid.some(r => r.length + startCol > cols)) throw new Error('The pasted range is wider than this table or exceeds 200 rows. Add supporting-table columns first.');
    while (rows.length < startRow + grid.length) rows.push(Array(cols).fill(''));
    grid.forEach((r, y) => r.forEach((v, x) => { rows[startRow+y][startCol+x] = v; }));
    if (target === 'exposure') state.exposure = rows.map((cells, i) => ({ id: state.exposure[i]?.id || uid(), cells }));
    else state.support.table.rows = rows;
    changed(state);
  }
  function sample() {
    const s = create(); s.sample = true; s.transactionType = 'Renewal';
    Object.assign(s.fields, { title: 'Renewal and facility increase', borrower: 'Northline Homes — synthetic example', relationship: 'Northline Group — synthetic', decisionDate: '2026-09-05', rm: 'Alex Morgan', pm: 'Jordan Lee',
      transactionNarrative: 'Northline requests a six-month renewal and an increase in the revolving construction facility. The request combines the borrower’s emailed project description with operating information entered by the PM.\n\nFinal terms and supporting information remain subject to review. This is a fictional editing example.',
      psor: 'Sales and closings of the financed homes are the primary source of repayment. The PM can add project-specific absorption, pricing and completion discussion here.',
      ssor: 'The PM can discuss cash flow from the borrower’s broader business operations here.', tsor: 'Guarantor support and collateral liquidation remain subject to the PM’s analysis.',
      exposureNarrative: 'Amounts and terms below are fictional and were entered manually. No figures are represented as independently verified.',
      supportNarrative: 'The sample operating figures show closings increasing from six to eight homes. The PM can replace this paragraph with analysis of the actual figures received, then paste a table or chart below it.',
      conclusion: 'Preliminary discussion only. Outstanding analysis and the full bank memo remain to be completed.' });
    s.actions = [{id:uid(),action:'Increase the revolving facility',from:'$50MM',to:'$150MM',difference:'+$100MM'}, {id:uid(),action:'Extend the facility',from:'September 30, 2026',to:'March 31, 2027',difference:'Six months'}, {id:uid(),action:'Update reporting delivery',from:'Email to PM',to:'Email to PM and RM',difference:'Add RM to distribution'}];
    s.exposure = [{id:uid(),cells:['Northline Homes','RLOC','$200MM','$50MM','$150MM','$32MM','03/31/2027','6','SOFR + 300 bps','4.00%','25 bps','Unit releases','1st DOT']}, {id:uid(),cells:['Related entity','Term loan','—','$10MM','$10MM','$8MM','12/31/2027','6','7.00%','—','—','Monthly P&I','Real estate']}];
    s.support.table = {headers:['Period','Sales','Closings'],rows:[['April 2026','7','6'],['May 2026','8','7'],['June 2026','9','8']]};
    if (g.HBFProofAssets.chart) { const i=pngInfo(g.HBFProofAssets.chart); s.support.image={data:g.HBFProofAssets.chart,width:i.width,height:i.height,widthPercent:80,alt:'Synthetic monthly operating figures; April, May and June 2026.'}; }
    s.signatures=[{title:'Portfolio Manager',name:'Jordan Lee',signature:''},{title:'Relationship Manager',name:'Alex Morgan',signature:''}];
    return s;
  }
  g.HBFProofModel = { FORMAT, VERSION, MAX_FILE_BYTES, EXPOSURE_HEADERS, FIELDS, clone, create, sample, get, set, changed, emptyAction, emptyExposure, uid, validate, hash, checkpoint, restore, parseTable, pasteGrid, pngInfo };
})(globalThis);
