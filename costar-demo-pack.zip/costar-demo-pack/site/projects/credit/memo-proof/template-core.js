(function(g){
  'use strict';
  const D=g.HBFTemplateData, MAX=12*1024*1024;
  const clone=v=>JSON.parse(JSON.stringify(v)), uid=()=>g.crypto.randomUUID?.()||g.HBFCrypto.uuid();
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
  const bytes=s=>new TextEncoder().encode(s).byteLength;
  const canonical=v=>Array.isArray(v)?'['+v.map(canonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}':JSON.stringify(v);
  async function hash(v){const text=canonical(v),digest=g.HBFCrypto?await g.HBFCrypto.sha256(text):await g.crypto.subtle.digest('SHA-256',new TextEncoder().encode(text));return Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('');}
  function string(v){if(typeof v!=='string'||/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF\uD800-\uDFFF]/u.test(v))throw new Error('Text contains an unsupported character.');}
  function create(){return {schema:'hbf-template-draft-2',template:D.templateKey,session:uid(),values:{},actions:null,inserts:[],extraRows:[],hiddenRows:[],revision:0,reviewedRevision:null};}
  function changed(s){s.revision++;s.reviewedRevision=null;}
  function actions(s){return s.actions||D.actions.map(row=>row.map((p,i)=>i===0?D.fields[p].value.replace(/^\d+\.\s*/,''):D.fields[p].value));}
  const actionField=new Map(D.actions.flatMap((r,i)=>r.map((p,j)=>[p,[i,j]])));
  const checkboxGroups={...D.checkboxGroups};
  for(const pair of [[17,18],[19,20],[21,22],[23,24],[25,26],[27,28],[29,30],[31,32],[33,34],[41,42]]){const members=pair.map(n=>'control'+n);for(const id of members)checkboxGroups[id]=members;}
  function get(s,key){
    if(s.actions && key===D.anchors.request)return s.actions.map((a,i)=>a[0]?`${i+1}. ${a[0]}`:'').filter(Boolean).join('\n');
    if(s.actions && actionField.has(key)){const [i,j]=actionField.get(key);return s.actions[i]?(j===0?`${i+1}. ${s.actions[i][j]}`:s.actions[i][j]):'';}
    return Object.hasOwn(s.values,key)?s.values[key]:D.fields[key]?.value;
  }
  function setSingle(s,key,value){
    const f=D.fields[key];if(!f)throw new Error('Choose an editable field in this template.');
    if(f.kind==='checkbox'){if(typeof value!=='boolean')throw new Error('Choose a checkbox value.');}else string(value);
    if(f.kind==='dropdown'&&!f.options.includes(value)&&value!==f.value&&key!=='control0')throw new Error('Choose an option in this bank field.');
    if(key===D.anchors.request){const old=clone(actions(s)),lines=value.split('\n').map(v=>v.replace(/^\s*\d+[.)]\s*/,''));if(lines.length>100)throw new Error('Use up to 100 credit actions.');s.actions=lines.map((v,i)=>({v,i})).filter(({v,i})=>v||old[i]?.some(Boolean)).map(({v,i})=>[v,...(old[i]?.slice(1)||['','',''])]);changed(s);return;}
    if(actionField.has(key)){const [i,j]=actionField.get(key);if(!s.actions)s.actions=clone(actions(s));while(s.actions.length<=i)s.actions.push(['','','','']);s.actions[i][j]=j===0?value.replace(/^\s*\d+\.\s*/,''):value;changed(s);return;}
    if(get(s,key)===value)return;
    if(value===f.value)delete s.values[key];else s.values[key]=value;
    if(f.kind==='checkbox'&&value){for(const peer of checkboxGroups[key]||[]){if(peer!==key)s.values[peer]=false;}}
    changed(s);
  }
  const ratingLinks=[{cover:'p57',paragraph:'p906',label:'Existing Risk Rating'},{cover:'p51',paragraph:'p907',label:'New Risk Rating'}];
  function ratingParts(text,link){const match=String(text).match(new RegExp('^([ \\t]*'+link.label+':[ \\t]*)([^\\r\\n]*)([\\s\\S]*)$','i'));return match?{prefix:match[1],value:match[2],suffix:match[3]}:null;}
  function relatedFields(key){const link=ratingLinks.find(x=>x.cover===key||x.paragraph===key);return link?[link.cover,link.paragraph]:[key,...(checkboxGroups[key]||[])];}
  function set(s,key,value){
    const link=ratingLinks.find(x=>x.cover===key||x.paragraph===key);if(!link)return setSingle(s,key,value);
    string(value);
    // Only the rating value is shared. Keep a PM's additional lines and custom
    // paragraph wording; do not regenerate a narrative to fill a cover cell.
    const parts=ratingParts(key===link.paragraph?value:get(s,link.paragraph),link),cover=key===link.cover?value:get(s,link.cover);
    setSingle(s,key,value);
    if(!parts||/[\r\n]/.test(cover))return;
    if(key===link.cover)setSingle(s,link.paragraph,parts.prefix+value+parts.suffix);
    else setSingle(s,link.cover,parts.value);
  }
  function setAction(s,i,j,value){string(value);if(!Number.isInteger(i)||i<0||i>=100||!Number.isInteger(j)||j<0||j>3)throw new Error('Choose a credit action.');if(!s.actions)s.actions=clone(actions(s));while(s.actions.length<=i)s.actions.push(['','','','']);s.actions[i][j]=value;changed(s);}
  // Source rows supply geometry only. New rows have blank, directly editable
  // cells; no example answers, checkboxes, signatures or identifiers are copied.
  const rowLayouts=new Map();
  function rowLayout(id){
    if(rowLayouts.has(id))return rowLayouts.get(id);
    const r=D.rows[id];if(!r||r.nested)throw new Error('Choose a row inside the smaller table to add a matching row.');
    const xml=D.xml.slice(r.start,r.end);if(/<w:vMerge\b/.test(xml))throw new Error('This row shares cells vertically. Choose a row without shared cells, or insert a separate table.');
    const cells=[...xml.matchAll(/<w:tc(?:\s[^>]*)?>[\s\S]*?<\/w:tc>/g)].map(m=>{
      const properties=m[0].match(/<w:tcPr\b[^>]*>[\s\S]*?<\/w:tcPr>/)?.[0]||'';
      return {properties,span:Number(properties.match(/<w:gridSpan\b[^>]*w:val="(\d+)"/)?.[1]||1),paragraphProperties:m[0].match(/<w:pPr\b[^>]*>[\s\S]*?<\/w:pPr>/)?.[0]||'',runProperties:m[0].match(/<w:rPr\b[^>]*>[\s\S]*?<\/w:rPr>/)?.[0]||''};
    });
    if(!cells.length||cells.length>20||cells.length!==r.cells.length)throw new Error('Choose another row or insert a separate table.');
    const layout={cells};rowLayouts.set(id,layout);return layout;
  }
  function addRow(s,table,selected){
    if(!D.tables[table]||table===D.anchors.actionsTable)throw new Error('Use Add credit action for the request table.');
    if(s.extraRows.length>=200)throw new Error('Use up to 200 added rows.');
    const previous=s.extraRows.find(r=>r.id===selected),sourceRow=previous?.sourceRow||selected;
    if(D.rows[sourceRow]?.table!==table)throw new Error('Click the row whose layout you want to use.');
    const layout=rowLayout(sourceRow),after=previous?.after||sourceRow,r={id:uid(),table,sourceRow,after,values:layout.cells.map(()=> '')};
    const index=previous?s.extraRows.indexOf(previous)+1:s.extraRows.findLastIndex(x=>x.after===after)+1;
    s.extraRows.splice(index>0?index:s.extraRows.length,0,r);changed(s);return r;
  }
  const protectedRows=new Set(['row0','row19','row29','row33','row34','row45','row50','row54','row55','row56','row72','row79','row87','row88','row92','row93','row100','row104','row106','row110','row114','row115','row147','row149','row151','row162','row187','row216']);
  function hideRow(s,id){
    const r=D.rows[id]||s.extraRows.find(r=>r.id===id);if(!r||r.table===D.anchors.actionsTable)throw new Error('Choose a table row.');
    if(protectedRows.has(id))throw new Error('Keep this table heading. You can edit its wording directly.');
    if(s.hiddenRows.includes(id))return;
    if(D.rows[id]&&s.inserts.some(x=>{const p=D.paragraphs[x.anchor];return p.start>=r.start&&p.end<=r.end;}))throw new Error('Move or remove this row’s inserted exhibit before removing the row.');
    // Removing one cell of a vertical merge changes neighboring rows. Keep the
    // shared form intact; its individual paragraphs remain directly editable.
    if(D.rows[id]&&/<w:vMerge\b/.test(D.xml.slice(r.start,r.end)))throw new Error('This row shares cells vertically. Edit its contents directly.');
    s.hiddenRows.push(id);changed(s);
  }
  function restoreRow(s,id){if(!s.hiddenRows.includes(id))return;s.hiddenRows=s.hiddenRows.filter(x=>x!==id);changed(s);}
  function parseTable(text){
    string(text);if(bytes(text)>MAX)throw new Error('Paste a smaller table.');const src=text.replace(/\r\n?/g,'\n');let row=[],cell='',quoted=false,closed=false;const rows=[];
    for(let i=0;i<src.length;i++){const c=src[i];if(quoted){if(c==='"'){if(src[i+1]==='"'){cell+='"';i++;}else{quoted=false;closed=true;}}else cell+=c;}else if(c==='"'&&!cell&&!closed)quoted=true;else if(c==='\t'||c==='\n'){row.push(cell);cell='';closed=false;if(c==='\n'){rows.push(row);row=[];}}else{if(closed)throw new Error('The pasted table has invalid quoted text.');cell+=c;}}
    if(quoted)throw new Error('The pasted table has an unfinished quoted cell.');if(row.length||cell||!rows.length||closed){row.push(cell);rows.push(row);}const cols=Math.max(...rows.map(r=>r.length));if(rows.length>201||cols>20)throw new Error('Paste up to 200 rows and 20 columns.');return rows.map(r=>r.concat(Array(cols-r.length).fill('')));
  }
  function pngInfo(data){
    if(typeof data!=='string'||!/^data:image\/png;base64,[A-Za-z0-9+/]*={0,2}$/.test(data))throw new Error('Insert a PNG or JPEG image.');let raw;try{raw=g.atob(data.split(',')[1]);}catch{throw new Error('The image cannot be read.');}
    const b=Uint8Array.from(raw,c=>c.charCodeAt(0));if(b.length<45||b.length>6*1024*1024||[137,80,78,71,13,10,26,10].some((v,i)=>b[i]!==v))throw new Error('Choose an image under 6 MB.');const v=new DataView(b.buffer),width=v.getUint32(16),height=v.getUint32(20);if(!width||!height||width>6000||height>6000||width*height>20000000)throw new Error('Choose an image under 6,000 pixels per side and 20 megapixels.');let pos=8,idat=false,end=false;
    while(pos+12<=b.length){const len=v.getUint32(pos),name=String.fromCharCode(...b.slice(pos+4,pos+8));if(pos+12+len>b.length||(pos===8&&(name!=='IHDR'||len!==13)))throw new Error('The image is incomplete.');if(name==='IDAT')idat=true;pos+=len+12;if(name==='IEND'){end=len===0&&pos===b.length;break;}}
    if(!idat||!end)throw new Error('The image is incomplete.');return {width,height,data:b};
  }
  function keys(v,expected,label){if(!v||Array.isArray(v)||typeof v!=='object'||Object.keys(v).sort().join('|')!==expected.slice().sort().join('|'))throw new Error(label+' has an unsupported structure.');}
  function rectangular(t){keys(t,['headers','rows'],'Table');if(!Array.isArray(t.headers)||!t.headers.length||t.headers.length>20||!Array.isArray(t.rows)||t.rows.length>200)throw new Error('Use up to 200 rows and 20 columns.');t.headers.forEach(string);t.rows.forEach(r=>{if(!Array.isArray(r)||r.length!==t.headers.length)throw new Error('Table rows have different widths.');r.forEach(string);});}
  function validate(s){
    keys(s,['schema','template','session','values','actions','inserts','extraRows','hiddenRows','revision','reviewedRevision',...(Object.hasOwn(s,'sectionChoices')?['sectionChoices']:[])],'Working document');if(s.schema!=='hbf-template-draft-2'||s.template!==D.templateKey)throw new Error('This file uses a different template revision. The current document is unchanged.');string(s.session);if(!s.session||!Number.isSafeInteger(s.revision)||s.revision<0||!(s.reviewedRevision===null||s.reviewedRevision===s.revision))throw new Error('The draft state is invalid.');
    if(Object.hasOwn(s,'sectionChoices')){if(!s.sectionChoices||typeof s.sectionChoices!=='object'||Array.isArray(s.sectionChoices)||Object.entries(s.sectionChoices).some(([id,v])=>!g.HBFSupport?.sections.some(x=>x.id===id)||typeof v!=='boolean'))throw new Error('The supporting section choices are invalid.');}
    if(!s.values||typeof s.values!=='object'||Array.isArray(s.values))throw new Error('The saved fields are invalid.');for(const [k,v] of Object.entries(s.values)){const f=D.fields[k];if(!f)throw new Error('This file contains an unknown template field.');if(f.kind==='checkbox'){if(typeof v!=='boolean')throw new Error('The checkbox value is invalid.');}else{string(v);if(f.kind==='dropdown'&&k!=='control0'&&!f.options.includes(v)&&v!==f.value)throw new Error('The saved choice is not available in this template.');}}
    if(s.actions!==null){if(!Array.isArray(s.actions)||s.actions.length>100)throw new Error('Use up to 100 credit actions.');s.actions.forEach(r=>{if(!Array.isArray(r)||r.length!==4)throw new Error('Credit actions need four text fields.');r.forEach(string);});}
    if(!Array.isArray(s.inserts)||s.inserts.length>100||!Array.isArray(s.extraRows)||s.extraRows.length>200||!Array.isArray(s.hiddenRows))throw new Error('This working file has too many added items.');const used=new Set(),sourceReplacements=new Set();
    for(const x of s.inserts){const notes=['narrative','source'].filter(k=>Object.hasOwn(x,k));keys(x,['id','anchor','type','value',...notes,...(Object.hasOwn(x,'replaceSource')?['replaceSource']:[])],'Exhibit');if(Object.hasOwn(x,'replaceSource')){if(x.replaceSource!=='p1550'||x.anchor!=='p1549'||sourceReplacements.has(x.replaceSource))throw new Error('The credit-report replacement is invalid.');sourceReplacements.add(x.replaceSource);}notes.forEach(k=>string(x[k]));string(x.id);if(!/^[a-z0-9-]{1,60}$/i.test(x.id)||used.has(x.id)||!D.paragraphs[x.anchor]?.simple||!D.fields[x.anchor])throw new Error('An exhibit has an invalid location.');used.add(x.id);if(x.type==='table')rectangular(x.value);else if(x.type==='image'){keys(x.value,['data','width','height','widthPercent','caption'],'Image');const im=pngInfo(x.value.data);string(x.value.caption);if(im.width!==x.value.width||im.height!==x.value.height||!Number.isFinite(x.value.widthPercent)||x.value.widthPercent<20||x.value.widthPercent>100)throw new Error('Image size is invalid.');}else throw new Error('The saved exhibit type is unsupported.');}
    for(const r of s.extraRows){keys(r,r.sourceRow===undefined?['id','table','values']:['id','table','values','sourceRow','after'],'Added row');if(typeof r.id!=='string'||!/^[a-z0-9-]{1,60}$/i.test(r.id)||used.has(r.id)||D.rows[r.id]||r.table===D.anchors.actionsTable||!D.tables[r.table]||!Array.isArray(r.values))throw new Error('An added row is invalid.');if(r.sourceRow!==undefined&&(D.rows[r.sourceRow]?.table!==r.table||D.rows[r.after]?.table!==r.table))throw new Error('An added row has an invalid location.');const count=r.sourceRow===undefined?D.tables[r.table].widths.length:rowLayout(r.sourceRow).cells.length;if(r.values.length!==count)throw new Error('An added row is invalid.');r.values.forEach(string);used.add(r.id);}
    const hidden=new Set();for(const row of s.hiddenRows){const rec=D.rows[row]||s.extraRows.find(r=>r.id===row);if(!rec||rec.table===D.anchors.actionsTable||hidden.has(row)||row==='row0')throw new Error('A removed row is invalid.');hidden.add(row);}
    return s;
  }
  async function checkpoint(s){const frozen=validate(clone(s)),e={format:'HBF-CDS-TEMPLATE-WORKING-FILE',version:'2.0',document:frozen,sha256:await hash(frozen)};const str=JSON.stringify(e,null,2);if(bytes(str)>MAX)throw new Error('The working file exceeds 12 MB. Nothing was removed; download Word and reduce an exhibit before saving.');return str;}
  async function restore(str){
    if(typeof str!=='string'||bytes(str)>MAX)throw new Error('Choose a working file under 12 MB.');let e;try{e=JSON.parse(str,(k,v)=>{if(['__proto__','constructor','prototype'].includes(k))throw new Error('unsafe');return v;});}catch{throw new Error('The working file is invalid. Your current document is unchanged.');}
    if(e.format==='HBF-CDS-DOCUMENT-PROOF')throw new Error('This is the earlier five-page example. Open it in that saved example to keep its content; this full-template correction uses a new working-file format.');
    keys(e,['format','version','document','sha256'],'Working file');if(e.format!=='HBF-CDS-TEMPLATE-WORKING-FILE'||e.version!=='2.0')throw new Error('Open this working file in the Studio version that created it.');validate(e.document);if(e.sha256!==await hash(e.document))throw new Error('The working file has changed or is incomplete. Your current document is unchanged.');e.document.reviewedRevision=null;return e.document;
  }
  function apply(source,patches,offset=0){let last=source.length+offset;const sorted=patches.slice().sort((a,b)=>b.start-a.start||b.end-a.end);for(const p of sorted){if(p.start<offset||p.end>last||p.end<p.start)throw new Error('Overlapping edits could not be exported. Save your working file; nothing was removed.');source=source.slice(0,p.start-offset)+p.text+source.slice(p.end-offset);last=p.start;}return source;}
  const textRuns=s=>s.split(/([\n\t])/).map(v=>v==='\n'?'<w:br/>':v==='\t'?'<w:tab/>':'<w:t xml:space="preserve">'+esc(v)+'</w:t>').join('');
  function paragraphXML(pid,value){
    const rec=D.paragraphs[pid],src=D.xml.slice(rec.start,rec.end);
    if(value===rec.value)return src;
    // A w:tab in pPr/tabs defines a tab stop, not paragraph content. Older
    // metadata includes these as leaves; never replace formatting with text.
    const runs=[...src.matchAll(/<w:r(?:\s[^>]*)?>[\s\S]*?<\/w:r>/g)].map(m=>({start:rec.start+m.index,end:rec.start+m.index+m[0].length}));
    const leaves=rec.leaves.filter(l=>(l.value||l.type==='t')&&runs.some(r=>l.start>=r.start&&l.end<=r.end)),oldValue=leaves.map(l=>l.value).join('');
    if(value===oldValue)return src;
    if(!leaves.length){const run='<w:r>'+rec.runProperties+textRuns(value)+'</w:r>';if(src.endsWith('/>'))return src.slice(0,-2)+'>'+run+'</w:p>';return src.slice(0,rec.close-rec.start)+run+src.slice(rec.close-rec.start);}
    // Preserve every unaffected run's formatting through the single edited span.
    let prefix=0;while(prefix<oldValue.length&&prefix<value.length&&oldValue[prefix]===value[prefix])prefix++;let suffix=0;while(suffix<oldValue.length-prefix&&suffix<value.length-prefix&&oldValue[oldValue.length-1-suffix]===value[value.length-1-suffix])suffix++;
    const oldEnd=oldValue.length-suffix,newText=value.slice(prefix,value.length-suffix);let cursor=0,inserted=false;const patches=[];
    for(const l of leaves){const end=cursor+l.value.length;let next=l.value;if(end>=prefix&&cursor<=oldEnd){const before=l.value.slice(0,Math.max(0,prefix-cursor)),after=l.value.slice(Math.max(0,oldEnd-cursor));const addition=!inserted?newText:'';inserted=true;next=before+addition+after;}
      if(next!==l.value)patches.push({start:l.start,end:l.end,text:textRuns(next)});cursor=end;
    }
    return apply(src,patches,rec.start);
  }
  function controlXML(cid,value){
    const r=D.controls[cid],src=D.xml.slice(r.start,r.end);let patches=[];
    if(r.kind==='checkbox'){
      const n=r.checkedNode,tag=D.xml.slice(n.start,n.end).replace(/w14:val="[^"]*"/,'w14:val="'+(value?'1':'0')+'"');patches.push({start:n.start,end:n.end,text:tag});
      r.textNodes.forEach((n,i)=>patches.push({start:n.start,end:n.end,text:i===0?textRuns(value?r.checkedGlyph:r.uncheckedGlyph):''}));
    }else{
      if(r.textNodes.length)r.textNodes.forEach((n,i)=>patches.push({start:n.start,end:n.end,text:i===0?textRuns(value):''}));
      else if(r.paragraphs.length){const p=D.paragraphs[r.paragraphs[0]];patches.push({start:p.start,end:p.end,text:paragraphXML(p.id,value)});}
      else patches.push({start:r.content.close,end:r.content.close,text:'<w:r>'+textRuns(value)+'</w:r>'});
      let props=D.xml.slice(r.properties.start,r.properties.end).replace(/<w:showingPlcHdr\b[^>]*\/>/g,'');
      if(cid==='control0'&&!r.options.includes(value)){props=props.replace(/w:dropDownList/g,'w:comboBox');props=props.replace('</w:comboBox>','<w:listItem w:displayText="'+esc(value)+'" w:value="'+esc(value)+'"/></w:comboBox>');}
      patches.push({start:r.properties.start,end:r.properties.end,text:props});
    }
    return apply(src,patches,r.start).replace(/<w:rStyle w:val="PlaceholderText"\s*\/>/g,'');
  }
  function plainP(v,size=20,keep=false){return '<w:p><w:pPr>'+(keep?'<w:keepNext/>':'')+'<w:spacing w:after="80"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="'+size+'"/></w:rPr>'+textRuns(v)+'</w:r></w:p>';}
  function tableRow(values,widths,header=false,size=18){return '<w:tr>'+(header?'<w:trPr><w:tblHeader/></w:trPr>':'')+values.map((v,i)=>'<w:tc><w:tcPr><w:tcW w:w="'+widths[i]+'" w:type="dxa"/><w:tcMar><w:top w:w="50" w:type="dxa"/><w:bottom w:w="50" w:type="dxa"/><w:left w:w="65" w:type="dxa"/><w:right w:w="65" w:type="dxa"/></w:tcMar>'+(header?'<w:shd w:fill="F2F2F2"/>':'')+'</w:tcPr>'+plainP(v,size)+'</w:tc>').join('')+'</w:tr>';}
  function addedRowXML(r){
    if(!r.sourceRow)return tableRow(r.values,D.tables[r.table].widths);
    const source=D.rows[r.sourceRow],props=D.xml.slice(source.start,source.end).match(/<w:trPr\b[^>]*>[\s\S]*?<\/w:trPr>/)?.[0]||'';
    return '<w:tr>'+props.replace(/<w:tblHeader\b[^>]*\/>/g,'').replace(/w:hRule="exact"/g,'w:hRule="atLeast"')+rowLayout(r.sourceRow).cells.map((c,i)=>'<w:tc>'+c.properties+'<w:p>'+c.paragraphProperties+'<w:r>'+c.runProperties+textRuns(r.values[i])+'</w:r></w:p></w:tc>').join('')+'</w:tr>';
  }
  function tableXML(t,width=10800){const n=t.headers.length,ws=Array.from({length:n},(_,i)=>Math.floor(width/n)+(i<width%n?1:0)),size=n>9?12:n>6?16:18;return '<w:tbl><w:tblPr><w:tblW w:w="'+width+'" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders>'+['top','left','bottom','right','insideH','insideV'].map(k=>'<w:'+k+' w:val="single" w:sz="4" w:color="000000"/>').join('')+'</w:tblBorders></w:tblPr><w:tblGrid>'+ws.map(w=>'<w:gridCol w:w="'+w+'"/>').join('')+'</w:tblGrid>'+tableRow(t.headers,ws,true,size)+t.rows.map(r=>tableRow(r,ws,false,size)).join('')+'</w:tbl><w:p/>';}
  function imageXML(im,relationship,id,width=10800){const maxW=width/15*im.widthPercent/100,scale=Math.min(maxW/im.width,650/im.height),cx=Math.round(im.width*scale*9525),cy=Math.round(im.height*scale*9525);return '<w:p><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="'+cx+'" cy="'+cy+'"/><wp:docPr id="'+id+'" name="Inserted exhibit" descr="'+esc(im.caption)+'"/><a:graphic xmlns:a="'+ 'http://schemas.openxmlformats.org/drawingml/2006/main'+'"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="'+id+'" name="Inserted exhibit"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="'+relationship+'"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="'+cx+'" cy="'+cy+'"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>'+ (im.caption?plainP(im.caption,16):'');}
  async function exportBytes(input){
    const s=validate(clone(input)),zip=await g.JSZip.loadAsync(D.archive,{base64:true}),patches=[],replaced=[],touchedRows=new Set(),edits=new Map(Object.entries(s.values));
    const omitted=g.HBFSupport?.excludedRanges(s)||[],flow=g.HBFSupport?.flow(s)||{spacers:[],headings:[]};
    const compactEnd=(flow.headings.length>0||omitted.length>0||Object.keys(s.values).some(k=>D.paragraphs[k]?.table==='table35'))&&!Object.hasOwn(s.values,'p2312');if(compactEnd)edits.set('p2312',get(s,'p2312'));
    const sectionNums=new Map();if(omitted.length){let numbering=await zip.file('word/numbering.xml').async('string'),next=Math.max(...[...numbering.matchAll(/<w:num\b[^>]*w:numId="(\d+)"/g)].map(m=>Number(m[1])))+1;
      for(const [i,section] of g.HBFSupport.sections.entries()){if(!g.HBFSupport.included(s,section.id))continue;const p=D.paragraphs[section.heading],num=D.xml.slice(p.start,p.end).match(/<w:numId w:val="(\d+)"/)?.[1];if(!num)continue;const original=numbering.match(new RegExp('<w:num w:numId="'+num+'"[^>]*>[\\s\\S]*?<\\/w:num>'))?.[0],abstract=original?.match(/<w:abstractNumId w:val="(\d+)"/)?.[1];if(!abstract)throw new Error('The supporting section numbering could not be preserved.');const id=next++;sectionNums.set(section.heading,id);edits.set(section.heading,get(s,section.heading));numbering=numbering.replace('</w:numbering>','<w:num w:numId="'+id+'"><w:abstractNumId w:val="'+abstract+'"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="'+(i+1)+'"/></w:lvlOverride></w:num></w:numbering>');}
      zip.file('word/numbering.xml',numbering);
    }
    const spacerRanges=[];for(const p of flow.spacers){const prior=spacerRanges.at(-1);if(prior?.end===p.start)prior.end=p.end;else spacerRanges.push({start:p.start,end:p.end});}
    for(const p of spacerRanges){patches.push({...p,text:''});replaced.push(p);}
    for(const id of flow.headings)edits.set(id,get(s,id));
    for(const section of omitted){patches.push({start:section.start,end:section.end,text:''});replaced.push(section);edits.set(section.list,(Object.hasOwn(s.values,section.list)?get(s,section.list):section.label)+' — Not included');}
    for(const x of s.inserts.filter(x=>x.replaceSource)){const rec=D.paragraphs[x.replaceSource];patches.push({start:rec.start,end:rec.end,text:''});replaced.push(rec);}
    if(s.actions){edits.set(D.anchors.request,get(s,D.anchors.request));const t=D.tables[D.anchors.actionsTable],header=D.rows[t.rows[0]],prototype=D.rows[t.rows[1]];const start=D.xml.slice(t.start,header.start),finish=D.xml.slice(D.rows[t.rows.at(-1)].end,t.end);const headerEdits=Object.entries(s.values).filter(([k])=>D.paragraphs[k]&&D.paragraphs[k].start>=header.start&&D.paragraphs[k].end<=header.end).map(([k,v])=>({start:D.paragraphs[k].start,end:D.paragraphs[k].end,text:paragraphXML(k,v)}));let content=start+apply(D.xml.slice(header.start,header.end),headerEdits,header.start);for(let i=0;i<s.actions.length;i++){const vals=s.actions[i].map((v,j)=>j===0?`${i+1}. ${v}`:v),ps=[];prototype.cells.forEach((cell,j)=>{const p=D.paragraphs[cell[0]];ps.push({start:p.start,end:p.end,text:paragraphXML(p.id,vals[j])});});content+=apply(D.xml.slice(prototype.start,prototype.end),ps,prototype.start).replace(/w:hRule="exact"/g,'w:hRule="atLeast"').replace(/ w14:(paraId|textId)="[^"]*"/g,'');}patches.push({start:t.start,end:t.end,text:content+finish});replaced.push(t);}
    for(const rid of s.hiddenRows.filter(id=>D.rows[id]).sort((a,b)=>D.rows[a].start-D.rows[b].start)){const r=D.rows[rid];if(replaced.some(x=>r.start>=x.start&&r.end<=x.end))continue;patches.push({start:r.start,end:r.end,text:''});replaced.push(r);}
    for(const [bid,box] of Object.entries(D.boxes)){
      if(!box.paragraphs.some(p=>edits.has(p))&&!s.inserts.some(x=>box.paragraphs.includes(x.anchor)))continue;
      const contents=box.paragraphs.map(p=>paragraphXML(p,get(s,p)??D.paragraphs[p].value)).join('');
      const content='<w:tbl><w:tblPr><w:tblW w:w="10800" w:type="dxa"/><w:tblBorders>'+['top','left','bottom','right'].map(k=>'<w:'+k+' w:val="single" w:sz="6" w:color="000000"/>').join('')+'</w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="10800"/></w:tblGrid><w:tr><w:trPr><w:trHeight w:val="1140" w:hRule="atLeast"/></w:trPr><w:tc><w:tcPr><w:tcW w:w="10800" w:type="dxa"/></w:tcPr>'+contents+'</w:tc></w:tr></w:tbl><w:p/>'+(box.pageBreak?'<w:p><w:r><w:br w:type="page"/></w:r></w:p>':'');
      patches.push({start:box.start,end:box.end,text:content});replaced.push(box);
    }
    for(const [key,value] of edits){const field=D.fields[key],rec=D.paragraphs[key]||D.controls[key]||field.range;if(replaced.some(r=>rec.start>=r.start&&rec.end<=r.end))continue;let text;
      if(field.kind==='paragraph'){text=paragraphXML(key,value);if(compactEnd&&key==='p2312')text=text.replace(/<w:pPr>[\s\S]*?<\/w:pPr>/,'<w:pPr><w:spacing w:before="0" w:after="0" w:line="20" w:lineRule="exact"/><w:rPr><w:sz w:val="2"/></w:rPr></w:pPr>');if(sectionNums.has(key))text=text.replace(/<w:numId w:val="\d+"\/>/,'<w:numId w:val="'+sectionNums.get(key)+'"/>');if(flow.headings.includes(key)&&!/<w:pageBreakBefore\b/.test(text)){if(text.includes('<w:pPr>'))text=text.replace('<w:pPr>','<w:pPr><w:pageBreakBefore/>');else text=text.replace(/^(<w:p(?:\s[^>]*)?>)/,'$1<w:pPr><w:pageBreakBefore/></w:pPr>');}if(rec.row)touchedRows.add(rec.row);}
      else if(field.kind==='text'){text=textRuns(value);}
      else{text=controlXML(key,value);if(rec.parentRow)touchedRows.add(rec.parentRow);for(const p of rec.paragraphs||[])if(D.paragraphs[p].row)touchedRows.add(D.paragraphs[p].row);}
      patches.push({start:rec.start,end:rec.end,text});
    }
    for(const rid of touchedRows){const r=D.rows[rid],h=r.height;if(h&&!replaced.some(x=>h.start>=x.start&&h.end<=x.end))patches.push({start:h.start,end:h.end,text:D.xml.slice(h.start,h.end).replace(/w:hRule="exact"/g,'w:hRule="atLeast"')});}
    const addedByPosition=new Map();for(const r of s.extraRows){if(s.hiddenRows.includes(r.id))continue;const t=D.tables[r.table];if(replaced.some(x=>t.start>=x.start&&t.end<=x.end))continue;const pos=r.after?D.rows[r.after].end:t.close;addedByPosition.set(pos,(addedByPosition.get(pos)||'')+addedRowXML(r));}
    for(const [pos,text] of addedByPosition)patches.push({start:pos,end:pos,text});
    const byAnchor=new Map();let imageCount=0;let relationships=await zip.file('word/_rels/document.xml.rels').async('string');
    for(const x of s.inserts){const p=D.paragraphs[x.anchor];if(omitted.some(r=>p.start>=r.start&&p.end<=r.end))continue;if(replaced.some(r=>p.start>=r.start&&p.end<=r.end))throw new Error('An exhibit is inside a removed row or a floating narrative box. Restore the row or place the exhibit after a regular paragraph.');let xml;if(x.type==='table')xml=tableXML(x.value,p.availableWidth);else{imageCount++;const rid='rIdHBFExhibit'+imageCount,target='media/hbf-exhibit-'+imageCount+'.png';zip.file('word/'+target,pngInfo(x.value.data).data);relationships=relationships.replace('</Relationships>','<Relationship Id="'+rid+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="'+target+'"/></Relationships>');xml=imageXML(x.value,rid,900000+imageCount,p.availableWidth);}
      if(x.type==='image'&&(x.value.caption||x.source))xml=xml.replace('<w:p>','<w:p><w:pPr><w:keepNext/></w:pPr>');
      xml=(x.narrative?plainP(x.narrative,20,true):'')+xml+(x.source?plainP(x.source,16):'');
      byAnchor.set(p.end,(byAnchor.get(p.end)||'')+xml);
    }
    for(const [pos,xml] of byAnchor)patches.push({start:pos,end:pos,text:xml});
    zip.file('word/document.xml',apply(D.xml,patches));if(imageCount)zip.file('word/_rels/document.xml.rels',relationships);
    if(Object.hasOwn(s.values,'p19')){const footer=await zip.file('word/footer1.xml').async('string');zip.file('word/footer1.xml',footer.replace(/<w:t([^>]*)>Borrower Name<\/w:t>/,'<w:t$1>'+esc(get(s,'p19'))+'</w:t>'));}
    return zip.generateAsync({type:'uint8array',compression:'DEFLATE'});
  }
  g.HBFTemplate={D,MAX,checkboxGroups,ratingLinks,ratingParts,relatedFields,clone,uid,create,get,set,actions,setAction,rowLayout,addRow,hideRow,restoreRow,addedRowXML,changed,validate,hash,checkpoint,restore,parseTable,pngInfo,exportBytes,paragraphXML,controlXML,esc};
})(globalThis);
