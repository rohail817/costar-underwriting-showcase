(function(g){
  'use strict';
  const M=g.HBFProofModel, d=g.docx;
  const run=(text,opts={})=>new d.TextRun({text,font:'Arial',size:20,color:'000000',...opts});
  const para=(text,opts={})=>new d.Paragraph({children:[run(text)],spacing:{after:120,line:260},...opts});
  const prose=text=>text.split('\n').map(line=>para(line));
  const heading=text=>new d.Paragraph({children:[run(text,{bold:true,size:23})],spacing:{before:260,after:130},keepNext:true,border:{bottom:{style:d.BorderStyle.SINGLE,color:'000000',size:6,space:5}}});
  const sub=text=>new d.Paragraph({children:[run(text,{bold:true})],spacing:{before:180,after:75},keepNext:true});
  function widths(total,n){return Array.from({length:n},(_,i)=>Math.floor(total/n)+(i<total%n?1:0));}
  function table(headers, rows, cols, options={}) {
    const cell=(text,i,header)=>new d.TableCell({width:{size:cols[i],type:d.WidthType.DXA},margins:{top:80,bottom:80,left:75,right:75},verticalAlign:d.VerticalAlign.TOP,
      children:text.split('\n').map(line=>new d.Paragraph({children:[run(line,{size:options.small?16:19,bold:header})],spacing:{after:0,line:options.small?200:250}})),...(header?{shading:{fill:'F2F2F2'}}:{})});
    return new d.Table({width:{size:cols.reduce((a,b)=>a+b,0),type:d.WidthType.DXA},columnWidths:cols,layout:d.TableLayoutType.FIXED,
      borders:Object.fromEntries(['top','bottom','left','right','insideHorizontal','insideVertical'].map(k=>[k,{style:d.BorderStyle.SINGLE,size:4,color:'000000'}])),
      rows:[new d.TableRow({tableHeader:true,cantSplit:true,children:headers.map((h,i)=>cell(h,i,true))}),...rows.map(r=>new d.TableRow({...(options.signature?{height:{value:950,rule:d.HeightRule.ATLEAST}}:{}),children:r.map((v,i)=>cell(v,i,false))}))]});
  }
  function image(data,maxWidth,maxHeight){const info=M.pngInfo(data),scale=Math.min(maxWidth/info.width,maxHeight/info.height);return new d.Paragraph({children:[new d.ImageRun({data:info.data,type:'png',transformation:{width:Math.round(info.width*scale),height:Math.round(info.height*scale)}})],spacing:{before:100,after:130}});}
  function section(children,landscape,s){
    const header=()=>new d.Header({children:[para('HOME BUILDER FINANCE',{children:[run('HOME BUILDER FINANCE',{size:16,bold:true})],spacing:{after:0}})]});
    const footer=()=>new d.Footer({children:[new d.Paragraph({alignment:d.AlignmentType.RIGHT,children:[run((s.sample?'SYNTHETIC EXAMPLE  •  ':'')+'WORKING DRAFT  •  ',{size:15}),new d.TextRun({children:[d.PageNumber.CURRENT],size:15,font:'Arial'})]})]});
    return {properties:{type:d.SectionType.NEXT_PAGE,titlePage:false,page:{margin:{top:850,bottom:850,left:720,right:720,header:360,footer:360},size:{width:12240,height:15840,orientation:landscape?d.PageOrientation.LANDSCAPE:d.PageOrientation.PORTRAIT}}},
      headers:{default:header(),first:header(),even:header()},
      footers:{default:footer(),first:footer(),even:footer()},children};
  }
  async function documentFor(input){
    const s=M.validate(M.clone(input)), f=s.fields, digest=await M.hash(s), w=10800;
    const actionRows=s.actions.map((a,i)=>[`${i+1}. ${a.action}`,a.from,a.to,a.difference]);
    const request=[image(g.HBFProofAssets.logo,160,65),new d.Paragraph({children:[run(f.title,{bold:true,size:32})],spacing:{after:200}})];
    if(s.sample) request.push(para('SYNTHETIC EXAMPLE — All borrower names and figures are fictional.',{children:[run('SYNTHETIC EXAMPLE — All borrower names and figures are fictional.',{size:18,italics:true})]}));
    request.push(table(['Borrower','Relationship'],[[f.borrower,f.relationship]],[5400,5400]),para(''),table(['Decision Date','Loan number','Request type'],[[f.decisionDate,f.loanNumber,s.transactionType]],[3600,3600,3600]),para(''),table(['Relationship Manager','Portfolio Manager'],[[f.rm,f.pm]],[5400,5400]),heading('REQUEST'),table(['Credit action','From','To','Difference'],actionRows,[4800,2000,2000,2000]));
    const exposure=[heading('EXPOSURE'),...prose(f.exposureNarrative),table(M.EXPOSURE_HEADERS,s.exposure.map(r=>r.cells),[1550,1100,1250,1250,1250,1250,1100,500,1250,800,800,1150,1150],{small:true})];
    const transaction=[heading('TRANSACTION NARRATIVE & RATIONALE'),...prose(f.transactionNarrative),table(['Credit action','From','To','Difference'],actionRows,[4800,2000,2000,2000]),sub('Primary Source of Repayment (PSOR)'),...prose(f.psor),sub('Secondary Source of Repayment (SSOR)'),...prose(f.ssor),sub('Tertiary Source of Repayment (TSOR)'),...prose(f.tsor)];
    const sections=[section(request,false,s),section(exposure,true,s),section(transaction,false,s)];
    if(s.support.included){
      const wide=s.support.table.headers.length>7, tw=wide?14400:w;
      const supporting=[heading('SUPPORTING ANALYSIS'),...prose(f.supportNarrative),table(s.support.table.headers,s.support.table.rows,widths(tw,s.support.table.headers.length),{small:wide})];
      if(s.support.image){supporting.push(image(s.support.image.data,(wide?960:720)*s.support.image.widthPercent/100,wide?450:650));if(s.support.image.alt)supporting.push(para(s.support.image.alt,{children:[run(s.support.image.alt,{size:17,italics:true})]}));}
      sections.push(section(supporting,wide,s));
    }
    const closing=[heading('ATTESTATION'),...s.attestation.flatMap(prose),heading('FOLLOW APPROPRIATE CREDIT AUTHORITIES POLICY'),table(['Title','Name','Signature'],s.signatures.map(r=>[r.title,r.name,r.signature]),[3600,3600,3600],{signature:true}),heading('CrDD SUMMARY/CONCLUSION'),...prose(f.conclusion)];
    sections.push(section(closing,false,s));
    return new d.Document({creator:'HBF Credit Decision Studio',title:f.title,subject:'Representative document editing example — working draft',description:'Step 2 representative slice; not the complete bank template. Snapshot SHA-256: '+digest,
      styles:{default:{document:{run:{font:'Arial',size:20,color:'000000'},paragraph:{spacing:{after:120,line:260}}}}},sections});
  }
  g.HBFProofExport={documentFor,blob:async s=>d.Packer.toBlob(await documentFor(s)),buffer:async s=>d.Packer.toBuffer(await documentFor(s))};
})(globalThis);
