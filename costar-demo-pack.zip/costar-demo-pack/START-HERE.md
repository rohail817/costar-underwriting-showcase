# CoStar underwriting demo pack

1. Unzip the whole folder. Keep its files and folders together.
2. With Node.js 22 or newer installed, open a terminal in this folder and run:

   node start.mjs

3. Open http://localhost:8765 in a current browser.

Python alternative: open a terminal in the `site` folder and run `python3 -m http.server 8765 --bind 127.0.0.1` (Windows: `py -m http.server 8765 --bind 127.0.0.1`). Then open the same address.

No package installation, sign-in, API keys or outside data connection is required. Simply double-clicking index.html is insufficient because browser modules and local sample resources need HTTP. Closing the terminal stops the server.

Start with Bridge Credit Intelligence. The portfolio overview links to all five working demos and the HBF Intel project brief. Use the included fictional examples. The local pack sends no activity events and has no connected borrower database.

CoStar branding is illustrative. Independent work by Rohail Abid; no affiliation or endorsement is implied.
